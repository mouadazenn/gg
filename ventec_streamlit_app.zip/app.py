import streamlit as st
import streamlit.components.v1 as components

# Page configuration
st.set_page_config(
    page_title="Ventec Industries – Tableau de Bord KPI",
    page_icon="📊",
    layout="wide",
    initial_sidebar_state="collapsed"
)

# Hide Streamlit default UI to keep the original dashboard format unchanged
st.markdown("""
<style>
#MainMenu {visibility: hidden;}
footer {visibility: hidden;}
header {visibility: hidden;}
.block-container {padding: 0 !important; max-width: 100% !important;}
[data-testid="stAppViewContainer"] {padding: 0 !important;}
[data-testid="stToolbar"] {visibility: hidden; height: 0%; position: fixed;}
iframe {display: block; width: 100%;}
</style>
""", unsafe_allow_html=True)

HTML_CODE = """<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Ventec Industries – Tableau de Bord KPI</title>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=Plus+Jakarta+Sans:wght@500;600;700;800;900&display=swap" rel="stylesheet">
<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.4.1/chart.umd.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/xlsx-js-style@1.2.0/dist/xlsx.bundle.js"></script>
<style>
:root {
  --navy:#0f203a;--blue:#2e5596;--mid-blue:#2e5596;--accent:#2e5596;--accent2:#3a68b5;
  --light-blue:#3a68b5;--pale:#f0f4fb;--white:#ffffff;--gray-light:#f8fafc;
  --table-header-bg:#2e5596;--table-header-color:#ffffff;--table-row-alt:#f4f7fd;
  --table-border:#cad7ef;--card-bg:#ffffff;
  --gray:#64748b;--border:#cad7ef;--green:#059669;--green-bg:#ecfdf5;
  --yellow:#d97706;--yellow-bg:#fffbeb;--red:#dc2626;--red-bg:#fef2f2;
  --text-dark:#0f203a;--text-mid:#1f2f53;--shadow:0 2px 12px rgba(14,32,58,0.10);
  --shadow-lg:0 6px 28px rgba(14,32,58,0.16);
}
*{box-sizing:border-box;margin:0;padding:0}
html{scroll-behavior:smooth}
body{font-family:'Inter',sans-serif;background:#f4f7fd;color:var(--text-dark);min-height:100vh;font-size:14px}

/* ===== LOGIN ===== */
#login-screen{position:fixed;inset:0;background:#ffffff;display:flex;align-items:stretch;justify-content:center;z-index:999}
.login-left-panel{flex:1;background:linear-gradient(160deg,#0f203a 0%,#1a3a6e 40%,#2e5596 100%);display:flex;flex-direction:column;align-items:center;justify-content:center;padding:60px 48px;position:relative;overflow:hidden;max-width:480px}
.login-left-panel::before{content:'';position:absolute;top:-80px;right:-80px;width:320px;height:320px;border-radius:50%;background:rgba(0,198,255,0.07)}
.login-left-panel::after{content:'';position:absolute;bottom:-60px;left:-40px;width:260px;height:260px;border-radius:50%;background:rgba(34,113,232,0.09)}
.login-left-title{font-family:'Plus Jakarta Sans',sans-serif;font-weight:900;font-size:32px;color:#ffffff;line-height:1.1;margin-bottom:12px;position:relative;z-index:1;text-align:center}
.login-left-title span{color:#7eb8f7}
.login-left-sub{font-size:13px;color:rgba(255,255,255,0.88);line-height:1.8;text-align:center;position:relative;z-index:1;max-width:320px}
.login-left-badges{display:flex;flex-direction:column;gap:12px;margin-top:36px;position:relative;z-index:1;width:100%}
.login-left-badge{background:rgba(255,255,255,0.10);border:1px solid rgba(255,255,255,0.22);border-radius:12px;padding:13px 18px;display:flex;align-items:center;gap:12px;font-size:12.5px;color:#ffffff}
.login-left-badge-icon{font-size:20px;flex-shrink:0}
.login-right-panel{flex:1;display:flex;align-items:center;justify-content:center;padding:48px;background:#ffffff;max-width:520px}
.login-box{width:100%;max-width:380px;text-align:left}
.login-logo-wrap{display:flex;align-items:center;gap:12px;margin-bottom:28px}
.login-logo-img{width:48px;height:48px;border-radius:10px;background:white;padding:6px;object-fit:contain;flex-shrink:0}
.login-brand{font-family:'Plus Jakarta Sans',sans-serif;font-weight:900;font-size:17px;color:var(--navy);letter-spacing:0.5px;line-height:1.1}
.login-brand span{display:block;font-size:10px;font-weight:500;color:var(--gray);letter-spacing:2px;text-transform:uppercase;margin-top:3px}
.login-welcome{font-family:'Plus Jakarta Sans',sans-serif;font-size:22px;font-weight:800;color:var(--navy);margin-bottom:6px}
.login-desc{color:var(--gray);font-size:13px;margin-bottom:28px;line-height:1.6}
.login-field-label{font-size:11.5px;font-weight:700;color:var(--text-mid);text-transform:uppercase;letter-spacing:1px;margin-bottom:6px;display:block}
.login-box select,.login-box input[type=password],.login-box input[type=text]{width:100%;padding:12px 14px;border:1.5px solid var(--border);border-radius:10px;background:#f9fbff;color:var(--text-dark);font-size:13.5px;margin-bottom:16px;outline:none;transition:border 0.2s,box-shadow 0.2s;font-family:'Inter',sans-serif}
.login-box select:focus,.login-box input:focus{border-color:var(--accent);box-shadow:0 0 0 3px rgba(26,109,212,0.1)}
.login-box select option{background:white;color:var(--text-dark)}
.login-pass-wrap{position:relative;margin-bottom:16px}
.login-pass-wrap input{width:100%;padding:12px 44px 12px 14px;border:1.5px solid var(--border);border-radius:10px;background:#f9fbff;color:var(--text-dark);font-size:13.5px;outline:none;transition:border 0.2s,box-shadow 0.2s;font-family:'Inter',sans-serif;margin-bottom:0}
.login-pass-wrap input:focus{border-color:var(--accent);box-shadow:0 0 0 3px rgba(26,109,212,0.1)}
.login-eye-btn{position:absolute;right:13px;top:50%;transform:translateY(-50%);background:none;border:1px solid var(--border);border-radius:5px;cursor:pointer;color:var(--gray);font-size:10px;font-weight:600;padding:3px 7px;line-height:1;transition:all 0.2s;font-family:"Inter",sans-serif;letter-spacing:0.3px}
.login-eye-btn:hover{color:var(--accent)}
.login-btn{width:100%;padding:13px;background:linear-gradient(135deg,#0f203a,#2e5596);border:none;border-radius:10px;color:white;font-weight:700;font-size:14px;cursor:pointer;letter-spacing:0.5px;font-family:'Plus Jakarta Sans',sans-serif;transition:opacity 0.2s,transform 0.15s;margin-top:4px}
.login-btn:hover{opacity:0.9;transform:translateY(-1px)}
.login-err{color:var(--red);font-size:12px;margin-bottom:12px;display:none;background:var(--red-bg);padding:8px 12px;border-radius:8px;font-weight:500}
.login-hint{display:none}
@media(max-width:700px){.login-left-panel{display:none}.login-right-panel{padding:28px}}

/* ===== SIDEBAR ===== */
#sidebar{position:fixed;top:0;left:0;width:230px;height:100vh;background:#ffffff;border-right:2px solid #cad7ef;display:flex;flex-direction:column;z-index:100;overflow-y:auto}
.sidebar-logo{padding:22px 20px 18px;border-bottom:1px solid #cad7ef;display:flex;align-items:center;gap:10px}
.sidebar-logo img{width:36px;height:36px;border-radius:8px;background:white;padding:4px;object-fit:contain;flex-shrink:0}
.sidebar-logo-text{font-family:'Plus Jakarta Sans',sans-serif;font-weight:800;font-size:12.5px;color:var(--navy);line-height:1.2;letter-spacing:0.3px}
.sidebar-logo-text span{color:var(--gray);font-size:9.5px;font-weight:500;display:block;letter-spacing:1px;margin-top:2px}
nav a{display:flex;align-items:center;gap:0;padding:9px 20px;color:#1f2f53;text-decoration:none;font-size:12.5px;font-weight:500;border-left:3px solid transparent;transition:all 0.18s;cursor:pointer;letter-spacing:0.1px}
nav a:hover{background:#f4f7fb;color:var(--navy);border-left-color:#3a68b5}
nav a.active{background:#e8f0fb;color:#0f203a;border-left-color:#2e5596;font-weight:700}
nav a .nav-icon{display:none}
.nav-section{padding:18px 20px 5px;font-size:9px;font-weight:700;letter-spacing:2px;color:#b0bdd4;text-transform:uppercase}

/* ===== MAIN ===== */
#main{margin-left:230px;min-height:100vh;background:#f4f7fd}
.topbar{background:#ffffff;padding:13px 28px;display:flex;align-items:center;justify-content:space-between;border-bottom:2px solid #cad7ef;position:sticky;top:0;z-index:50;box-shadow:0 2px 8px rgba(37,99,235,0.08)}
.topbar-title{font-family:'Plus Jakarta Sans',sans-serif;font-size:16px;font-weight:700;color:#0f203a;letter-spacing:0.2px}
.topbar-user{display:flex;align-items:center;gap:10px;font-size:13px;color:var(--text-mid)}
.user-badge{background:#eff5ff;color:var(--accent);padding:5px 13px;border-radius:20px;font-size:11.5px;font-weight:600;font-family:'Plus Jakarta Sans',sans-serif;border:1px solid #d0e2ff}
.page{display:none;padding:24px 28px;background:#f4f7fd;min-height:100vh}
.page.active{display:block}
.section-head{display:flex;align-items:center;gap:14px;margin-bottom:22px}
.section-head h2{font-family:'Plus Jakarta Sans',sans-serif;font-size:20px;font-weight:800;color:var(--navy)}
.section-line{flex:1;height:1.5px;background:linear-gradient(90deg,#d0dff0,transparent)}

/* ===== ACCUEIL CARD ===== */
.accueil-hero{background:linear-gradient(135deg,#0f203a 0%,#1e3c7a 60%,#2e5596 100%);border-radius:20px;padding:44px 48px;color:#ffffff;margin-bottom:28px;position:relative;overflow:hidden;box-shadow:var(--shadow-lg)}
.accueil-hero::before{content:'';position:absolute;top:-60px;right:-60px;width:280px;height:280px;border-radius:50%;background:rgba(0,198,255,0.06)}
.accueil-hero::after{content:'';position:absolute;bottom:-40px;left:40%;width:200px;height:200px;border-radius:50%;background:rgba(34,113,232,0.08)}
.accueil-hero-top{display:flex;align-items:center;gap:24px;margin-bottom:24px}
.accueil-hero img{width:72px;height:72px;border-radius:14px;background:white;padding:8px;object-fit:contain;flex-shrink:0}
.accueil-hero h1{font-family:'Plus Jakarta Sans',sans-serif;font-size:28px;font-weight:900;letter-spacing:0.5px;line-height:1.1;color:#ffffff}
.accueil-hero h1 span{color:#7eb8f7}
.accueil-hero .subtitle{font-size:14px;color:rgba(255,255,255,0.8);opacity:1;font-weight:400;display:block;margin-top:4px;letter-spacing:1px}
.accueil-intro{font-size:14.5px;line-height:1.8;opacity:1;color:rgba(255,255,255,0.92);max-width:860px;margin-bottom:10px}
.accueil-intro strong{color:#ffffff}
.accueil-badges{display:flex;gap:14px;flex-wrap:wrap;margin-top:18px}
.accueil-badge{background:rgba(255,255,255,0.12);border:1px solid rgba(255,255,255,0.22);border-radius:10px;padding:12px 18px;font-size:13px;display:flex;align-items:center;gap:8px;font-weight:500;color:#ffffff}

/* ===== POLITIQUE ===== */
.pol-doc{background:#ffffff;border-radius:20px;padding:44px;box-shadow:0 2px 12px rgba(37,99,235,0.08);border:1px solid #cad7ef;max-width:900px;margin:0 auto}
.pol-doc-header{display:flex;align-items:flex-start;gap:24px;margin-bottom:32px;padding-bottom:28px;border-bottom:2px solid #f0f4ff}
.pol-doc-header img{width:70px;height:70px;border-radius:12px;background:#ffffff;border:2px solid #2e5596;padding:6px;object-fit:contain;flex-shrink:0}
.pol-doc-title{font-family:'Plus Jakarta Sans',sans-serif}
.pol-doc-title h1{font-size:22px;font-weight:800;color:var(--navy);line-height:1.2;margin-bottom:6px}
.pol-doc-title .ver{display:inline-block;background:var(--accent);color:white;padding:3px 12px;border-radius:20px;font-size:11px;font-weight:600;letter-spacing:0.5px}
.pol-doc p{font-size:14.5px;line-height:1.85;color:#334155;margin-bottom:16px}
.pol-doc p strong{color:var(--navy)}
.pol-section-title{font-family:'Plus Jakarta Sans',sans-serif;font-size:13px;font-weight:700;color:var(--accent);text-transform:uppercase;letter-spacing:2px;margin:28px 0 16px}
.pol-list{list-style:none;padding:0}
.pol-list li{display:flex;align-items:flex-start;gap:10px;padding:10px 0;border-bottom:1px solid var(--border);font-size:14px;color:#334155;line-height:1.6}
.pol-list li:last-child{border:none}
.pol-list li::before{content:"▸";color:var(--accent);font-size:12px;margin-top:3px;flex-shrink:0}
.pol-engagements-grid{display:grid;grid-template-columns:1fr 1fr;gap:14px;margin:20px 0}
.pol-eng{background:#ffffff;border-radius:12px;padding:16px;font-size:13.5px;display:flex;gap:12px;align-items:flex-start;border-left:3px solid var(--accent)}
.pol-eng-icon{font-size:20px;flex-shrink:0}
.pol-eng strong{display:block;font-weight:700;color:var(--navy);margin-bottom:4px;font-size:13px}
.pol-sig-row{display:flex;gap:16px;margin-top:32px;padding-top:24px;border-top:2px solid #f0f4ff;flex-wrap:wrap}
.sig-item{background:#ffffff;border:1px solid #2e5596;border-radius:10px;padding:14px 22px;text-align:center;flex:1;min-width:150px}
.sig-item strong{display:block;color:#ffffff;background:#2e5596;font-size:11px;font-weight:700;margin-bottom:8px;letter-spacing:1px;padding:6px 10px;border-radius:6px 6px 0 0;margin:-14px -22px 10px -22px;text-align:center;text-transform:uppercase}
.sig-item span{color:#1f2f53;font-size:13px;font-weight:600;display:block;margin-bottom:4px}
.sig-item .sig-zone{display:block;height:48px;border-top:1px dashed #cad7ef;margin-top:12px;padding-top:8px;font-size:11px;color:#94a3b8;font-style:italic;text-align:center;letter-spacing:0.3px}

/* ===== CARTOGRAPHIE ===== */
.carto-wrapper{background:white;border-radius:20px;padding:32px;box-shadow:var(--shadow);overflow-x:auto}
.carto-doc-header{display:flex;align-items:center;justify-content:space-between;margin-bottom:28px;flex-wrap:wrap;gap:12px}
.carto-doc-title{font-family:'Plus Jakarta Sans',sans-serif;font-size:19px;font-weight:800;color:var(--navy)}
.carto-doc-title span{display:block;font-size:11px;font-weight:500;color:var(--gray);letter-spacing:1.5px;text-transform:uppercase;margin-top:2px}
.carto-ver{background:var(--accent);color:white;padding:5px 14px;border-radius:20px;font-size:11.5px;font-weight:600}
.carto-diagram{min-width:700px;border:2px solid #f0f4ff;border-radius:16px;overflow:hidden}
.carto-flow{display:flex;align-items:stretch;min-height:420px}
.carto-io{width:100px;background:linear-gradient(180deg,#ffffff 0%,#2e5596 100%);color:#1f2f53;display:flex;align-items:center;justify-content:center;text-align:center;font-size:12px;font-weight:600;padding:12px;writing-mode:vertical-rl;transform:rotate(180deg);letter-spacing:1px;flex-shrink:0}
.carto-io.right{transform:rotate(0deg);background:linear-gradient(180deg,#00b67a 0%,#007a50 100%)}
.carto-middle{flex:1;display:flex;flex-direction:column;border-left:2px solid var(--border);border-right:2px solid var(--border)}
.carto-band{display:flex;align-items:stretch;border-bottom:1.5px solid var(--border)}
.carto-band:last-child{border-bottom:none}
.carto-band-label{width:120px;flex-shrink:0;background:linear-gradient(180deg,#f0f4ff,#ffffff);color:#1f2f53;display:flex;align-items:center;justify-content:center;text-align:center;font-size:11px;font-weight:700;padding:10px 8px;letter-spacing:0.5px;line-height:1.4;border-right:1.5px solid #2e5596}
.carto-band.manage .carto-band-label{background:#0f203a;color:#ffffff}
.carto-band.realise .carto-band-label{background:#ffffff;color:#1f2f53}
.carto-band.support .carto-band-label{background:#2e5596;color:#ffffff}
.carto-band-content{flex:1;display:flex;align-items:center;gap:14px;padding:14px 18px;background:#ffffff;flex-wrap:wrap}
.proc-pill{background:white;border:2px solid #2e5596;border-radius:10px;padding:10px 16px;text-align:center;font-size:11.5px;cursor:pointer;transition:all 0.2s;min-width:110px;box-shadow:0 2px 8px rgba(34,113,232,0.1)}
.proc-pill:hover{background:var(--accent);color:white;border-color:var(--accent);transform:translateY(-2px);box-shadow:0 6px 20px rgba(34,113,232,0.3)}
.proc-pill .code{font-family:'Plus Jakarta Sans',sans-serif;font-weight:800;font-size:12px;color:var(--accent);margin-bottom:3px}
.proc-pill:hover .code{color:white}
.proc-pill .pname{font-size:11px;color:var(--text-mid);font-weight:500}
.proc-pill:hover .pname{color:rgba(255,255,255,0.85)}
.arrow-row{display:flex;align-items:center;justify-content:center;padding:6px 0;background:white;font-size:12px;color:var(--gray);font-weight:500;border-bottom:1px dashed var(--border);gap:8px}

/* ===== OBJECTIFS ===== */
.axe-card{background:#ffffff;border-radius:16px;margin-bottom:22px;overflow:hidden;box-shadow:0 2px 10px rgba(37,99,235,0.08);border:1px solid #cad7ef}
.axe-head{display:flex;align-items:center;gap:16px;padding:20px 24px;background:linear-gradient(135deg,#2e5596 0%,#1a3a6e 50%,#0f203a 100%);cursor:pointer;user-select:none;border-bottom:2px solid #0f203a}
.axe-num{width:44px;height:44px;background:#2e5596;border-radius:12px;display:flex;align-items:center;justify-content:center;font-family:'Plus Jakarta Sans',sans-serif;font-weight:900;font-size:18px;color:white;flex-shrink:0;box-shadow:0 2px 8px rgba(37,99,235,0.3)}
.axe-head h3{font-family:'Plus Jakarta Sans',sans-serif;font-size:15px;font-weight:700;color:#ffffff;flex:1}
.axe-toggle{color:rgba(255,255,255,0.8);font-size:18px;transition:transform 0.3s}
.axe-body{overflow:hidden;transition:all 0.3s}
.axe-body.collapsed{display:none}
.axe-proc-section{margin:0;border-bottom:1px solid var(--border)}
.axe-proc-section:last-child{border-bottom:none}
.axe-proc-title{background:#cad7ef;padding:10px 24px;font-size:11.5px;font-weight:700;color:var(--mid-blue);text-transform:uppercase;letter-spacing:1px;border-bottom:1px solid #cad7ef;display:flex;align-items:center;gap:8px}
.axe-proc-badge{background:var(--mid-blue);color:white;padding:3px 10px;border-radius:20px;font-size:10.5px;font-weight:700}
.obj-table{width:100%;border-collapse:collapse;border-radius:10px;overflow:hidden}
.obj-table th{background:#2e5596;color:#ffffff;font-size:10.5px;font-weight:700;text-transform:uppercase;letter-spacing:1px;padding:10px 16px;text-align:left;border-bottom:2px solid #0f203a;border-right:1px solid #3a68b5}
.obj-table th:last-child{border-right:none}
.obj-table td{padding:10px 16px;border-bottom:1px solid #cad7ef;font-size:13px;vertical-align:top;border-right:1px solid #cad7ef;background:#ffffff}
.obj-table tr:last-child td{border-bottom:none}
.obj-table tr:nth-child(even) td{background:#f4f7fd}
.obj-table tr:hover td{background:#e8f0fb!important}
.obj-kpi{font-weight:700;color:#0f203a}
.obj-formule{color:var(--text-mid);font-size:12px;font-family:monospace}
.cible-tag{display:inline-block;background:var(--green-bg);color:#00703a;border-radius:6px;padding:2px 10px;font-size:12px;font-weight:600}
.seuil-tag{display:inline-block;background:var(--yellow-bg);color:#92400e;border-radius:6px;padding:2px 10px;font-size:12px;font-weight:600}
.freq-tag{display:inline-block;border-radius:6px;padding:3px 10px;font-size:11px;font-weight:600}
.freq-M{background:#dbeafe;color:#1d4ed8}
.freq-T{background:#faf5ff;color:#7c3aed}
.freq-S{background:#fff7ed;color:#c2410c}
.freq-A{background:#f0fdf4;color:#15803d}
.resp-tag{font-size:11.5px;color:var(--text-mid);font-weight:500}

/* ===== DASHBOARD ===== */
.dash-stats{display:grid;grid-template-columns:repeat(4,1fr);gap:16px;margin-bottom:24px}
.stat-card{background:#ffffff;border-radius:12px;padding:20px 24px;box-shadow:0 2px 8px rgba(37,99,235,0.08);border:1px solid #cad7ef;border-top:4px solid transparent;display:flex;align-items:center;gap:14px}
.stat-card.total{border-top-color:#2e5596}
.stat-card.ok{border-top-color:var(--green)}
.stat-card.warn{border-top-color:var(--yellow)}
.stat-card.bad{border-top-color:var(--red)}
.stat-icon{font-size:28px;flex-shrink:0}
.stat-icon-box{width:44px;height:44px;border-radius:10px;display:flex;align-items:center;justify-content:center;font-family:'Plus Jakarta Sans',sans-serif;font-weight:800;font-size:13px;flex-shrink:0}
.stat-icon-box.total-icon{background:#e8f0fb;color:var(--mid-blue)}
.stat-icon-box.ok-icon{background:var(--green-bg);color:var(--green);font-size:18px}
.stat-icon-box.warn-icon{background:var(--yellow-bg);color:var(--yellow);font-size:20px;font-weight:900}
.stat-icon-box.bad-icon{background:var(--red-bg);color:var(--red);font-size:16px}
.pol-eng-icon-blue{background:var(--mid-blue)!important;color:white!important;font-size:11px!important;border-radius:8px;width:32px;height:32px;display:flex;align-items:center;justify-content:center;font-family:'Plus Jakarta Sans',sans-serif;font-weight:700}
.stat-value{font-family:'Plus Jakarta Sans',sans-serif;font-size:28px;font-weight:900;color:var(--navy)}
.stat-label{font-size:12px;color:var(--gray);font-weight:500;margin-top:2px}
.dash-filter-bar{display:flex;gap:8px;margin-bottom:20px;flex-wrap:wrap;align-items:center}
.filter-btn{padding:7px 16px;border:1.5px solid var(--border);border-radius:8px;background:white;font-size:12.5px;font-weight:500;cursor:pointer;transition:all 0.2s;color:var(--text-mid);font-family:'Inter',sans-serif}
.filter-btn:hover,.filter-btn.active{background:#2e5596;border-color:rgba(200,220,255,0.8);color:white;box-shadow:0 2px 8px rgba(37,99,235,0.3)}
.kpi-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(300px,1fr));gap:18px}
.kpi-card{background:#ffffff;border-radius:12px;overflow:hidden;box-shadow:0 2px 8px rgba(37,99,235,0.07);border:1px solid #cad7ef;transition:transform 0.2s,box-shadow 0.2s}
.kpi-card:hover{transform:translateY(-2px);box-shadow:0 8px 24px rgba(0,0,0,0.10);border-color:#3a68b5}
.kpi-card-top{display:flex;align-items:center;justify-content:space-between;padding:12px 16px;background:#ffffff;border-bottom:1.5px solid #cad7ef}
.kpi-proc-tag{background:#2e5596;color:#ffffff;border:1px solid #0f203a;padding:3px 10px;border-radius:6px;font-size:11px;font-weight:700;font-family:'Plus Jakarta Sans',sans-serif}
.kpi-card-body{padding:16px}
.kpi-name{font-weight:700;font-size:14px;color:var(--navy);margin-bottom:6px;line-height:1.3}
.kpi-formula-lbl{font-size:11.5px;color:var(--gray);margin-bottom:12px;font-style:italic}
.kpi-targets{display:flex;gap:10px;margin-bottom:12px}
.kpi-target{flex:1;background:#ffffff;border-radius:8px;padding:8px 10px;text-align:center}
.kpi-target label{font-size:10.5px;color:var(--gray);display:block;margin-bottom:3px;font-weight:600}
.kpi-target .val{font-weight:700;font-size:13px;color:var(--text-dark)}
.kpi-target.cible{border-top:2px solid var(--green)}
.kpi-target.seuil{border-top:2px solid var(--yellow)}
.kpi-values{display:flex;gap:6px;flex-wrap:wrap;margin-bottom:12px}
.kpi-val-item{background:#ffffff;border-radius:8px;padding:6px 10px;text-align:center;min-width:80px}
.kpi-val-item label{font-size:10px;color:var(--gray);display:block;font-weight:500}
.kpi-val-item .v{font-weight:700;font-size:13px}
.v-green{color:var(--green)}
.v-yellow{color:var(--yellow)}
.v-red{color:var(--red)}
.status-bar{height:6px;background:var(--border);border-radius:4px;margin-bottom:12px;overflow:hidden}
.status-fill{height:100%;border-radius:4px;transition:width 0.8s ease}
.kpi-calc-toggle{width:100%;padding:9px;background:#ffffff;border:1.5px solid var(--border);border-radius:8px;font-size:12.5px;font-weight:600;cursor:pointer;color:var(--mid-blue);transition:all 0.2s;font-family:'Inter',sans-serif}
.kpi-calc-toggle:hover{background:var(--accent);color:white;border-color:var(--accent)}
.kpi-calc{display:none;margin-top:10px;padding:14px;background:#ffffff;border-radius:10px}
.kpi-calc.open{display:block}
.calc-row{display:flex;align-items:center;gap:10px;margin-bottom:8px;flex-wrap:wrap}
.calc-row label{font-size:12px;color:var(--text-mid);font-weight:500;flex:1;min-width:100px}
.calc-row input{padding:8px 12px;border:1.5px solid var(--border);border-radius:8px;font-size:13px;outline:none;width:130px;flex-shrink:0;font-family:'Inter',sans-serif}
.calc-row input:focus{border-color:var(--accent)}
.calc-btn{padding:9px 18px;background:var(--accent);border:none;border-radius:8px;color:white;font-weight:600;font-size:12.5px;cursor:pointer;font-family:'Inter',sans-serif;transition:opacity 0.2s}
.calc-btn:hover{opacity:0.85}
.calc-result{display:none;padding:10px 14px;border-radius:8px;font-size:13px;font-weight:600;margin-top:8px}
.calc-result.ok{background:var(--green-bg);color:#00703a}
.calc-result.warn{background:var(--yellow-bg);color:#92400e}
.calc-result.bad{background:var(--red-bg);color:#c0392b}
.no-kpi{text-align:center;color:var(--gray);padding:40px;font-size:14px}

/* ===== VISUALISATION POWER BI STYLE ===== */
.viz-topbar{display:flex;gap:10px;flex-wrap:wrap;margin-bottom:22px;align-items:center}
.viz-section-title{font-family:'Plus Jakarta Sans',sans-serif;font-size:13px;font-weight:700;color:var(--navy);text-transform:uppercase;letter-spacing:1.5px;margin:28px 0 16px;display:flex;align-items:center;gap:10px}
.viz-section-title::after{content:'';flex:1;height:1.5px;background:var(--border)}
.charts-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(380px,1fr));gap:20px}
.chart-card{background:#ffffff;border-radius:12px;padding:24px;box-shadow:0 2px 8px rgba(37,99,235,0.08);border:1px solid #cad7ef}
.chart-card-header{display:flex;align-items:flex-start;justify-content:space-between;margin-bottom:6px}
.chart-card-title{font-weight:700;font-size:14px;color:var(--navy);line-height:1.3}
.chart-card-meta{font-size:11.5px;color:var(--gray);margin-bottom:16px}
.chart-canvas-wrap{position:relative;height:180px}
.trend-badge{display:inline-block;padding:3px 10px;border-radius:20px;font-size:12px;font-weight:700}
.trend-up-good{background:var(--green-bg);color:var(--green)}
.trend-up-bad{background:var(--red-bg);color:var(--red)}
.trend-down-good{background:var(--green-bg);color:var(--green)}
.trend-down-bad{background:var(--red-bg);color:var(--red)}
.trend-neutral{background:#ffffff;color:var(--gray)}
.kpi-summary-bar{display:flex;gap:6px;align-items:center;margin-top:14px;flex-wrap:wrap}
.kpi-dot{width:10px;height:10px;border-radius:50%;flex-shrink:0}
.kpi-dot.green{background:var(--green)}
.kpi-dot.yellow{background:var(--yellow)}
.kpi-dot.red{background:var(--red)}
.kpi-dot-label{font-size:11px;color:var(--gray)}

/* ===== CALCULATEUR ===== */
.calc-select-wrap{background:#ffffff;border-radius:14px;padding:24px;box-shadow:0 2px 8px rgba(37,99,235,0.08);border:1px solid #cad7ef;margin-bottom:20px}
.calc-select-wrap label{font-weight:600;font-size:13px;color:var(--navy);display:block;margin-bottom:8px}
.calc-select-wrap select{width:100%;padding:12px 16px;border:1.5px solid var(--border);border-radius:10px;font-size:14px;color:var(--text-dark);outline:none;font-family:'Inter',sans-serif;cursor:pointer}
.calc-select-wrap select:focus{border-color:var(--accent)}

/* ===== TABLEAU EXCEL ===== */
.excel-section{background:#ffffff;border-radius:16px;overflow:hidden;box-shadow:0 2px 12px rgba(37,99,235,0.10);border:1px solid #cad7ef;margin-bottom:24px}
.excel-toolbar{display:flex;align-items:center;justify-content:space-between;padding:14px 22px;background:linear-gradient(135deg,#0f203a,#2e5596);flex-wrap:wrap;gap:10px;border-bottom:none}
.excel-toolbar-title{font-family:'Plus Jakarta Sans',sans-serif;font-weight:700;font-size:15px;color:#ffffff}
.excel-toolbar-btns{display:flex;gap:8px;flex-wrap:wrap}
.excel-btn{padding:8px 16px;border:none;border-radius:8px;font-size:12.5px;font-weight:600;cursor:pointer;font-family:'Inter',sans-serif;transition:all 0.2s;display:flex;align-items:center;gap:6px}
.excel-btn.primary{background:var(--green);color:white}
.excel-btn.secondary{background:rgba(255,255,255,0.1);color:white;border:1px solid rgba(255,255,255,0.2)}
.excel-btn:hover{opacity:0.85;transform:translateY(-1px)}
.excel-proc-tabs{display:flex;overflow-x:auto;background:#f4f7fd;border-bottom:2.5px solid #2e5596;gap:0}
.excel-proc-tab{padding:12px 20px;font-size:12.5px;font-weight:600;cursor:pointer;border-right:1px solid #cad7ef;white-space:nowrap;color:#1f2f53;transition:all 0.2s;user-select:none;font-family:'Plus Jakarta Sans',sans-serif}
.excel-proc-tab:hover{background:#e8f0fb;color:#0f203a}
.excel-proc-tab.active{background:#ffffff;color:#2e5596;border-bottom:3px solid #2e5596;margin-bottom:-2px;font-weight:800}
.excel-table-wrap{overflow-x:auto;padding:0}
.excel-table{width:100%;border-collapse:collapse;font-size:12.5px}
.excel-table th{background:#2e5596;color:#ffffff;padding:10px 14px;text-align:center;white-space:nowrap;font-size:11px;font-weight:700;letter-spacing:0.5px;border-right:1px solid rgba(255,255,255,0.25);border-bottom:3px solid #0f203a;position:sticky;top:0}
.excel-table th:first-child,.excel-table th:nth-child(2){text-align:left}
.excel-table td{padding:9px 12px;border-bottom:1px solid #cad7ef;border-right:1px solid #cad7ef;white-space:nowrap;text-align:center;font-size:12px;background:#ffffff}
.excel-table td:first-child,.excel-table td:nth-child(2){text-align:left;font-weight:700;color:#0f203a}
.excel-table tr:nth-child(even) td{background:#f4f7fd}
.excel-table tr:hover td{background:#e8f0fb!important}
.excel-table tr.group-sep td{border-top:2.5px solid #2e5596}
.cell-input{width:80px;padding:5px 8px;border:1.5px solid var(--border);border-radius:6px;font-size:12px;text-align:right;outline:none;font-family:'Inter',sans-serif;background:white}
.cell-input:focus{border-color:var(--accent);background:#f0f8ff}
.cell-calc{font-weight:700;border-radius:6px;padding:4px 8px;display:inline-block}
.cell-green{background:var(--green-bg);color:#00703a}
.cell-yellow{background:var(--yellow-bg);color:#92400e}
.cell-red{background:var(--red-bg);color:#c0392b}
.cell-neutral{color:var(--gray)}
.excel-footer{padding:16px 22px;background:#f4f7fd;border-top:2px solid #cad7ef;display:flex;align-items:center;gap:16px;flex-wrap:wrap}
.excel-legend-item{display:flex;align-items:center;gap:6px;font-size:12px;color:var(--text-mid)}
.excel-legend-dot{width:12px;height:12px;border-radius:3px;flex-shrink:0}
@media print{
  #sidebar,#login-screen,.topbar,.excel-toolbar,.excel-proc-tabs,.excel-footer,.dash-filter-bar,.viz-topbar,.nav-section,.kpi-calc-toggle,.kpi-calc,.section-head .section-line{display:none!important}
  #main{margin-left:0!important}
  .page{display:block!important;padding:10px!important}
  .excel-section{box-shadow:none!important;border:1px solid #ccc}
  .excel-table{font-size:10px}
  body{background:white!important}
}

/* ===== QUICK ACCESS CARDS ===== */
.accueil-quick-card{background:white;border:1.5px solid var(--border);border-radius:14px;padding:20px;cursor:pointer;transition:all 0.2s;box-shadow:var(--shadow)}
.accueil-quick-card:hover{border-color:var(--accent);transform:translateY(-3px);box-shadow:0 8px 28px rgba(34,113,232,0.15)}
.aqc-icon{font-size:22px;margin-bottom:8px;color:var(--accent)}
.aqc-title{font-family:'Plus Jakarta Sans',sans-serif;font-weight:700;font-size:13px;color:var(--navy);margin-bottom:4px}
.aqc-desc{font-size:12px;color:var(--gray)}

/* ===== RAPPORT DE PROCESSUS ===== */
.rapport-hero{background:linear-gradient(135deg,#0f203a 0%,#1a3a6e 60%,#2e5596 100%);border-radius:20px;padding:32px 40px;color:#ffffff;margin-bottom:24px;position:relative;overflow:hidden;box-shadow:var(--shadow-lg)}
.rapport-hero h2{font-family:'Plus Jakarta Sans',sans-serif;font-size:24px;font-weight:900;margin-bottom:4px;color:#ffffff}
.rapport-hero .rh-sub{font-size:13px;color:rgba(255,255,255,0.85);margin-bottom:16px}
.rapport-hero .rh-meta{font-size:12px;color:rgba(255,255,255,0.70)}
.rapport-perf-big{font-family:'Plus Jakarta Sans',sans-serif;font-size:44px;font-weight:900;color:#7eb8f7;line-height:1;position:absolute;top:28px;right:40px}
.rapport-perf-lbl{font-size:11px;opacity:0.7;position:absolute;top:80px;right:40px;text-align:right}
.rapport-progress-bar{height:6px;background:linear-gradient(90deg,#00b67a 0%,#f59e0b 30%,#e03c31 60%,#e03c31 100%);border-radius:3px;margin-top:20px}
.rapport-stats-row{display:grid;grid-template-columns:repeat(4,1fr);gap:14px;margin-bottom:24px}
.rapport-stat{background:white;border-radius:12px;padding:16px 20px;box-shadow:var(--shadow);border-top:3px solid var(--border);text-align:center}
.rapport-stat .rsv{font-family:'Plus Jakarta Sans',sans-serif;font-size:26px;font-weight:900}
.rapport-stat .rsl{font-size:11.5px;color:var(--gray);margin-top:2px}
.rapport-two-col{display:grid;grid-template-columns:1fr 1fr;gap:20px;margin-bottom:24px}
.rapport-card{background:white;border-radius:16px;padding:22px;box-shadow:var(--shadow);border:1.5px solid var(--border)}
.rapport-card h4{font-family:'Plus Jakarta Sans',sans-serif;font-size:13px;font-weight:700;color:var(--navy);margin-bottom:14px;text-transform:uppercase;letter-spacing:1px}
.rapport-kpi-row{display:flex;align-items:center;justify-content:space-between;padding:8px 12px;border-radius:8px;margin-bottom:6px;background:#ffffff}
.rapport-kpi-row .rkr-name{font-size:12.5px;font-weight:600;color:var(--navy);flex:1}
.rapport-kpi-row .rkr-proc{background:#2e5596;color:#ffffff;border:1px solid #0f203a;padding:2px 8px;border-radius:4px;font-size:10px;font-weight:700;font-family:'Plus Jakarta Sans',sans-serif;margin-right:8px}
.rapport-kpi-row .rkr-val{font-family:'Plus Jakarta Sans',sans-serif;font-weight:800;font-size:14px}
.rapport-kpi-row.bad{border-left:3px solid var(--red)}
.rapport-kpi-row.bad .rkr-val{color:var(--red)}
.rapport-proc-select{padding:10px 16px;border:1.5px solid var(--border);border-radius:10px;font-size:13px;outline:none;font-family:'Inter',sans-serif;cursor:pointer;margin-bottom:20px;min-width:260px}
.rapport-kpi-table{width:100%;border-collapse:collapse;border-radius:10px;overflow:hidden}
.rapport-kpi-table th{background:#e8eef6;color:#1e3a5f;font-size:10.5px;font-weight:700;text-transform:uppercase;letter-spacing:0.8px;padding:10px 14px;text-align:center;border-bottom:2px solid #c5d4e8;border-right:1px solid #d6e2f0}
.rapport-kpi-table th:first-child{text-align:left;border-left:none}
.rapport-kpi-table th:last-child{border-right:none}
.rapport-kpi-table td{padding:9px 14px;border-bottom:1px solid #eaf0f8;font-size:12.5px;text-align:center;border-right:1px solid #f0f5fb;background:white}
.rapport-kpi-table td:first-child{text-align:left;font-weight:600;color:var(--navy)}
.rapport-kpi-table tr:nth-child(even) td{background:#ffffff}
.rapport-kpi-table tr:hover td{background:#ffffff!important}
.stat-badge{display:inline-block;padding:3px 10px;border-radius:20px;font-size:11.5px;font-weight:700}
.stat-badge.ok{background:var(--green-bg);color:var(--green)}
.stat-badge.warn{background:var(--yellow-bg);color:var(--yellow)}
.stat-badge.bad{background:var(--red-bg);color:var(--red)}
.stat-badge.nd{background:#ffffff;color:var(--gray)}
.rapport-action-section{background:white;border-radius:16px;padding:22px;box-shadow:var(--shadow);margin-top:20px;border:1.5px solid var(--border)}
.rapport-action-section h4{font-family:'Plus Jakarta Sans',sans-serif;font-size:13px;font-weight:700;color:var(--navy);margin-bottom:14px;text-transform:uppercase;letter-spacing:1px;display:flex;align-items:center;gap:8px}
/* ===== RAPPORT INLINE ACTION PLAN ===== */
.action-plan-card{background:white;border:1.5px solid var(--border);border-radius:14px;margin-bottom:14px;overflow:hidden;box-shadow:var(--shadow)}
.action-plan-card.bad{border-left:4px solid var(--red)}
.action-plan-card.warn{border-left:4px solid var(--yellow)}
.action-plan-header{display:flex;align-items:center;gap:10px;padding:12px 18px;background:#ffffff;border-bottom:1px solid var(--border)}
.action-plan-header .aph-icon{font-size:16px;flex-shrink:0}
.action-plan-card.bad .aph-icon{color:var(--red)}
.action-plan-card.warn .aph-icon{color:var(--yellow)}
.action-plan-header .aph-proc{background:#2e5596;color:#ffffff;border:1px solid #0f203a;padding:2px 9px;border-radius:5px;font-size:10.5px;font-weight:700;font-family:'Plus Jakarta Sans',sans-serif;flex-shrink:0}
.action-plan-header .aph-title{font-size:13px;font-weight:700;color:var(--navy);flex:1}
.action-plan-header .aph-val{font-family:'Plus Jakarta Sans',sans-serif;font-weight:900;font-size:15px;flex-shrink:0}
.action-plan-card.bad .aph-val{color:var(--red)}
.action-plan-card.warn .aph-val{color:var(--yellow)}
.action-plan-body{padding:16px 18px}
.apl-field-label{font-size:10.5px;font-weight:700;color:var(--accent);text-transform:uppercase;letter-spacing:1.2px;margin-bottom:6px;display:block}
.apl-textarea{width:100%;padding:10px 12px;border:1.5px solid var(--border);border-radius:8px;background:#f9fbff;font-size:13px;font-family:'Inter',sans-serif;color:var(--text-dark);resize:vertical;outline:none;transition:border 0.2s,box-shadow 0.2s;min-height:60px}
.apl-textarea:focus{border-color:var(--accent);box-shadow:0 0 0 3px rgba(26,109,212,0.08)}
.apl-input{width:100%;padding:9px 12px;border:1.5px solid var(--border);border-radius:8px;background:#f9fbff;font-size:13px;font-family:'Inter',sans-serif;color:var(--text-dark);outline:none;transition:border 0.2s,box-shadow 0.2s}
.apl-input:focus{border-color:var(--accent);box-shadow:0 0 0 3px rgba(26,109,212,0.08)}
.apl-two-col{display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-top:12px}
.apl-status-row{display:flex;gap:8px;margin-top:14px;padding-top:12px;border-top:1px solid var(--border)}
.apl-ssb{padding:7px 18px;border:1.5px solid var(--border);border-radius:8px;font-size:12px;font-weight:600;cursor:pointer;background:white;color:var(--text-mid);font-family:'Inter',sans-serif;transition:all 0.2s}
.apl-ssb.active-ouvert{background:var(--red-bg);color:var(--red);border-color:var(--red)}
.apl-ssb.active-en-cours{background:var(--yellow-bg);color:var(--yellow);border-color:var(--yellow)}
.apl-ssb.active-cloture{background:var(--green-bg);color:var(--green);border-color:var(--green)}
.apl-ssb:hover{border-color:var(--accent);color:var(--accent)}
/* Collapse toggle */
.apc-toggle-btn{display:flex;align-items:center;gap:6px;padding:5px 12px;border:1.5px solid var(--border);border-radius:8px;font-size:11px;font-weight:600;cursor:pointer;background:white;color:var(--text-mid);font-family:'Inter',sans-serif;transition:all 0.2s;flex-shrink:0;margin-left:auto}
.apc-toggle-btn:hover{border-color:var(--accent);color:var(--accent)}
.apc-toggle-btn .apc-chevron{display:inline-block;transition:transform 0.25s;font-size:10px}
.apc-toggle-btn.open .apc-chevron{transform:rotate(180deg)}
.apc-collapsible{overflow:hidden;transition:max-height 0.3s ease,opacity 0.25s ease;max-height:0;opacity:0}
.apc-collapsible.open{max-height:600px;opacity:1}
/* SSB suivi toggle */
.sac-toggle-btn{display:flex;align-items:center;gap:5px;padding:5px 11px;border:1.5px solid var(--border);border-radius:8px;font-size:11px;font-weight:600;cursor:pointer;background:white;color:var(--text-mid);font-family:'Inter',sans-serif;transition:all 0.2s;flex-shrink:0}
.sac-toggle-btn:hover{border-color:var(--accent);color:var(--accent)}
.sac-toggle-btn .sac-chevron{display:inline-block;transition:transform 0.25s;font-size:10px}
.sac-toggle-btn.open .sac-chevron{transform:rotate(180deg)}
.sac-collapsible{overflow:hidden;transition:max-height 0.3s ease,opacity 0.25s ease;max-height:0;opacity:0}
.sac-collapsible.open{max-height:600px;opacity:1}
/* legacy compat */
.action-row{display:none}
.print-btn{display:flex;align-items:center;gap:6px;padding:9px 18px;background:linear-gradient(135deg,#0f203a,#2e5596);color:white;border:none;border-radius:10px;font-size:12.5px;font-weight:600;cursor:pointer;font-family:'Plus Jakarta Sans',sans-serif;transition:opacity 0.2s}
.print-btn:hover{opacity:0.85}

/* ===== SUIVI DES ACTIONS ===== */
.suivi-stats{display:grid;grid-template-columns:repeat(4,1fr);gap:14px;margin-bottom:20px}
.suivi-stat{background:#ffffff;border:1px solid #cad7ef;border-radius:12px;padding:18px 20px;box-shadow:var(--shadow);text-align:center;border-top:3px solid var(--border)}
.suivi-stat .ssv{font-family:'Plus Jakarta Sans',sans-serif;font-size:30px;font-weight:900;color:var(--navy)}
.suivi-stat .ssl{font-size:11.5px;color:var(--gray);margin-top:2px}
.suivi-stat.ouvert{border-top-color:var(--red)}
.suivi-stat.ouvert .ssv{color:var(--red)}
.suivi-stat.en-cours{border-top-color:var(--yellow)}
.suivi-stat.en-cours .ssv{color:var(--yellow)}
.suivi-stat.cloture{border-top-color:var(--green)}
.suivi-stat.cloture .ssv{color:var(--green)}
.suivi-filter-bar{display:flex;gap:8px;margin-bottom:16px;flex-wrap:wrap}
.suivi-action-card{background:white;border:1.5px solid var(--border);border-radius:14px;margin-bottom:14px;overflow:hidden;box-shadow:var(--shadow)}
.suivi-action-card.bad{border-left:4px solid var(--red)}
.suivi-action-card.warn{border-left:4px solid var(--yellow)}
.suivi-action-header{display:flex;align-items:center;gap:10px;padding:14px 18px;border-bottom:1px solid var(--border)}
.suivi-action-header .sah-icon{font-size:18px;flex-shrink:0}
.suivi-action-card.bad .sah-icon{color:var(--red)}
.suivi-action-card.warn .sah-icon{color:var(--yellow)}
.suivi-action-header .sah-tags{display:flex;align-items:center;gap:6px;flex-shrink:0}
.suivi-action-header .sah-title{font-size:13.5px;font-weight:700;color:var(--navy);flex:1;min-width:0}
.suivi-action-header .sah-val{font-family:'Plus Jakarta Sans',sans-serif;font-weight:900;font-size:16px;flex-shrink:0;margin-left:6px}
.suivi-action-card.bad .sah-val{color:var(--red)}
.suivi-action-card.warn .sah-val{color:var(--yellow)}
.suivi-action-body{padding:18px}
.suivi-field{margin-bottom:14px}
.suivi-field label{font-size:10.5px;font-weight:700;color:var(--accent);text-transform:uppercase;letter-spacing:1.5px;display:block;margin-bottom:5px}
.suivi-field textarea,.suivi-field input[type="text"]{width:100%;padding:10px 14px;border:1.5px solid var(--border);border-radius:8px;font-size:13px;font-family:'Inter',sans-serif;outline:none;resize:vertical;background:white}
.suivi-field textarea:focus,.suivi-field input[type="text"]:focus{border-color:var(--accent)}
.suivi-field input[type="date"]{padding:9px 12px;border:1.5px solid var(--border);border-radius:8px;font-size:13px;font-family:'Inter',sans-serif;outline:none;width:100%}
.suivi-two-col{display:grid;grid-template-columns:1fr 1fr;gap:14px}
.suivi-status-btns{display:flex;gap:6px;flex-wrap:nowrap;margin-left:8px;flex-shrink:0}
.ssb{padding:6px 14px;border:1.5px solid var(--border);border-radius:8px;font-size:12px;font-weight:600;cursor:pointer;background:white;color:var(--text-mid);font-family:'Inter',sans-serif;transition:all 0.2s}
.ssb.active-ouvert{background:var(--red-bg);color:var(--red);border-color:var(--red)}
.ssb.active-en-cours{background:var(--yellow-bg);color:var(--yellow);border-color:var(--yellow)}
.ssb.active-cloture{background:var(--green-bg);color:var(--green);border-color:var(--green)}
.ssb:hover{border-color:var(--accent);color:var(--accent)}
.suivi-action-card-count{font-size:11px;color:var(--gray);margin-left:auto;margin-right:10px;white-space:nowrap}

/* ===== POWER BI STYLE ENHANCEMENTS ===== */
.kpi-card-top{background:#f4f7fd!important;border-bottom:1px solid #cad7ef!important}
.stat-value{font-size:26px!important}
.section-head h2{font-size:18px!important;font-weight:700!important;color:#0f172a!important}
.axe-head{background:linear-gradient(135deg,#2e5596 0%,#1a3a6e 50%,#0f203a 100%)!important;border-bottom:2px solid #0f203a!important}
.excel-proc-tab.active{color:#2e5596!important;border-bottom-color:#2e5596!important}
.pol-eng{border-left-color:#2e5596!important}
.rapport-hero{background:linear-gradient(135deg,#0f203a 0%,#1a3a6e 60%,#2e5596 100%)!important;color:#ffffff!important}
.login-btn{background:linear-gradient(135deg,#0f203a,#2e5596)!important}
/* KPI value cells in Excel table - clean */
.cell-green{background:#ecfdf5!important;color:#059669!important}
.cell-yellow{background:#fffbeb!important;color:#d97706!important}
.cell-red{background:#fef2f2!important;color:#dc2626!important}
/* Stat badges */
.stat-badge.ok{background:#ecfdf5!important;color:#059669!important}
.stat-badge.warn{background:#fffbeb!important;color:#d97706!important}
.stat-badge.bad{background:#fef2f2!important;color:#dc2626!important}
/* Action plan cards */
.action-plan-card.bad{border-left-color:#dc2626!important}
.action-plan-card.warn{border-left-color:#d97706!important}
/* Suivi actions */
.suivi-action-card.bad{border-left-color:#dc2626!important}
.suivi-action-card.warn{border-left-color:#d97706!important}
/* Rapport hero perf */
.rapport-perf-big{font-size:38px!important}
/* Scrollbar style */
::-webkit-scrollbar{width:6px;height:6px}
::-webkit-scrollbar-track{background:#f1f5f9}
::-webkit-scrollbar-thumb{background:#cbd5e1;border-radius:3px}
::-webkit-scrollbar-thumb:hover{background:#94a3b8}

/* ===== PROFESSIONAL BLUE-WHITE THEME ENHANCEMENTS ===== */
.rapport-kpi-table { width:100%; border-collapse:collapse; font-size:11.5px; }
.rapport-kpi-table th { background:#2e5596; color:#ffffff; padding:8px 10px; font-size:10px; font-weight:700; text-transform:uppercase; letter-spacing:0.8px; text-align:center; white-space:nowrap; border-right:1px solid #3a68b5; border-bottom:2px solid #2e5596; }
.rapport-kpi-table th:first-child { text-align:left; }
.rapport-kpi-table td { padding:7px 10px; border-bottom:1px solid #cad7ef; border-right:1px solid #cad7ef; font-size:11px; vertical-align:middle; text-align:center; background:#ffffff; }
.rapport-kpi-table td:first-child { text-align:left; font-weight:600; color:#1f2f53; min-width:140px; }
.rapport-kpi-table tr:nth-child(even) td { background:#f4f7fd; }
.rapport-kpi-table tr:hover td { background:#e8f0fb !important; }
.rapport-kpi-table th:first-child,.rapport-kpi-table th:nth-child(2),.rapport-kpi-table th:nth-child(3) { min-width:80px; }

/* Excel table enhanced */
.excel-table th:first-child,.excel-table th:nth-child(2) { text-align:left; }
.excel-table td:first-child,.excel-table td:nth-child(2) { text-align:left; }

/* KPI cards */
.kpi-card:hover { transform:translateY(-2px); box-shadow:0 8px 24px rgba(37,99,235,0.15); border-color:rgba(200,220,255,0.8); }

/* Section headers - blue line */
.section-head { border-bottom:2px solid #cad7ef; padding-bottom:12px; }
.section-head h2 { color:#1f2f53; }
.section-line { flex:1; height:2px; background:linear-gradient(90deg,#3a68b5,transparent); }

/* White card generic */
.white-card { background:#ffffff; border-radius:14px; padding:22px; box-shadow:0 2px 10px rgba(37,99,235,0.08); border:1px solid #cad7ef; }

/* Rapport hero */
.rapport-hero { background:linear-gradient(135deg,#0f203a 0%,#1a3a6e 60%,#2e5596 100%); border-radius:16px; padding:30px 36px; color:#ffffff; margin-bottom:20px; position:relative; overflow:hidden; box-shadow:0 4px 20px rgba(37,99,235,0.25); }
.rapport-hero * { color:#ffffff !important; }
.rapport-hero .stat-badge.ok { color:#059669 !important; background:#ecfdf5 !important; }
.rapport-hero .stat-badge.warn { color:#d97706 !important; background:#fffbeb !important; }
.rapport-hero .stat-badge.bad { color:#dc2626 !important; background:#fef2f2 !important; }
.rapport-hero .rapport-perf-big { color:#ffffff !important; }

/* Suivi stat cards */
.suivi-stat { background:#ffffff; border-radius:12px; padding:18px 22px; text-align:center; border:1px solid #cad7ef; box-shadow:0 2px 8px rgba(37,99,235,0.07); }
.suivi-stat.ouvert { border-top:3px solid #f59e0b; }
.suivi-stat.en-cours { border-top:3px solid #2e5596; color:#2e5596; }
.suivi-stat.cloture { border-top:3px solid #059669; }

/* Action plan cards */
.action-plan-card,.suivi-action-card { background:#ffffff; border-radius:12px; border:1px solid #cad7ef; box-shadow:0 2px 8px rgba(37,99,235,0.07); margin-bottom:12px; overflow:hidden; }
.action-plan-card.bad,.suivi-action-card.bad { border-left:4px solid #dc2626; }
.action-plan-card.warn,.suivi-action-card.warn { border-left:4px solid #d97706; }
.action-plan-header,.suivi-action-header { display:flex; align-items:center; gap:10px; padding:12px 18px; background:#ffffff; border-bottom:1px solid #cad7ef; flex-wrap:wrap; }

/* Login improvements */
.login-box select,.login-box input[type=password],.login-box input[type=text] { border:1.5px solid #cad7ef !important; background:#f8fbff !important; }
.login-box select:focus,.login-box input:focus { border-color:rgba(200,220,255,0.8) !important; box-shadow:0 0 0 3px rgba(37,99,235,0.15) !important; }

/* Stat card icons */
.stat-icon-box.total-icon { background:#e8f0fb; color:#2e5596; }

/* Filter buttons */
.filter-btn { border:1.5px solid #cad7ef; }
.filter-btn:hover,.filter-btn.active { background:#2e5596; }

/* Section head */
.section-head { margin-bottom:20px; }

/* Excel table group separator */
.excel-table tr.group-sep td { border-top:2.5px solid #2e5596; }

/* Accueil stats quick row */
.acc-quick-stats { display:grid; grid-template-columns:repeat(4,1fr); gap:14px; margin-bottom:22px; }

/* Progress bar */
.status-bar { height:6px; background:#e2e8f0; border-radius:4px; margin-bottom:12px; overflow:hidden; }

/* ===== CORRECTIONS VISIBILITÉ GLOBALE - OVERRIDE FINAL ===== */

/* LOGIN : panneau gauche entièrement bleu → tous textes blancs */
.login-left-panel { background: linear-gradient(160deg,#0f203a 0%,#1a3a6e 40%,#2e5596 100%) !important; }
.login-left-title { color: #ffffff !important; }
.login-left-title span { color: #7eb8f7 !important; }
.login-left-sub { color: rgba(255,255,255,0.88) !important; }
.login-left-badge { color: #ffffff !important; background: rgba(255,255,255,0.10) !important; border-color: rgba(255,255,255,0.22) !important; }
.login-left-badge strong { color: #ffffff !important; }
#login-screen > .login-left-panel * { color: #ffffff !important; }
#login-screen > .login-left-panel .login-left-title span { color: #7eb8f7 !important; }

/* AXE OBJECTIFS : en-têtes toujours bleu foncé + texte blanc */
.axe-head { background: linear-gradient(135deg,#2e5596 0%,#1a3a6e 60%,#0f203a 100%) !important; border-bottom: 2px solid #0f203a !important; }
.axe-head h3 { color: #ffffff !important; }
.axe-toggle { color: rgba(255,255,255,0.9) !important; }
.axe-num { color: #ffffff !important; }

/* OBJ-TABLE : en-têtes bleus + textes blancs */
.obj-table th { background: #2e5596 !important; color: #ffffff !important; }

/* FRÉQUENCE mensuelle : fond bleu pâle visible */
.freq-M { background: #dbeafe !important; color: #1d4ed8 !important; }

/* ACCUEIL HERO : fond bleu + textes blancs */
.accueil-hero { background: linear-gradient(135deg,#0f203a 0%,#1e3c7a 60%,#2e5596 100%) !important; color: #ffffff !important; }
.accueil-hero h1 { color: #ffffff !important; }
.accueil-hero h1 span { color: #7eb8f7 !important; }
.accueil-hero .subtitle { color: rgba(255,255,255,0.85) !important; }
.accueil-intro { color: rgba(255,255,255,0.92) !important; }
.accueil-intro strong { color: #ffffff !important; }
.accueil-badge { color: #ffffff !important; }

/* RAPPORT HERO : fond bleu + textes blancs */
.rapport-hero { background: linear-gradient(135deg,#0f203a 0%,#1a3a6e 60%,#2e5596 100%) !important; color: #ffffff !important; }
.rapport-hero h2, .rapport-hero h3, .rapport-hero p, .rapport-hero span, .rapport-hero div { color: #ffffff !important; }
.rapport-hero .rapport-stat .rsv { color: #ffffff !important; }
.rapport-hero .rapport-stat .rsl { color: rgba(255,255,255,0.75) !important; }
.rapport-hero .rapport-perf-big { color: #7eb8f7 !important; }
.rapport-hero .stat-badge.ok  { color: #059669 !important; background: #ecfdf5 !important; }
.rapport-hero .stat-badge.warn { color: #d97706 !important; background: #fffbeb !important; }
.rapport-hero .stat-badge.bad  { color: #dc2626 !important; background: #fef2f2 !important; }
.rapport-hero .stat-badge.nd   { color: #64748b !important; background: #f1f5f9 !important; }

/* STAT CARDS : bordure top visible */
.stat-card.total { border-top-color: #2e5596 !important; }
.stat-icon-box.total-icon { background: #e8f0fb !important; color: #2e5596 !important; }

/* KPI CARD TOP : bordure visible */
.kpi-card-top { background: #f4f7fd !important; border-bottom: 1px solid #cad7ef !important; }

/* STATUS BAR fond visible */
.status-bar { background: #e2e8f0 !important; }

/* NAV active : bordure visible */
nav a.active { border-left-color: #2e5596 !important; }

/* POL-ENG */
.pol-eng { border-left-color: #2e5596 !important; }

/* SECTION HEAD h2 lisible */
.section-head h2 { color: #0f203a !important; }

/* Excel proc tab active : texte bleu lisible */
.excel-proc-tab.active { color: #2e5596 !important; border-bottom-color: #2e5596 !important; background: #ffffff !important; }

/* Rapport stats (rsv) sur fond bleu */
.rapport-stat { text-align: center; }

/* ===== ACCÈS RESTREINT — icône cadenas dans la nav ===== */
nav a.nav-locked { display: flex !important; justify-content: space-between; opacity: 0.42; pointer-events: none; cursor: not-allowed; font-style: italic; }
nav a.nav-locked::after { content: '🔒'; font-size: 11px; }
.accueil-quick-card.aqc-locked { display: none !important; }

/* ===== NOTIFICATIONS CLOCHE ===== */
.notif-bell-wrap { position: relative; cursor: pointer; margin-right: 8px; }
.notif-bell-btn { background: none; border: 1.5px solid #cad7ef; border-radius: 10px; width: 38px; height: 38px; display: flex; align-items: center; justify-content: center; font-size: 18px; cursor: pointer; transition: all 0.2s; color: #2e5596; background: #f0f4fb; }
.notif-bell-btn:hover { background: #e8f0fb; border-color: #2e5596; }
.notif-badge { position: absolute; top: -6px; right: -6px; background: #dc2626; color: white; border-radius: 50%; width: 20px; height: 20px; font-size: 10px; font-weight: 700; display: flex; align-items: center; justify-content: center; font-family: 'Plus Jakarta Sans', sans-serif; border: 2px solid white; animation: notif-pulse 1.5s infinite; }
@keyframes notif-pulse { 0%,100%{transform:scale(1)} 50%{transform:scale(1.18)} }
.notif-badge.hidden { display: none; }

/* Panneau notifications */
.notif-panel { position: fixed; top: 60px; right: 24px; width: 380px; max-height: 500px; background: white; border-radius: 16px; box-shadow: 0 8px 32px rgba(14,32,58,0.18); border: 1.5px solid #cad7ef; z-index: 999; display: none; flex-direction: column; overflow: hidden; }
.notif-panel.open { display: flex; }
.notif-panel-header { padding: 16px 20px 12px; border-bottom: 1px solid #cad7ef; display: flex; align-items: center; justify-content: space-between; background: linear-gradient(135deg, #0f203a, #2e5596); }
.notif-panel-header h3 { font-family: 'Plus Jakarta Sans', sans-serif; font-size: 14px; font-weight: 700; color: white; }
.notif-panel-header span { font-size: 11px; color: rgba(255,255,255,0.75); }
.notif-clear-btn { background: rgba(255,255,255,0.15); border: 1px solid rgba(255,255,255,0.3); border-radius: 6px; color: white; font-size: 11px; font-weight: 600; padding: 4px 10px; cursor: pointer; }
.notif-panel-body { overflow-y: auto; flex: 1; }
.notif-item { display: flex; align-items: flex-start; gap: 12px; padding: 14px 18px; border-bottom: 1px solid #f0f4fb; transition: background 0.15s; }
.notif-item:hover { background: #f4f7fd; }
.notif-item:last-child { border-bottom: none; }
.notif-icon { width: 36px; height: 36px; border-radius: 10px; display: flex; align-items: center; justify-content: center; font-size: 17px; flex-shrink: 0; }
.notif-icon.bad { background: #fef2f2; }
.notif-icon.warn { background: #fffbeb; }
.notif-text { flex: 1; }
.notif-text strong { display: block; font-size: 13px; color: #0f203a; font-weight: 600; margin-bottom: 2px; line-height: 1.3; }
.notif-text span { font-size: 11.5px; color: #64748b; line-height: 1.4; }
.notif-time { font-size: 10px; color: #94a3b8; white-space: nowrap; margin-top: 2px; }
.notif-empty { padding: 32px; text-align: center; color: #94a3b8; font-size: 13px; }
.notif-empty .ne-icon { font-size: 32px; margin-bottom: 8px; }

/* Toast d'alerte */
.toast-container { position: fixed; top: 70px; right: 24px; z-index: 9999; display: flex; flex-direction: column; gap: 10px; pointer-events: none; }
.toast { background: white; border-radius: 12px; padding: 14px 18px; box-shadow: 0 6px 24px rgba(14,32,58,0.18); border-left: 4px solid #dc2626; display: flex; align-items: center; gap: 12px; max-width: 360px; pointer-events: all; animation: toast-in 0.35s ease; }
.toast.warn { border-left-color: #d97706; }
@keyframes toast-in { from { transform: translateX(100%); opacity: 0; } to { transform: translateX(0); opacity: 1; } }
@keyframes toast-out { from { transform: translateX(0); opacity: 1; } to { transform: translateX(100%); opacity: 0; } }
.toast-icon { font-size: 22px; flex-shrink: 0; }
.toast-body strong { display: block; font-size: 13px; color: #0f203a; font-weight: 700; }
.toast-body span { font-size: 12px; color: #64748b; }
.toast-close { background: none; border: none; font-size: 16px; color: #94a3b8; cursor: pointer; padding: 2px 6px; border-radius: 4px; margin-left: auto; }
.toast-close:hover { color: #64748b; background: #f1f5f9; }

/* ===== MODAL GESTION KPI ===== */
.modal-overlay { position: fixed; inset: 0; background: rgba(15,32,58,0.55); z-index: 500; display: none; align-items: center; justify-content: center; backdrop-filter: blur(3px); }
.modal-overlay.open { display: flex; }
.modal-box { background: white; border-radius: 20px; width: 680px; max-width: 95vw; max-height: 85vh; display: flex; flex-direction: column; box-shadow: 0 20px 60px rgba(14,32,58,0.25); overflow: hidden; }
.modal-header { padding: 22px 28px 18px; background: linear-gradient(135deg, #0f203a, #2e5596); display: flex; align-items: center; gap: 14px; }
.modal-header h2 { font-family: 'Plus Jakarta Sans', sans-serif; font-size: 17px; font-weight: 800; color: white; flex: 1; }
.modal-close { background: rgba(255,255,255,0.15); border: 1px solid rgba(255,255,255,0.3); color: white; border-radius: 8px; width: 32px; height: 32px; cursor: pointer; font-size: 16px; display: flex; align-items: center; justify-content: center; }
.modal-close:hover { background: rgba(255,255,255,0.25); }
.modal-body { padding: 24px 28px; overflow-y: auto; flex: 1; }
.modal-section-title { font-family: 'Plus Jakarta Sans', sans-serif; font-size: 12px; font-weight: 700; color: #2e5596; text-transform: uppercase; letter-spacing: 1.5px; margin-bottom: 14px; }

/* Formulaire ajout KPI */
.kpi-add-form { background: #f4f7fd; border-radius: 14px; padding: 20px; border: 1.5px dashed #cad7ef; margin-bottom: 24px; }
.kpi-form-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; }
.kpi-form-field label { display: block; font-size: 11px; font-weight: 700; color: #1f2f53; text-transform: uppercase; letter-spacing: 0.8px; margin-bottom: 5px; }
.kpi-form-field input, .kpi-form-field select { width: 100%; padding: 9px 12px; border: 1.5px solid #cad7ef; border-radius: 8px; font-size: 13px; color: #0f203a; background: white; font-family: 'Inter', sans-serif; outline: none; transition: border 0.2s; }
.kpi-form-field input:focus, .kpi-form-field select:focus { border-color: #2e5596; box-shadow: 0 0 0 3px rgba(46,85,150,0.1); }
.kpi-form-field.full { grid-column: 1 / -1; }
.kpi-add-btn { margin-top: 14px; padding: 10px 22px; background: linear-gradient(135deg, #0f203a, #2e5596); color: white; border: none; border-radius: 8px; font-weight: 700; font-size: 13px; cursor: pointer; font-family: 'Plus Jakarta Sans', sans-serif; transition: opacity 0.2s; }
.kpi-add-btn:hover { opacity: 0.88; }

/* Liste KPIs existants dans la modal */
.kpi-manage-list { display: flex; flex-direction: column; gap: 10px; }
.kpi-manage-item { background: white; border: 1.5px solid #cad7ef; border-radius: 12px; padding: 13px 16px; display: flex; align-items: center; gap: 12px; transition: border-color 0.2s; }
.kpi-manage-item:hover { border-color: #3a68b5; }
.kpi-manage-item.custom { border-left: 3px solid #2e5596; }
.kpi-manage-item.custom .kpi-m-badge { background: #e8f0fb; color: #2e5596; }
.kpi-m-badge { background: #f0f4fb; color: #64748b; padding: 2px 8px; border-radius: 5px; font-size: 10px; font-weight: 700; font-family: 'Plus Jakarta Sans', sans-serif; letter-spacing: 0.5px; flex-shrink: 0; }
.kpi-m-name { flex: 1; font-size: 13px; font-weight: 600; color: #0f203a; }
.kpi-m-targets { font-size: 11px; color: #64748b; }
.kpi-del-btn { background: #fef2f2; border: 1px solid #fca5a5; color: #dc2626; border-radius: 7px; padding: 5px 10px; font-size: 11px; font-weight: 700; cursor: pointer; transition: all 0.2s; flex-shrink: 0; }
.kpi-del-btn:hover { background: #dc2626; color: white; }
.kpi-del-btn:disabled { background: #f1f5f9; border-color: #e2e8f0; color: #94a3b8; cursor: not-allowed; }

/* Bouton "Gérer mes KPIs" dans la topbar */
.manage-kpi-btn { padding: 7px 14px; background: #e8f0fb; border: 1.5px solid #cad7ef; border-radius: 8px; color: #2e5596; font-size: 12px; font-weight: 600; cursor: pointer; font-family: 'Inter', sans-serif; transition: all 0.2s; display: flex; align-items: center; gap: 6px; }
.manage-kpi-btn:hover { background: #2e5596; color: white; border-color: #2e5596; }

/* ===== LOGO APPLICATION GRAND — OVERRIDE FINAL ===== */
.login-left-panel .login-logo-img#login-logo-img{
  width: 300px !important;
  height: auto !important;
  max-height: 120px !important;
  object-fit: contain !important;
  background: transparent !important;
  padding: 0 !important;
  border-radius: 0 !important;
  display: block !important;
  margin: 0 auto 8px auto !important;
}
.login-left-panel .login-logo-img#login-logo-img + div{
  display: none !important;
}
.login-right-panel .login-logo-wrap{
  justify-content: flex-start !important;
  gap: 14px !important;
}
.login-right-panel .login-logo-wrap .login-logo-img{
  width: 210px !important;
  height: auto !important;
  max-height: 86px !important;
  object-fit: contain !important;
  background: transparent !important;
  padding: 0 !important;
  border-radius: 0 !important;
}
.login-right-panel .login-brand{
  display: none !important;
}
.sidebar-logo{
  padding: 18px 14px 16px !important;
  justify-content: center !important;
  align-items: center !important;
  flex-direction: column !important;
  gap: 6px !important;
}
#sidebar-logo-img{
  width: 205px !important;
  height: auto !important;
  max-height: 74px !important;
  object-fit: contain !important;
  background: transparent !important;
  padding: 0 !important;
  border-radius: 0 !important;
}
.sidebar-logo-text{
  display: none !important;
}
#accueil-logo-img{
  width: 285px !important;
  height: auto !important;
  max-height: 110px !important;
  object-fit: contain !important;
  background: transparent !important;
  padding: 0 !important;
  border-radius: 0 !important;
}
#pol-logo-img{
  width: 230px !important;
  height: auto !important;
  max-height: 90px !important;
  object-fit: contain !important;
  background: transparent !important;
  padding: 0 !important;
  border-radius: 0 !important;
  border: 0 !important;
}
#carto-logo-img{
  width: 190px !important;
  height: auto !important;
  max-height: 74px !important;
  object-fit: contain !important;
  background: transparent !important;
  padding: 0 !important;
  border-radius: 0 !important;
  border: 0 !important;
}
#carto-footer-logo{
  width: 92px !important;
  height: auto !important;
  max-height: 36px !important;
  object-fit: contain !important;
  background: transparent !important;
  padding: 0 !important;
  border-radius: 0 !important;
}
.pol-doc-header{
  align-items: center !important;
}
.accueil-hero-top{
  align-items: center !important;
  gap: 26px !important;
}
@media(max-width:700px){
  .login-right-panel .login-logo-wrap .login-logo-img{
    width: 190px !important;
  }
  #sidebar-logo-img{
    width: 180px !important;
  }
  #accueil-logo-img{
    width: 220px !important;
  }
}

</style>

</head>
<body>

<!-- ===== LOGIN ===== -->
<div id="login-screen">
  <!-- Left panel: dark branding -->
  <div class="login-left-panel">
    <div style="position:relative;z-index:1;text-align:center;width:100%">
      <div style="display:flex;align-items:center;justify-content:center;gap:12px;margin-bottom:28px">
        <img class="login-logo-img" id="login-logo-img" src="" alt="Logo Ventec" style="background:white">
        <div style="text-align:left">
          <div style="font-family:'Plus Jakarta Sans',sans-serif;font-weight:900;font-size:16px;color:#ffffff;letter-spacing:0.5px">VENTEC INDUSTRIES</div>
          <div style="font-size:10px;color:rgba(180,210,255,0.9);letter-spacing:2px;text-transform:uppercase;margin-top:2px">Filiale Ventec Groupe</div>
        </div>
      </div>
      <div class="login-left-title">L'Expert du confort et de la sécurité</div>
      <p class="login-left-sub"></p>
      <div class="login-left-badges">
        <div class="login-left-badge"><span><strong>Suivi en temps réel</strong><br>Dashboard KPI multi-processus</span></div>
        <div class="login-left-badge"><span><strong>Accès sécurisé</strong><br>Profil personnel par département</span></div>
        <div class="login-left-badge"><span><strong>Rapports automatiques</strong><br>Rapport de processus &amp; plans d'action</span></div>
      </div>
    </div>
  </div>

  <!-- Right panel: white login form -->
  <div class="login-right-panel">
    <div class="login-box">
      <div class="login-logo-wrap">
        <img class="login-logo-img" src="" alt="Logo" style="background:white">
        <div class="login-brand">VENTEC INDUSTRIES<span>Tableau de Bord KPI · 2026</span></div>
      </div>
      <div class="login-welcome">Connexion</div>
      <p class="login-desc">Sélectionnez votre profil et saisissez votre code d'accès.</p>

      <label class="login-field-label">Votre profil</label>
      <select id="login-user">
        <option value="">— Sélectionnez votre profil —</option>
        <option value="Directeur Général|Management Général|DIRECTEUR GÉNÉRAL|MPM1">Directeur Général – DG</option>
        <option value="Responsable QSE|Management QSE|RESP. QSE|MPM2">Responsable QSE – QSE</option>
        <option value="Chef Service RH|Management RH|CHEF SERVICE RH|MPM3">Chef Service RH – RH</option>
        <option value="Directeur Technique|Production|DIRECTEUR TECHNIQUE|MPR4">Directeur Technique – Production</option>
        <option value="Chef Service Achats|Achats|CHEF SERVICE ACHATS|MPS1">Chef Service Achats – Achats</option>
        <option value="Resp. Logistique|Logistique|RESP. LOGISTIQUE|MPS2">Resp. Logistique – Logistique</option>
        <option value="Chef Service SI|Systèmes d'information|CHEF SERVICE SI|MPS4">Chef Service SI – SI</option>
        <option value="Chef Service MG|Moyens Généraux|CHEF SERVICE MG|MPS5">Chef Service MG – Moyens Généraux</option>
      </select>

      <label class="login-field-label">Code d'accès</label>
      <div class="login-pass-wrap">
        <input type="password" id="login-pass" placeholder="••••••••••" autocomplete="current-password" />
        <button class="login-eye-btn" type="button" onclick="toggleLoginPass(this)" title="Afficher/Masquer">Afficher</button>
      </div>

      <div class="login-err" id="login-err">Profil ou code d'accès incorrect.</div>
      <button class="login-btn" onclick="doLogin()">SE CONNECTER</button>
      <p class="login-hint"></p>
    </div>
  </div>
</div>

<!-- ===== SIDEBAR ===== -->
<div id="sidebar">
  <div class="sidebar-logo">
    <img id="sidebar-logo-img" src="" alt="Logo" style="width:42px;height:42px;border-radius:10px;background:white;padding:5px;object-fit:contain">
    <div class="sidebar-logo-text">VENTEC INDUSTRIES<span>Filiale VENTEC GROUPE</span></div>
  </div>
  <nav id="nav">
    <div class="nav-section">GÉNÉRAL</div>
    <a onclick="showPage('accueil')" id="nav-accueil">Accueil</a>
    <a onclick="showPage('politique')" id="nav-politique">Politique QSE</a>
    <a onclick="showPage('cartographie')" id="nav-cartographie">Cartographie</a>
    <a onclick="showPage('objectifs')" id="nav-objectifs">Axes & Objectifs</a>
    <div class="nav-section">KPI & SUIVI</div>
    <a onclick="showPage('dashboard')" id="nav-dashboard">Tableau de Bord KPI</a>
    <a onclick="showPage('calculateur')" id="nav-calculateur">Calculateur KPI</a>
    <a onclick="showPage('visualisation')" id="nav-visualisation">Visualisation</a>
    <div class="nav-section">RAPPORTS</div>
    <a onclick="showPage('rapport')" id="nav-rapport">Rapport de Processus</a>
    <a onclick="showPage('suivi')" id="nav-suivi">Suivi des Actions</a>
    <div class="nav-section">SAISIE</div>
    <a onclick="showPage('excel')" id="nav-excel">Tableau Excel</a>
    <div class="nav-section"></div>
    <a onclick="doLogout()" style="color:#b0bdd4">Déconnexion</a>
  </nav>
</div>

<!-- ===== TOAST CONTAINER ===== -->
<div class="toast-container" id="toast-container"></div>

<!-- ===== PANNEAU NOTIFICATIONS ===== -->
<div class="notif-panel" id="notif-panel">
  <div class="notif-panel-header">
    <h3>🔔 Alertes KPI</h3>
    <span id="notif-count-label">0 alerte(s)</span>
    <button class="notif-clear-btn" onclick="clearNotifs()">Tout effacer</button>
  </div>
  <div class="notif-panel-body" id="notif-list">
    <div class="notif-empty"><div class="ne-icon">✅</div>Aucune alerte en cours</div>
  </div>
</div>

<!-- ===== MODAL GESTION KPI ===== -->
<div class="modal-overlay" id="kpi-modal">
  <div class="modal-box">
    <div class="modal-header">
      <h2>Gerer mes KPIs — <span id="modal-proc-label"></span></h2>
      <button class="modal-close" onclick="closeKpiModal()">X</button>
    </div>
    <div class="modal-body">
      <div class="modal-section-title">Ajouter un nouvel indicateur</div>
      <div class="kpi-add-form">
        <div class="kpi-form-grid">
          <div class="kpi-form-field full">
            <label>Nom du KPI *</label>
            <input type="text" id="nkpi-name" placeholder="Ex : Taux de livraison a temps">
          </div>
          <div class="kpi-form-field full">
            <label>Formule de calcul</label>
            <input type="text" id="nkpi-formule" placeholder="Ex : Nb livraisons a temps / Nb total livraisons">
          </div>
          <div class="kpi-form-field">
            <label>Cible (valeur numerique)</label>
            <input type="number" step="any" id="nkpi-cible" placeholder="Ex : 0.95">
          </div>
          <div class="kpi-form-field">
            <label>Seuil de tolerance (valeur numerique)</label>
            <input type="number" step="any" id="nkpi-seuil" placeholder="Ex : 0.90">
          </div>
          <div class="kpi-form-field">
            <label>Unite d affichage</label>
            <input type="text" id="nkpi-unit" placeholder="Ex : % ou DH ou jours">
          </div>
          <div class="kpi-form-field">
            <label>Frequence de mesure</label>
            <select id="nkpi-freq">
              <option value="M">Mensuelle</option>
              <option value="T">Trimestrielle</option>
              <option value="S">Semestrielle</option>
              <option value="A">Annuelle</option>
            </select>
          </div>
          <div class="kpi-form-field">
            <label>Sens (meilleur = ?)</label>
            <select id="nkpi-dir">
              <option value="1">Plus eleve = mieux</option>
              <option value="0">Plus bas = mieux</option>
            </select>
          </div>
          <div class="kpi-form-field">
            <label>Echelle affichage</label>
            <select id="nkpi-scale">
              <option value="100">x100 (pour %)</option>
              <option value="1">x1 (valeur brute)</option>
            </select>
          </div>
        </div>
        <button class="kpi-add-btn" onclick="addCustomKpi()">+ Ajouter ce KPI</button>
      </div>
      <div class="modal-section-title">Indicateurs de mon processus</div>
      <div class="kpi-manage-list" id="kpi-manage-list"></div>
    </div>
  </div>
</div>

<!-- ===== MAIN ===== -->
<div id="main">
  <div class="topbar">
    <div class="topbar-title" id="page-title">Accueil</div>
    <div class="topbar-user" style="gap:10px">
      <button class="manage-kpi-btn" id="manage-kpi-btn" onclick="openKpiModal()" style="display:none">Gerer mes KPIs</button>
      <div class="notif-bell-wrap" onclick="toggleNotifPanel()">
        <button class="notif-bell-btn" title="Alertes KPI">&#128276;</button>
        <span class="notif-badge hidden" id="notif-badge">0</span>
      </div>
      <span id="user-name">&#8212;</span>
      <span class="user-badge" id="user-role">&#8212;</span>
    </div>
  </div>

  <!-- ===== PAGE: ACCUEIL ===== -->
  <div class="page active" id="page-accueil">
    <div class="section-head"><h2>Bienvenue</h2><div class="section-line"></div></div>
    <div class="accueil-hero">
      <div class="accueil-hero-top">
        <img id="accueil-logo-img" src="" alt="Logo Ventec">
        <div>
          <h1>INDUSTRIES VENTEC<span class="subtitle">FILIALE VENTEC GROUPE — TABLEAU DE BORD KPI 2026</span></h1>
        </div>
      </div>
      <p class="accueil-intro">
        Bienvenue sur le <strong>Tableau de Bord KPI Ventec Industries</strong>. Cette plateforme centralise le suivi des indicateurs clés de performance pour l'ensemble des processus de gestion, de réalisation et de support. Pilotez la performance, anticipez les écarts et contribuez à la poursuite de notre <strong>système de management QSE</strong>.
      </p>
      <div class="accueil-badges">
        <div class="accueil-badge">ISO 9001</div>
        <div class="accueil-badge">ISO 45001</div>
        <div class="accueil-badge">ISO 14001</div>
        <div class="accueil-badge">6 KPI Pilotés</div>
        <div class="accueil-badge">8 Processus Couverts</div>
        <div class="accueil-badge">Suivi en Temps Réel</div>
      </div>
    </div>
    <div class="dash-stats" id="accueil-stats">
      <div class="stat-card total"><div class="stat-icon-box total-icon">KPI</div><div><div class="stat-value" id="acc-total">—</div><div class="stat-label">Indicateurs clés de performance (KPI)</div></div></div>
      <div class="stat-card ok"><div class="stat-icon-box ok-icon" style="font-size:22px;font-weight:900;">&#10003;</div><div><div class="stat-value" id="acc-ok" style="color:var(--green)">—</div><div class="stat-label">Objectifs Atteints</div></div></div>
      <div class="stat-card warn"><div class="stat-icon-box warn-icon" style="font-size:22px;font-weight:900;">!</div><div><div class="stat-value" id="acc-warn" style="color:var(--yellow)">—</div><div class="stat-label">En Tolérance</div></div></div>
      <div class="stat-card bad"><div class="stat-icon-box bad-icon" style="font-size:20px;font-weight:900;">&#10005;</div><div><div class="stat-value" id="acc-bad" style="color:var(--red)">—</div><div class="stat-label">Hors Cible</div></div></div>
    </div>

    <!-- Quick access cards -->
    <div style="margin-top:8px;margin-bottom:8px">
      <div style="font-family:'Plus Jakarta Sans',sans-serif;font-size:13px;font-weight:700;color:var(--navy);text-transform:uppercase;letter-spacing:1.5px;margin-bottom:14px;display:flex;align-items:center;gap:10px">Accès rapide<span style="flex:1;height:1.5px;background:var(--border);display:block"></span></div>
      <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(200px,1fr));gap:14px">
        <div onclick="showPage('politique')" class="accueil-quick-card"><div class="aqc-icon">📋</div><div class="aqc-title">Politique QSE</div><div class="aqc-desc">Lettre d'engagement & engagements</div></div>
        <div onclick="showPage('dashboard')" class="accueil-quick-card"><div class="aqc-icon">▤</div><div class="aqc-title">Tableau de Bord KPI</div><div class="aqc-desc">Vue d'ensemble des indicateurs</div></div>
        <div onclick="showPage('visualisation')" class="accueil-quick-card"><div class="aqc-icon">▲</div><div class="aqc-title">Visualisation</div><div class="aqc-desc">Graphiques et analyses</div></div>
        <div onclick="showPage('calculateur')" class="accueil-quick-card"><div class="aqc-icon">∑</div><div class="aqc-title">Calculateur</div><div class="aqc-desc">Calculer un KPI</div></div>
        <div onclick="showPage('excel')" class="accueil-quick-card"><div class="aqc-icon">▥</div><div class="aqc-title">Tableau Excel</div><div class="aqc-desc">Saisie et export</div></div>
        <div onclick="showPage('objectifs')" class="accueil-quick-card"><div class="aqc-icon">◎</div><div class="aqc-title">Objectifs Stratégiques</div><div class="aqc-desc">Axes et KPIs par processus</div></div>
        <div onclick="showPage('cartographie')" class="accueil-quick-card"><div class="aqc-icon">◈</div><div class="aqc-title">Cartographie</div><div class="aqc-desc">Carte des processus</div></div>
        <div onclick="showPage('rapport')" class="accueil-quick-card"><div class="aqc-title">Rapport de Processus</div><div class="aqc-desc">Rapport détaillé par processus</div></div>
        <div onclick="showPage('suivi')" class="accueil-quick-card"><div class="aqc-title">Suivi des Actions</div><div class="aqc-desc">Actions correctives et suivi</div></div>
      </div>
    </div>
  </div>

  <!-- ===== PAGE: POLITIQUE ===== -->
  <div class="page" id="page-politique">
    <div class="section-head"><h2>Lettre d'Engagement & Politique QSE</h2><div class="section-line"></div></div>
    <div class="pol-doc">
      <div class="pol-doc-header">
        <img id="pol-logo-img" src="" alt="Logo" style="width:70px;height:70px;border-radius:12px;background:white;padding:8px;object-fit:contain">
        <div class="pol-doc-title">
          <div class="ver">Version 3 Mars 2026</div>
          <h1>VENTEC INDUSTRIES<br>Politique Qualité, Sécurité & Environnement</h1>
          <div style="font-size:12px;color:var(--gray);margin-top:6px;font-style:italic">Filiale du Groupe Ventec</div>
        </div>
      </div>
      <p>Dans un contexte industriel et économique en constante évolution, <strong>Ventec Industries</strong> — <strong>filiale du Groupe Ventec</strong> spécialisée dans la fabrication de gaines de ventilation — affirme son <strong>engagement stratégique envers la qualité, la sécurité et l'environnement.</strong></p>
      <p>Notre ambition est de développer nos activités industrielles de manière <strong>responsable, durable et innovante</strong>, tout en garantissant la <strong>santé et la sécurité</strong> de nos collaborateurs, partenaires et intervenants.</p>
      <p>La présente politique QSE définit les <strong>principes directeurs et les orientations stratégiques</strong> qui guident nos décisions et nos actions. Elle traduit notre volonté de :</p>
      <ul class="pol-list">
        <li>Assurer la pérennité de l'entreprise par la performance industrielle et la satisfaction durable des clients</li>
        <li>Garantir la santé et la sécurité au travail en intégrant la sécurité dans tous les processus et en maîtrisant les principaux risques industriels</li>
        <li>Réduire les impacts environnementaux des activités et promouvoir une utilisation responsable et durable des ressources naturelles</li>
        <li>Renforcer la croissance durable et l'amélioration continue du système QSE afin de soutenir le développement et l'agrandissement de l'entreprise, tout en maîtrisant les risques et en assurant la satisfaction durable des parties intéressées</li>
      </ul>
      <div class="pol-section-title">Nos Engagements</div>
      <div class="pol-engagements-grid">
        <div class="pol-eng"><span class="pol-eng-icon pol-eng-icon-blue">01</span><div><strong>Performance Industrielle</strong>Assurer la pérennité par la performance et la satisfaction des clients</div></div>
        <div class="pol-eng"><span class="pol-eng-icon pol-eng-icon-blue">02</span><div><strong>Santé & Sécurité au Travail</strong>Intégrer la sécurité dans tous les processus, maîtriser les risques industriels et garantir des conditions sûres et saines</div></div>
        <div class="pol-eng"><span class="pol-eng-icon pol-eng-icon-blue">03</span><div><strong>Protection de l'Environnement</strong>Réduire les impacts environnementaux, promouvoir une utilisation responsable des ressources naturelles</div></div>
        <div class="pol-eng"><span class="pol-eng-icon pol-eng-icon-blue">04</span><div><strong>Amélioration Continue</strong>Renforcer la croissance durable et le système QSE afin de soutenir le développement de l'entreprise</div></div>
        <div class="pol-eng"><span class="pol-eng-icon pol-eng-icon-blue">05</span><div><strong>Conformité Réglementaire</strong>Respecter toutes les exigences légales et réglementaires applicables à nos activités</div></div>
        <div class="pol-eng"><span class="pol-eng-icon pol-eng-icon-blue">06</span><div><strong>Implication du Personnel</strong>Encourager la participation active et l'engagement de l'ensemble du personnel</div></div>
      </div>
      <div class="pol-section-title">Notre Système de Management QSE — Engagements de Direction</div>
      <ul class="pol-list">
        <li>Assumer la responsabilité de l'efficacité du système QSE</li>
        <li>Soutenir le Responsable QSE dans ses missions et fournir les ressources nécessaires</li>
        <li>Respecter toutes les exigences légales et réglementaires applicables</li>
        <li>Améliorer continuellement nos pratiques pour atteindre l'excellence opérationnelle</li>
        <li>Garantir des conditions de travail sûres, saines et conformes aux normes en vigueur</li>
        <li>Encourager la participation des travailleurs en matière de Santé et Sécurité au travail</li>
        <li>Piloter le système selon une approche proactive de gestion des risques</li>
      </ul>
      <p style="margin-top:16px;font-style:italic;color:var(--gray);font-size:13.5px">Pour la réussite de cette démarche, nous comptons sur l'implication et l'engagement de l'ensemble du personnel de Ventec Industries.</p>
      <div class="pol-sig-row">
        <div class="sig-item"><strong>DIRECTION GÉNÉRALE</strong><span>Ventec Industries</span><span class="sig-zone">Signature</span></div>
        <div class="sig-item"><strong>COMITÉ DE DIRECTION</strong><span>Ventec Industries</span><span class="sig-zone">Signature</span></div>
        <div class="sig-item"><strong>RESPONSABLE QSE</strong><span>Service QSE</span><span class="sig-zone">Signature</span></div>
      </div>
    </div>
  </div>

  <!-- ===== PAGE: CARTOGRAPHIE ===== -->
  <div class="page" id="page-cartographie">
    <div class="section-head"><h2>Cartographie Générale des Processus</h2><div class="section-line"></div></div>
    <div class="carto-wrapper">
      <!-- En-tête document comme le Word -->
      <div style="display:flex;align-items:center;border:2px solid #2e5596;border-radius:8px;overflow:hidden;margin-bottom:20px;box-shadow:0 2px 10px rgba(14,32,58,0.10)">
        <div style="padding:10px 18px;border-right:2px solid #cad7ef;min-width:200px;display:flex;align-items:center;gap:10px">
          <img id="carto-logo-img" src="" alt="Logo Ventec" style="width:48px;height:48px;border-radius:8px;background:#ffffff;padding:4px;object-fit:contain;border:2px solid #2e5596;flex-shrink:0">
          <div>
            <div style="font-family:'Plus Jakarta Sans',sans-serif;font-weight:900;font-size:13px;color:#0f203a;letter-spacing:0.5px">VENTEC INDUSTRIES</div>
            <div style="font-size:9px;color:#2e5596;letter-spacing:1.5px;text-transform:uppercase;font-weight:600;margin-top:2px">Filiale Ventec Groupe</div>
          </div>
        </div>
        <div style="flex:1;text-align:center;padding:14px;border-right:1.5px solid #bbb">
          <div style="font-family:'Plus Jakarta Sans',sans-serif;font-size:18px;font-weight:800;color:#0f203a;letter-spacing:1.5px">CARTOGRAPHIE GÉNÉRALE DES PROCESSUS</div><div style="font-size:10px;color:#2e5596;font-weight:600;letter-spacing:1px;margin-top:3px;text-transform:uppercase">Ventec Industries — Système de Management QSE</div>
        </div>
        <div style="padding:14px 24px;font-family:'Plus Jakarta Sans',sans-serif;font-size:15px;font-weight:800;color:#ffffff;background:#2e5596;min-width:80px;display:flex;flex-direction:column;align-items:center;justify-content:center"><div>CG-A</div><div style="font-size:9px;font-weight:500;opacity:0.8;margin-top:2px">v2026</div></div>
      </div>

      <!-- Schéma cartographie style Word -->
      <div style="position:relative;background:white;border-radius:8px;overflow:hidden;min-width:700px">

        <!-- Ovals gauche/droite + bandes -->
        <div style="display:flex;align-items:center;gap:0;min-height:520px;padding:0">

          <!-- Oval gauche - Exigences clients -->
          <div style="flex-shrink:0;width:72px;margin-right:8px;display:flex;flex-direction:column;align-items:center;gap:12px;padding:16px 0">
            <div style="background:#b8c8d8;border-radius:50%;width:68px;height:160px;display:flex;align-items:center;justify-content:center;writing-mode:vertical-rl;transform:rotate(180deg);font-size:9px;font-weight:700;color:#2c3e50;text-align:center;letter-spacing:0.5px;padding:8px 4px;line-height:1.3">Attentes Clients</div>
            <div style="text-align:center;font-size:8px;color:#555;font-weight:600;line-height:1.3;max-width:68px">Exigences des clients &amp; parties intéressées</div>
            <div style="width:40px;height:3px;background:#333;position:relative">
              <div style="position:absolute;right:-8px;top:-4px;width:0;height:0;border-left:10px solid #333;border-top:5.5px solid transparent;border-bottom:5.5px solid transparent"></div>
            </div>
          </div>

          <!-- Zone centrale avec 3 bandes -->
          <div style="flex:1;display:flex;flex-direction:column;gap:10px;padding:10px 0">

            <!-- === PROCESSUS DE MANAGEMENT === -->
            <div style="position:relative">
              <div style="background:#f4c6a8;border-radius:6px 6px 0 0;padding:5px 12px;font-size:10px;font-weight:700;color:#7a3a10;text-align:center;letter-spacing:1px">Processus de Management</div>
              <div style="background:#f9deca;border-radius:0 0 6px 6px;padding:14px 16px;display:flex;justify-content:center;gap:20px;min-height:90px;align-items:center;border:1.5px solid #e8a882;border-top:none">
                <div onclick="showPage('dashboard')" style="background:white;border:2px solid #f0f4ff;border-radius:6px;padding:10px 18px;text-align:center;cursor:pointer;min-width:100px;transition:all 0.2s" onmouseover="this.style.background='#f9deca'" onmouseout="this.style.background='white'">
                  <div style="font-family:'Plus Jakarta Sans',sans-serif;font-weight:800;font-size:12px;color:#333">MPM1</div>
                  <div style="font-size:10px;color:#555;margin-top:3px">Management<br>Général</div>
                </div>
                <div onclick="showPage('dashboard')" style="background:white;border:2px solid #f0f4ff;border-radius:6px;padding:10px 18px;text-align:center;cursor:pointer;min-width:100px;transition:all 0.2s" onmouseover="this.style.background='#f9deca'" onmouseout="this.style.background='white'">
                  <div style="font-family:'Plus Jakarta Sans',sans-serif;font-weight:800;font-size:12px;color:#333">MPM2</div>
                  <div style="font-size:10px;color:#555;margin-top:3px">Management QSE</div>
                </div>
                <div onclick="showPage('dashboard')" style="background:white;border:2px solid #f0f4ff;border-radius:6px;padding:10px 18px;text-align:center;cursor:pointer;min-width:100px;transition:all 0.2s" onmouseover="this.style.background='#f9deca'" onmouseout="this.style.background='white'">
                  <div style="font-family:'Plus Jakarta Sans',sans-serif;font-weight:800;font-size:12px;color:#333">MPM3</div>
                  <div style="font-size:10px;color:#555;margin-top:3px">Management RH</div>
                </div>
              </div>
            </div>

            <!-- Flèches échanges Management / Réalisation -->
            <div style="display:flex;justify-content:space-between;padding:0 24px;align-items:center">
              <div style="display:flex;flex-direction:column;align-items:center;font-size:9px;color:#555;font-weight:600;gap:2px">
                <div style="width:0;height:0;border-left:7px solid transparent;border-right:7px solid transparent;border-top:10px solid #555"></div>
                <div>Directives + objectifs stratégiques</div>
              </div>
              <div style="display:flex;flex-direction:column;align-items:center;font-size:9px;color:#555;font-weight:600;gap:2px">
                <div style="width:0;height:0;border-left:7px solid transparent;border-right:7px solid transparent;border-bottom:10px solid #555"></div>
                <div>Données sur les performances opérationnelles</div>
              </div>
            </div>

            <!-- === PROCESSUS DE RÉALISATION (flèche bleue) === -->
            <div style="position:relative">
              <div style="background:linear-gradient(135deg,#0f203a,#2e5596);clip-path:polygon(0 0, calc(100% - 30px) 0, 100% 50%, calc(100% - 30px) 100%, 0 100%);padding:0;min-height:110px;display:flex;align-items:center">
                <div style="padding:12px 60px 12px 16px;width:100%;display:flex;align-items:center;justify-content:center;gap:24px">
                  <div onclick="showPage('dashboard')" style="background:white;border-radius:6px;padding:12px 22px;text-align:center;cursor:pointer;min-width:120px;border:2px solid #f0f4ff;transition:all 0.2s" onmouseover="this.style.background='#e8f0fb'" onmouseout="this.style.background='white'">
                    <div style="font-family:'Plus Jakarta Sans',sans-serif;font-weight:800;font-size:13px;color:#2e5596;font-weight:900">MPR4</div>
                    <div style="font-size:10px;color:#333;margin-top:4px;font-weight:600">PRODUCTION</div>
                  </div>
                  <!-- Flèche interne bleu foncé -->
                  <div style="color:white;font-size:28px;font-weight:900"></div>
                  <div onclick="showPage('dashboard')" style="background:white;border-radius:6px;padding:12px 22px;text-align:center;cursor:pointer;min-width:120px;border:2px solid #f0f4ff;transition:all 0.2s" onmouseover="this.style.background='#e8f0fb'" onmouseout="this.style.background='white'">
                    <div style="font-family:'Plus Jakarta Sans',sans-serif;font-weight:800;font-size:13px;color:#2e5596;font-weight:900">MPR5</div>
                    <div style="font-size:10px;color:#333;margin-top:4px;font-weight:600">Finance &amp;<br>Comptabilité</div>
                  </div>
                </div>
              </div>
              <div style="text-align:center;font-size:9px;color:#666;font-weight:600;margin-top:4px;letter-spacing:0.5px">Processus de Réalisation</div>
            </div>

            <!-- Flèches échanges Réalisation / Support -->
            <div style="display:flex;justify-content:space-between;padding:0 24px;align-items:center">
              <div style="display:flex;flex-direction:column;align-items:center;font-size:9px;color:#555;font-weight:600;gap:2px">
                <div style="width:0;height:0;border-left:7px solid transparent;border-right:7px solid transparent;border-top:10px solid #555"></div>
                <div>Demande des ressources</div>
              </div>
              <div style="display:flex;flex-direction:column;align-items:center;font-size:9px;color:#555;font-weight:600;gap:2px">
                <div style="width:0;height:0;border-left:7px solid transparent;border-right:7px solid transparent;border-bottom:10px solid #555"></div>
                <div>Fournitures de ressources</div>
              </div>
            </div>

            <!-- === PROCESSUS DE SUPPORT (bande verte) === -->
            <div style="position:relative">
              <div style="background:#5cb85c;border-radius:6px 6px 0 0;padding:5px 12px;font-size:10px;font-weight:700;color:white;text-align:center;letter-spacing:1px">Processus de Support</div>
              <div style="background:#7dc87d;border-radius:0 0 6px 6px;padding:14px 16px;display:flex;justify-content:center;gap:14px;min-height:90px;align-items:center;border:1.5px solid #4cae4c;border-top:none;flex-wrap:wrap">
                <div onclick="showPage('dashboard')" style="background:white;border:2px solid #f0f4ff;border-radius:6px;padding:10px 14px;text-align:center;cursor:pointer;min-width:90px;transition:all 0.2s" onmouseover="this.style.background='#d9f0d9'" onmouseout="this.style.background='white'">
                  <div style="font-family:'Plus Jakarta Sans',sans-serif;font-weight:800;font-size:12px;color:#2d6a2d">MPS1</div>
                  <div style="font-size:10px;color:#333;margin-top:3px">Achats</div>
                </div>
                <div onclick="showPage('dashboard')" style="background:white;border:2px solid #f0f4ff;border-radius:6px;padding:10px 14px;text-align:center;cursor:pointer;min-width:90px;transition:all 0.2s" onmouseover="this.style.background='#d9f0d9'" onmouseout="this.style.background='white'">
                  <div style="font-family:'Plus Jakarta Sans',sans-serif;font-weight:800;font-size:12px;color:#2d6a2d">MPS2</div>
                  <div style="font-size:10px;color:#333;margin-top:3px">Logistique</div>
                </div>
                <div onclick="showPage('dashboard')" style="background:white;border:2px solid #f0f4ff;border-radius:6px;padding:10px 14px;text-align:center;cursor:pointer;min-width:90px;transition:all 0.2s" onmouseover="this.style.background='#d9f0d9'" onmouseout="this.style.background='white'">
                  <div style="font-family:'Plus Jakarta Sans',sans-serif;font-weight:800;font-size:12px;color:#2d6a2d">MPS4</div>
                  <div style="font-size:10px;color:#333;margin-top:3px">Systèmes<br>d'information</div>
                </div>
                <div onclick="showPage('dashboard')" style="background:white;border:2px solid #f0f4ff;border-radius:6px;padding:10px 14px;text-align:center;cursor:pointer;min-width:90px;transition:all 0.2s" onmouseover="this.style.background='#d9f0d9'" onmouseout="this.style.background='white'">
                  <div style="font-family:'Plus Jakarta Sans',sans-serif;font-weight:800;font-size:12px;color:#2d6a2d">MPS5</div>
                  <div style="font-size:10px;color:#333;margin-top:3px">Moyens Généraux</div>
                </div>
              </div>
            </div>

          </div><!-- fin zone centrale -->

          <!-- Oval droite - Satisfaction clients -->
          <div style="flex-shrink:0;width:72px;margin-left:8px;display:flex;flex-direction:column;align-items:center;gap:12px;padding:16px 0">
            <div style="text-align:center;font-size:8px;color:#555;font-weight:700;line-height:1.3;max-width:68px;font-style:italic">Retours d'informations</div>
            <div style="width:40px;height:3px;background:#333;position:relative">
              <div style="position:absolute;left:-8px;top:-4px;width:0;height:0;border-right:10px solid #333;border-top:5.5px solid transparent;border-bottom:5.5px solid transparent"></div>
            </div>
            <div style="background:#b8c8d8;border-radius:50%;width:68px;height:200px;display:flex;align-items:center;justify-content:center;writing-mode:vertical-rl;font-size:9px;font-weight:700;color:#2c3e50;text-align:center;letter-spacing:0.5px;padding:8px 4px;line-height:1.3">Satisfaction Clients et parties intéressées</div>
            <div style="text-align:center;font-size:8px;font-weight:700;color:#2d6a2d;max-width:68px;line-height:1.3">Produits &amp; Services</div>
            <div style="width:40px;height:3px;background:#333;position:relative">
              <div style="position:absolute;right:-8px;top:-4px;width:0;height:0;border-left:10px solid #333;border-top:5.5px solid transparent;border-bottom:5.5px solid transparent"></div>
            </div>
          </div>

        </div><!-- fin flex ovals + centrale -->

        <!-- Pied de document avec signatures comme dans le Word -->
        <div style="margin-top:20px;border:2px solid #2e5596;border-radius:8px;overflow:hidden;max-width:560px;margin-left:auto;margin-right:auto;box-shadow:0 2px 8px rgba(14,32,58,0.08)">
          <div style="background:#2e5596;padding:6px 16px;display:flex;align-items:center;gap:8px">
            <img id="carto-footer-logo" src="" alt="Logo" style="width:24px;height:24px;border-radius:4px;background:white;padding:2px;object-fit:contain">
            <span style="font-family:'Plus Jakarta Sans',sans-serif;font-size:11px;font-weight:700;color:#ffffff;letter-spacing:1px">SIGNATURES & APPROBATION</span>
          </div>
          <div style="display:flex">
            <div style="flex:1;border-right:2px solid #cad7ef;padding:8px 16px;font-size:11px;font-weight:700;color:#0f203a;background:#f4f7fd">Responsable QSE</div>
            <div style="flex:1;padding:8px 16px;font-size:11px;font-weight:700;color:#0f203a;background:#f4f7fd">Direction Générale</div>
          </div>
          <div style="display:flex;min-height:50px">
            <div style="flex:1;border-right:2px solid #cad7ef;padding:8px;border-top:1px solid #cad7ef"></div>
            <div style="flex:1;padding:8px;border-top:1px solid #cad7ef"></div>
          </div>
        </div>
        <div style="margin-top:12px;font-size:10.5px;color:#1f2f53;padding:4px 2px;font-weight:500">📅 Version : 25/02/2026 &nbsp;|&nbsp; <strong>Ventec Industries</strong> — Filiale Ventec Groupe &nbsp;|&nbsp; <span style="color:#2e5596;font-style:italic">Cliquez sur un processus pour accéder au tableau de bord KPI</span></div>
      </div>
    </div>
  </div>

  <!-- ===== PAGE: OBJECTIFS ===== -->
  <div class="page" id="page-objectifs">
    <div class="section-head"><h2>Axes Stratégiques &amp; Objectifs</h2><div class="section-line"></div></div>
    <div id="obj-page-subtitle" style="background:#ffffff;border-left:4px solid #2e5596;border-radius:0 8px 8px 0;padding:8px 18px;font-size:13px;font-weight:600;color:#1f2f53;margin-bottom:16px;display:flex;align-items:center;gap:8px"><span style="font-size:16px">🔒</span> <span id="obj-page-title">Chargement...</span> — Les axes et objectifs ci-dessous correspondent à votre processus</div>
    <div id="axes-container"></div>
  </div>

  <!-- ===== PAGE: DASHBOARD ===== -->
  <div class="page" id="page-dashboard">
    <div class="section-head"><h2>Tableau de Bord KPI</h2><div class="section-line"></div></div>
    <div class="dash-stats">
      <div class="stat-card total"><div class="stat-icon-box total-icon">KPI</div><div><div class="stat-value" id="stat-total">0</div><div class="stat-label">KPI Suivi</div></div></div>
      <div class="stat-card ok"><div class="stat-icon-box ok-icon" style="font-size:22px;font-weight:900;">&#10003;</div><div><div class="stat-value" id="stat-ok" style="color:var(--green)">0</div><div class="stat-label">Objectifs Atteints</div></div></div>
      <div class="stat-card warn"><div class="stat-icon-box warn-icon" style="font-size:22px;font-weight:900;">!</div><div><div class="stat-value" id="stat-warn" style="color:var(--yellow)">0</div><div class="stat-label">En Tolérance</div></div></div>
      <div class="stat-card bad"><div class="stat-icon-box bad-icon" style="font-size:20px;font-weight:900;">&#10005;</div><div><div class="stat-value" id="stat-bad" style="color:var(--red)">0</div><div class="stat-label">Hors Cible</div></div></div>
    </div>
    <div class="dash-filter-bar">
      <span style="font-size:12.5px;font-weight:600;color:var(--text-mid)">Filtrer :</span>
      <button class="filter-btn active" onclick="filterKPI('all',this)">Tous</button>
      <button class="filter-btn" onclick="filterKPI('M',this)">Mensuel</button>
      <button class="filter-btn" onclick="filterKPI('T',this)">Trimestriel</button>
      <button class="filter-btn" onclick="filterKPI('S',this)">Semestriel</button>
      <button class="filter-btn" onclick="filterKPI('A',this)">Annuel</button>
    </div>
    <div class="kpi-grid" id="kpi-grid"></div>
  </div>

  <!-- ===== PAGE: CALCULATEUR ===== -->
  <div class="page" id="page-calculateur">
    <div class="section-head"><h2>Calculateur de KPI</h2><div class="section-line"></div></div>
    <div class="calc-select-wrap">
      <label> Sélectionnez un indicateur à calculer :</label>
      <select id="calc-select" onchange="showCalcForm()"><option value="">— Choisir un KPI —</option></select>
    </div>
    <div id="calc-form-area"></div>
  </div>

  <!-- ===== PAGE: VISUALISATION ===== -->
  <div class="page" id="page-visualisation">
    <div class="section-head"><h2>Visualisation — Analyse KPI</h2><div class="section-line"></div></div>

    <!-- Summary KPI ribbon -->
    <div id="viz-summary-ribbon" style="display:grid;grid-template-columns:repeat(4,1fr);gap:14px;margin-bottom:22px"></div>

    <!-- Donut + filter bar -->
    <div style="display:flex;align-items:center;gap:18px;margin-bottom:20px;flex-wrap:wrap">
      <div class="viz-topbar" style="margin-bottom:0">
        <span style="font-size:12.5px;font-weight:600;color:var(--text-mid)">Fréquence :</span>
        <button class="filter-btn active" id="viz-freq-M" onclick="filterViz('M',this)">Mensuel</button>
        <button class="filter-btn" id="viz-freq-T" onclick="filterViz('T',this)">Trimestriel</button>
        <button class="filter-btn" id="viz-freq-S" onclick="filterViz('S',this)">Semestriel</button>
        <button class="filter-btn" id="viz-freq-A" onclick="filterViz('A',this)">Annuel</button>
      </div>
      <div style="display:flex;align-items:center;gap:8px">
        <span style="font-size:12.5px;font-weight:600;color:var(--text-mid)">Graphique :</span>
        <button class="filter-btn active" id="viz-type-bar" onclick="setVizType('bar',this)">Barres</button>
        <button class="filter-btn" id="viz-type-line" onclick="setVizType('line',this)">Lignes</button>
        <button class="filter-btn" id="viz-type-area" onclick="setVizType('area',this)">Aires</button>
      </div>
      <div style="margin-left:auto;font-size:11.5px;color:var(--gray);font-weight:500" id="viz-count-label"></div>
    </div>

    <!-- Status donut + charts -->
    <div id="viz-status-row" style="display:grid;grid-template-columns:220px 1fr;gap:18px;margin-bottom:20px;align-items:start">
      <div style="background:white;border-radius:16px;padding:20px;box-shadow:var(--shadow);border:1.5px solid var(--border)">
        <div style="font-family:'Plus Jakarta Sans',sans-serif;font-size:12px;font-weight:700;color:var(--navy);text-transform:uppercase;letter-spacing:1px;margin-bottom:14px">Statut Global</div>
        <div style="position:relative;height:160px"><canvas id="viz-donut-chart"></canvas></div>
        <div id="viz-donut-legend" style="margin-top:14px;display:flex;flex-direction:column;gap:8px;font-size:12px"></div>
      </div>
      <div id="viz-progress-section">
        <div style="font-family:'Plus Jakarta Sans',sans-serif;font-size:12px;font-weight:700;color:var(--navy);text-transform:uppercase;letter-spacing:1px;margin-bottom:14px">Performance par KPI (dernière valeur vs cible)</div>
        <div id="viz-progress-bars" style="background:white;border-radius:16px;padding:20px;box-shadow:var(--shadow);border:1.5px solid var(--border)"></div>
      </div>
    </div>

    <div class="viz-section-title">Graphiques Détaillés par KPI</div>
    <div id="viz-charts" class="charts-grid"></div>
  </div>

  <!-- ===== PAGE: EXCEL ===== -->
  <div class="page" id="page-excel">
    <div class="section-head"><h2>Tableau de Bord Excel — Saisie & Résultats</h2><div class="section-line"></div></div>
    <div class="excel-section">
      <div class="excel-toolbar">
        <div class="excel-toolbar-title">Tableau de Bord KPI — Ventec Industries 2026</div>
        <div class="excel-toolbar-btns">
          <button class="excel-btn secondary" onclick="resetExcel()">Réinitialiser</button>
          <button class="excel-btn secondary" onclick="window.print()">Imprimer</button>
          <button class="excel-btn primary" onclick="exportExcel()">Exporter Excel</button>
        </div>
      </div>
      <div class="excel-proc-tabs" id="excel-tabs"></div>
      <div class="excel-table-wrap">
        <table class="excel-table" id="excel-table">
          <thead id="excel-thead"></thead>
          <tbody id="excel-tbody"></tbody>
        </table>
      </div>
      <div class="excel-footer">
        <div class="excel-legend-item"><div class="excel-legend-dot" style="background:var(--green)"></div>Objectif atteint</div>
        <div class="excel-legend-item"><div class="excel-legend-dot" style="background:var(--yellow)"></div>En tolérance</div>
        <div class="excel-legend-item"><div class="excel-legend-dot" style="background:var(--red)"></div>Hors cible</div>
        <div class="excel-legend-item"><div class="excel-legend-dot" style="background:#ccc"></div>Non calculé</div>
        <span style="margin-left:auto;font-size:11.5px;color:var(--gray)">Les calculs se mettent à jour automatiquement · Données sauvegardées en session</span>
      </div>
    </div>
  </div>

  <!-- ===== PAGE: RAPPORT DE PROCESSUS ===== -->
  <div class="page" id="page-rapport">
    <div class="section-head">
      <h2>Rapport de Processus</h2>
      <div class="section-line"></div>
      <button class="print-btn" onclick="window.print()">Imprimer</button>
    </div>
    <div style="display:flex;align-items:center;gap:14px;margin-bottom:20px;flex-wrap:wrap">
      <label style="font-size:13px;font-weight:600;color:var(--navy)">Processus :</label>
      <select class="rapport-proc-select" id="rapport-proc-select" onchange="buildRapport()"></select>
      <label style="font-size:13px;font-weight:600;color:var(--navy)">Période :</label>
      <select class="rapport-proc-select" id="rapport-period-select" onchange="buildRapport()" style="min-width:160px">
        <option value="0">Mar 2026</option>
        <option value="1">Avr 2026</option>
        <option value="2">Mai 2026</option>
        <option value="3">Jun 2026</option>
        <option value="4">Jul 2026</option>
        <option value="5">Aoû 2026</option>
        <option value="6">Sep 2026</option>
        <option value="7">Oct 2026</option>
        <option value="8">Nov 2026</option>
        <option value="9">Déc 2026</option>
        <option value="10">Jan 2027</option>
        <option value="11">Fév 2027</option>
      </select>
    </div>
    <div id="rapport-content"></div>
  </div>

  <!-- ===== PAGE: SUIVI DES ACTIONS ===== -->
  <div class="page" id="page-suivi">
    <div class="section-head"><h2>Suivi des Actions</h2><div class="section-line"></div><span id="suivi-count-label" style="font-size:12px;color:var(--gray);white-space:nowrap"></span></div>
    <div class="suivi-stats">
      <div class="suivi-stat"><div class="ssv" id="suivi-total">0</div><div class="ssl">Actions totales</div></div>
      <div class="suivi-stat ouvert"><div class="ssv" id="suivi-ouvert">0</div><div class="ssl">Ouverts</div></div>
      <div class="suivi-stat en-cours"><div class="ssv" id="suivi-encours">0</div><div class="ssl">En cours</div></div>
      <div class="suivi-stat cloture"><div class="ssv" id="suivi-cloture">0</div><div class="ssl">Clôturées</div></div>
    </div>
    <div class="suivi-filter-bar">
      <span style="font-size:12.5px;font-weight:600;color:var(--navy);margin-right:4px">STATUT :</span>
      <button class="filter-btn active" onclick="filterSuivi('tous',this)">Tous</button>
      <button class="filter-btn" onclick="filterSuivi('Ouvert',this)">Ouvert</button>
      <button class="filter-btn" onclick="filterSuivi('En cours',this)">En cours</button>
      <button class="filter-btn" onclick="filterSuivi('Clôturé',this)">Clôturé</button>
    </div>
    <div id="suivi-actions-list"></div>
  </div>

</div>
<script>
// ==================== LOGO SVG ====================
const LOGO_SVG = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAA4QAAAErCAYAAACGm00pAAEAAElEQVR42uz9aaxtXXYdhs2xTnfvfd/HqmKRlEVSpKiOVEOrsx0pkG01diDIjmIgMmAJjgE7yQ8DNmRbiBw4gRMgkJJAsGQ1gTs4EWJZlpQogRxZFCXKpDpLFEVKpDqSYmf2qmJVsareu805Z6+RH3vvtWa39rlPQf7xEcWq73v3nrObteaac8wxx8BnP/s5CiAQESGF8/8SEUqtlDdvHuRw2AtJyf48Pj7JNNX2O2i/LwKI3D88yG4HCb8OkVqrvDy9iP6r/nOU4/Egh8NBRn9ICjB/33Wa5n+ef1W4fOrhcBAA7foBSJ2qvLychUIB1p9X33s6ya6U4feezxe5Xq/qmczXUArk7nQSFP0MMN/ny4uw0n7P8TR8ti8vL3K5TLLcXv8ZUvaHg9zdndSjhOhPnqYqT0/P7XfXS1zfzeFwkMNhP7y/6/Uq5/NlfihQL2b5wNPpKLvdbvj7z88vcrlcJFsyu/1O3jzcD3/35eUs5/O5vdf5Avpzvr+/k90ueTcQuVyu8vL8Yv/l+rtYfnfwXqepyvPzc7thgCKEcLn1w2Enp9Mx/V0Acr1e5fn5RV13X1RTrXI6HeV0OqXvutYqT09PQoocj8f23rBct/6dqVY5Hg5SSgnvfb6PabmPvi7nfT1f0un+To6DNUdSHh+f1Fpbb6H/7Js3D7Lb7cLvA5CXl5d53Qjc51Y5Ho9yd3caxpHnpxe5XC/uvfe9cnd3ksPhsLFXrup37XXd399JKWjPYL3Xp6dnIdnWKaSv8ePpKMfs+zBf2fPzWS6Xfr16qwhFTncnORx26R54fnqWWqsIiqyRirXKfr+T/WE/P3dy/o+KGRSR42Gf7r1aKY+Pj+pCYN7r8XjYfP7ruwMgbdEv91Z2pT9DmocrEJHr5SpPT0/zz6v4PT8syMPDfTsDzG4G0v2uX2OINeoDKquQlIJ5L1ynSS6Xi7lvERHW+f6Pp+PmOeb/juzn4MPD3XD9icgc7yr90hdA5Hqd8li4K3I6ncQ9sb6Xr1d5fjmbvaiii9zf38l+X9LPFlIeH9d1pk7l5X+UUuTu7pTumfkMmOYzi+5bl+s4Hg/DeCgi8vT0LNM09c9XsYSk3J1Om+/j3btH8/vrHay74eHhQfa7XYh/gMh1qstemCOkuDgJQN68eRjeOyny/PQkU+1xUEfCUuY1DR2oOS/M9X2/e/fkt2F7BgWQN2/uBcOzaJKX9b2ra17/+3ic479+dhRKnSi7XQln53p5darLOhd7Ucs9n04Hubu7G76Tp6dnuQ7irGB+J6Ug+yuplfJOxSeoXI/LXngY5AUA5PxykZfzWbKvnuPbUY7Hvbo3qHujlFE+B5HL+TI/b5UHrqtGSDkc5+eir0fnk5fLRZ6fnpd4br+dpOz2O3m4vxve2/Pzizy/vEgB3A6fv+d0Gp+dAOTp6Vku67mL+Gzu7+/keDwMf/9yuSz5YvZw5595ePOwhHeb49s6YArPZs3RHx7ux+9g+f1aq1s1/ew63R1FKJt54zRdRaSox6cWGCAAZLeDHI/jPO5yucw55PIu1yPt7i7WBFQLppJSp/kMH8WVy+U65yli1/3d3annaK3GOEutNHEHtI9Af1ddzp7jRr1UK6XWyb4HiImv8xokhTG0hsQuC1A6EAMQW1rZbzW/QSxBdE1AJL7wmIuFhCG9Wth/YzfCcqfr3qG9h/R7fWXVNsr8d/N/p7/aEjsh2qJcA/B8XRurfD2AOb8w6C/aeFD9XazXh7l44PyfjdcaP7Jd4uvXglBE7+3sAHrVH/YHrb9jFLiELnHQBTvDhcSiRvq7pAqupkCLNxQvgz0ZJpB+1+h9mdVsikG1V5ZnWFk3LqL/h+rzsH354YNg4Zrb74/++b7iy1yo6XGELYF81VrZ+DF/Ke09M0aYVkRn3zv6eXUNxPZSZ0vTfHQsCr+Y1/xrXxXC/2Dyn/fYdkW9F2J5HvbwsA8Vm89GJ39+7W/9c5qgqP8T97kYrq/3uH9mL9s+wywG0V3BrVvx4Vzn0gYMorswbKzB5Evmz2LLKObPfOWeWospB35icA6bqyL695kVL687g5IcZD0HgY0V3c6C+Teqy0p4ay/A/wSTt4x4Tg1vb1mr6zmGW/ePtv/zH0yKLiIFM8zlmSW8xlb7O3ztK2mLFzf3LltZ3gtV3k4xB3tvAaWI9nl9LSJ9Z9y6MaowhvjeKGXOmW48lPVJ9/yBHWy8sddaeCLcI7kVtzH4x+2Y70GWrUOOHbK88Tvx88nsXJBXPEtbL9Dno695HrrQWfacK0/GixY6Nud3jNZgwXultcjSBm5FJA+oxbOqFeBurWc1WvwAzMfC8hmFrSiD3e/mA/keURzD3J+jTQ67mDF8wEtPZHt/L3/PJEjDFopJ8ZZeKbNg39FSuluxB2g/ZISDAnTrOaJ/5ih5pX/pWDpcS/Dsv1eX/7w+xkTIK0fokmygLcoCva7wPrHBBu2NAgGuaBSBENvwhkWsaHYdwjuaE4sVbUoiy3rsL10Wqv+8T+KTFUJII0rY8CYAwiw9nRMDr0sGqYLzawIeGXOG9wuWt4tnuQWHuLNwBUNev9BtUvaqb6atN24XAh226KsmL2DNM9kCIsKzhvvP+z1M+jUHWGTUdT38o9XY5qsL+kHuNHoNGLwjxCNFZCOp4zAuw3UcBjE3KQDWxGZNXiU2DyW+UrikKAHC8P7xkwaA5W3AF/o9U4UcqBSR4+UIMV1JrM/ivdJCvStKPN85DixZWQD2Z4C6/VvbCTmGydn7FjY3Xxrzt9QAxNGeTEBGIALrQl3U8z3xWg6+eXzfTKM93nM5s+U4VSdIg8I92VppF18X3zZDfM3KpclTIg76insEFiBiBSxyxkQWFyHyD7kaOT5M9PpD0kRAAmzRxjT8w2wPXwj60xG3EhDmsACTQnF04FA3qWKcMzU+HPSBcYa7LjGSPbZChrls/yybJSAFgHXOEvNkqHoi7gG0lL3M75odDFb/iZ0LbtTzyxJDa531GyLF1dPqgBsdRNl7og3w2UNs1fv23ssTStxcdYCN0uvt6jgO9s6QTZz6Vh+if7qwGdXMG5GbpqPX36tum2MrGVgOTkre65X0TW4cr30hiW2Av29VKNvo/LrJdGD3AQavD0we2GtrCjFJaagyJE2iCb4iPDIgrrbgnv9TgKT4tZEi7NjS7x94RaimKySlo9Xc2hujQIwbQAD9vsd7FTS4hTaDA2Std4TfLy2BDdGqAp7BgFsntT3qKJ1pcOPE22pq2LiiabDvs9+gE+j1kK+bcRGhMtIRAq+oYVS3ITyD8TqvrFJrXZD4OlNIM8T1xhICLNCSIfvAAP3wGdFWUurQ8nF9xzz4QxKAidshpd3aEp9WtsjWumBHwG0qwleySyDb5dp2HDHLQmKPr7+PWPBQ160mPkCd0TdYNv7oNt2w28/gJrFg87XFk5dwJWpjL7Dt+R4/dIfGf46I4YIlSxZbW88/89cCfe366EkY8r7sBb0ekSJSMVM3hTERuqnj94C0bGW6x+NmHrceBouGOUQ6Al5sCDLDWv3/gCGAn7KS9KLYSv3r+5SdfAW4ithd2dhPoZaOmP5yCx2UN93wvN8W1/3KAEwevs1QOI76K9vHgLzjQ8nQ9N17DRu1so1i6PGoWC2wdw9pkTK9Hfa6E0UXEzfJjKQKruyRGDrtX6kBCBxZE7A83Eqsy8jyutT9znM32YE6pg2s/GcdTNmruOHq17OKbOgBPJQR8hpLkXCI2qhG0M9J70/BGLQ0ifcIIcNyiyrb5xZypCgay8JrlMNX8fNUIqHX93tjR7zZEbDJliUckLp94zZJm/lJNujNc98lKIRdQpBXH5xreVCyQVs14yEqGUhnAEXT1mjXg9ma3Dxw1xW4LnWYq+T7oY6Y96m8FmU1//gqnki/ULMRb4EKjjKKASrg9tfwmloMeQWlpvf8N36eJnlrB8qrUV/YGP6qnAu9gOunjC0I3D1XDFBY9OmtwZJWv0JdPvb7FabdbL3+Sco0Tct+roZeSXkdtNxp/XYPUKdHN8KdYombGfYAdMJ+Jpmch7deEV+ZaIZDXPOZfQI4SmWpijyGbvFwFYY8ne8VEzU2SxWmR4TcrCvBQVY5ok6ZmaMB4AFiky7bRm/h6S29YMANBErTwPTO8NUBln+3Ahj6jLhdcDAtV7jVZGuUxmV/4PU0wrggaR4sgM2sk6/5N68o9G6R89g2sM6k8GoMBhpEaDHolTRLxNXdCElbSZ/02T5f43MAoOu8lpoz61LbW41skYzpkBe1wFZVwQW4hh5fT0EzOF2FvrT97IkqS9bcX/A6IEeDMFk8UNfQahV9dr2CJrydRbsCMzmL43Xlec72u6GpUUpDmNzhwARt8fQmJoB+3lFkCnxurbQMR0R4QVv0Cw4oORhdnUl7RwiTZGfsq7ItbKBMuqDMO4RbCGaKaoZgz05JIG+2yzy6tdUKH9SDoc7CK5NljIh0eI8Cbfl3Ra/tRAglvem1oC+Kgvmackb9vj7UX9MlYVZo87XHiX52Dkm9gZ6O1uD6DAr8E8UrMFX79iDyqmdolgt08olh4yX87Pu1+zTR1z2ZspHLYLDm3nc25vWd/9esv1vjja+5lhQQU+IMBmWUdobbcEK+/lvVaYcwswsZzWl21JUyTVWmaVoAHr6OQpaAA/p+29p/D5YmFkoib3AKqZP2TeAC+bNqs6XjlxzO5tYZec1s6ZgQyzFfSuIJ1CF7vlcs30qW8ap0arQ3yMFfgq/YoXz13jYjEshnZXPKH8bxgbaAokrqddjLaPJd68CxoDRd8ta9QRMac6YRhhWu7+hszf/li8XMsmkGGjKAgO8FtPjJ0ttXg6R0Y95des+zACGX4Obm8RiPXzOkbIJqfV8sjZKVXr7xe6NRPI2F8GYJ7nPuJW7g/c9AbJ7ta5dfko646sTpweQAIOVsvlT65IZWRQPrcTsnxhbIpSinFBG+b2BV4NMKVu7pXglTRC9/tUDnqiJTVZkz6j5cChr1OkmQZ9MQ86IK6gLtoHBE/9ocIZh+j//nWun49Ft9ejuQjYAmUCHcSsFV3TsygQ/2ZMRcH7Ra5I0OzUJZA+1bQygZ+IpNGpPCIV3Rg63r4P/7CspAZpXWhPuj7z6gMKSIVMGilOvnmXMdmvFAJ8GGipeeh71ekAWqa/XKUbQsHyT/YYoEpQUGj8fwVcFBd899p2k9FCL4w41o/brB/D4zp5FRGiogsL2i4ECRra6OxvZIXZ9U86z64DbMjBwMGklzKHJzRIPSNRB78WO6A3pW6lZnF16JkYEKz5vP36k0U+81kVL0fDZklEdiSWLS155S/XvzFQNVGMBTQVcV1jrHbhWH7bHwChGRNhdGJcClzr3BdXXqVYhOvaGDRBwB7p8dmrs+b1sgO8VgswJjcUloJgFCC628Yn6983xg1jYZMZJht8wlLsLXx1AMdnX+DvJZUt1d9PsAGuwQR+F28DhkoVZxu9sSlzoF7vu4iK6tI+w0C8x3BtT7gwgW9UM9U7x2eEa5Ulpg67DSueGGjcWhiBKzjHH8vYApuNsUCcfnBzUgighVgTHQFsxEpvc5awO10pPdkPXREWJySH/b+/KdXknVwWUQK3MWCcfHK/1qziO/z58iVRj2PlpMy7tQ+eXZ9gpA08Xu4jb6Z2FjKTsAEgtZG28Jq4/glb+5rBGtlEoPumMrEiGAjK2IzGoh/axdBgu9d5MDRlPATYFKd66zn7d5fNxaZDa/gUD2tvVIy+umPZDFJGRwLwp98bcDY6bwrDYMZD+JIJBSFNqwCnEyBu0+n2EpB52CgyjDTJF6vch0nZZBydjxq3V5gVwP0EUEpZRW0PmzdiLlOlWpZFgkBoXDuMynCyRtK5CKpsdeEDNm9u0d0CJ46w9UTrbP5/j6uNFtY7g/N+yucwz4JGApyWi7KTTfjQSJzl61lTxHerixCThUwh2Oek2iCb40BpRqO5ukXyzk1SSHgbaZ/UBxNpjPDcCi0aDK3GmpggWYyOiIDmkasA1rXelaNRzaujMc3wEkccxQgBkVsqWKfSTUaEqk23G07qw9QlXzan6fzMk61ffaPbDG1doKWVVuhe9dBJaYlLK0h6btcK77aZ5fM2g8FH2HSES55t/f7/dSp9oTOazUrypkMXTIdX7PJBRKzttlUC4u9ZhObhdca0LYimK1xtkasKVl2YHcpA8qwhRH4X25E2t9jlnH1ocI/b211mbZQejyutO/VuuOmNjSxMaqqNhIqXTbs8zZXHhdHmZlXlUW9HMGKv75dzuyiPGFpL6mlR1g6WDzuqQ7r3RPz8zCtLWnE0xNxfcUTo9fV+kDzHo9ZGCqPW+a0rOZhdUpCVxCaRPZ2h68PhqX+y5FgA5ctu4uOj22Lr+OJeZRPc/5sdhnZ9cCDHhBMuQDulsXQUsudiEiUiHEao+FmRYdEn777tYYDNize/3nVQE8O77WYiXOaGLe/3TJp6bOzQleXgS5WMWWKy7v2DnplAyUruzFpcoP1vNFg4UY0LYBf3TSgp1ZcbtqYqizxxeWs7sL1Xf33Kd1cX2BpQFCi0b2mFr7/gVkCIq08ReKoeqTMVfqDZAtimN/P0Wf80gOSkJY9exbpKC2zGp9Rsqio52DdV4XsZTtB7zVg4ABfoKaLOxIGLATgQQLKv2ObLikoez6+kYUmFDni8/XjuhZ/m5nBsxn11RrEzhcGy67shNgnY+fzzpry7Gem6LEwtDPbp2yt3OoClDcBO4Cpqzf//JypkmatYq4RhgHTCwUbCYHGu3O2vuljLnjq8+Up3EBavcq6pCm4axFoi3S5mudpkkul6ud9dsYyNaLYPXA4wANSZUhRfvgzJuiVjGJkN7NZJ293lJ4C3GGzHzlHDRLqzzUi1+CWq0cJ4UyFrhoswrKv9F/RinzZm9CFLQH3uxZSRMQ9B/tOea7Y1wFLpjCYr3wZy5do7vAFmhY0aNiukAaLLGbURS9gI2n3zyYGInXrFszAOy0KM57wncJdAev1qo6WrZzu9vvpE41gxotVW2A6O8KUtWlJqOdeq2t97BLxTe2v5dK3AWjFWlAKn9ulsFaIinX6zQ/T4lqvKWUHrTdHqoTE7ltLS+O9EBdfUdrrd1XCjGxWe+X/noyQkL7vRmIssW8otivLTyXY1PtXWDQbUFf07oIpgJLDAvErct5zbqOI6O0vT2A51hhu6lzwre+sWooqjRQPCGyW5L7Ecy+Kj6vXrmh08Gc9YCQkHTLANONNR3zJKUFh7Y9a0zBEGLHgGmxzE7WaiZFbQKu9gXWgjYvIg2+BftcQofSnAUxUdXvcSV69FDZP097bMWOiLSzW1Jgb7HcYSaMYYuZtcDXcbKSM6gHbHbcJaEzdgDbqfgBKiVBLlyXWT5oNVZX2KfPfU2MXSE9dx1roCb42IQRvQLrnq327DVKh05kGx3n4NrFX5PURDFav9N4tjPkioQo5UhI2e1kxCqrC3hG5pSb0tuxrqlBRbstwzOqTrUtZNNhap9vCxSdcHuFaDogxI+lkK4VT27MAlJSRWw6doLe7LCsnAJxUFB2BnGj7cyNZ3cr1qmwjhy8nc9UOkaGTaGgKaEJaE7W5UyX1Md6vce+RqlLDOW1vtY8UOmjiy/OT3E9B+fvRbjxOQ+pS00wqQKOIc9bfdW9uK7OsQpsPaO7srVOJhfV+QdQZH88HMwne+zp7dtHmaYaRnO43OgHb+5lt98NE7J3bx+lTvPAKNSBLwuC/uaDu65guASFNbF+fj7L5XxV6qG18bLLcqO1Tu6q50Ruv9/L4XAcUu5KgTG91wv16flZ6tWabK7H1105yfF4SOkHdZrk+fm8oPS9Eiq7IofFTLx7yIk8PT4ZpEZ/6OF4zA3YZTa4fHx8ssioWpj7/V7u3tyniY+IyNPTi1zO51QVq5sOn4Yb+/HdU1usPgfb7Xdyf3cQIDe+f3l5kaenlyVZsUMUoMj+YSf7wy6D6YSs8vR4nTdnUnic7tS7Sdbi4+OTLZbQx7DLrsjdwylPPirlcrks+6AfkFRdleNxL4fjaZhkPD4+yeV8caag/WdPp6McDntXbNrOIAC5Xic5v5yN7DvU5z3s93Z9Ij6DaaqhWFwjzPHNw3DdUSiPn3+Uqwp4+sCZDXBz09eX82zeC3Wotk+tlPuH+8Xo2rEM0GPB9Xx1jaP5Bmfj85Ku1cvlIudzDUforuzkgw9Oiv1gC8LHd88NNAq0JXaj8p4ZdcrhNE3y9t07gxjqLiNE5Hg8yv6wn7tbSzwqu2ISCjq3wuv1IufHlzSfKwXy8Oa+d9jg991ZXl5eksRhjpen09G8O6jEpdYq794+pqV6N9d9GNIqH989yrTcp1ZooVDu7u7kdDoZ4G/NWapQnp6epU6TaB9NHWv2+50yw4ZEkhWW/fcsl/O5FeHmlQPywYdvOoiWPODn52eZlME1FB/UFre6c1W0V3XoID49PjdBHBFP7p/BsbuH08CWhPL27bsWk4TWVWK3g7z5QN2TS/6naWom5aaLs5x5ZVfkzcOdpY6pwuF6vcrj43NaQJOUu7vZeN607tWfp6cXOb+8CDSzR3HU37x5kP1+P0xQP//5tzlNkyKH404e7u+Hyek0TfL47ilS/NSa/+CDh/au/fdMU5V3b98NE+jdbicffPCwmRy/ffvOqAnqOHo4HeXhLj9/Wec9EbqOGjB1dMM1r9rtdvLhB2+G7P3L5SpPj+e0VqRA7u6Ocnc6Du/r8fFpMd42lUhLqt+8eSO7UlKm0PU6ydPzi2PXLEl5pZzujsu5RsfUmD/ncj7L88vFEBB1UT9dJ3UzMDuuFJG7uzsDRuvD83q9yvPzSxqZScp+v5P7+4fhWr8u+Vom90XKEgPHhuJPTy8tdnt2CFmX3z8GYKWfnS+L2XqiyltFTnfH2fg9dMv6efbu3VNyb33PfPDmwT0/C8S/e/cu5Lomd2jnacw6pony8vzc8uq1eNQaUHd3p5Y/ZYBArVWepxch53UugQ0h7RycP0ePk0HO5yepdeognSgwZ4mb+12ROlWZrpPKz3qms9+va0yxjpr7QBGgyvU6LYB/HDoupcj+sB8OwkzTJNM0CXY7kbUTCMyWwktRez5fO2NFjRWRIrsdZZ+3WW1SVvQLQMZWG6PAKyVOI02y0jGRmwDrZLBoBBh+hLf2VnZrZBZHYZAxr5fMMQ9ajkEjnimqRKbGtTL5NZ1uRPNZUb7YFBgPRxtKkO+oaE484lA1sNBNFOXCo4VmZoWZOe+M1MhSkGfUqk0vOayc5xLM5nubw3dG7DOndAqyw6gadMktr8SCMO/UhvQ3uliydnDQ6UfQ5vFwVLvknaLklhErilhrnekMihETJbLZumIU2w3qlEoaqkCGFPt3Yvfy+DmgQIoSXIFSzeXWmlUyzXR0TyJb747jv86W6u4YvYG9O2gW+mxJDN6hEnkOVMTX9y3+KMeYSWC6llkjTtFK107i/B53MzXHxQBDJ6NFl6GUT6G4UJSV1rYimhoFdOkOisAkGJSgikwue86uG5hwVkVGforoRNDZOghKJpxRqEAjnlT0IkdbgqHDuzPEkekgliUSBJsqhWXUhVGdn0ZXtJQkJmpClJF4V58x18rNXrCt7IoBT+hUUHUniSsyvMS3UhJlb0ZqYzFqJAbXtqDfeo6EzmGcvTNUPEaDSSwzut1lBK5FydA1sue2s1pw9Kg5B8iB4HWfrHPqHUtNujtDYZLa2DbZSAXo2T/xLPIjLppmD5EoTESbm4miwpGR4TN32Uuj/a05gH+nIjY2oMTnoFkNo5gHWP800wlr3XN2sDx0dL33dU/4KrqcPDlqb8LGKNq4aYA9BaAjmSez+3TND4rxJy3L66mSzItXGtYFXe4Kj4KDG88VDfDzhvImgiXihj3vZb9+uAFm5GvcOwC0uJt05GWglGy/f2bGGSEVRNB6ZQ5kjI3SihHb1YYrLg3goMNPoKnDPcXxOujPwM80wQCZeowti4iawu9Bycg+k8TgkWmN0Gbf17PD05J9g3hgWr8PlAhHK2m2WmrWT9Kfjoea+V8OXWiBA/kG6EmghM8k+3A2daXb2vmjIgpxQWCoURrnHF7hpdJtLbD5U2wJK8NEK16RmEfQFmZ56xlIf/2QElr8yATuGGdV1g2tN5797qQYCvMmHP4cOabwkNtiHbYDPfiZ9zGM1dRULwAa7IuxMchPF1Ql+JzpgAjjmZUojEFsMWjPBTe3kQ+lQ9uJhI7p9iPZ+uctClZqAxD+AiHp1Y0ln7vWRKSi09RoEv9ckCC/JF1I+W6dPYKSjpueRYOYpL82Spa1D9F1J3FLep1qYiBRYZXMiNo/3/hsNTU3sBZU9yYWAJnbs0o6GAUZqPdN2J+Iya8ko/0YKAWvs1CgQmAXsaRkrRQHchbBWIRZg07eigSiupXLaVC8TDg7YLd0dJgmI5RdWSj+HJzRSpAHGuqVCEiu50E/o2FE2yDiqEQYJJeqMKcVgLDdNmwQzNRZmfVHGbvqaaLGvitbt4BqBnFDOJS+Ds0kJqm4RwpAMopBsZIe7l8DmtKdL6A5trYtYxRFmevBaGdiTdbE17g+QsWAeA3GuB0ZcCeBrplFyJFio7MCdff9SjW3oD6tcxjE+f2W1CSjcTesKteY3r1WaQCwETCM7OGmT4M+5IQYhB6SB3lLgye7YTa5rcTtu4Ar3Vx1WzftTQa5vC1kqYS77PmRz65SKpQCqjswPPiDwfx56k/qUNstQTg/W294Mip35TATRqRTuxi90mP77d1e903HQAMyzgar3ZMbzQhAtg9m6QLZMFqF+TAk63IsvQsZqz2vs30lDE+LRLoyB5Hllo7ywNPt/ZRbBxFDy3pj6ybFmHIqigWw8TV0xsWSDKe/wqZKK/tvWx1iAAOIUj/lsLsWk24E5Eaw7e9kkK0tP5sNA1IPYPBWXPYoqOTeS3iNCrpBWHMJcwBWAZCx2BhVZlsC8gZN5+CMk8RIARuH91y9tARzW30WkrqIcQzIjO+GN+chs6+1SQeG7zr3s4rIdaqlDydT35Rbq+oyvdKXKj+RXLKMzSIyj+ejuTaOVYRT/evXKHja8i83GHf/oujvszShNQEAb4E4I/Siz3VioBzM1BNTIdDqEVIJNHoALVtTcOujfVaCbBBo0lAmaRndn7Je8essdNqyczA5f3uXucSYjlhA4r2hokQwHbf2RB5sXydz34Xk0vc7iDZMxJok6Pi+bi8zm7OutCDrVjyEVjquTg3eFWrvkc94VUN7LTUwr2whOHp60tlAeD+wUb/TrVjWn9tAAbNYwTTfKaMWDHXG6B3EocuRrNqjfg6IZAqr7w4mseB9skybA9DlFhxkb1B0R5D5NsKwPSKGfUUOCquN16w7gVLlVT50dI3MQYy7mXpRgfBkaD7wfaIW4vy48ZIfvFPP6vNMN2RsrdfGUVgYD0ELQoF3Jnbba9jfXnxQlawfPbVIKlWXLppE6hIdN5Xom5Ay4iNe10TNFOh8QuZRzsGifR/jUT+gn7WgLA2BaZAzi/mWln5cWcbMtSs69iFmb7Bsq4dF3dBhuS1wCAwPvb17hYLAGbnPcPuWaMmSzEnWmWHa6UhfwMjoPKNcJEkvDVrTk4TXBuLV+w6KQphCjP7Bj4QMNtaiVt0yRt9abkt5gA5ROR0AsdF5Is1s1DiBQ0hVeKsuMzFqUWvFK4OwP+i0GiY7W0Cv14wOP3/vSqnIYxB1Byh9R+wIHLNyOvFyJUx3wiiIrtddxOyvEULpiCrLx5btghxjNPg1VjJ5corBmpCFsuqVe31h88rvTmhk6zMwomMrvV8xSIwyHyLdVIx4yPj7V+GKtIDljURIxMRncVuXKciq1WuZOUskcfx9k0rKqPal88jwsvtawK2RjFWOSb7OXwIp0KgMIIcUfDdji9dmdQ75TJgYmZ1U+OA6xpRuFT9ZKMmEoOySj/QvBLdgtZbJbV/SMD7A4Rm6dQevCxv6PIRs2cxbSxMO0KjbWFD/F/2cEUW1911tBqCw51WQEa5PkSy/u/UMeWN9gDnrxaaYKZo6tF8xZ8X7RYp2n8CrQJBoLYEMI9hoMdHkP1rwLIiLyevSRn8iI2Z0ag3iRktke1dwYAsy8jM3uTRS2PxmWNOCTGbFmFtxbKLkhvYmENZs1m7tyKFvkaZ+Q1fk09DOSO8h01WE5jmHssiFD4IEGfyYDJaIZIE75cVsg9bFu8qCnt5fJME+kJrS2FdPmGA2sFhX9X/UMeaivHh78Q1MYRkLXPqFGZ47ki6W/ozaEg+TS7RXsZB1sU2VhUvsil/yr2CHpMrPriuIUWBPk9M8qAdEmmoNKKQxUOslOg7DD3C5Dbt6qsENZiPruiOfG/CWNn7WSDP/iKyskIikDppLeh7wtceKX/tdItzTkYYAmN5mzjKi01la071SovHbKxCXDFhwaGJUIa59hjmJuJ7xYxHlhCbL8Z6H8tkE5XVUdiYAxUDBMk2+aYv5VoxI9KVcfdWQUK1X9BKCcD6kxUKzeYGNwzKfSx3o6MlRpShBkE5vRGJV8KrHp3x2qGZ1taw6biSE/Zmo9c+O2FMBMMa9iynPqc9AlU6zerVHqjsrkZwmJVHXHCXvGmYzYHHGOXDzh4Oy+eYeRXIfry+JtR+Yo9cyMpD6/PWGB5svEAeXA5kl6rmF/isgi8amwJ2/hY4e5+2FXNDabRcOTq3eSqMSCbd20IWSbM5ri7akFT4TzsoIXECRboVUrKWEm7mEAsCqi8xZudmKsmVmlaJpyasoombBwYBflBHrzD4JjApGV3gh0+4w85l2jTGQsWX4z7cAlPZOV4o2rHYAknWxpWYtacSJF2Po2Rh1bSCv77PCzXIqSGk9Zyi5SyTjQK8XitMFXXCKY9Ic4qBAN8+IzfIm3GmygAAP6CkrGbE0/PnM5rhDiHSQLAujrgPYkINiiyHD2Y5yt35GMqjGNvW2/nsFMJ4u02qkDXX4izYxZoroeusFDDKjWNWPZyOwtGKr8bIaBH7qCJxQTbF9wM3aLjUeyM4zxkjNwwnjiDUt1vYdza8vK4b1dzJDzF4PjTIppmxwlThjY67Lo0Sui90KB9UxQgdAxvSkIlHRjKat703FtwcDIp1HL89aq9QyB6WSIMxdGtvFAtw4XCSiiXWlTGGxfGh/V5TZOBJwoN9jZbXTaORtV2BG7IwDhBASp1GYdDS8ZLsfWvfd+GjYPtrzVN9nkcT2epSojTkWmHTDArfCFQuMJliQMcoPR3XwRdmwMYLsnKOkDumim2oJXchU4GMklS7rhgP08v2nRL+gYB7vnUc1qE8xEu5wcdkjtn1L3KKzOdS60fqpwHNYNkUiFAF31ujzNIqnyCLC4KjWsEgy2xyd5z+Nk62+3BjnvjDIEfWauIGP3yrFLEPEMjbIERiCnP6vpNnxSqZHLIKc8erWEbZFqZZxB6SdrfqcZpKic3wOrV5mKEsBStupFeoYq8UrXtf1Qxqje74RslwfJ5KujUmUiwzF22ZRtd7xrWIqsEHHWYHuLj3R/nO92zwuKvyzyGwxbLNSKY3K+8w35mM+do3nzwd+tvnVTV0aZglNj+z1EIrP27bqSY7mXgUBbaZYcLTbuixrfnNsjSleENcZm/BZs1TiSG8i74RS+aFAtJc1lIAQhDKp/KzbvOXCNgPRS5HEYosJHmJF2vwI3DpLX5bpQKiBeSN8tzTo9rZwWszR3YNd/YzoqZ6zMorUqoZpzWpYEN4lEJTMk6t5x9iNZ6hl6y8VVzWvfnuJ6tkql4tkcaxKV9N1aiiT7kKu6qaGSqTQ3VrrMKgBRYregOug6Op9pK6h+YaJH1zHbNXBOkiUqhEvsEnW/IinxQ+of2U1i9t6nqkEauHbz88u0nlqnRUHofhOvqjznn12m7HJ688FKmyxUidpSuwOamlFUYlDyOthOfu4yELplMUwdd1ARSBVDYJrv5bSQYL1F917RalmBk17RUGU5LdJvtB2zs74KEnoSJPiLCEQiwpqtUNpRtNQa6PWzEdwfe9YikDFmWSnZcyd89pNoddu4nofBSJVdTZa8JrXePd7U2DQcrDvdiXOKLbnVI0Ef0BMAdmVMpxxmPekelbLwVLKbpTXznYGAzBqVmwsweh3PYBqnWSCE3ZSz3m32wX5b/0+Pa2rkiJ1ul0gLarLXvRltYdA4uW0JqKlKFNaxGrRe0WtgJw2zqXCAjt9XmSa1gOXAZ0oKHM3A3CFOUy8gPPuYlWxwjTrsAj0UMSZ9VIoBTslJrMUDShSihV90SpDdapuNo+BUwyMkh4uz2Bqz76r6zkwS63N3eI/JasAjgMd2uEODRx1UZo5DpeQXK0xc7WLCvY0TTm2dI9vN+dk/bTi8LG2h0qT6dXzKjSllbrqupZVJNBJ1LqnARrIhYuMHqgVWufLK818fZKh0LU+e5XssV6bVa351fOwPxcunnieRVKSZyep/U8pZclDPDQ2x7rqrH3oungjghKwPBe4ZtNSODcz6yS+rDkJHItjNidney5mA6w5wCK3CeU16IFZVs6KoW72DYu4krckaP+8m79nqjVrky3dvOVsYmcPmMt0s+SdOdEZHzVUFt0LVftIRwAFxppNtwC6lVqxywG2c6TPTd8UoWS+nLabqNe7BXOXRorywFuLgzYDN8ppl/yiuuvPAJo5LrlYTNWdQpGyY8qWW4GIuvrspnm1JDMeWlGfLf46HoPZc1knTov8USjTcg6bN72qq4cRA+dz3hQ/eyOilF5hVc1okQ2/0MbgsWAgq5fa61dZ1btca6P1MytmBtqu7EKTwIy9f+5zbxmqYOmb6u7ulBgm94f+/PwyFw9ICHnovx8LqDnoXc5nmdqQN7v+YZkL0VT0Zbnp7h0T08xaq1yul9ApWx/89To5hL7f1ul0jB5I6vC/TJNcL9cUrzgdT806gOpaL5erm3cROZ1OSglSfVKdn6uVcmfrch0O++bd5RMVAHK5XOT5+TwvCES118PxIIfjfij2eb1Mcj5fZMTqubs7DTsRdarycj6nsxBkldNp9ovRqKyuS56fX5wPi9JTLJC709GYberLaGtxwOa+v79TZuQ+iamL15A4isz8HYfDYS5oVFtb0+hYKZfrVVVgXdVPuPjO7Uubrcq2NEk5ny9jlJuU4+ko+90udrmW9/bycnb0evSOhojcP9yLwiHMRdSpzl5QCQK7BsW7u7vUGFYEcrmc5fxy6ShUe6+zN+bp7jhE/1/O5+YTFzj9Qrlb103ybF5eznK9XsWLdczeeoewv+c9cpXzy1kZcaNRX4AS17jaz+fzWS7nNbYwMCWOx9nTz4gHtQQkKheu99ALYjZB9PWQISm7/c76Tak/0zTJy8tLg+a1vcUcMw5yOh1zaXMRuV6ned+KKvTg9w56d1l1Ta/Xq5zVnve0l/v7O2WhYNf/+XzuyZDu7JJy2O/lcNxbVTtFq5ymSfa7XRc8UfQ6kvJyPjdD49Pq+0hLCVv33hx3OMCJZ1+93W5nRJ00zXpdgx5EGxk2lx3kbvV61U0M9lj59HweqhYDkPv7u4A0t7N1qvL0/JzmP+semPeyVyJmO7Oen8+jHqn6/Vj0ACLnl4uczxcl/mB5Kafj7PdVlZ2B/ozZf7KmXrni4phXVr5eJ3l6eh52GXe7ndzfn4aNolopz0/PJqnWCoOlzN6nGAit1Up5Xp+9mm2mfnb3d81L2RrSz3vxcj6bgqMXUJDD4r2pAQntNdjyNROeINN1CmuiAQ2k7Hd7uX+4G/aN2hoHQtExx+g5b7KMErZc7/n52QLYjeo8s2JOzntRJ93X69X5qNqRl7Irc2ykLY5FIOfLWViZexQvP3+5Xk1O15LiOn/23d0x7YIVQM6Xy3Lu6u4T2/Off/+ud9eULsAcOy6zf6Oxtuj78HA42Gs3I0CQl5cXuV6uDSiHTffkcNj3czABAs7nOX7DFauN/VAgDw8nB8LbWcE5X2VKIDG5l+TDke0Md8DMWuCf7o6z3zkdkqCe4fUyNaGWVVF61SLZLXtu1B2/Xi/y8nIxAA2lK0o/PNxbBenouDGvo8tZdrt9UjPNceF8uXQmFbUY3HxWHE+n6KyxAqecZq9NOsAEvcnTvBhJVez2Zs71el2ARGM/3eq+fZsD0R32lYpY/dC/t/yFEgrRVIHOO/cUCytlbBWTLako8YZjbouRtfybj5hDy0sps3Fk9d42qgsCR1tcgKe5G9OJsaZtr0ULmqJjXWgdtRV39DQHJxcuSxGnZ2PYOpT9Tc2HIQZ0twXxMgS8lWI6f2/zsUt/f5o7v6o4MlTCLUXJVTaXlBG/qHumMKUVRKW+lZZXrP/UiB2hRS705iowB6mmT9QqARGH0wNZgQ1t3NqKQ9CgbJ5y2fyzCsRSex1Vt3WwxzQMU3CpuUZL+YEbzGeXqXf2KysCN3f6GSugpmBVZj8k/e6camxlFVTL420o5+aaW6gfq5KroZIz6YrZkFkXg26o08r8jiuSvSKknVdO1DYhIanVnWILmkOBT56VhCbytXrHcdlcfYZbYeuLLcEasG0i2J/fNNXu4SSeEVHFeBUG+ulCc9EzbM7DsrEktMDYgkJOU7QOmT+rqo6+foYwh6QGFAF3WKFEAAWqI6+TUxRRWYBRgetoKwPjQxbfOBvStWQJ23mUrQfbDRd1CMPQWdt5UynALto4GBptWYAAe/JCzzRh5J86H6pc49kabx3bT9LzU/nvapaEEzXZ7Vy3NcxL66SMikFkUYNeuyAo5VKqoV/32Vl0qj5iB1Lbepg32aw3Sqr2Z857UTYcpPYyb3mNKfBRAkBr44vKNxSLKXO00sVjlNQvUhYGUxeZQqPsl7IWi9oLT1aOWBDaoqKEy0qKYJzn9vekE25TUw/GjvQZJ6qD0jpJfj0lNF1daAKaiq5m612xgsUzmSVqSkDlarxE3029Vyx1VzUYSie5kugaG8uGnZbOlBnbSSjgc0faakcYWyIHsnprKar8Vdvzznt4H/xHDXMFIqxdI4L0bYjdUqwi2JDp51E1fkPlGw2Oc3Xz84x5oXrnwXvZGZvY3MNSSnEoA8Ed9U4UcEPC2lYNfLPj7DhMN1ffz25hOFath1x7MOaivFrKLm8KcMkRVANh9QNujJHSxZuMhCdEMXjgRJRa6Sv7OB3UD3zqbHhtGSpPFzPjhx74sCFQ4umoPlGDkgTX6NNKDYBYY/bhgbgE6WhEjsBv74GPQ8qarqJbEGBGfuuUkTVB68izqzDMokekYoiksvzewi4WVwgb8Jaqq13UtAF+aLGXe9zpaGGU4Og70RK7tB5xpRjDTUP/YKyYWvG1GhCzG/Vmfk5rtyBy3DV8Mi7Ogt3sIPBmMxZZ0Av+XEwUKxPqiRG8ce+G4Yezd5DNAPWTRT//0exXMOdWbqivnVhI1ZC5NTZORd9FmC3lQKHGixGbx1bUGmR8bx6UwEZMC9tiObdptCAo6SQKaJ4HIPnCN/PIbiYqYfFvIClpnDaJkMhwhkp3w2DCGkP3FgNV5ZUOSAcORVVEaUnKWE0r8CgVXKvPusySAcYQvtJocgxwZv0+RHlkiRGhETDURkz9V2ASLE1fhE7OBwCSScCcWrGMx6e7AAdHi3j7MPHMOz97SokdhOBorIHmZKPdMB4yCS+M52mirDpQU+7SCHDG11EwutKzWrypINxaeIUITlBUxEZCoPw2acFRLRDZ59C6MIYW2Uhz8ZQp5aPCOJ/QQEyfH+UiKJivn8xeNIhC0fdQNHAy3J0DtUckp2ZuMZLpCwV7P6iA/1rhNXYo0Fuav1KKW6LkZtTGoKJRYjAbnEzQDXNOKhDK58L2/FbrIOTtCLcJf17Lhked3pSqkYLBC+sK/FyEnqw3QmNuDToP8TzK9oHLy+ExMTezXeU1elrhAVm3FMjYrMUpbzPaDe1dVI4HKKgnfRJkPxoj080awKsrLgIWBrWGPTDgxPZXw+LOjcc4aK3Xt8yf6MPYcrGdcaPZPNw68sPBpg+eNge4zkHUajamRz7Dx3s9E6aROH3etguiENSgGiebSUTQgTLolKK0DTIiKpRCI7UcSDSvsyXbnnTc9FjkCLmR28a8ob5jR9RJNTvBUci0Onde4TMrFGO89l5UGFC2ktU4sq3zamXDdx+tBNoMibz6THuPaCZJQJUhG0CGZq/iKBZxBjqd903gVmuRgKy2Xs53mLkncYqT0bPJvg3Sdp4EnvEgUTmRG3mBCsMwHZ338SbcVKMWPcM7QvA9VQmpmlyfB167ZV4SXYvs0AhVWdBljeUpNnRjb7Q96DqJ/T7G9kUpYOgL0yRuezlx4qZLbqBeD4HVJI4zxA9uP5QU/kY4MHBLHdYJKmv61etMxruyIVRXTdN9E8lcMS1ez+T2wJ0P5QlNq8UDb0ieMFS8MVYTrJAuCGIBFdyOoQYA6v8dx2hUcLCHkALQEe5Psx1uevL6R+WACgzXoYvv8AXAei8786xunSocqZX6WZX18zAaKF3zCiYFkYpRZMo2Cc0M/d74fv7E2Sn82r0KDyTf/PVcCRtDeBjDar3deaXqwucwzeYzAAZX88riaGUXrWys5Ijk9q8HF6nR9Wxa0jhQyRTSKMJFxwJB4d9PoLqlqllN6Mqv2oNwqJGjzvo+sx+vfI+VkiSdLqk3Hc2Qk0Y/tHZ6oiBnOgaSIIuDDQqRwpkaJYBgQhs0Z+aXt3G+IK6WjScFhQjAeJGE7iGi9Hi/N02Hmhb6pFixHiZGs3qhEb5pZAOlmzcBkRtT644qYem8G00CLY9L//62htq1+WdDIG4EMrwybjVKxA3neuTxjol6ddWHY+BmsQvnKNpqmPCXroKIxOEmKwhd8y0cdFTPL6Dxo0SM9m3pmZe5Y8rUGtEUrg6N9FPB3pss377WFuFWSNb0Wy0dQaNkt1Wm+OTfdvNfERwk7fWO69Rgykvf3U+U87WKGpKEPdYYdOyM24dqly+y3USOEmFVPFqsN1L7tvaxoVE3GszYCqDT9xy9W2LXOk1yzP5IuviaPq2Mg/WBSiWkZO+TqtmuBZu4XbgJDUC/bt2CEgrDm81a9Raqvl6PAHNLHBUGjeYw0dtKj3rcJbQA1Gu81kRZOHig9X3Mlq01Bod5raWylWBBQNc/HMcCYiNVITO01gFPFHFm9lbYZNwhNFCUQzh90h8BmiWTW6h1q+CYEd2DP+ujINYtnC9YsAqH/oJjMJL9jL0BbozLUm8+2ccuTD6WOLcEjN3nZISJTnITZMzZN9knRFrkwGnx/T3r45Id5mAl2LmFGUIFgJqrd/mmP+6Qoc4bXfmVwAWLaCYh/4Y/YAuRDCldsIFI8hDDEAvYWA52+Hyg+SHrnGnDGsI7m22bOSuKHK1LQOv0GfXzuK/05VTXIRZA9nQqal6VNxf1W4sL3ET/9XmNQbJMb/KlZtUClcTE/35IWruLG3NuSUIDbcuw+HPo4AXp3m2FRQpK4wJLOHT82Ueb4BmVyiS4MGyx3uImAwhKcIgbZca7ki57Z7Eg2rtHHG0Hm3DL7WSDAQnFAjDxJno2KkiQI4gm0NhPKBtdxdAgYDIsjaRFM+qCwSYva8ebG61Om8ov/74OnZycyyMaDU1TRLZeB/2D0F0aGc3r+hTWfizwys4hJF+rfCVS6B5/V0beTljNntWqtltf+wp0kKM1kHV4/HGT0aKZ224MUwF1yiOzYjRJZYARY1dhg7ELX3q6mBbmoBTty8rFOwAGTBcrBxiy7vqtYjJbZ5MMzJHDPsJrZeUZ/TyTtYmbW2Ge9tYimPospmC8DNNxerfJcav9kwGLt/bA9n6En9d/bWYr1kMOW8eJSwy32CSprZliAXBkYTGIgRmQEYoDLkynsg0DcPQMYEHZnsjqcYo4u4QhcvBK6qpr8KWm8Tccp3oOwTQ/udXB0Xus9Zw3KTLaeoi305FkZGXEUsyFuWyQhb3cBOyTFBjd/MXNR8M8lXttfS1unMcYVyuxri3/TCW2Z/KY5DqCsUMD1aFAdn+cMd2wHPaXrC2KNTHLNSxSz9eth5h4T5rCNrOw0DUOxzEzgB+EWWm9ngqGfSmbh0zAbPfP+7QvKV7JydJ8jPIVbsfnsGgdzScOaKMrx41OLFisj3oBmxvfck1KTBAHAYR5VHQGkDYBtptHBT/CeTom34MNxMCLF6ZnNSPK2LIRBuNSPbsJf6gyQ8PxOogqbeFquWADrgtunEh5AiuGvx6c651IyGhaLgiPNDsJXWAynE9Iu2dQ7yHOZiALLLR/6XvuNON5TH2fxFFTddcxNyPmcKWHx7hWpGvQd8IcIJ3LH2JSpzerT5JDUwxDlDXdFNQ7m5EKP0yWFVig6BeplG0IwQwUrBT4cLMG9m9zRJKMII0MuwPzdRYLAtvheLPGEBwZ27wwrXPj5nm4xhJEg+wRzSiTNxenXGhsXTim0mhVbOph/TWJYTIHlHaHVRGsPVgR55vTzAu3ulx4FYXJ0kJpO9WbKDsGABVNh00LNQ1jN1LqgkGmrA2LszkR5RuXzYqyW6FQJSZN/CAkFG7un+IEY+BYN3wVBvXabozJ3yER0EzPZye+MRB0un1Z20PsZJTXD/P5ouYDKWl8XvffOH9THXzEHIpbYDuwEcGVutEG3SvXm4hAFsxhKGkelfb2zAw6jWhL5gUaKbsujyA2AYvgsttmvxXFl68EU4dFrmgDyeQHMF7+kBTU2M7x4T/A5HjY2Dlw1d8at6n1HQgHijJ27xDXdXqH/mLgwXCbpnCzkqCZeWfCsgqdyhZYcCMk+OGn2ptlHAPR4zGCyDbUf/Z0AiZ0yoKVlOKopKayrVYJi/CcBFmGsu00gUa9vQdfWaSTZ64rDdKQlaoiMqtISfeT4aKK2FcJs3gqXeJdexLBMBDpAhWTaru/cEoRyCq0iSQGUPN+mRlW07X6M9Pi7aH++b0hJPSrv5emaxrahs6Bqead4CwIkmwx7URVX0Dlrex+mNVFmKjE2S7tc+QSlFrdjCJ74UFFYWjBPKkGjVG9E4XQQYRJJ2++bo0QjQ7KVXoarhJGV+bSA8vUGlB0XXBfq8zKgk2pknQlnlP9DaIFMZeiAkm0yms4HJMqm8q4mxocWD17dJlZl3VZEo8j5VUKZIcauw8WuvDNxCq7xU/MzwytPHpmasFhbcaEf1Wkgy8ixaofhzlAUJ09MBSnbqsAlcarIkfxXiINmU3CH96EmRoxWykntXsnrZwdWSlclnFRUKLatMqQ6Yyj9YSC+Q5xct1IurFZYg8ftAfzLLQJgWf3ZR6NvsQ3VC+tVqq65NHMXanzARECdWIqzfMsSboaq6bCdYxLK+ybopwsXlOSz7RYlVC7fyBO6CoxJPcGx1qkpJ0h6kMRrHyyDj9b/IWjXGrVUBocTcu0u/dJUSMc7S88rh1NvAeCJlkL18A/VNdf7Jwhm3gY1eiFRDGbirHBveuq+/l3LLHSB2ujSCli1FhNOumsr+gFn8L+UGrn6xqhh7UY1N8NRT6kX0iARhdzQwbOrtyrZrNs7OyLh/r8pLVkicK6sOCCEZSiuY9RUTjnfdL8e00HV6y1li/GbZIeY4VwsL+N4AvjuBZcLPYApKLcW7E42PFVuv2VdJ25AS4rOfWu3O5qimpyZCqgjwYQ0NqZQSqHFFQbI7rSamxmpeJCzBspQF4sxxnBjYLMnAliaPD9/Tk1bMfgxBp/zZiem5gKGilaHK1atXfaNBCPjy9EQgmheni6cQix/iNdGAGD4qWIF8cL4RbWKHt9IHWqUlmtP5Qysi1Do2rphU+mI7xZk9NKnauginbYVLlcr23YWH/sblcEBcaYuuf9Pb2rrO3Z2L3lOd929jC8E0nQ2erFEbxybOwumM+oKtEO7Gkl4c6ER15rS1JyvsQqoezUSEmTiIYahTZhikkGuuqtL1CXzy/iOs+LnHiYrkq6o/SFuNoDXPiu2nfSNGqW7ywFi3FyRKuaMSqznlEvCEuBlCbrI+Hw8B1UwxlXZstDcCT11+ny+TqYWJEHWOKEV/B0xQTD/OjicSdj4Qz/3tf1JqspsQ1cs83IovhrA2YRcZQwKvEB1sXBwHjIWYWuLgxTTV1fl6Ht3WIEDHdq0CF7qwtJrUqNj3GwVgtSpGpwi/FzmzVyYkV1YhvWgHi3clus+TGEZkyczFKs1zxNU2QlphL0NAe7BpzgzhqPvJhxYs7G7mWH5mPYYtPyXbOf6eqltdqeiDkgvXALRs2YodWNP7j1s8y7NZYpMWgbDQScqYDVAlV4JVOCSJ67jW9ZAaaFUJQlg79KN2xEie/LpwSmgMiSXK0QqBQXDb1KL9Iw46I7VuOBFtvRTODYJvmHEA+zEXXPsMuaEPBoyKD9Tvp350iWRa/RJV4pi5PwTGlFrnBLRyHEf6a1MnWHAx4coTrPVS6wWEDoR8BhMTzojiXF5fpfpUQhqNmSZ5Jpqi1fRLJeWtxRFa8OkSjZHHUXndHxIVx/ovCtO9/iFC690JzhCrl6WdM7M/FGnSOaOAENUEKiQzkk3erZ3KX5nPx9NksRda8chrrI3OvWHQnVe8kDqEGaIPjLdiaLy18aOFtryGdhcjhrezLPYbLbrLkRCzq/3owVRgMwjBjpena7GgNB35jJz90OGFtRmugpiVp7RZOhEO/ePck01fAd6we/efOwmMN7NUc0w8o6VfOaqzJ49cb3K6pTWdtBv6LP2tgVixdPQn6YzTYvizGuac3On7Df78fm6pzNI7WMdE8MF/VQzsWqRgvpnIrv7k+yK7tAJ+Cy+F5ezrOZs0veyDnp/+CDNylysRrPPz0+SRS0kWZO++bNneow2YD//PQil8tFFU0W6Z2N7499oaoPWQ2P/fjVihzv9zt5eLgfIp+Pj0+zqXeCzpRS5OHNvexKcQfY/LOXyyUxHO7v9eHhXva7fd+EKoGtU5XHp6d0GJxCORz2cn93l66H6zTJNE2y2+0ljB6hf/5srDoHFl/MzB1vSq1TPPgUovnwcNfWtaeEVVIeHx+FEyO9Yb2H+zvJjKZn4/j1+SEN2of9Xh7e3IWOxfrner3K4+NTbBItP3s6nazhs3q712uVx3eP0Yh0+a83b94MfajWdbOaIpuSv1JOdydl2E4neU95enqS6VrbvewPh2Y0nMWA8/nSTN4NuLCcjA8P97LbFUfXQjP5fX5+MvcYz1KGjtLhsO/mxR4ZXf68vLzI8/NL29erYEd8Bvo5LHv++WUxT06SUKEcD4dl7UQQ6vn5RS6LaTPUgCOEsltiabQUmL9jqlWe3j3ZAXgFvM3nR0nTgpeX5ZrXad/SxbFqpZxOR9ntipxfzl2UaLm202kxMl6u+vnpeTaednYfK3j2wYcfCKKgYztdHh8f5XKdHK1V2nD/w5sHOez3PaHXQJcfSymQy6XvJejZ1TL/zn4370UMCEukyLu372bwSRthL+tht5ufbY/h1SQOtVZ5fHruXnvOmacUyJs3D0O0eo4FzymFjKTcqfXYk9a+3x/fPS5m3HDkuSWWf/Ag+13041rPo3dvHxfjegcScY6DW2fQNE3y9u27iLhI74Z88OFDm0P2iGydJnn37mnx94xz02VX5IP27HKw+t27R+d72//ueFgN4nWnu78n43ernmmtIs/P/Z1SgW8iVXZlN+cVGD+Xx8fn/Iwk5f7+NBukM7TkTYw2VJoWq+ZniohKLIBSlXfvntLzty7v9M2bB0NB1Efw5Xpdzuid9TQF5Hqd5nje0kC3Jwvk4WGJQ6wqL5g/+3qd5Ek9FwNdU2R/2MubN/fh7Fmv43K+yKM+E1RxV+u8V+7uTjJChHrcL2HcgqTc393J8XQYoknz75+NSJaO/afT/P26w6wBi/ndPIoEcSe2tfnmwzey3+3S72et8u7xySi1e5js4f5eDsdDBF6Xa3h6fJZpusbCCnPudXd/kuPxmO41AeTpack7m4u4HTV4eLiTw+GglmWnwtdKeVTX78+A+/tT8zwXoUy1Sp0mZT3X7+V0PMp+v+/MRNj506enZ7lepxDvpIpgB3nzcD/UYjmfL/L8/NyBGapWAillX+TNw0NOilhe+l4CJSmSXme1NIcUorhOYZL0GOde2ymT0dD24k9TBDKJKHR/XSh9Hmp+sJK2ZgHlVSglDPKmg8HQaF9ph2FvGM4dprKYePZqWylSts5ECWggVfJOViMqUzTNYyCV7zuvgmz/IekyWnSIKpCXBWaAm5/0IjYZHg5HtYDIK66dfU7HlWWpbyV752o25byhuAkJBUHWc9MbGzf8EadpmpOsY+kUWDMwOntTVl5a99X7hO33O6m1yvk8pTNURmKdHHS8a0qlaYmp6UgwoPVrohDnd6kQReaUMWUsDJSFskZ1yOaGzP13q2nxZ7Si/rxypCxQqF2zdbzu7IwKHDXRX0vjsJQN39ShaEo3kF9jg0Ga9c0D7vKiEbWhDDkKpEYgGd6/J2gtMRwJ1YWj57cItExVdYZs/72BZRjMQlDFq6WKBTvlR79zvUZWkSndEvAWHTYW0g7sq+6RVQh1CHG7ndpTJUfrouk82q4IykwB9PPKWTEoC5VwpegXXQzBFkzr7KRdowz7aT0HNPVTihhTtCrVJHuNOstICeoRrSQCMHS0KNs5Msi8pliKnWtvDIKS2LuoTqGhQfrYSHHMJEnGI7JzEx0oCWeIgkerCEsye736ELqOiNYcL0hipwZVK3M62vKg6Lq+xl9VRpQ0BRygs64alVLm7pimjOY6DpQgXOrGH4K4BwOBSIwgwbI3I2NrZStJAH/nv6qm428bA77TPoOuzYrGFIVVre9kft2xlLIzx3RW2va3Fk2+UNbzk2Aup47N84vW2i3JeTAUjbP7psA2XExhm+V4LnbCdIB7kwWrnySt1ZIWZWSWc/mvNWrwlu9tOtzCaDSZPEOTr6yzlJz3rZGjWecV3ciIrjmkCU0O+vbo1P2mLl2KikPqOoQ2DrJzPgav2DSSyHwPtXWpBRSdhVxJfKjtuMMyQ4iNgWI/SxR3yriA0fL5VN9K5ZmRyUoaO2xa8t+21LZG5RMbjBu/prtKVogjT3a0eiqVEEGR1auvbCiAOoqOof3BLOqsm0NRks0+SDK2p43K0triR+ay0od5c08TaxMwfzdy9o47doxPY0alILeHaz3bUiO0hqLY5wQJLpiQBLRXW/MykdZfD3LqCgU5kLDSrqnlgB0FxNteWF7qa6TwpCuNgpJLVWTJT3J+u+LNJuQx6aAvyKrtIt2yGLGS64tlUSdOJs9zpL7rk8aUZzROnIxn34aXKXxhhnCQiCsijWE9XDnmGj2Ruo14e05Mpc9Go3W2sn2T3rM4+X7zQrfcmQaGToL0XM4oclz2Kpy0+2Yhi0SUKOnMh9YWEq95M09ZVYPAzvB6I3Ov3KdNtiMYmgMpdlYGSYd4uTxNKyallJsa5Mtt1RbvPRME2g9yMCIQqJ7rNez0glWADdxa1fZ3QEiChiDBkqTRDMB4zh1un/XqWdf12fHGIU8n3z4STttUU3IjE0bIDbl5vClW1bOm7bjctPQISV2P31wp7Ms/z++kCnnDq1OiF7WXsffG9SGpD8VabRoJ2jfcxwvv1xocfm2FYmj4vlgGNpyMR+tRYGxmYu61jB6snNI2p6bn/hF95URCDmB6JRirkg/XQABIXpHZ+tFrn0aljQXdHa7WxkKoYo5GgzMpOrg13lO3VIhKomcm1QKitd6TkcK7nf1EDlhCWTZsGcyvH1/HQlx9DlDS57AtxEOJmLISBGM/fzbae0ZYc/3tuozCZL/qmWgkZR86LmQA1qszGE+aE/l1BsG9ODNAifNj7QFXLlSX/uIa1/YVvrp+ZsSi7nTo2AAhEzfUy2Qw3dOElgW4JXfMoWbRdqfIXhbzXZ2q5kPybvA8x0J9GG+ZYNMj3xDPwvAUWHg7gda+1QU/BLfk17xIAUpyrOkBBYZ4SERjeG0PYo4zdVOr4E1+jWPuvT4AilPXnety3g7k7v4ImxSOsuaRmqPBB5dgOM9JlLRjbrruwRvOIqfjxCUaQ7/PH5Iyrg44DuS3ap7BmattcmQFMHCrWrfLm0E72yU/ULQuMqqKMvewComPE265tYkYkOxRrFE+ZoqCogdeMFyuWoKdxp4xwE+MydzqJRfttGE6C3o6m+4A78CVFdSgbkNjhPQNUQKTHG2tUzvWkHQZMAA7BkyF0PhnB/for88rSmrl1IxVsSYeo4Q6EcPICvA+61o2E1tTchUbaDqxiAlI12c6CSa7EEPgdrhfmYFXufBE0GtoIhsOpCDG84QYhaR1pnQb3DLPFdhA8Ne1gLGCd+LhSZWQWmgEuUCPe/ZDAUfHfuKgoIFYkRJgW2W1A3Fjr1pA0o6V3u4NvIc4PSs6EY6lIHqN4qzvuNk26uucIZLZPsf/GZ7bAfCn7Wn3zpXkVglMPLfC3DKT7qQFurWwkAcS1ya0J8dbFwGaTnwPF7mBn489WWGoVdmx8R6Zgd2IQHzfn2uTxL83pkwGF4jVuQ/TIV1bTdtFAYPIrgycATJW6P41lKsN79tRmy88NMBSFalkxfvBrWksugXN+FBRNk3pLdbk8FPkKNtrk0bqotIX0BzTplK5c459rm4dqA5vVvs5S877YiwoUlFjSPEKbreKUrfIs4Mi9cpihii97nnpQ8mXFu3ASQSB+vtZf6v0AIPZdzLBQyL6mCoIeBNbW956HRlopTSthvuahJ7Jy0eu4DqEIqC8o5ZnVCXR7crOYdD5R2EbFfLrL0EjkZ/CWVtqu3s8AKzgOiavesi6G4QcONrsHkifDcjYQjRIYJ4DGAoVxkpnmx40yRfHA+mGoTTFCIz0x40hxZ1GQmSUnOvBeOTx26uDMirDZg5VUfWOYgcWbFOEt865ItErYqgGhzxQZ2t69SRNkzgG+mpPT1fqoozFHDb+mfR2ZVaN2d9TB2PphI0QoCkk509U41MexWrWTFy37NaSHhlJx/t2is4hpOA1GU9PRAsbO2qNEXglzFW9ntMNU/itM7ioE3jOiZb5eygF8w1XlGBLRaeGOK5eB15uep+PFEs9loVZ8MI9/ZXiVrNmglJblg26vCEfBoUgmK7hzRQwyTtY3NraSIP7syiuGY5Xv+8hyHEDnNIPtxhgCxsJ6+vW4iavawUWtNiZg25Ig6I64yp2uy2MLvd1hou9IPRldFzjWbeSr4wW63ExiaPyKzZaFp0pfmRL6bK80lM9yklb9DbRajO57X5rU4uKne8N6aulAtVWnuvcTP4bKTVW/4OeGQj0u4BqwPmk6cW4EDoHVWBMEOCgJBqfKi0h2yWwcdsU1RVfuhuxUnToDXnV33eqMLpg1brclEpbPweVz45JNlv4bnvLI6pGtrnRfhlsSjyVqieLvfg3CYNSljMAKzUKp04qqOuUPCF0GbWvCM167Agxgrz4So+InbZR9GfqjZTlWIHSPPCNXpPClpjDJvO2SMEggVG0NUjqQYPh7zPMFkHNU5EeJBkHKSRzG7J2CPSPV2uvQTXjCKQXvpl/N3XYoXWmlRmnk3zTRtVBZVZ3wZLo0RMzOsRSp9GwHRjEuSPTXC+w+r8a5fVNLkgwspXXJD861Qbd82NwUmxFg9sN3ZoD1rxZpWHDJeNpPK0CQpsFsc+umwjBFTImm6CaaaQk8vzezL13R82cdDYjM/DHzr3PHHgHzvOIIk55WzpFEXpeO8ECkCenJAORy9OntkZGcKtjFmSh457OV9i6x5h0+rYKjoU7BDGMBWZnFqBoj9gqX0JxOwoqWD6zzYiJJOqccN2N+d8Xsf5j2SxzlslzYNlkcgMYmTiDWdgiJFIPs5EJH682T10t3iBaLCNXsfdzWVoxsejcijQK35o5kXXSPeXQRj97DmiFAXaRh5Zf0IP34mfJiwJ/ByDG2nDwe2j9HtjuYygANILltTz0fS32CiQUBdK/y37tRZ0/Y2wTxgLMnpVZJ20BjmpNnzWQd/AlzOP28sj2UpHkWa9AeWF3umauabzIKzZndOTMnxmux8hEN1V/Kt25Oar5sFGZpA0LIO1eimLpxJjfr2bPzcwAM+1JEX61UlFXsRvPulXadju0KIMxIbaPf97z1Qke6CGcDfyzefypwUpoURcdrOLSAi2Capl0nYZku7HUsH8wp2SIm2iBxcxaQto82xoYqO0RkKHqA2lzf2BoxUNndaHlqTUKRt9BBI2VRltMdfnQnZ9n9LOKjGYW6AIBMDMCWZdoG0yIMw2wa47SqEZ9pjX+8rq5uhQx846mkwlntcFfv/3SaFR1sKkZ9GJ0IdeTYCbdKuadb+m0Iaq1Cu/0nNATvYrmre5PT0hzWefu3aVpPBQ481yEa9DFM2yDlrex/Y60FUXdhTUyFy2PzQ2E1VqZtH2yrN2qFGMBkf1u1z3kal9vIGWqbGsBULYgyVwOHMwM3yIG0+6aangG76dm/juCGo2gQV3WEM1z0N6ZnqKeJmba+xTjeVGI5LYTalZX9QJD4x6Dbh2S54P03u33p0Y63rIjVQPlzaateR9wbAdNm4OKELD5AXXxqv0USS/Er0JrpGmKRvQ9pVWLfzgqjFGd9tUF3TQNmJxJfnKTZjY06+quPsm28k5mkfQeQi7aIEaRG6M2nDEqJ5xGgkFfxRZ8Tu27M6tWUTftx7ixSpC0euH3MVrBrGe7C2OkbOq0sCyu4H1I01OyY6dCAxLa/6oG5PWnYmaF6xvvQ2aG9rQNfsbLGVd6rOBG+w7O86GNcwAhIFG0r7aiUTSaYMIWSNgMEEdHXLtoqhFgC3hvF+RFHFU+y24PxsQbD2ZEKtMeyEvFDPOFWEsuKJp+r5L6GeKL7rThR1/c23090tYbxl2tbp2xG+D/Tc+napLH2uY5gnBOV9Wuht4c2CzJvmcOSw6JdOKya6THGQPQBXO98599l1KVBPHsZvMlG8WdpaOEFZHGkxk0av+pJZhO02Q6SOsbuNapz3DqeT81+9FQCPewur+zzhiLakTMB0nRA+mU0B0SpRY5ox4qCfGeXToDJgbKq7ao1Op5WskO2kPLtYGJVVinKApVv86yKByuJt/b7XOLjuh/NU1UXUO2LkTz+PSdLqxegLMq4ZzXYsYSlkOhBaZS5mt0PKnSil9L61rG4g2eB8+HhvL/A1T3Ug3qY5sCUdtBYrtepSm/1TRQ0vhC6cNWM1Oo6DHdu48uqtblOcOJ5LSPL7Mqljdob4rOdEJMsIW9OQqUeu76KrSHYjuTKDLJKqFsu++NMlVXOfusZl48qBZZas+6o3BZ7wkFD/3QKgVWMApdxXBWsDOyL3qQtWsSLV5UXFYUNofRuzUEHVhlqeJ98FsIKWW3UJCxWJWskKwyrIYIKmWaekJwvU6zIp7M71nLeBv56jUeLXPSsghR6Xen0+u1Y1Y856ZfVkN1O4BCqRUtYWE2mLZ4R67fS4HZtKird2YJBZSO0wZNdmbkHSByM0CryMM0GW2pefMUmSqliPcD7cWQjluyeFWG5A1uT6tricVunxn1s5+k7dqVlSLnXgVXIJ7oflqaEq6fW63BI7fbmqGpI0eeC5uXrqiRDd1FYgN5q+lBrCAtscZ1SFIbt/2yrovKeY3pmdk5HiwK4EmaQ7fP/OikuJnzrnTc7U403bYBOItK+apGSWIBfGkYM8b2m5p8VJez0SqWmtkdzvt1fd5Qye9qLN9VZBfP0+WwZq0LKLwqc9qzZVXrpAbaVyV0DQiofEqreHowUlfzbH6uCOfbWiSsqu9wyXZVxiaSwntY9dD8EL3zYbW5CdeCXK0nvadWcGKNU/78kqm/C6bdKbT93+LUEpgqdde2tLlmzf7YsZ/puUJr7TO1BaEgKAtAOq1+usrzl2o2suyKm9233aZKBhVuzeoxPrJe82Sx36Fvl63PVWq3MFsopzSA1PKMUXv+BJ0HO/Vh5X+q8yyyzvUTLMPDq5Fn3bQ13lhgsr8nMrYKW8FHW1DpmgBq/YcxmVXWi1WkFtMR1+0Sqi4xByDhOt++aogU2D2/3n9VbCAzfrM4khTtPpD0Ftf3DBE7qramdW8//46x7S5tKPLu7iRlV6IT6/LnfL64xWQhoLu7Y1v0WTJ+vlyUEXov/mqdpfqPizdJxgJ8OZ9N8aWVNMtuJ8fDXhWbni7F2adQFwu0aj/YFTkdD5tFhFVynP/H6oslxhxeSZUDs+dJWkTPfnHXy0Vy0vTsM6g9xzSCBIhMU20+gylNgpTj8WC7Duqertep/b5EfFmOp2PqGTd7JF7lcrmklFsKFx+WXURvloL7fD47c95+mO8KUq+ZdUO9vLy4NdIDSClF/W4SVmuV63Q10tUtnBbIdK2Lb+SYBHw8HRa7ET+zCnl+fpFpukopOzkcD4vXYkTfXtraib1rAHI6nYJf2uqbc71Ocjlf7fcrUGO/38vhuOvy5tTFKuRyvcr55Wxn21Qidzoe5dD2lKfaQc7n8+JZCqsyuXhjHg77pIiePaiMf5WmXy3Az/G4l/3i8+aRuvPlItfrNHf+/NydzL6jpcx+VNfrFA3Wl+dQl+cw7w2FhrrCfvazizj+br+TXdkZ+unL84uyh7AI77omoRVPpXu1Xi7nrjS6gBWz997OgGgk5eXlEmkwat8VzN58ZA5TXa+TXC9XW0gva2S/L+rduW4xKS8v50ABXAv5giKnu3zPkrO3qPdjW43BSylyOh2sOI+aA6tTXfa8svrQghiKYnY4HJb1U03cXt/z8/Nz9HZrsac2z8Moiz5/Ri9AbId59W/0wObq1beaJWd0oefnl8FzmxOc+WwtRim4x8O6nEO++9f/5+l0NKI3ptCflngHS+pa2SqlFDmaNWHX3MvLefERzufZT6fj8j5yZtHz88tAPI7COt+7pprDUTSfn89WYGyhfq+F0+pDPBKoe35Z/JNpSVpr5+Du/pSq981rgfLy9KI66S7/WPai7sKunmdCkct1ksv5vNHJghGP0ZdwOh1lV/T4g/YprPL8fHbgfAdNSylydzraTrBaV+vZrnMeLRh3Oh1l5xJSqOT6+fllOGu3elL797H++PVyXXylEW0bSDkcD7I/7G1HebFaulzmc32/24VRmLXbdDmfZbrWnKy77BUzy6xzj2ma8+CEbTaffUVOx2NKbitl9o87n88GmFnzxfncPsjpdBCPDq2h7ny+LB69di+X5ru7nz1ZlQUXjKfopHxmbYt27bQe746Nxqtq7nbenl/OzYfZs6dEKIfTSQ4+79N54/m65AC+GzYDU8fjwcQLOPbay/kyA2CMVFvKvD6O+11USV7288vLRfmaqiphyZuOx0OmOyi1TnI+X5MYRdntlzzdWEXN67HWyMaiiBwP+zk/VjYYGuR6eb703Nj5UO93+8XL0a3gZaFM0zT7+tK1dtW73FfDf6XVtlmSr50v6Fx7fjVoBSlBWE/NQvS6Q8lYB0XLLnFcyurnhUCX4EonVW1Y1i48uXqBDP0Gq3tmlSbozpU4mxAJ1UuAS/p1W7v5FInuHloOaut2SF5UXa8K0QPNwPOa9Ol7g5aGLmUxxFQ+Vet16sFiU/So719+38upQ5kfz++lpNdeyk6El4T7vCoHIr6Xxcdl4rSg2qvPZe+izhtmP4MToq1B5hsrk6beag84XRQiJMpY5kCmRjVa7kGcbHGZkyw/r6L9BouUpmwLZWwbvF52JQRvg457xQdltwI1XwaFtM37rC5Ik+42dwozyvzeDZq5PPv13diCS4l61P7eU2W4lWKrnlEft50LQvPeFzrYfD1UXVMVNxbkUu+ZWpcun6Fa6GF0pe7F+WdXs+ICisjUVT2lU4dZFjqpWttQ/299ppUUTLPxrN4zZVdMJ9HTpPt9FVXgrV0rRDo5KdeLn6HqXlu6e7R2c+gLElksV0iRnZvddbQmu+dtlwvYqSLUvvNpqi42uUK5JDLiYgtsjeprgAuODmbQ2hXxXz2gmk+sjQHUfpMFApZwjCnLKBEzWlBVR7ZIKbshBXRaGC1Q0Z+VgeLlk+DsuWqKlE6Awv2s954JgLE0axEKDJALisiyzofKtLprs3Y59PgGSqQ3Qwb3YQuHBgA3X1D4ZtLSLehsEa/6hjUWVQk00EyR1fp8yvI+kZqwCyh1qs03z9qUVJFSllnqvJgsqhOn9Wv0jPGuICRj7b7cXtSAba20762geUAur1WwK8u7KpYSqGfU2Pshmrq4Ckf5MaQCyHSFYrpISPwLILt9McSMxu6gtdpAb9UvuVZJGwctHpYl9hZrBbvaaxy0NQT6yE3ZlblYWs4+WpmZdh9n9kLJC7TNz7W0Z6Pj3CqIUx1NmlBMsJWZoju6xqqIoXHRLL1I6+Gr18rifwwnWBdmDZVP3pqn6EIDMi0MCbGeicpqpqg4vN+7eLMyAhwlWHemCjAzhBit49aifFpYcUqqeM5c6hp/bd4I9zzqtHbKrSry2jXUKuoIQnHnuUhDZ8g0S6S1lnDrYq4TimJOxaaZzlWGlFawARtw+bEm1Fd0azA3wdJZWG2duZE4dcYb9XutNVIge+8NBclYmAgUmBUlauxKWeffRmIstitAZrLq7EhfQTpjQTdOu87urcIglr/MULjpFrQ3Le8cX3QjesJJKCuqkdh5DUcVN2UDBgh5wqRyFNvI+kbmN5eMukIFPOrZDGKhdaphYVUYUxlh09FDsxlEjbTD0alC91l11KMAQDd0bR5KXhmjfQ4V+wAyLYU6fBd7QwxpnWvj0vZf/RFNF0EfHyhmeHx9Rhi06PugMpPO2IjK6/3lrIBHrSK7nRjDc42RZ9SndY3WRi+uqpGyrpzeqYC2iYFznW9os6bcLIFzCThVQ6HQXQ2GvdwADigVy2xOSl2fuMKFnEzLlJwP77IUkQyS9mg+m+05Vcr+eLDdayWDSC9MqIqUUpaDWeIci9mLK0ixQSZPOPnKhFub0GsLCC5dxWq5aW3Oaewzq4sPvXr87B1HHjTatD0RZwmT3slFkBI7gPqs0T8X3Taa1x49gk4nI5rLnXZLjHVBVImdVjjI0myL5fmydn1hYw4c1wyMiFEUkiAlVU70UZ4JY6UxZ2H4Rsr/zPVJEkW9+THMPnIr4FLZgRwpljqIEtWlTSwOQjP9nqnX+ArQrF/DTKbFJAXxPPVMAS3UwfhpvePFhu5r2waTpAvktj/ianjdv6a6w3Smd0k6TyTZ/itdTMNbcNpOAZxnGU3hZfxj0WnfUUDO+YnoPCgoIOvkE6nBugiNqJ/9r9t+k1rwRQzwB/VMl52hC/k1qa8Urms2ERib10yXWekzpUx/Xj/fBnLo8QwtUBO6kt4uq7Ri0NB4B6JK1IVEuBGGigwJm0qUSBp13q0RFNWR9mdbXO8doLJV3XxJpUDXeUa1uHsg67nJ3mDicE1YwaU+/xrNaJuweqWhzRr/T2EWrjvIx60kXgtTsbEXoOaccwGldW/d8CBF6Fu3UZHV4iq3fWLKZtJ7SE+D7NtDMgwDf+G2oIIz8fX0YEn7QwOZYv8i3HRxJv5giigq6wBRRpmZESujAtmKatRohypWKh8yflNxvohOhtAbv2c86GHZ0t5RLgJxexGFZRCH15GtIyyHlhaC0ag9G8Ju1l1sA5jOF5UOExV9pVaf7Neg7JTm0rABkZqik8ygN5OFgSQlHHWxdeHEduSsPpOGguPBzoFfTiott1o0QqGVpCn7elKS+dLlxYZWfGxInVgj9eYziI094MWhqniljdER5sAOmOK1zykoZVVAMVg1lUVaAOY621q8mq2OS06BizAzP6XAFIP+UPE+m/p5l1KUYBCNGFSbSy16nH3pyJabrtvi1avQ5vP6CzVyW4AF16jtfmCVgU2MQfPX0kmQEmyWgaWzUVRuTf2RY/2wGMygZdox6FQpNjGRl0wB0dnKMDnYOQDdYMf7o/NhpFC3fZYwX5qisQd0PNDR632pUjv+j0WrGzEGaNaI/juKnVkGFhYOIJqDQo3usQOrLSmmm7RJNd7sqAMTxctwHoVuHdfafAHGJE9sjKCIj7vshUJm/aIS40iBVIk9rMADINtFIfrskmk5O/BOK7h2O48IrlAL7gGu46c83JCANVGzWqV4bN0qo5+iiwF1Ttq/jzIavXtMxxBzRbkC9ngDtM2yyFjAqPVOK5Zj14PzhnPgaQaYOeHUpSlbWo7X1NwRWtweEx2ehxzZpizncwkCU0iKWYSQO84xcyETuHpDC0jOQqNu1loVNDqPaAALx14ca1FsRWN0jNCdRKaFsa1BrNfm6KSSG0qeRmex8Y4RkMz1yRXAWL/Yc+014JG1DkLZtrDveazyNh6kWWsxn81PilJO15XJnkrSnql6D8zcQ1xaNSn2rGxrEbQuTLag3TrsT+mGP4/Pr7mZVMEg2lY1UaJKJXonKppB03W4xhmP9RvjK+Tek3J6FRkYqEnmGw5BUbBRD4r6JirFPfiB1f5kStvAwZ7ZUUQ8dQnWByqRP9eqqNRiPa+zbbXdAhHBAFHW90TmFDcdoPuxvUuQUFqkFPFAzWwd/OHbwBjdVdIAI8wH96F/g+J6+kNcRf7AWCnLIQkD01VqpL4lUtk0CrdOOcOg2khhlPWdmDqa/gcSG15fDKvkBYv6kQUGqKfH28euNCPsEiNtighS3MceqiM7jRV1XkSZiNVK5SbPztBa7e3DNtKYS/+vUuFYfafK2E9sLVytGXVe/OYhmEZJchYrohLjWCC3EcKqsqZV6EPAmR6OYp8tsyleRxUXb969jb7FV45twEazS5gDeJ5ekbpfDWjFnnlkndKUjrUX80yra1q6ibtXy9pRXQ9IynqhimMFt86yTJEZN9B+ffjWlXPc34oRrokMnSwJtq+QQaAn/MyCMK3i6kw8UpF0mBrtrym5rvPbVYEN3Og26Vra+bF5WjBd4ipeQbfYLmeSkzQvZ+kMq7gvvBWTosNGc6pelIWDt6iHzKWbh9D1y62u4l5fARV0uXP3/Pr+b0IbUF1Euj3oZtNShemsyCho54rJOxaKIV5nfCt93Mj4BDlsPTfTNfRIU5jLmBfS+KPrg1EFs2aVrcVZtWyfCBwku34Zw2CKBzNACtDsgHarkJuYAWIuEnND5vfPQKpxa1H7S2MIbg/j7isdMey+HtFo7Gy/VmvO8FpyAELQFuY6t9vHoE/rbQjtmYNgAQwT54Mm8pBuhM71WczZ7XHX5/WY8soJJGbfkvgZZdWjapn7FrlYaVgk5rxa/acusopwSGV8UWwHRRkkxz0uII5NUvsIbvUoRW1iraxFW1igo/otaBDB1N5vW1HKV7cMVOlmPCWDDJSCbaMcLAeaByJjl8hTBnRHNkfM9IMt6G94SjptVM9c+9PF/Lu311MJffO8YVQbdXwnu0JgFjiDn1qyxnun31KV9cxqv8YUUrL0G1MEqmIwMTRb0cyyzhN2o6U2K+dVAzM0xoBxCcqYeu9IRPhhSD0QL+6gh8iK6lBq1gJN0uKLgBWVLGb/twOzqRqKUagcdscMBjQ2uVsVKWMRAndIaqVRhGRS+59BdxgDe2Bs29xmIJkkpdKpxJuJkFa/M/vyFRYO/tDDwBrmNXmZyg276jIVzTc+A69Au4Xai2L0atsGZDOAaa6xzuqvMZxO1Cx2eLoip0KUqY0eRt5pks+DGg+vDXizH++hIBv5bw33gztMgQQrShMhDyblcxkdHNSAMBy9O3p5ZmcRQKfcqi2CNEiy4WTuPJT1eeFFjZgAVSv934rD2PXY9cx7zAUc9brrgvbYWdgQZd5KRDzmk1QOWqTVoRtyM7nQoEA6o7vMgu9g5+3dDJ3OdeacTsTS6Wg0JmZOebeI0O8YisbbSIT+7PM5jbEF8iJGYs9O5l3wuNy7dkB7thTXZbZzbLaZzZRhpmcfPcXZnIEyJCopMErPINp6CAZIu9Vi63hg0W/Ti/Tc6L7AUkJUo5tpV1eP20WCFMTrC2bK1HohWOXg+PeAt8nQZvNs1hJ5D9z685pCVF3j3t5ltYa9Nw5O402XmbdqtNQf7LSH7KirI4n5PH3F7BIChPZc9OYLscW5t4J2loZ0RUhSePYOD5wDAdwBNJircwn2ZvLDrUBMg3bS3XozGkWnj4aA7C7OvK3NTHbAL1cfX5lTJLB0bJhI4/cgUlN0ucvXW0QXA51iP1Myx/OySPnD+ngtCoJeMMV478hApMfRGgLSyRFwAYfS6gvnIAlavqGo+U9FfYQ3rfZoI7PDxS2u6pJnU1cVKUzo3xgnP9p03l8HTVeAmwWU/jSsjoOI9ZSnqLS9jhIjdXvRYgbM6yJ4AVCIotY3/V2pwloFdlW8w3hfMe8WGfqz9S3LOxTxGdMLVWwwCzQAAdl0r3FhgiYMdM0wW5BIbIg4T9q1feuW6NCHuA/0tTg16Opx4Celi9ou6AAr111i0LXG98oTkXNiSWMylnVV8iw6Hw/QxsxMzcT1fTb1by3jnpDi4JH/hFkRY9s8idyTCljOzboWi3tpjIBBnz3TnfelwwDbnTNW2txKUGDOCj0jmAONkW6ixanWGGYFRQZ1CzyAaWqY8LxjOKuhay3Us+DKUjwAYkhVQJHYgDVmwPL5TRwlSSwlAcjd1tNM0RvpyxrvavfGLdb6K3rfZs94LWaZ20mY7lMfhfDjQmbPhLEE6Ym9JLO3zdtS02/8s0jSdEY6MR1YiGLz5WGXEtaCyQg1SWeadJALhmLcxKkk36su9NwsrPz52q+f9tx1wK0GqeJncRNx6pYeUHPd0qwAheMq0rqgKBYhcqSJ5hx3R5NjA95iT9A3TzjGP+rIel0DmcrD0VIkRGk2uLOlNY4g+6lOHXFcE+DWubCoukXNe+tysUSy/FuFcgcale5GOqsHcQO3Wzkga/djopo3ZEPnRYiS1lhVzQ5YFWcaqWTd+RGNtmSeNou0M1coGHbDQ/kbIXXHjRugUgKFoZQ+mxQKoGWItValH9u6H6UP1zr5YlEFRW1+PnnrewvJrcqrqBeknQY5VUpZ6DPrXBXZZ8EqDQeiHxikYNLS/UENZ1ZXpa131mRNK4xGWmBPIObET/r3oNuwaJ+17m2IhqZPlYtioRI3Wr5rWpRf0WatEl6TOM83TRkhpa7m8kkmYmZf6BLA1ZesiuzmisYQIWYVsDkhuE6T6dhrOqbh5apkYH0Mtfnl0VihzAqndf7uZMHXxmQu86yUQkPXe5+mIqWs/xypKrVyEXbhOiE6q6WRUjEnH7VWuSp10KLimlFFFavqy6nKxNp8KKfr1GTa215UCW07iEQFYYU69udZ5j3K/v2iqMS1LmqHBWae0uQHq0/k1NU6C/Tc1hIXd05hl1UdFvPabv5og+aafzYFfRSgVhrbHtP5Xj1R6d/d/Ny6HgMWz8vl/bR4ENkSYgg9fc5qBeSqopJNrLJf3l1lT5j8+jG0aOM3okCnNYXRIAfnuDfValg0tc6WKo1IWLroAoytSoyrlHm/rs8Oo8SjKSraeMNlrWeKwCt400V4bIKwqpB25cn5C4sCRxt7onYfUB0vqmjKmVVH7WfEbvbP5DrTKI3qSOoZPquSuRaP6zoP/mlCqdM0W4Ek8/soep6YATtnrcI6SZ2657FUW/DP8cYBcUbUCBYMcF1uA6ATzSNRZFZLnKbJW7E2QLQYJke1nQLCUdz0o4E9m/V8NLuKMrnkDYXd83akUbGKstXu2zYinqxAWqOTLzdVF/9kTY/n6ppqlLCLYXK1+FzXGNxzIWN4v+apHoivbOPv89lXbQnaArmyqAkzYfPfT+pc6QDdIvC8q8oerS0olbuhKZ53Q/Rlb7FK5c6sc7gmM6X7ILYup7CBt8A0W+YogF93MudbgKW1U82EL89nVSotiwKxr1jq4gXc1pPqUp6nGVDDsnFXAR80P2NJelvRhzQCUx2oMf7L4pR9wzhPzyO18GKPhT0n7aJukgK1emzCamYkncHV45dRcIip9oQCwXzaB83A7NBrb0YhADFNhd71zECRCgien19IVxAH6mlZDy3F1YUjZsGP3fdtC+2Jo3rJq7qhVgLU9gZ1qo4+F+lietjdDJIvlEnRTRKFzxbxymH6IVsEkEbtMSvRixPOssIf2qy2yzYX3YBo11iAltjuVhVQZ2sxn9BFWurkdwCvs1F4UaO2RcM82Gg5LuHEebLo+Xh4ywnLdzVD+razMxdMHTktSvNdzY2MBgEdEm/l1eakdDXt7YP5HcHD6qc5EgmqdbmeUU+k2l1Emq4DliQLBiJeDqjpuhQR8yaeLboa0XkxXVfcHR8B1v8uGHCp1PMzyVFMbM1p0mY2KZRJyCJ6ILLTQEY0VY8q9gJdyzSjmYCtn1PMuxPskvacQyBWIQKvztsS16JpCwnSUrXTs/053GrNs0GNnOqsbFrKsq3mNdNmFo0AzyTp4BH9dy70rLUC4iRTXQ8sRUktO7cHlmetEj1nm9tirJR9vw/WFg9XgYepznSzppjaHuFu47nMsYLZjELzE5Tl+VgMuKsElmgCb+6kDrlprHaACGKp4+0IK3rNIcaAOjkDJrfCi2uLi1ba6DNnzrRyKRyKopRpGd/S33tA2apM16ugHMI8eG8w1EbhnEHIvrxLmeZiS0pGopm7Avu1/5vKKsxgq+pcd5XlNQ6tFXvt8PUsFzy/74VRIRp2aVYyetRiOQdaK6bYzzQdIQSmUQez15yk7x29t3uytJwFog5gTeXkdfnqZJBrvf1VgCrUfO5zwzHL1v2en4U4T7SVZr7O0kKBU7XHgmYObuM8oFpUviDk1BJ5LULVKcjqbDeJiee5OypuS4NK8kDUGVgn1QSgsQ2TOs3vv+xEANmt+6Qgp041taVFHbz4c0VU4aV5DtW1jHphzbqCIbqjv15Ddm8KjJ60j64WNJtptoj8wb5emiraoCsFTbFC3tqmi5MGNeztxjY6URL6VUYDb4fKbjtnrNpbD1aIByKCvT23FlCoVpGJItfLZfEB7qw1PQvarNqoBe90aoP4OJLrNIwDWkGyTCypKaAqxhTQxap000GzD2gALDFiXHWapOyK7Jy9GTU4E+birWbBbbKPHRnJZmYpsT5CrSQ28qC3b98FZKWoQeuHhzvZ7faDNifl6fGp+XvEi6Xc39/JbrfrG5xd4vtyuTbTYzrpdSHl7u5uMUx2FDOZzTZfXp4lJZeLyP6wk9PpNCCq9gr/6flF6rUmsq857eP+/l72+11AZrkYzl6v16XLcJV9ETnsd7Nh5mJG+XylXK5VPv90kU9+5lF+4nNP8qnPPstPfvZZPv32WT7/7lk+9+5ZPvf2WZ7Pl8XDbSlrVyUoQA77Q6PBdfyTrTPycj7LdZrmdKD04EdAsNvPJqKMFF9Okzy/vIjUqSseLuInlSLY7eXu7qRa9v2zZwPRF7meL3PesBSqM3pXRWQ2O165+3OBvFgIlPmZPr+8NAPxdYOvHZrjYb8csl08ZydFym5eD8/PzyKLj1PZ7+aiHF0567B4ggGUIrNX4Nz9ECk7yH6/X+YP1rU6zYfcEuDO57OcXy594y1+VVUwm8Pu5i7M9fzSbD/aYD8glWU2992XJllOp+t+uZxN0UyN5KHIbgcTJGU5LAGRaVrMfVF6kgpNm4CcjgdL61ACGefzWaZK2ZXd7Cm0BOHV32Y2VS0KsWPbzpfzs0xT7fMQUtp72++K7PYHKep9N2+sJaDV61Wu03zorIbDc2FN2e1nM9ey+vStPo9LAlule2A1ahMnozI4TVPreq07pi7/2a2Fn+r81HoVVFoBItY1zRXI7H+43+87srwUWrVODWRaPUMndmR1Zj2I7Hf7xUNx9YPdyVSrXK/T/OzqtPjfUU7Ho+ocLJ0oilymszos0USyKFFKv7i53WUJC2udu18qaSCrTEvc2e+KU0hcHBAXn8Lz9dLV8srahZi/43g8yX4Hlfd0UY6pVjk/P9nJY3YLFUFZlGHn35k7torRgk7bZb3K9Tp1SpCsXYl57x32xyUR1B6hc3zbich5jZeAorqx7Z35gC/K76qbS5Td4u1a5xW1xq2pVnm5XKUsnnilFVNLLbTus06HMV6CL+cXoVB26NwYNg9azMb1KJFeVuY19fJ8nuN92S1FWQcQq0AOOwiXtaopoLtdketU5eV8WaKhmrVaILHjbj/fE4pKPrvG6vlykcv1KmW1nEFnYOz2Bzmd9mZEYY1xZSlU3757lMv12uhuzQd1+Y794TgDqstCLoqFIRS5XC5CUgqUnfhyhlUROZ16XtLouQ0zrnI+n2ewR6nB6qLweDw23zUxs7rzu5rP7oWdJbWBmJUiZb+X/W5vRhsgs1duWbrMHnxfGS1Pz89S62yGPvvpzvF5ul5FFoP1Uro9U1n83cpuJ3Wq8vL8IqsAlB7dIEWw38vpcGi6D1bgjnI+X2aDcwVKrm+8ynx+dq9BNlr3HCeu8vx8lt1+J/t9kYLdLHLIOV6UspfjYs4OxbhcQfTL9Twn2qvVzgIUTct5fzzsZKrT3LFXnUMsLI394TDPHNbe0W/7gSLPz88y1TrvtaU2rMLWGTweDsZbEdL1GKZpmo3nl848ym7JuWYAebc7yuGwazEFSj529n+8yvPl0tV2FyVXSBESsjvsZb9H81RevQ3Xj7ler3K9XtrzXlkZq1fifreXu9NxYVGVToNVLJlpurbctS7t4JUxIyKy2x1kt4AkZVfk4XSUu+Ne7k87+dgHJ/now14eTnv5oo/ey8e+4CQf+/BOvujDozycDnI47OT+/k6kHCwkpigpz0/PcrlcFxGUqnLv+Sz64M2DM2W3f56fn+V8vi5xQnX/ls+5uzvJUf2+zn9ezmd5fnrp2h+KKXE47OdrT9oq0zTJu3dPvUJUNdDp7rTkWoqZCMjLy1leXl5k5FH+5s3DUJ28fR/zOmV/OMibN/dZzdjrIj+b42csemsZtjeDAQXPzzKIE0jB6nlmUZBucdR9BQ3ZQyGEmrZKWb11ujylEfuAQsGcclcmc+0fUgFEdhBxLfo4GN7/d58d6bOV+x3kdCxyWoqWz7+d5Mc//VZ+/DOP8l0//Dn5oU98Vn7oH3xOfvTT7+RTn3+Rz3zuRd49TfJ0vsr1MidklVXAutxSaVLAerZyFdzBcohX3yni2jVASwxEoxxN+r9xZvusgSpEIMo0XBjohFpqvL1v6JkHdI+WNntZJcwhqo4PMCf7c5bqZOCX4KTpkroLRsJ4R/YbV213dsKJpuOuqCvgOw9VFV+eRymGF9YdLnsxxoZY69krmq4glwOrtAPMe92pZ6Y7l3q3aFGB0tFSo82FFelkK4dI7efZOx1Qyn9dPKbqoTFDgZ1/tydt0E5sqwG9KCoRk248xIqP0Nm6rJ2iNgtY5hWmu+ToyZ2wLr59tVMcRVkmtPWsTe8dKqkp4DJoBAY/Kn0/WNQHvZeRRBRPHFpP3SqqbS/Ohedy74ttCzV9Wj0fM+GyPBOQplC2N4SMMayMrZXxckuI5vXOpUjqxegS5Ke6ADh0nSTYGanML8LFCRipX43UdsEaqHepBVc0DbIpnbruOjRNnQrBtV4TTmxKeuK0qlc2sZEi2PVibEbhS4/l675oYwgW9W/xW3XbuXTWQDc3ii7w1Dyyyl5kV6SpKIuTfV86OgaAUl02WRR0zUz/uiCqou0VrZCqKGuIAlp+ikjPRYkCTXo88XYrMP6cnk3aRzZ2vSMAxHk8KoaRs8BoNhxKaMvOMXdfRW8HswImmv6ox2faTKabLWuz/kkTQDftyq74nkg7z4oa0YERVVnXgzqbqvMuNiM+TvmR6p40HZ290LXnYcLSWYzLKQMBw1ScSr9/dz7rM8Uk5DC+qdrvr83cSpVtRxGYZhpVzpI3huc9V9Z3vgL16OKKRl3c0Z9FuHS0oQRu6EZ+aLu+Zon0GTtRYw26E7Te+wzslX5++znFSiUsx16gD5gXXMVSlrGyfaGcDkXuTwf52Id38rEPjvLFH7uXn/PlH5ev+covlp/3FV8oP+OnfUS++CN3c67c9AmW3Lo5FSzq2YDUWuxYgzOPh0DZWIliC+R6FPZ4QVMjX+eh131T2Wc3feHWxpzWfNx7c9POrhoHA1gHVSv5wIFIp2U5C4qaJx03sDzzYR8/uNihDdj3jKCAIjemTSXMD9JJDRvetwwChvueppilFfxUMmoe9FB51A+zKnU/neiYDmdRHk36qqBQDcq+WKrFT749y/f88Kfle37kJ+VvfM8n5G9/7yfl+3/kU/Kpzz3Ku3dnmeokuzIHxcO+yL7sZqTlAMFB02kSs3dH42hjdfDDyK4yL/C+xZY6o+h4TIYHs1VgSLNODtgO3CrKi6PswoihqEuBmt+k9QQT2RlGMs3sA6M4i1jFPHs9dpbLDCsr1ApB0RB2UN1JzxvqspOW1u1ATU+mp+y2wxdmw1OsYbZhJaqA6Hnylk4/r220QCYp2iRqVqg955ZUIjTbATtiDZVg6yQtC1qgmoxofoJxNsccwuZUtpGyFQ3cu8UlVrI7pc3AlP56bUMXLanuwobBsPsf6wHGEgW2aKiSXvWtI9+aog/k/lpsNKPi6G5mxCIqqQlSSxXNcKJ7f4LS9QvXQhvzTRKKKr50lbUMvC/y0uht9q7dXFCHu5669kU6VcKexwu3Urt3TI8FdPFURMidZPpy1O8BilrdVILX9bsXb1lkAYycyN0osIppEEsuJ/2vCynsVVximImnoxG25Aiw6wIyRqUVZVMnqRb3sNZR2iMQyVqkK9g85dTsmTXZ1SBxUxumjeHw1HgY0NqsDgbTj+R/0Dx/arVf9X1kxBlDnNGegaJFrqB0A6J5ySAoLGyCop6De5WBvQjlmxlp2wYzDkpfiSANrS1RTm/0M3W0YimxMSNeXmmdM19VKaFspuiqbmscpujHDdyU3FJLdQ17zLXUTeXIYaYp9GfHCRBdPjI4zIScTzUykJjQ2zUMw1rsqY/NN9wqlm5E2wzL5t+vcz66znKeL1f5kU98Tn7wxygTKV/3zT8opRR58+YkX/yRB/nKn/ahfM1XfFx+8c/+IvmFX/VF8mUfv5MvuD/Ifge5TjOL7lq7DzaGDL6ZWs+QytCCP8Pi3y85iB2xi2o71pajC8YByMjPITiund4tHWI/UWT9ERAKQX8/BuBVG3Lvi6zov6KEiJ1iAAcvIZ2/0fsgm+Hx2xtZuZlwqJOoS5Fk7kJ3iyRaJ2DjVqCTNb0G0ChkEMp+v5tpiyLy2Xcv8n0/+jn59r//D+TbvuvH5Du+7yfk+3/0s/K5d2e5ThfZFchxB9ntIB/58LSg1N6cuMp0VSkMcj+r+XFVlf8qhUz/eBQdCkTGNk5QdFqE2CXCxjzYpL5UHaDRc1UdEnXI5kbYjEavuuuDWKlGpNFNU4MK5IjzaUHRlhLULbwDp69z21atLnlGliLG7tBKe7SgDIy0s/bLpDgFs9Yh71k6aQmD1Mb3xpuny7QY9JEu82nXUdXfI8wlQCGHLoSJPm76ucL287pYsoJHfkg6wrQa2fVTMHatqWejul6dDdQ7HaDtWga17kQumVqKnh1fsgn0gmxPuQJzH72hmsOyPkZ0A/MSe8LpAW6wJVMQWjGwcH/MPDF1TKkq2b6G+s50R3zdCef5GSAu2qQIYo2rtRVJkuSss7U9gWQT4bDMFleB6U4OOp3L7KkG3PjnotcLN8XTNMrNYA4Oq/ZjiAldaK0LDGMxuW+tgZjIuNcaFl8ctbFAJKsBfPVotG/c6dklLPEjZnT2f1qBCba8wppKV0n9vt3YcEuADXBUTZFMUlLn0FV0LIlD+aOiUhotdu168oopBGl0BEzoVfW6OIDc+v+uwj19T/Tzg8E6UJ8/I9dUExeQ/A31zzDxyLDnQqYbjzR+ilGvD0QG8cE974rQTw2PLDsXgIE6Tgrb+QTBIHV0ehSaBbI+m5qPAuYFXVYPK09s57rTUt5lpKeYvIOWnRM1RsOX6WXYpjOZGTL4DmcEsAogp+Pejo4LZLpe5Mc+8ZPyQz/yafmmv/79sttBPvbhSb78Sz6QX/iVH5df/tVfKr/oZ32R/Owv/Yh84RfcCVDk5XJdhBApTnRXNbls0UyXE211hOEVlJVVDW93mob+iJnoTKiExhbnm999yxUo61YKRPaAyC3z7zBmT19t3/jmJmaWBYORyXB8DnSmzlCUONtVoIhH9gClfJtLkqf+khqB1vzmRbzkeNjJ6eEorJQf/tQ7+Vvf/qPyF//GD8hf/Ts/Kt/3I5+Rz3z2UWqlHI57OR4O8nCEAAenCLccQbRyz3BFj3sYxni0I6kx+bZnOh1lNoooUHsHMiYvfvvDpWUG2aKl6dpT2312s0ewPn0iHt1UhyeTAkideE1wWaOQK09fyfHCtft7PUulepmg2wKpcJ3ZvFYKzwzpzoYtJHWxR40kU6wumDYs9x5aqyePo4xIpxYDSknVVHyJD6CxabFMsXadog3LKQHTVKizEbcBXSK1HqBaRdHSf4PIjMTOJjd8YrkBakGhTDA1NhWthm6ISJ+i0ZsVokEb56sAneAyBG5dqMcbhptdVkAOdW9IM0B8N4zWy5NikkhJO5b9fWik1qtmKk6PJtfZV4bxwSkmEZPmtWneEySKmyWml74o8YmJJSio7kClpALROvlhwDbT822IEge7l62HQuv5BTGK4Qy2S2L8s5gUMgFccR0Ds5maynIigkALVGidEvP01o7okqQF8JeDokTFC+9vnoLIUB1i73bjgncGptJk2lHx1p+3YGJY3m6o2lPa4FuJAjVt2xGbZKoouCHO0gbsc2Z5lwQhJ7L4eozD9vv6+Q0Tmwbx2XXfkWbWjFIOvgCg85AmTbVMxKEjUYyqtLhbX1FN6zNj6WCre120WkluurMJIf5ZPoLGODNboXamM+7Vdb6UcJ9lhEXoRqEkBTdCGioI8cjuG65TF45JQqOOrO/sWCCnu10Tsnl6vsrf/d5Pybf//U/KH/3G75GPfHgvX/WlH5F//Gu+RH7lL/xS+Ue/6uPys7/8i9oLuF7nuc7drpi1W6S3qC0MLTcsmXyM9ed5YubjfWiZYxUcKK+bpXuzbPVdP3XOO0uaeIbYn9m/ypuKDmUNh8K2f4ZfYxZppSMjwVGUKIaU6QHaLFF3iR485913DxUKqP99kyJnLwqmOtNBP3hzFEGRT3zmUf7yX/sh+fpv+QH5q3/vx+SHf+wn5eX5LKVQjrsiDw/HBZnhIsRgg6buEiFBf8yigJa275vcqAg5RFy3jmEoJUxeigQPE6akPKSYkBntgtUUJJNosqJlgD0QKKFYAuyQeydEMV4JaTo6ofOhkUPCGk/7H/TFT7LKkHG6tdjAuuZIt8LpMmG6hDB2I+mOd0icDdCdKFuUsHcNWtHPzo1ngvxqop3vIMA4H0fOOix1SXTnl/46mQhAUdEL9WcxldPn6CTP5KwVzSkW5kpMQSuQBdackgh3+4m+85z6Ay5Jo6YbkhJ4T4OCDIpCFxFDKzYxKips15M522J9CtUhnsshq+XMaQA0W6Ri42xR+nwOZ3aFv5tPhXreof7D6Gi3LbCueOp7EjbbR7Ifh4UsJCjE6WQ/83PtUuORJUNHvZNR8mwonxJMHKlkx8lBYgJrRZQVGc2tYu2e+NYybddRD7nQFOV2gDcdSvCdT/2Gqt+zVCJZ8XyD6xBlNdS6BjvzBYbaH+a8kCR8RkBYt2rcGluBXX3NjqFr5tUqAwU/4mDO1BhuvlNRbqmYQiEndd0sbVVlNCTWTlcDIp0fqV7PKfuTKhaK8fllBgSJppJHjwskQH+fa1wsaYwgzqD95sMmFDU05EiJOmfy8w2Up7U7oFEw7owgO6G1goLYGKayAQuu2eEx84zxNAbktEejst9pFnPIz18z1kITF6s/70VkauN9KyUUcnfay0OZAeuXl7N8x3f/A/nW7/xx+YN/6u/IT//4g/yKX/Cl8ht+5c+VX/WPfrl8/COzcEpdVJ53RYF88BDJVge6/1CBA9w3oGRbWziWCsfwMxOQcrseRCjNDdW+sS42+CewPMy99wXMjNvnuajSkxvN2gJyjw4VLJpXjmRoGuxApU4K6H7XRYnue9QFAbLWJBnTMW/U2jnc9hnUOqvpyUQ5Hffy5s1RzudJ/tLf/jH5k3/5e+UbvvWH5Ht/+DNyvV7lsC9y2hc5fXBc1JgWBUMzJbm06WGpVlqcgtobSR8q7tpIJMXIeiBa648mP2PogmrGxFSmULN60iicmlgA5p2jvE0Oi8DGpklS3CWG6BAHHEh7npoLZgd0LXRsR31UYqJmTQ3qKbctRsfbFEli5uecaI2mFGUwWihEU2UaIQsOO2DGokGhzlBPnunRxhRvab5vjmqJkBDDrOl03iY7iH1gZfZ8aaiptuzqiLL2VtI9Mg982ENr/ZviqhelstyESDhCoyK6zpwTgbxVlaKukiSmJG6sSIUEK7QW4uTJfWcTCAeo7jI0YQLEwkOfbHCzXMEowgFJw4eJnJZnFwYGxVRQD4qeYi2EenotDdPcPi7TujW+vdZE0XWXMiAO233s+TZKp7Uqs3vxwIBOQpF06d2LgetecqtD6WeRKUbZMIrAMWUSGcCBSGZmY4NSd6f7UcWYgFFlGQnQkeVZwblLM4vchdEhUdbRKJDMMlTBsHy6IJw9GvTzbAktLMi/vuM2S2zen8oA6M4j9Fg+fjCWi5h2yPW+Vt6MfSY21EqRQQSLFFVL0LerZ7BPZuCKJubSFerQzAz0mKJF7q2FmYu3TMQXHSMC8ICsChiMJ7UHZTAARThgfmQ9fvgTxM//UtN7fLEf2TVQLVKYfKn/IFT3Exydh0meAp+YSwcTl0usUy/k746QOynCSvnRT3xO/vAPf0b++J/7e/JVX/ox+bX/2FfIv/BPfbX8E7/wy2S/K704ZJfTs0KaNfgceuptbXPiYtRJKRxSPnv9YkEYqzwcu3arDgXSYnNQcC7/c6bNulivGme21vIqeBCcz2fK8IilXK9TWPxWPXPvxDUsojtNUxPuMAjpksDtFpU1n+jOcr11kfVdf6e/IYrIbr9TZrm2c1GVEbg5TZZNVMoqWR4R87Vguk6zlPL9qcjxtJcf++Rb+W/+6vfL//Obvkf+xnf9uLx9usjdYSenxSqhKmdrI+iCiEr6hWASI2d6TOhO1VoAI1CMTOINOzNpS0N9nifpPn0SEYOVnYtxhq2J8JAZRk4nrxUCR0UE056V2jQUsQg1tLIFwGioJSMDBypYMwloioDvkk4P3yCizZp265HLcPH+30G0yWjr567mxUToZOUjsN77c/C+02JOIazqGowwiEG/Bww3H3f03Cp8MhUJyb64Xu+fGSSfJep6Dsx1TJvwBNw3uzm8APaZa4CJb3pek+kJHxMq3+00UdgMvqdogP3swdaK60GpWCggLnatTI84fgeUYBFowlf3yLMNEjiE0s8xWBaIBfMMewQwU6FUzwsZhzCpyDVF1NOIkBzwfqfBZ6lgug/aIyfHDFBjbQi7hqHpXwrpBkNn2KtHmqaA421aBlQiUoEc9IMwXCIVuKd4k2a/QnmB9UTT35dDngyJgq7749T5WreyiJnVNVuGoZPkM3OzHJmR2CUCHxIs6i2WnXQQSAt0ICi3KLpheC4pBzcz0OoKuK7KpFkE6twJTGGEr+sMZdsB17OPSPIfGG4LQ/eX+v1glHMgP9oUWGCvURWiqhMpDuC2s9c0VSUT3229V2jqGbj5/A6cgfApqUvMs7MrAjGxKN7wj/Pdfpdwt7yHkEzHozdW/HnvAC8L8UgG4ZMS59ARHwiU4j2S81Lv4IJZVfvlWuX8cpWHh6P8sq/+R+Q3/dqvkd/4T361fPFHHuR6vsjT+bpY9dgnvdvtZvsko5C69CIWmyc74yvNd/Fw2FtG93K9tYrU6RqY9kJK2e2aRZfOoeo0dZs/PQu8gM+7XXFAhC0Ga1PsRuh6ljJbYaV9inU3fPazn+coh6us8ubNG9nvS/MB9I3yd49PMl2n9nel2FP9zZt7KaUoupmlS7x7fOoJlZ6RJ+VwOMjd/TFB2+fF+fj0LFw8AjVVorLK4XAw/iCaZlMr5enpuRWMeh2WMkuBl7JYRIjId3zfJ+WP/bffJX/iz3+nfO+PfEb2uyJvTnspS+EZuymI1E+3TdIg4JPjAc3FKL16iXONCtLZDngalEeoVRHi2XPGPDcNYPpzELpZHBQtcF3QwJRT/2JIewhtHp9Z5CoIbZYPir4njqSs5wO9OTSoZvcsrVLV7kbIaNQ+MlMe2iKD7BQRSqJY4iVFDfIx6DPAzTvow84ONKQEB0ZxjFxIBQ340QdSmPFqeTTSNJYawXS8MW4immKQMviDWXkw2i6mSip0Ih7U2zQVFk2SHR4Iwq2OciT82L9zFjyiKO7qAXKUUGMg1eAOHieJl8wejgrNnN6CgcI1JJ9LtwmoRpnHM4xahc/+eyohInHAWAJPq3ttPlUuyCADUGCfMxyCLEjKWQ4zd1X8OCiELhtJOjRkDvqsa9PgJbAQhKeWWTVPmwhTJICdGFYkeeGSSRcE0C6jtLpZcDvm4UQj0koWKZuLrooLYxuDDgAwBtO19LMBTNSKSnemBlbM+hxcg2AgPWp9nY34lQRXjs4GWnMPiPK9WxhJen3Si7t4c/AoHWpUts2eoKLw01kmqdhMfWZSrHIwIpHPUNkdGO/GFoBERpUZj2MR8lrPyCzQWU03Z5eEUBh3oUao2djexQS3NhvTtcsN0Z2oVhsRXQRwzuZpeE0t6raCZXpEk/ioUO6BXjgQgUZIafbOhdQq8ni+yFQpX/VlXyi/8Vd9tfzmX/fV8gu/6otFZPa45WonAcjz84tcLufZi1J0rVDleDrI3ekU5mxn38AXeXp+NhoO6/UeDgd583CvGH598z8+vsj5fO4NLel+iHd3p3B2zK5QVd69fWwFoy0GRfb7nXzwwYPL1dHW6/U6ydPTc9QeqB2o2RtvG9rA4f0CM0LaXEQhBNG1ag/kJrpN6QaOoNGygVaNmWXSQ/TLZtrB0Za4+pPRCNCs3ibrJUyVctjt5HQ6yuVa5Zv+5g/JH/uGvyt/8r/7HvnkZx7lzd1OvvCD06xo1IyZufD/dVEbB9JhBsJ9txXdSkBv/BENLNhywSFTuiylU9ZMMjg/DK6os9AorqJ2GnDKycc1mgjt5gmnvlsbwJgmjawbOGAyQRzySe9N5uZzdKdPzyhyfTcSinYZDmDboB2FBzZ4+r4bmbMHTZcUehqUUXjXewCAsUtC0yWxazQ+d9gO67AYtMlUl2pWdENH7dJiF6vJdEyukpBAr/UffDcGsu+WsqW7fjCaVwjfDSQ8KLFdfF3M6Vkhn4iSer4zyxC9zxlMQiRhNhxq9jajCvryUsNQGNB8LK3eMPJcUoLBKvezryHX0vdBbALevXi0zBRkgh/odBlmwFuYDIGdQzbzwKu/Io0Sq6URWpuCQATQ6tYD9f/wS2Ba2EBpVYg4AESfl5oqLpZxYudk7QS/L1zggU2lPg11dsT8LpHWiYPd7e+rUsakYsBoIaO+X2zyvjF40PehIcvrTpFaM0Pilv9s2P0Pcc9V6TesDCZl2h7DmZ0NBsZVsy2BfJGWUKfpbD3oup5Q+zOoXyTVAe25oAHMMAOXzFrr7u76AlKftU10jTY2igPAfd7F0e9LIrGZwqmO85TgS275MJ0fjd3gkOQ4qmgAJN17MfYPIlZ0RysqC7ZzahPDxLJssr/f2nTZvbuCxSqyi/GHROiMKGsyAxrMgWNamK1vTgcpgPz4Jz4nv/e/+ivyh/7U35Tf8Ct/jvzLv/4Xyf/gF3yp7HdFpmnO4UuB7EpRTDfll5qyOWb+aV2FHKFsSDDTUOFZBLDtCLS6Sds/IDAWs+aBj6gI7kxMG0SSgeUqV9lDVejUpws38d+OOgIS5wRsxgPP3sGAorgalSNKPevv1A+hOnsKY8INmIW4BsRa62IW3F/wfgf5goejfO75In/6m79f/tDX/135C9/+g/Lu8Sxv7vfy8Q9PUivlurRkNUpmvAuN34/rcNQuU90LJHROewsmFpXXNCNIpIl1Cq9Wk0q8kyRUqXmzSc2y0NPyRMycQno4ZEl7re13gztERrXPAPRB009rDdJ5DuoiA+75ep+AWUWwI8x2fVI1z6yyYVRlpUExqZMtWAl4QRcKkEyFbXzmzI9VG6M3wIc2gHqQnpHK5L9Oz6FYz0OaGVF/0EESKqkb4KfJJKnyKSrEVb9T7/EGm9Cvh5mfafAdcS01DTsDFWSSVmuPlfrU6EYaEabrpNpA1AVwYDrJazfUz6nZHuX8+1UYiX/t0cEIiMCdOt5EoHWA2nNgLDbhrZrijHegNpliYzVTTzp3znqjxUvzeq28tJ+DiQ0ZGtEOBhTaqg12ar5mHmA5D9zcqVKTDeqDI5tKalGTpaDRtDOtzkNLVR/OFzlkTK/5ZLpKqX66JDGiRVbkwN9H6xT1uXcKA7VyXUu0+Zmdp6M2WV//nYIXEzAJjp9IR/vEgJs+F5HUI5vWUHwAi1DNWGvgZii7B0S8RuVQcPTFMBONCCgRfqKAUmu2txXtnbbAbzZP6FoE8LJW1QEESSpgAVNL9ffnho42SJHryHgwytSmYFU8QUPvLubYpipeLbmFjj2iSxBakIPKL84nqiJRXlMtRsDuIX3bVRS46/QiDJq/zgEzWvsE9WXafEPvr3Uf1kadpo0xLqYnl2xKdbgurjjPZmSdUfFNif67vii1Y6zq/et34fcpmQALnrXV1dSniTJRZF9EPvLmKE8vF/m//+nvkD/xF79LfvUv+5nyL//6r5Vf+8u/Uk6HnUyAVIHsyiqSxEC5rEySUybq98lO8AVlg19hFDLllk8EMoKPDu2ODZwbu2iHAfti9nRVWwSZaQ9vNx9DDuh/YpM8/0DakLRv8ZfOqcUQubEPCK7jXMUOXxJhAlxqpUzTTBn9yMNR3p0n+aPf9F3yf/2T3yF/7e/9qExXkTd3B/nom6NM5DwL6dBMgPko3JDKghTpM/SItduo53rgjT/187CiO4T6/uTZd6647UCQ1luQQ4TMKnGa2UGtnOpnK7Rx7QDjw4ouGrG6atBh33nCYD4IiXNls0sAQmOjxyIqdAbGA0zcc2Fy7gVPO7Em3y2QOt8pPU+Tg5cqAcxktuG80WB9Jn0A6SA7UrRXCx2FDgotEm5jCs1MmRhlOn071kfQ7hc7O2DjzuK5CcROin7+Cf2YGRoCR0XytFmVMFtRAmU9wT4TrZ8Po6xJB38Mat3VOCGUCnvQrCBE+0S4oskkSatFR2yBI6EYZqN7Iz8yICo/e+NvZKef6XzC6zQGaxpogEskUMphkivb9bIcGwUwrEqOSPhy5pHS7Ml+blKQxFS6rr1FuPoZSGfKvX5CUcwWcZ26vp1pFEiD+43xFYSbD11Ao9HQNZLuWFZ0Jwyg9pi1sXvwitUZoO5AUq1rW1BEYMmEBUu/g94hLvkJSS/j7Jw4+xsNbm/Qvam7l340gkkq5tQiEStJm6wFgbaeoxlLpuC5w8AOSSZJtelCP3c99DLq/hhJN69ULFEuMYmDWt2NBvajsx7J5+cw2IOWkYiEtqoZQBBtzALCgGb087jGkRwbbehucWDe5ca1eLEY3w8FY5Glu+zRGiIT6fN0DLF6BGZViC2YzTglbcyDZVrM3TFvNoV09CsU/MqfxtJaacD52FPqvor+6ypF6prrvznKtVb5//yl75Zv+Jbvl3/yl3yF/C9+4y+RX/dLv1w+uNvJ26eriALBV2EYMg60rLYSKOigghec2irsxOYXVV7xBzkuC98c2mrmaSaMSk4BkX1MpiIKln/RgNokiYeOl1BaEhYyeancUNBRSj96qQVRdw50clYqBinTRPngYS8FRb7+235I/qM/8e3yF779h2S6TPN84KFIJWWi9+lqJaWBLE2SA99pE/FzFExRwuwVMk+oXZmwBg1JfF30qc0Iu0tunTlImDLiOFNOo+O006BHMGqrvStSNIWAFq3O1mrqHylcmrFONGNNCGnK8C6rTatSaY6xzIRnSGtZz44idlJnQ79pQI3zCoFFPG8ebnthlcEMK8F0cZzxewdV4ApqRpsQ1V1AUrcSUKqMbjgMiQiN6vpJQn2LdAsMRYl0VaPn6+AnqakTcZ+8eDqpOORAwj0ZJq4WUpGYh5cydw2pUWzdfXZrujfAvEcNDerbKcFJOFaLZGVhIA6fxVnvIIiF6E2m7CCYlH0wRWUiXBJG47pUvhaTgsO/4rS+WKAqxCcG7TMjuiHK67FKUoyqfoaeKx3gfky82TSNqNkHMAqV6FpXJ9nwXbrs2PUeZFp8iklx5ZZzQPnbvrViZkjmRFPF8Wz+T5xY2pagqe8vqXkzWyu4qUio4l4JHGGr0MtsWAdpUaOyMqcvihK0w0gEKzV3s/YdBMd7LhzXCMmzpmETYtYRKBG0Yj5zL2LPjNC1v32QWY/ayOOwILUq0TlQu/bAtuiOOW+c0U4AxhYiNJ6q67mqx1GYnT0JZdjsNOiuPAN12YOmxBhCz2zK/LuirZDzfM3sHf+usyaEOIF0pJ3BrINsi1CRLMmkJEJ+glgIMl9HmhjowbVpmj/jw/ujVFL+3Ld8v/ylb/8h+ad/8ZfL//I3fq38ml/6FVIr5e3TpXULuVXRrTmYvncFZA92Q5q3vsJHfvM3mKru8tW/L+IKwrB1wODpYhM4VZIpvkhgIvoFldRuMEjpKx+NtmLwgiBkYjZJudbZTP740Tv5tu/6hPzeP/435ev+6vfJ+TzJ/Wkv2O+FrLNlBJzQupOYr84VLq3ApVPirPVi1hZP8hsZ1VzWv8j64ihaouuOIEFqhqsW3ceEKacRzm6LZgjdO7Z0BmNXBLRbDin9ND6AaOAJV+hmM3C5f5cl+5O0hSThEqit58VQsFqj+zVpVyaxsjGp4mmASp7dJHyGOqvmWRTtq++LKilPHeIOO3jg2ab6GQvZz4dCpKjCi+GQSMDLgJOwixVkc1JmT8aBe1iM0nU0Ylzz/pZBsdHPuKi5VK2My1w6xTEnFNqLmGw5vpDrLmMjwAeFleV9aL/DgPe1l9b+XRjg1T55ko4V+NE66jamP56YCe4ygJNtzUL7GzJ2dAROcdmxBbw6G2Uofw4lNGPVcDNhBya8KzelSWe2AWTcixzw0xy9BrQMDtRErXv8PU7kxiu26tlzH0OZdOdHNZRR+oaV5E/gbo68X/V8vqdkolO6xc3Oay9O+Ko4aTMNHVxcN85Ss2CZSHD0E3Nme4Xv6NPn9K+MSmgqFTYQ3ZLgA4wAzOuDNE/BuqH7SPrKUnb7WRo/zOtGM+RLdDlIAKiSgtJVeMFzgpIIgnEjbKpxIJiuHG0RmcTZWKggzvZ1ONoxJuC61pZBFZoK4seV3Ix+AhiEzqFilVkfSu0j7mZtq0QLHs2uCD1J9DrBJRXWgYCboEJ69KnOLXwBrk+AhUoOQqblTHm42wsp8vXf8v3yF//WD8s//yt/jvybv+mXyNf+7C+Rx6eLvJyvjdqZFldDFuRCW6fPP+PoXRXN6rtVAgYX66EjaXSHyAAE+5f7HGnpfBedLGm10PBrkKSzIiEpp0an3VmARnnEWFHGVb9sMyzovoQJ0jjVeasd9zv5B59+J7/rv/wr8ke/8bvls2/P8ub+IG/uitQ6NQ8Qqkn9NAhSpEjpRSMskmXod06IpA+QMoqwBZsJCTM77RlpFcRlU8N3MyFG7MEqNzpFVB0nVwpJgZnDo1ZNy5AoI9iiDgkzV+NDa0R4UzVNiJMw19L8cHQKK5MKR0vqip6aCoe2puD8OTK/GU2XwDid66JHS3QwZubsQ71IcjoziqdNhtsMjr0WK9ag5krEUy6s5YIZ8oalpWB2ILdeNsonKKh5KnoPYd8f+6VvCgXQSet7b0JD4SBi3rl8SFWBN3TjzGyuGIpiUYbqpgjVlhVkoKL6eeCQFnjJc7iOkFh1Wz1gR3GG41mnxHVtyNUE2SLeNMqrCS3PqFrSmBx3qjBS25GsluyFhFY9bP38/n7cnI2lEnutAk3/jpUP0oLEg9TWn4kc9C80QEJl+ixc5oXy4txLhNN3TESretN465rOxTC5VcAVIjY8onkmbfeopWqU8ey8oKWB6vPYz4nb9iATsbEWF5f3WEIfxDIlKN3MWxeoHKpb0e0POLYLrD4BbZwZU6hsV8Blt9LHQjVTZ9MDXJ3XrpNF7dfofDKpihe6YhReEVf79RbVPaHNnZgAk9RCNbBglhSxpuX93JAR+OLIwxqQsnUk030MPS+knonGZuHo2JYB4TrxdMqa0GM0juQm8UzKlNvF2ZwY6yM/Q66Uy634Du3V0o4T0fiHRiHHPq7D6DgBy2LQIolZHxIuJ/asNMPYI5Rqbld077ZpfewKRuRK58gWdEnVdgErGLgEgibcBL1m0Xw3Z2uI+e8/uDtKFcof+8bvlP/2235A/rX/8dfKv/4/+WXy0S+4k6cLfd8p6cExjA4wEXYTKe0Zru+luJGOTSamWXdjZfVZRxOplRQTi5w1SOxNornsMK16t1pAmI4btYEjbEfJFYl1dYM0SoBYzB71HCLczLutg8msO4GA4PvDjpyvYb8vcp2q/KE/87fld/2Xf1X+/n//Kfnwgzv58G4ndbpKhZ+LzCp2OK8qJuICeraQrkim6dZ0xDKiNYESpJFJyigzCMHWetm5wKHkg50+hQK6aQa/hTki7AfJ/QylCfB6YL9VZExdd6IXE02ndU0UyJRctAi29CCDwDCLfjwxs2TaWS0J+hKSB87s8C76A5fq2DkaKCphp6PRxQNL3ZSwntCQPSokuM286Q6LejG6eIP0+U2bVztPMdEzc7HoMXRBjw6H+UhRoA7N7BsRg9dWF31df0X3/Zy3FGSEOCZJ82JCm0jnJUPy0bCggVd6btTMy9hCuBWeKSjkWRqSIvBNrCQV+LXiCiDypiMtBQqKKsyBt5+lI3qaNTflglN5ckpbv46XknecPbWAcNtSUx+RnBpIzLIVnTSjO2OjzSfKCFp3GxM/PCoATRe+3kbBqgLm/j7QM7AYGR3IRpGD2EAx92+VVHFTdBDmBKUoQa2sKJKBybUTU2l/We21IYwGcyje3YQ6RkIhCRMEWgHG7Zm0gxR4u66gd11TcvucNQANoWpAJmY1vplG10PJ+sdigVfToVPvYuFY0+cz1MvS+XdKNIrws2sK63NUT6WCCscOYj8vQMdHZz7HbmnItnupTbtJujwlYZggo38jGo1Cggryek30yJ7pKIvNndyLYjKWYvaQY0CI7wy2feVsz1qJav2R/QE2p/plSXW85+RysdXFYVrQLeZQTvgOY4sa682MeIa3zi/M2q5LAPvw4SSPL5P8n/7QX5ev+ys/KP/uv/TL5J//p36eCETOlyq7HdKZXM8uYcuVqstzaADgsozUafp2a0YZmoB0izvl0UklvQJgMabvYB6TjqT2jYcGHiGCaZqYi7/MH/T8/NIoO7Pdq/2Z4+k0e/cpGtx6B7VWOZ/PUU5VbZTT3WGZtdJIzHxT12mS6XJNUQGScjodZ6NFX1kvD+/p6UV2ELk/7uVb/v5PyH/wX/01+bq/8t1y2BV5OO1lqrDXTK9X6TZ1Iv9sfN086pKcjjSHiSTm0nluZxaAMkenP19o5aPdDSoRDESPU8kue0lavXy/jGk1NF2xGPBntTCGOUpsmKzS0IVGaE1+0ANOatsJV8B57+U32pNIJIAxb1wMyVjgO4W0VpTRJj7bvXLbDc5mQlIftaSfTzMfpZXKYOZYrBIZo2dmRjhwC1hLlJt1I/k84cj3kL6dCrwCLcFWu+X2uiZt5z21obIqpvr0ssmaFuGAC/iaJgMJvGUzj4OkVk3kxaGBB9rZRIMiq1la5wV2a60LbM1uVluw7pDmu6ntHozQIC0QnDq6etYk07xCvD9ZSNLpzZuTnD7Ma3mp9Cz2ujGjxA5EU7w1x77FX1jxmw7mJvYsYXMg48+LDAlFo8HEhAIHbO4bD7xpdkrbV+qMNWBiVhUlyhvwqpSQKJ7GzK/Pqh0HuM7gK94Oy9o59X1vE1PjcyeJDYQ6zwMVn6lntykKNCjv/eF0bPZ0RSbG5Mj0IkbLQIMGSMpPIjrZcjDnlMR6b0llEp6wzh0ATaU4K17JNHmf2dkm7tkqgDzQz0NXNQPDMrA4f770rg8bM3ybM27GX9oL+fhnTtNI8ZYYsPigMQ/yFkKgtW5BUuzrPDSbQggWGGL9MkcHN7aateZ+VZ9b7eMCSClFns4XkVrlX/zVP1f+nd/8K+Rnf9lH5N3zdXacKBBhlf1+L8fjUZ2JnRlyuVzkcrnGdyuU0+kkh/3OWR+JXC4XOZ8vEujki3Xe/f1JCoo5Z/uaqfL88pIyNckqu91OTqfTZrgGm78DrT/Ssm7fvn1c1DjRkyF1hw8PD824PkuCH989zVSYxCNLRGbj+l0J6Dggcr6c5eX5LFZOun/2w8O97Pf71r3Uipzn80UwXeQz787yn/43f0f+s//3t8tn3j3JF9wfhHUWi9FCGz05SfbUcmGanx0OFroUxT2rjlr5wk4XkbazBpVQctCl8ibJurjXpuB0tDg4KCv4VnnEHLl8dPh5OH3F8Dy1v1L0Y9RBIOehuyRdUbeGA0FmqFscJ8TTsbS/ly1SQk5ikEmY9xHETxHtHXQXrQlyLIIWyHtnIsKUwcRQRHFAQtVdRudZJbpz0S8wWwMeBAadr92qcoqt/vXAWiTR3tEGz5oCHEazncw7Ej/IEbKYqagFqWuD37g4QC0oxDAXZ4EjOyCkZ0RoimJskEeiwpzp5EgUIdR+aHQOQdv7J2fikTS+TRE/V2qxdHNWbe1Uk/U21kKgfTtUWxIp/9FBB1qP1yG8lWTCw7rKFibdmsZRfpF7UflpJCo/22z2VbZSILCh+hD73abDadahLeYwGPL3/oX27Au9YJvUZ7Mxft7/JpAktptKcTTIjYzwVlHjCw1BUEltwmcuLoZhTVpbEMO6VmfEOt6h6aQI72iAEZORbm8ZokY4JuAE8O/WCpTFsxfJIa59TrHxqKPPXmNf0fYNta2BKN0Dbz2EhE2Q0XuhQQBxYnrO91TTbxPt9yyYOEp7XvQZJtOAD+h9+FhpiiV64NifCYPB3R4HkO4F2+RAnI9118rYtHTnpy+u48gFjNex49Bg1FFngK07k2479Fv1dpjOnO8iQtt3LM+jlNkv9PNvn+WrfvrH5N/4F3+Z/JZ/5qvldDjI08skpYgcDwc5nY4BJAUg5/NZnp5eVLG9vmORhzf3cjjsQ+788vIiz88vFpBVwM/Dm3sppYTnBECmqcrj42PCBpjX1W6/kzcP966bbVf43lwQE7YQ0AzcqWaOhJGslIKDusBNzOj9bLrxI2PSefG8bUdGuV5nw8fTaS9/+q/8gPyuP/Jt8i1/78fl/riTj7y5k+s0hdkNpjSmqNEIBuhiiLh4U0lq3zbLa1OBCSZmmMVv5g+TjZB0tCo1lZCJ36B0ewLQzDVZJpj3ZvCwfeSIMOGq6PkS825bXFImxK5zOuxMsFl/JYW6m6IxMxbSuOyw7Kdkna3ztJKKOUC9V22pYsBMpXAKuG4j1OxdFZOAIWHn63XQzrxanS9WSahJosSCPABUg+2DGDEOmq4FVcdHs7ca+1yJLCCjO/oYMUjWqCnS8PSmQW4sXqBCM39UolqVb6ER6FG0UjcTZApQWJsJHaBrQ0pt15LOUJt2sfX1VGl8LCO1EcYHs81AxUHKngg6Ce+AmjthD3O38MpoS9fYVNwY5OfKn9BBxL7wMT5qgoTvhhCjrehrLp5FR5fSPkykt3uxIh9t3kzT8vxcY1LoNasAnSDS7ik4KmpxBC1x3oh0XmXUdHskHSqflBmlCJeo0CZmcN1qetK3Wk/caLNnxPo+Gpvw+DVNuVqgkX62NYv1iVlkBlSYM9CxcQBlhsBx0dndn2iSyqDGSzfnAe2NKQkLimGXdIYBOwCgTLrnmX9l5M2UR+JARP2uGf3IfeVNRsuWbK7bnYEiOd2fSoU1CIp7NoHzBISBBWOR5Ds/osHY9bOLtpWK3ae0UaoKf1BioaH3he4A+2fZWDLKTkMBgp7ayqQjyYRchsx80D0YOwIU8yxfGIv3ihVln+Qa7XrHcQSsOfobQ4EdxWe04zKceAkyy5aW9zpml+mcifKq0wGAi3U25KMfPsiP/+Sj/Lv/8V+Qb/jWH5R//1/5FfK1P+uL5bPvnqXyVWYRsa27yfmKHoYo2IyuTD0M2fInZugZY6WzjyFoGzQ1cvSDqa/1Tykj7zlvLRE/od2fOtCqZ4QptJNCuVwop+NOpqnKf/hHv1V+1x/+a/L25SofPhyl1irTVB2S1JOUgOBAQlgYqSnGbcc8mfHD9AMKhQ14buibA+6A2bduFlEG3wGrDMuNjk7oGGHsqWjiJnOKS2+AeOl8hcrSUk2GNFFoi4OgSS/i53IUtQYmsUfGV3DdnGg8lSHjiDHYUpfECvj5HdHnFSBRDS97DgMJentMiB25pRWs4UYqRw8VSnw2dPJ4A8NpU1ak5s+6G64KIyKXy79B+7SsZQZ8NmYL0b7aCxONQ6Ti5dMnqTZRokosuijEaA9y2JkHXLfavBa4Jl8E2JDGeXdum66oeuVb3SUNiXpknwwdxIg6j1BGGYKYCMCBE3KQOCmViUVBgWirrbcFjZgkipKClOsqWxM/NFdJ1yfgKPa7rqMpDm6syNAp5uAMjiHAPCejsopRtRfX5oi+ZQptCUWoMEzr+43sZqvghNEokJuXqfwALWOCkhjK+5lFtxDpu4iKUdDBMu856fAg+vvNFhjMWWK7eWM2gQdJlHNcK347xdJXvUxzPb2Xw0y2BprJ4XngdfeGKPdGyGeWP8L5SXr6sCQD3P4cwkhRWTfnI4Oqg90aiXKF0Sp6VlU+pucKHTBqCnTGLnDOG2EEsJhAFsn30nmDbnVOU6GkdMrKKQIxxrPAhXWq3ZlNAbOYp+ZDYwyy88yheaFyw+tE2e92ctrt5c988/fL3/m+T8pv/y3/hPyWX/c1Ipi1SUqRMKtObuTegs18JYz30DKetnIQuv3Ta/7bthSFQQY3P4Njqo2gfpYeCsw8OXxIYZa5iSyGkLeC+lSrXKYqp+NOfviTn5d/9Xf+Kfnf/9/+O7lUypvTXup0FS4KokKtW9a1nLL6ujiktQ1konsIMccvzHPb+kN0dBiDs8a+XIbzGMv/ozZRoitwxBpdC5JOTeolAKcyYxkL3CYy2c6jRKQQWhmLIt4HjpIjH/6NoSRKakaURTl9az8hfUPIT56ut4RuF4Ksi6xSUCDMjGQole4+Mjx2jOF29GtC6zqh12QJvIPw3OB2IBrA0hq/6OiMFo0A3dpRyD1TSX4vMi5Nxbir0vUixneDqz4QyfSZQD3z1oF28s9aIItQBxMgI7XTdci+Ei1x4nqQ+4Qi0IyRL10dc2njkZHIF5j/24KPtjsz/SD0CppcwBByS1Y7X+m5gApdZPWUZT1076e26lJQs3UN3DI0a4jqybX4QQgr2+vR6yJ2GjFAaLXk+kZ44HhJatC2TayARhyMzRx7ATYBcy4QDDOBlLGIhYkaQWihx8F5f3PYRWodG8A9K3dT+hmqB7E+c28T184obVXUHqL7jPY6XWdDN0+TWGqtzscLFW1+toiDiN06t7mC3Q69bwtXvJEj1IibKZ02t+8rlcnmy8ErLQDoXXXp1DOb0I7uLC0u2WQ8QzhsszDtkLXnXErQRMCogWLOtFFmgZgLeMEUn6yo4oIwEbefkHQzb4zEhJVRVpf8lImPIlzh1x+Et8ZA2ysQK6KDUMLIsLvU1NFNXrl8/iLiqN3PIYMgTh2/EZMW97+3wLsYE+lsjpZTjTC5haX29PVvo9BAHgtIV4c/L5Cog+pzwvReZsqOTHWSD+4O8snPPMlv+wPfKP/O7/9G+dzjWfa7IpdrFMeC0Igytv/GLdGCLE+LIDsTcHdzRDzbRe4H9zb3ZV68QhJjVC6J9Xbx26ksCCSOkPJqxUuVlTaEAxKmV6dKqdPsLfh13/wD8tt//zfI9//4Z+XDh5NwqlJrFU0B63YDVLL2GSaq/dtUy1wN4eh0j0752/DCmSEqtAh+OjGspJgHWV6fW2HQDAtuDIRC45EaY9pmP3JItc1HMINbQxQF4o9YfgCs4oLAKoAZZAuxU6K7e7SwONXclsXeO7WmI/dqM6p5Dy1Nr+eQrEiFRONlR7GFM67Ouo1dht12HOOhkJQDrssaKQreD0l5eQG2ANfc+4XIZvxEVVDaUqj1lBAvLS3ZnEVB7A5niHvIS9ShUXoaVSTacWhEngMAviGJZs6ONrkSp0gHndvSNuMd3hU+p/lpKnGf1DtT3DC6FXJIu9IjpoL13bAzJcoqArqrqQ4FiFJFZS8EZ3BC77W+SKEsS3ynfJadR4sv3gReZxph/lW35dtcOJJZTi0NHos9qGvp3ne649spi5ZCqcyTNZ3bk9qUgJQ90rzti4VERuoiJsfSz4p0rI7SxcjoC0WYd+uF5MGomREAJ2VLRVUYaq9Ae1Bq2X9Yfg0tTEW6ZyS1d7VWlWP0TivgSikyMHfoOl/pjBkGHZXNws6CAgh5dVdLZwKqQwmi+EJJn2t9Dzh1CU9Rz9gFYGqQ2rvRGasr+R1w6EhIDuoy3VGjyoGgRMbUB+hupVlX4pk9XHzdqvpMP1fd93QB4rWUXjV7zQE46x8QRgDHjuHFESE4meIwQ7vOySLjGEROC1yQ13+DuijaG8q5MRkz+Zb1gvb+0hudLji9WBfU6VrdpLfTYUZjMHcTVErF6kxDC1TV2q2mEkGCVaBLq897mq1VdFasHVCmSjnsdwIp8l98/d+Wv/0Dn5Y/8Nt+vfyin/VF8vxylcOhyG6d8cNi7ZIUyBqfY2JPhAGsq1l3xRTFcAqizkolKf5W/8M1rwWykg4yphSptoGRgR/+vprXaQmoosFBAgWFQMBq27+pFo49XyaBiOx2Rf7Pf/ib5V/63/6/5If/wWfkC+52Uq8XIaeOVVeHAQMRTaXq2LVuov7OpUsCDOaiaIIvuPxncFzkZqt0inee/468i5ghNsYjz/oNIuHpR8Sozg9OIWTmYE9bySpgJwiURvkNui9swg8z6lZthzJx1WIIqxrLdsFVX0ulmOZQ+/lIydHixHTmgA3tAUwB4t+ZDwQgdM9A/EyBIOluGtQbSd+0gycUPyAOI1CUUcX0qiwquKwzNoSkhbikJbqKF0twzLH65ZqBOLdiPsa3pDFquPV1VWk6hNngbezg98Q4NZMNtBwJogi1+qCO7YxRoKxY0BF+Z+2RUkNgxY7EDO3b4rPFDhUPLL9BBQOdpC57sa6FAfzsdKc69mWNNs/WSIYu4WfYc8Uc7GLmcsp8nylan+PlIJ1HXt7NA9wMrIhaLzYm2TYDFwV1+C3YXieDdbSndWjzbopVHNVbvyfKAIIsYpjHxrYcTVR+dkwBMHgNUNMGMCSw9PNRI+EeTTYYWLRugGpmpFsXIypflrDS6BxSd8H8makSND/eAWPXk6P3HC9I1XlRLAUFCvcuAtX/6VwcrsOhigjWfDTH7Dn4pmYHzopiIwAp85RRwD60iyzN1HHRWdWXsvt5rll6Yej8RyNvpLlXZxR04NUwvVQuphKQ2UMUzn6psWvqYhmgYuKyVIu2d1KAl2VOsF3L+p8OjKhmwRAt9/ghQ44jgePmzejtyQxk82swb1B38YBs60YhNequYgJUCXoBD8HgfIShkRIc9Pe6Cq6O16zVjFAgdLC8bRXM+jHpq8oZqLwe1yVS6yQk5aMf3Mt3fO8n5F/47X9c/uu/+L1yd9qLUORynSIDq+W0tLopcPkNsHTToZpYTLOn8O810yJhqgQGpGm0zPdcbjcuFcWqKj/CodIX02qSQqmchU6qeuDAmD7Rf4dCTu1/V1Iu0yQP9wf59Ofeyf/8d/5J+d/9p98kdwfI3XEv00R9lirlwSQjoFJVXOfuXNcgLQCz5tiYhWT26FpwGnRQdUVN8p7YbdBTVbRIjuNYMeTXjrvtFO2oKV0mKkBMLPO8QnWQtCSRNlmmWM+9PDjBJsKUDaXFbvzp+dUc0bdUVcxw4G/PxlAr7unExyE1IpqmSFvjOyTaAiW6w+KarYbyIpK4nkuaMaddfqpcWaVLLVHpJI3WeaRpbSmatKVKjxQFU5CHLlhxMHNklGESpdkIsSQ/xlzm+7V/9IxqmJ9lVIz09BW65remzCUdKlFFBVUlsx5YeHWfwo1/uqyVpozODp1xAmjI9zpOtFjSbSaCaUFrFKGLFvmOd0qgQTqP3g/yvsk0RXisDDJi31GBOVDHhqUGedGnABMwPxIYACydBOVJ24AhNfhrJCFfJ93/MJvA3rWnDs/5gdqvkoAxIah5719uzC7lfBaaWTiHdShxMguDMNDsfNecGFEV4ZJvGjNqX5xLRh90ar/crLIt2QNqZEWrQuqyEq1j7YoQZoweB1QoyqYAufKr2wMwWgcesIG7xgiuaZ9g0/mUImMqP5L2Y3xmnmJN9yqy39Pnev+Po4hSAq+cGWwApLZd0LQ9aLuatahlbyiEmJbj8XYkiKaTby6Vg4JLj8RkNlywANtW6IkKwzfsabRcOcU7Qva1lqi4m2C4JtlQthahqfUKBneGOqvi6XKd5OG0l889Psq/9jv+hPzOP/gXl3nDItfrUvzpGenRzI0HjvRYi3Nlj3tAjcFBTPzUGh2ZXkl6Ij4+PjFW4P0Ld7tiLSMcjDdN182XvduVgUnrfON1WtQRnXQw1/a9B+iXWZc3bw7yN7/7E/Jbf8+fkW/9zk/IF3x4J9M02UILuumum+POeiF9WDQSzhZ1cdQ5wrF5LPVGfwWUvDMTjwvSy+xK9+YyPBYJlgleBp9qTs+SBrtHTCZsQt8xgJegzsXCV1+lfF40Kk2hiQfAqYyKob90emfm52YfybrX6Mxox+LmjsIG+2Gm9wgGuoftsioinymcRTJjJ01BQ2oerrj1TRFVUb4AY2aqC0Ug4/EgEUmiVbsVSSSUYze5U0o039N1JuEPftjnY8x5O70wmksrc9+EZifOyygoPUoGMtp36WlIuiPf94ddn/Ra3KLVZN11kTHKbhlMZgP5A3PyaMRLJdMe14BXrLB2PlBCG5bOB4MMW9oZEP3L1vVKjSzTSHcm5uw0yY2dyYKVpVefbzQZmAvaZTpYxu8OAz7yVpWNmJDRzTJ5gQ6ad9TBliZ0sApVaNKUQgmojdlFdw996ETcJzcojoEu6p4TPVtswCbMrNb6VvBCEPY5mK6dppa6F9qFyWAkjlPAAJpabyUbmvJqasp+axEg77hgdIZ2ZU1m6a636BJJ3F8QmB4A8yQXzooi5OBWOAcuJnpTUaMLPPDsxEANWDKfw01KrjjNvE431p6AcV1bciSDPUgSEJwDNbxyFi0tVJuDG/uKRtGEY23EvALOYH6lSusxBUMvb/RCla9IkkO8YuWuQnxMCmJWOsuGCJeYvDaFaVws0GcPnCehGdPSnrUI1+y7n75XpsgXasxAgRVe4Ef7eLYzrHsJegsakx+u63ZRAH33+Cy/8Z/6BfJ//Nd/tXzpx+/l6TzJ3fFg3+/ya9N0Vc4L/QwGILtdGTi9sBWaQQiNFKDIblcSdellOr9Os4VgQZtR1utOAMHnP/uWpmOjh/ZZ5eHNg+z3u2EwfHz3KNephqJvpY68eXPXebRu5Uy1yuO7x+VFFXe4Ug7Hg9zfndrDqZVymarcHXfy9d/8vfJv/b5vkB/95Dv58P4gl1YMOk5YlhBH5fhNkCCoh5py3knyQs87Wa42dYMhHXb2c4WvyERcHs7A13YAiisJkBx+TN5Vz5cUFpsYu4oks1nqu+2BlxVIknsj+5E4f10SLbKCZVaqbkkjmU+4tIgqYYZNhpH6WSUzNLfSCZcE2Jy9Jyzd8gWh2+hszxIXn64Lnc4C8RZ21AOxnYsYHeKI6LtSd4trzh5sce5Wy+iq2QWO0PxhbjHwEIuFmJ2DHMw9mKLUL1IYtbKbSGSW6sUN3L8rFNsiXikVWye1MQvWNOmRoq+S8WYieDxID0xxYNjR9OjCAIzwlRyU6bHrY4YQjWjtodVdZeMA2Oy8cQh0A1Z516ioB3l2sXYhRrmLiR9fnqSZ/yKCVRnTtebnckbCloyoui8iR2MEW0eYx711HPSMCoqxYNHbDaHkjK9J1wBIlKG5ee14VRsBEkEx3f204QY3PhKJlymS6norE485Dpzl1pBRM9jTFqhIkCtxc8lk/n2MzoIUCw4xHfD2l5V4QrtvtA0BhGfAVyzWTPWXg+SRroax6t5KUThHgZM4aD2l4c9XLYTy2i1o5mwtQL7tH2DdjZs/txOy0505ujwzTfKcD3iaN2kQTAGeUIDpauvV6xjme8YlqZmNEOieh2FDO3HHZWzo828v8o/9vC+R3/Nbf438kq/5MjlPkH2BGU2AQB4fn2S6Xi2dtVY53R3ldDql76zWKm/fPfWRJTfnvN/v5KH5DDrDSBG5XK7y+O4pWHAZNffPf+4tmWbe86O4v7uTw343JGw8Pj7JVHtBaDpOEHl4uI98f4WMPD4+WXl2hU4eDkc5nY4iInKdqlRSToe9/Bdf97fk3/tP/rw8vlzl7lBkqnV+bVVLjNNRCNHa8LY9PzhcfbfwRiJgNgTg0KYs1GbDmhjUfMgTJSZNS9XIskgsTKexi9FY37t+QIoVtlglpCkSJWmYV4S6xHSIDUbPwmTtyibChCmH4gK3Mo80QY34bI5MxvMY5rAC5EZCsZ1UknyF8pQzfV3RRCDBtf39IKDzFrNAUNzKAoqte3JRqJTKSon3CWfubSHwIJE+2p5W2sPi2zZFHIuUa+ELeHsOV+Bvls0JK8sfRCHv92gfk2ItrPGOskPDouR7FS+DVpzrBkoTo/K5bt4lzxJbCd1DDJBl7a/WaD8xLe1WMxt3aNgWr2FINkGW7u2W+yBm5tL5VcD6vDgsewskcBURLB0PTgTGJ00YcKdtp0ZyBJ6SVZ3xHHRzyUGDApJ2nVaZ/i5olSTWpHdUspsJTGzK+7PSnUBNJ6XHTRxbZ1MQPhIIBAmLQj+rHNNMBIlUMcRUsjZ+UAA8B3EXWYs8AzIB1UVxc/++RAQG5GOkhai8B2Bg7QZprUWSPa+5J0ZfBznktpWG0QCNTD+m+b560GQQc+n3Izp6Td8AaPPCtACX82btLCS8kv3t3ymtoiY57FDr7lVWdEO28x9u7CqmhbfrDGfELvHPKAEUkRAj/Bmkc1WV1wytiah4hgmXerfbyePTWb7iSx7k//Lb/zn5Vb/4K+XlMsnBMC1Fnp6epU6TsY4hq5xOx8XoPq4dkvL47skBiP3n9vsi9/d3g9wRcjlf5OnpeZ5RDOfeOh+rUkaIlX7GKtEXAHVrvSDeckUlADUfEWs3SNIOzCJaNtRlNuF02Mvv+WPfIv/27/tGeblS7g6z52BCCBcD5ovtJ7NJXduLsrxwOipB/OzMtw5S+ihX+F0qjr4k6qb+GToEYhHpmF+o4p1ndDmnJAhnzTtLQXfaH6T7nJipGC2d32Dukuad7RrpFFjXIhnrRECTkzTyyiHphX1vKwrTniFkVgqTRCDGDOtZMqwXmFgnFfqaxmbLiW4901VtRlAHYveKt3QQkYKStHK6iIQdwLaG9iZO0orUUKIPKCyLQtvdGyNqJAISUElpEczPHq5CcDZDZngHAzvA9cfMLCfdHEb2M2JHUd1QNd1b72IfpW0ALJLz1q5PTxlp64KS21SY+UBHmU5p4epVevaEt7MZWHdpAQjErGP5sSpxCD0rGpPO+WqJwD6XVID5chWl10yQIkp3QwunwAox+euY41bpli1mFsXNnTmauNHDX14otO8jR/etN2aRUvTe4iD+qzlndAAByUBflij18ZEiQOnzWqM8DrTFH7XacUSMgkiO+AlHpYwojr6lN9vA83FZDWldYVXL7ByWDe3Oj88PLLi442EvMhF1Uqo+zffRv2KBUpCGmaXGCl7cSrChkidoMS/3PXppru8x6AzACMSkr1W6LUH7AKpEuPS1rmfptRUGlHzgulbtPJmy6fGx117lUFfIx0O6Anw9s28B8HD5GrrUmcNI2GfKzHkOp1WiRQxFfHoAc+6vwMENv07e6ij2P+acRLQi0NdKDLx/lTXF+rsFZVbkhhNwGjCwzNqAF5nq7BwEyZeysPyQdsSZTbgpxXL4vGcYhQe6B8yBVz3ru+qNiIpskozpabuRuipZN40HBjsZg2WkYK3W6aBM16s8PBzkRz71KP/q7/iT8mf/+g/I6bCTl8t18VHvsm40FkrMU4YMK9beHdwyzkvOBy2OleBw+Pzn3tIQCF0C83B/L7t9CexLUR3CeQ4w/i0Aebi/l7Ir9mBUHazeIYx/Doe9lP1R6lTl7rSXf/8//0vyu//wN8uHd/tZ7UcvAFohdjHoWRwdj41yzy/Rsq35y+qdbstl9AW8t6Exs16a1gCM4Uf6gpkJ7rssbsA7yeSBLVMgTpFEBv8vPdPoPY96O5tBwRSOmhCTJbiB8EFPhjf6b8lGwmiKVzZ8MW5xiTGAj818AFsC3705t9T6kKIaZp5LMq27Det0hzRFo2AOnpOmCEsmTLrdAM0OT452XjJz5bqUEe1juBWmHZoN+H80oe9BCd2VYdLNHtEYfYcft8bsHe04Ii85o+DGm7zdIGNUPRs+J8Sv93OSbmgv6gGbKQb3X3GmqzcKKBvZjwkedOq1I1YBXbJhOhq05tlwtigp+h9XojkziERcg9oYnRY90Sqj5ksx9OXc6hLH7lpOO7P0uuEGCuGSWvgIW0JQ+fpp9i7J2R0FnnIqAdx8b2w5Oi8+JIbQG70WDAiHfGVDWm75JIqa0zZJjRcyy8FwwBaaZt4u6YaET8pduzfuZEsICYPeEd/vKaUMls3WU74G/d9lrdwwF6mL5ySJ92GJgzNzEHvMTCl1wh8Bn1H3HwkQlZFHoq4C3H0z3Z9pt1Q1Dpg0tQMTyFFVyUFSPmQrOJuuePP5kqMvVrsbgE2JqSjdsZ/vnx+VLdkKPuxLkfN1kv1+L7/33/5n5Tf9mq+Rl/NVdrsiuwJ5enqRy+W6gAX9vD+djnI8Hofn87t3T3mcoMhuX+Th/t7Q93sNA7lervL09BzPBzWCs7d9rEgp5IAfjSRBY+Ibx1fGQW+uSxGpFXIokEPZyf/mP/7z8rv/6F+Tj31wnNXMKlMij/m+goTlQ7uIFLmjxz8O44j21VmV4cBB6eVb3roQhBi/qS37D4gIlXw/VMetD8HOLWfCJ5LqrSCM1/Sfo2+3vE6FiZ4moo9TxBF1q3JHkRu2J/AS5R6uTj5Ciw9ADdUnI0vuueeFqvYwMjx+IASFOEbiTBnghsxHhRYUpYE2efb3sv6phkYXqTHU+i9B9Wxsj8LNLikG2zrxeYP3MrScIoSXHqtPncLQDGhoT6Ko1TgECfQ8j7PfMIg/0xLZIuDrHiquwwzkGSVpZj5jiukoeU5Km4noqYkxhhIj0aZMRodulkRjkMhspqWmW52CvVkSACtQztA9cf0iiJoljawAIsOSaDzc2qEPcSrIKo40cJFxf2irB7is0InEVEgyH9bFCTQfsI8gwL9ec56N3gMS6ZJI9S5h5KEXbu4d6hk8LzMIm91xKwF3oAW9ylRb34ibGBH+QLZ/cNtU2bgNeHNvwjAddA6dUaW39VuzTbcl07ic63Sd19TPWZxQlpuR9030JCCuzAYwdtAksZzAaKcjmff1NAoFjEBwo/xOQGFnWZzSzwOzmaHIXT0/0bbAsuaKRHNzdvVNmFELCrdEqFxMy5oqcYVkZ0e0lkBQUYW1JFq1N1xetvq82i7/wCbMn3emG1VaXFyJW1S+e7V9uRcTG1BMfS3ghJcajReusGMuBtbpuEw6jMgrRVEzgkr7HZkKHLpkuLauAEQmUg6HvUxV5N/4D75OLpeL/Ob/0dfKy/m6sAgppYjRVdgq4HsG3LUtGvtFrxOf/7ymh6J0GfajZdmGZnF7zGHUNRiCMnoGAvOioVNcqqTIbn4A/95/8ufl9/4/vk0+9uGdcJrtJ4zaYkCO+0HPgUy51QDhsEQZIabGdBuj2K657babpmmabTMb3k5Z7BQUm0EotVa5TpRpqnJV8rTrM50pT5TdbmeG8DOEjSZVg02Ee9Xj1N20KWjQQ1VUL52IVrEzRHDzJYPZQC//7YoIKsNkqGQBHDQTHWLakfnY2VbcnzTfmQEJJkm2YZ73+1jFhqCBCAaRF59Y0H1BR379esp0BjYGS7ZbRb2LkCB12cxbKIiTQGevlQMCCnzpn3abAsIIX4BvA8Z9zdW06xWSGuVTCrVm0lyATlHQl3h0RE4FxlgLYn2Y6tN5G7FPQXNFW/AqonofG7IuI6DBREHZUhDdKZIIyniAP3ZCGWEyxBk1w7wImTqG3ctArDWy8WiiBBrEwSYlAbGDhkjFbaqOXqqeYt/9Sg+DVbltzawqIjJ1j1Cf7ZtEeVsAysZYqiQ5Ebxoqq4IUvt65i9DT/Wsqz6mm400bVymf19eBj/L/g3dz1m+JKku9LXTA5fKEsDT9MnI0KFsFp4QV9zqLnCgK1nwUGqsszLhKSqzZX1OAEhDPwY+TRqnYBh9QQABGm2aWfeXpmvFZHRlkJYb31/eCHZQsaa6DjWrEiRak/iVfqkFmGjFfgL1f72ObDyp0tpZ0cn3UYz/a6Z43MAWMmn8u1Md+WyjHr1p84B0WR456ivK6tOc5es+Qa5cdm+lTO3XIGUZ5dntiuwgUgqklN4cqPT3zsR6wyoGg4gJOQZpjTsXuJX+QHr+R3cGG4CLEfKhsn7TINbynXWaZFd2Mgnkt/6Hf0auVeR/9uu/Vs7XSSZzvtCIkXFDpsQwqcgI9ITX65wHEnKF/vm9H8KszO1HCadWmKFM3rqBSIKPQ7G0ETz6Qy0COR6K/B/+4F+S3//Hv00++sFxNp80FghiUWDfh8JgzehbJhy9zw5M19oRWPboIumkd+btRyomJqTAeUEpKsjM8y8tGah1kuu1yuU6yVQpuwK5Pxb5+Bfcycc/+ka+5As/kC/8yPzfH/+Ce/nijz7IB/d72e+L3B0PcthBJU80Jqpp6eUCqzqnhx0zXagh0C36iht1i4EiUe2f5jqGOifD+2Ci7CGxe6S83aou3wrGlE5FU/TmotaegY6dNAdKfVMUbXrtCXVIMXCVV4WhdvqCxhVoCOV/pFjQJXrzjJM+IGO3uXkuahAkCW7kQPQmzBYylLBW7MWL8iQ1b+jqYVwWIilg7P9z5UpW+vt+fGaz4utZmoJI+5FCZwi6a5kwNugSVKBIccwN8XLpbjMh8W1k0umujhtVEvnrFYUGxlJcq4dS1aBK1uHCoLinnZeDe6FQXqBrEwzK47Xq58YgtG8AKxQ40Ix2FimAY7HTbWcz42y5uacyP7tdKaqQojGhpzaEdqCQpVLRJJtdaduNV7hiWtNmIwHZdx0Xj2JVRLVYC3e+AAYU6fGv/8uaiVYNOmml6O7rCjKzJT4DeQFXR25TYFZVRxS7gBmigF/HlnqXUbGt8JvtdHraItWiqyvFOJnl0SlsAaSUsuxTbS9Dc0SbLmgAUtJqMvzPFeTXohdw+51q7SF0a3OaPaniqjurRa83RNrBMO4vv1C0Eys5EGqy7xzZHvDkAPocMedCesFFGuE+MYA8RVJwMSQ2G2Md/f1XFcN6vuWnhvRsanvWyzlwvlY5X6tcr1V+8t1ZPvXZJ/nEp9/KJz79Vn7iJ9/Jj33qrXz6s2/l82+f5eU82ywc9jvZ7+cctQBS1yhUJdhf2ffIBK0Qy8JoTK0++mXswEbWOEjG2cSqbVMguZOk8kHVrdg61yTTdJlH5lDkt/2+PyusVf6V3/CL5VkoO8AwNmut8YxWKpGoa4OmLjhR1x2pUqVQiQJR0XMdE5BeaRmdUYTHx+fNaFhKsfRQx5Ou12qTfZek7/e7+cU7edc1hF+vk1I+7MjGw91Bftcf+Vb5HX/wL8vDcS9zGBAjY2yi/eLTJrAW0ZuKYWnrgMP+QlRgorEbkyD+454b8gJ57uzN/3y+VjlfZkXVu9NBftoXvpGv+GkfkZ//M79Ifu6Xf0y+5md+XH76xz+QL/rog3zsg9Or1Cl/6s9P/fmpPz/156f+/NSfn/rzU39+6s9P/fn/95/zZZKf+Oyz/MRn38kP//hn5Tt/4JPyfT/yKfnOH/i0/PefeCuf/vyTnC+TlN1OToed7JeRqErGwpcMowXwtOaNrhp0Yr7F7016PAHUGqJGtqCFqcCKoECmKrJHld/3b/2z8j/9Z36+vH13XuqjlfkxUwGKVwFVwHetNcxq6p/Z7XcO0OuXNVVKvV4tqA8LMoOsXY4lQcoeH59nM8NM6o4i9w/3st+XvM1JyuPjs9RaB90hyMPDvezKfIPXOhvVn457+c/+62+X//V/9E2yL3NXrbJKMC0Wx3ZWpa9RXXKUHDqEnOh0xY5e2oHi0DEICywWm8gGwxSgsxaBL+eLPJ+vst8V+Ue+6CPyC37WF8sv/+ovlV/81T9dfsFXfly+5KMP8uZun6KLK8JatR2E80L/h60ZNVqk1fw6/cJLQ9Chrwm3m+8zdK8fpqWK2neMAQ0CY0sIY4egnpNrW3VaD9Oh6f6e8+9AYumQ338u4Z6CGGYL0iL8fI/H+h4/q/cc1PweB7E0vWZHvaZHXZP1MQ7fSNbb1kLe+Gvjp4nk+cz7rAADS4moohMN16E6Lrn/0T/M/hzOK/kB++R52IPuteoM2bNDInTAG9dq0d/MMDi+ey87BwcQ+mcujqItoVMaOmn+8WWPYfCoauLgEQWB5KZMe/rcnOdUf3PRWG9rpEkyb64kbsbTlTdWiqVZjTQ6mM1yDvzj4mVgbF+wwY6PJGeXy2HjgQOJIJJTA+f/7/E2XYcim9Jw9kyNkbizu0YWJ6qj4s5ywXa27fpckeJ74/4zzRdIFMzT5vJoGuJMnThEv5LBIFb3nISzJ0qYHT1IbsdTky/RKGXfXAvhfMzMI8XpKHD8iowIEYeHeVBZNbYr7hokz3Ut3b+PxXi1af3n7eNZfvATn5e/9X2flG//7h+Xv/6dPyrf9YM/IZ/67KOQIvfHgxwPuzmnrU4YxfkV4sZt5vR1mmc0+ow2Z8lbIm1URVXC8lKS8qUUmaYq9wfIH/hf/Xr55/6HP0dezpMcD/v2OS8vZzm/nNW77uuzlLleKm1Ewd7kVKs8Pj6Z3He950outhT3IhvhFLVWmkF999IfH5+bimhGJ9gsCGUuCFcBmGA8LpCHhzvZ7YpUUl7OVe5Pe/kjf+475d/83X92noUrS+WsJbJV8UMzV+ZMxKFUhHTwTE2irTG2adW3Rc9xsHTKkVG4ZF6IRYqgiFyukzw9X6UUyM/4aR/Kr/janyH/9C/9mfKP//wvl5/1ZR+Rw87wU5r1hp6V+v/y9t5xllTV9vjaVXVD92SGGXJQoglQRIICioIiCqISDBi+5pzDMzzTCz4DZgz4TIiCigICIjkHyUFyHmAIA5N6+va9t6rO749K++yzT1X14Pu1n0Ho6b63btU5++y99tprEXd48ud9ysY0iidqMR+CRtuydkWmoNI2xUjSjakbMl/1r3hibyXf5byM0fMKNq7lyIZDKmZpn1inmRopacxng4xNETVKxdzWpxAibBk5F2nN6Aiqj0epzsEziPl58okzoYJbJTnGI7zACm7SH6b9mnplyX2cyBk29x8QmneclpQRkZq8GkUy37QooLzr3MCmvdT8vDF++i6cesn/Wi4bjJiiMukFllhX/BlJTVDi6rT8AKpBRvT7o2hCG0WZWb4Xp8nNAoWSM5FUs6+agpQ98wuVpmiZu8s8zNKeMuuN6RQvFYBEjDet4ocRe8wi5RnpEVkPKHAjeIcy55Evce45FxISMdOe4eJz2EWO0H4NoOaJU83UqxF6AaX7jme9Wq4xpANWeqz263bLM0YFwUoqPrmiczXFD5FG25fUaTHLJs9D8VqSxKwZhxsYFwitK7LggvGWoKARpvGmfk8b5V43GsIbD12YDNMWIguLaaIxy9zEOZtIOTG19FU98+35PU4rddQ4DcHy6RPle7kP8txcdr/WTo9w50OrcOXNy3DOVffi6lsfxqNPTqEbhZjsdxEGhDQvDkmANFCeg6TY2uBg7nFLuUANP7OMYeJtHH2zR+WMxUA0ljcUseGWEmzlgmBECMIQcZxgbi/E/37uIOz7vK0xM4zR6QQIgwDD4Rij0Ug567MG0sRE35sLpmmKwWBoxy1Ww0RR6PUpLCNGmqa1Z8r09CBrU7I2EU98JiYmEEWhdwFPDwYwsa3YVooWUFYQGhBGowST/Q4uuP5BHPHFk5HEMboh5S1k4ybjztM2tm0Gkb9TVa4eZkRn2ghwUC5CIcelfWEj58rnQ7UwBtMzMYZxgg03mIN9dnkaDtprW7zwOZtji6XzrF2ZMuRdGkBrqLB1KJEmIqMnJq5sPhyRFSgJISn6lJqAgRQwnJ2BezsVssZiSCbZhqyhbKMaTRtvP8NvEOdiSD5RB69um4P4yudp/Ae0Y4ps/M0eqQArjKSNVsWJZG42hU9R1Lb9/eZuHjnPwbdSfAWv99lxcWJPMuW3ZtALO9/zMiIjLO5P3X3i99JZE84cCanFoRfcMXJ9QGu16HtN8/+gmnhqBHDQoqLhRaB1j/xMfztmEWpNq41pkTVJe5nU0xGfbfXG5uuclazsRVP7dnoxoBam6thU8zPRijo+P4oasFKubzmfw0VurPdrLOwVQ3EjCorSfFzvws3mdIKcheNdXLlfillHajjX2lyOFWfcs4wXyaQumibkVzkP6uIX6kEPbc3UgcskwAW+z63CwFeyt5gXoqZzGM32DY3novEX+LxYaAWEyGcidBmk5gLVZCeu/JeS8Sg5Zj34qd9XR/OFjZWFQVUFJ6nB7Q88ibOuvBunX3oHbrjjMUzPDDEx0UU3CrNawAgDWj7faYy6mCjX7ZBuAMZpM9fcucq/QRplWXvQCBCZuJBb/o0wDDAcJthgTgcn/Odrscv2G2M0TtCJAozGY4xHY6uXwq9hcrK+IJyenrHLG/gLQmvNFmBZXUFIeYcwSVMdnzfAxGRfdAhtTHUwGAjKaYXaFhXvODHoRiFuvXcFXvWpP+HJqQEmuwGSREgzm/oixYv+KcqBuqKPI5PoTNlaPi9Sct9i42QiIhl3OMX0YIxeJ8Kzt9sIB+/7DBy05zbYbvNF7GEaR0ylNkhzlBUK88ehI5j14o46xUFd4mO0ZNEtCB3KpyfRblN4NibaavIhJNxrEVh/96g2V6Sndmg0FjS+DsmsUhn7tav0hrvx1CSGnutWtX0bCsG2RVu5TnRe3lP6Is3mwtQbXkqqvSnlsTG762uEmfX3tmnNs0vs6rozdofcON3VumTFt9hsepFrNs5avg5Vy3lP4S1SwnN+2UL2Og0rTcSm2SWbImGX8cyQ2mW1nkVT7JC+KqSsC+25tqx7fM/3qcSb2r0sPRZ9a1IBQLQ1rRXBztom1IMJTbHLrB9Q5n2vIiGT3nbkKpSaGoaKRe1lHahWcciTXzixwtN1bFMQtronpgUWM8tl6GNmFJ/Tl5OsD3A9m7PMAio04LZNblZTTK8P+FquI08uxeOB7uvk3gMntzMGEPeMWLwcjlJcddvD+PN5t+DMy+/AssfXotOJMNGNcuEpUXLapodWwaeRjImxiEyL8Q3bxoXUzrTt2QoV7Sh+PAwDrJseYvstFuLkbxyJpYsmMR6nIDKIx2NWFxS/k4IoKAtCeT8JxCij7oYxJvN17/f7zgIrO6KGQCY1daK+pfG8NZPH3mqin1E+9Y1MWYcwSdVNbECZEWMnwqNPTOHgT5+Ef97/BBZMdhAnCUgKmXPZ7gLBLmVrNbNYhf9NTFlUGQgz2lyL7DpCoWMy5bhC9SqOYwxGCRbOn4P9nv90vGH/Z2Hf526JfjcsK3qTF4716Knb/zfcvDqnOlgdUcvHSqEkQqdl+ZKq6vkbP0rWAvXkgUIizFqBuD7dQl7EGkdCvqbz4FMW9QVv46aYdd0jw2YRbSCj3UHkJKlmPRISpz3kVi38c1JdDcySAxmcrL+fZUE5m7WlGoybeql9rQsLpTiGQKllEm6EJxHxfUX6+ub3ytc98X02Z80a459XbriWugTb+h6JfZsCfgsnxchZmVkBO7tLkTx5LW0ALANFFVYWRrqtixHvoe2tOr2CWop723VsbFZHHRNAvp9F2TNaXKpmfb0JquceqzR8IxLM2QBeLc+22nXInyu/Fx47E+lS4e5tu8CmuucsOt/eTiXvRPI478hQ1p1xRTKbdzSYLD73snR/QQEE5HuQCwKpwHpd0d7EgGkqFmHP70kQ3VscKce38SxjUornWTON2gILxUWlsD0Hfc9VKW69rAcoLAi5tloAFD62jlpoe5so8J5pssCTL9gmVlaFefZzAYuHDz2+FiddcCtOPPtm3HLP4yAC+r1ursxZ+QYaDpwUfrHFGBnL10AKzV0ohdtPuFL6NOJm26NhHjCR+FhLteCDMMCaqQFesfu2+OUXDka/m9FJ47jqEHJLpCAgTEz2PfZBQJKkmB7M6OmOAaJOkBeEynMpxuvSJDV16ExBGQUF+T2xT92JiX7OC9ZZ9hllNOVunuXGSlOgP9FHYgze/h+n4dRL7sAGc/sYJymjctoJWqo0vmz/JIVf78i9C0C+pKfAkVp3NnZNokJECIkwimMMRjE23nA+Dn7R9njjy3fGrjssLTuBaZpm6q3itrlJEVTbJePMWonZDs6x5j4v8vBitWMjWtSmOzfLoNsmydIS3bb0Px9aV1LulAOsiRbSNgnUEvAmZE/rrP2rvizUWJ6mAuzggI13XrIGsa5dB6T4mzXdH/LP68iOnI/KQjKZbUnfM3zfe85PO0FV4oO0o2GedGRsSTMCNb6PTA5g9IRAds5s37PKb8+JmMbW8ajtgJUzab41AH9Pbj3R/rb1ogQHi3kWd0+KzkxdEtewxhUHRX1/m2r9ljTLGkp5qw/POrGkoNPr376q7wrXzT/Ptltog4/tuiV8VlnyENvQ7X3FT7vCXiS/vOtR14En0reAMc6TMM0XU7IFmtcO3HvsK8ZV8n2L91gPYI8X3SS+1Xj2ythXN5ohczoFRDJocy/8998tCGXn15S5pWXrYOrn0KVllnMeSMC9Lp8QTZBGVos1YcUaMoovYAlcKMOMddYrcg8WYolR3nBaPTXEXy+5E7854wZcd/tyJGmKiV4HAGUCNCRHHPj7s24g2UC+NTMo5qZ5scQLO8esXD43w8T3AEvskf9MGAVYMzXEB17/AvzXe/fNRGVGMYIgn79M7XtnU0aZgA0BcZxiMBg4D48o88mMOhH6/V5tHM0KwgJ1cNwuCdPT01mHMLAVzYp6bWKyhyAI/R3GQd5hVEyD09Rg/vw5+PIvL8E3fnMZFs3rleIpPBErMaXSnNmwYo35p5TdFgWOhhBuUjxXXDPciiaot4Cr9wuDAKNxjOEowZabLMKhL30m3nzAs7F9TguN83sgFWXJGRJEPQ1slgIrvGNCSvvaTaRpPfM2IdPR8Et1CNb6FJCu91Nl0uqfu4M6Wtp0GeohoVPu4fYQ/UhqOybaU1eo1DqUKijUonirK3DrREPqEHLTdL8ls1t2G4SK3Hp/GdvnzniAIg7S2IbW8HS9qNWhD6ARZW49H9k0b9fq+Vb3V1P5s/XvTLtNVUd/rLsf9jb3zA5rmZvxLmlbJVCI0jQk5DAtigqZOILPrxmXmGGa7kONirL2O8VZ2th5bTA0I7fU5j/oF0xC7Xyvfd9qFcjyNUhux8nX6KCa6/MVhEVi6otnXpNNODMkhoNK5HB8GwGyRjC2xahElVwwSqAjMETuJBhXzmwQvLGF0iDMxoE6nIkLd0mPXVgdSiOKRftVm5gX7c7Geomwej0AgbnqLqXOTPOsGT40u3Ea1ICLPgBWnhnWQJizvmzKqJq7zCa3y9+sEJWJwmwNTg3GOP3SO/Gb067Dlbc+nKmT9jpIje2vWI4eqKw2W225Eqh0QQLeB1PrABIuxNyXWwQMInscjYLMkmI8SvCtD++Po17+DKxZO0AQCE1kk42f+URlqoJwRq0BDAw6UYuC0Ji8UWu0iwaGw5GKOBYmnt1uR/HNqBbAIFcpJYJlihsnBvMmO/jTJffifd/8OzpkHMNfsg5j/4Ay92+WyDZZmT+xbqC/ZW6ITVcZeCt8A+QqqAZrB2NsvOECvOnlz8ZRB+6EbTZdwApBIAwJXMnEx2V3DhVBN2kDmhpvATvLyqf15tUUO9vPLLZBQmertNkmwW4fmNavtHiq712frLnP1viBPfVvZzUXSf6u+foUWlpmoB/GBMeMt43ghbCSNetRCEnrCHs6Wh76T2WU0UtY88Q9FsMamim2JPZTahI9pU9UJwUPRVpf7ZBoc2yyI8TWRxu13X/5nvb9QIkF1NC+BVJlzOziabM1hAckECwB0yYGWfvCGqRxu8UeEEibH6yfMxYrhv2OqzFXf7+IWemYOvBkfQrm2WwqiUrL50It3kCjCzIwfXbQkYvRoGHptQJ0OYDT5p7VLuBmsFcVf6t5Te4yURYH66sYXRcDZ3vWN1G6a+Y+tffVxZz8f+/97IZsQ3d+q2dZjzflf/w+J2kmRENEmBqM8JcLb8OxJ1+LG+54BL1uiG43qrRHmBpC9vtiZl2wooxRcgciAcLXQBol+9AHl8JuThX/HmQuCwsm+/jF516JFzxjKaYHMWseZbVWEASYmJjUySGUeboPBkPrGrMllJ0lYRg0qIwCNBqNDYmuYLUgDMIwci6gODaKyj0MA29CVcwgFgp6lFf8E50Itz24Gof/+1/x6Mp16EeExKQV+mz44CfrVzO0zzBT+qxNzbuD2nwcwRYiNTYqUCK4xmIJV9LMtsklBYR1gyHCMMQhL34WPnzYC7DLNouzQjBOEQRkUTkhB3L/5bWCcWX/BZpvxKHs467PphLkW6/NQa4dfAZ+24ZW12b0GQ0tAa3r9DhFp0pjtTsKtYlHXQHT5OGhiDbWFcf1BSFaH24+OopzuCilGlpQ3eoKK9/9obqOTNuMXK5Gz/1tei617+BRU1Vn+Dx7wofAyzxBS+i9iZHlyWFqUHBb1IrEeeAHmOzKjQR5XxWoqLuXCqhldStI986VyU/53tzXsMWsnq9Q0H7HNxPH6bSSuu+LiXVdn2q2kdoX7W0y+n/RV1OsIVEsmln+jGtLmN9L6RPoK0rZjBKJ3weRP95bIIIreAQVzuCPYHalQON9kjMibhDJE3OuvFjfTfadtyTDhc8y0nNGu3FPmNp6QnNVzNIs2QzwzwwXW4HPm83y1fz7lsrEve50VJ8nP99a+Ho54s2KR2BrujEHHdi6gQf8lflMsZdInOvV7LrCTKuLvwrYLWf6ZGG4YtU0jj/zJhx7yjV44NE1mDfZK+sM8IkKk/fcyDgSCoZI9WStyAJ2J7/sris3uSgi1Vk/cvcFESEMQ8wMEzzr6Utw3BcPwobzOxjFKQIu+NIwQzhOYswMhqoPpsnpqZP9iVoFWFq7dsr4Uj1jgImJvlPwcbGVwXDoQm1sfWbdw5wqaTLzeaJsAPJNXz0d511zP+ZPdpAkKTvw4bZ9oQQoTZFLRaBcChPfgIYNjZJl2EIqFhCGIdLUYM30ELvssDE++5a98ao9nw4g8xcMwyAzjzTtPJ6eCgpV19GoD8zi7giBhbLYqQtQxijw0L8+oWhKruV5rugQNBYc1r1RTbGbE7imLqZ2jquvySkIxqUxWQeB6BDwNaZ9nrqLkoeW9nl4x2k2aU69Crinc6StPUXdt1UhR+S3kYA7w1P+jpwPRJ2/Z4u15jkh1P1p2LAz0axQZIuK1kTfxmz6k/q8Xd39dQyNRYxSc9riXjtKzjWzUsoFNyaILZF67y0kav2CtjiHxwqXfzKyHd0kVdhHNVSLIi7E1hKpb4pnFmXfE2t89x+g5plDTxHfBKikxpRFni7mYexzTtn33utv6tTKGFTDxGlTQGsMDvpXsTTqwFNq52/idFM8YImTjjUOoLDRHuNZq0SW56SpAwIN9LNEnP/G+ObvDIgC/5x43f2tWVtNoDMa96QN+Kn5Yqu5/Vl29QoRGNlYaFGIOuMX1vwveZWltVGbJM0M2wMi3PPwKhx9wpX449k3Ik4MJie6SOJUNEHI6h7W5mK86lbz55omiKWrR0LlyjjkAgIhikKsnR7hdS95Fn708f0wHI0ycZ0gQJDXKN1uB7ZJT/7PgDAajzGcGbJ59GLMLvv3IAjQ63XhZx4ZXhDqX/1+3zGeLxelQWkr4SQEeYE1MTmJMAjKAatRnKLXCfHlX1yM/znuciye30ccp5DEtqpln5lfEle7Y39nS4nJ5IcbJLdDerKb6RsIJkRhgLUzI/R6ET5y5F54/6HPw4LJblYIBlkV7xt68Vndym5VW9aWV5FKeJo1Fpp1gdFbFLT1qGLITkNiIZOJ2VCKfIgu+QrZGmEg/nqym2V8RYwqJmJqu0x1RWZTgK4r8GvaLrUHR+Mz4gWRj87i614aoxc7LdeTpQypIYimeWCdGp6FYjrTeu/NJgcjtOguGyNmcJRnoB1NLRBmLSGiWqBDMSQX67+OTqw9e/4aVkeEmhNFfupKmr3mOsGv4V9J426ihPmSIzVxBtdrM7XJqzteYKxxDLXL/3/8VRuPAD+D46mCSW2K7oYEXrtXcg5OfW6zGIt4qs/D6yrTcN9LSX97wr8+Hij70CqtG2Jfa2Ee1UeVnbtiTgutzNrlOjNql8r7Pv8CABsC2KrrRta+hnmqnX0DdxCjPv/VzkNIG5OW8dm0uH7HngL2jKJb3MKxQDLGYJyk6Hay5tO5V9+Hr/38PFx723LMmTOBgHJbt1wJvOS0GVOZ2atDCizW1qgV87VpWX744pbVCWf4LWX1xcq1Q3zjgy/Fe1/zXKwbjNDrhrmKaIIoCkEUOI+ZAsJ4PMbMzDA/C2zAzRiDkAjdXlfxlGegx9q164xt6FRdbWpSTE5OIIoirwqVZVyvLOiJyQmEQYg4STBODSa6Ec6++l4c9rmT0Ot2MqN3Y6vdiWanNXsnU7fGgwj6bBKn+VpDoxblEiUHN6SsKF47M8IuO26K/3zPS/Ci52yeFbNkEIWhM4C7vgqZdQcU6gIlKwR9xVNZLNUkYBb1rQbFauzkwGML0KqFRm63xnM/HAoie52m96MgqC8waz4bR7nIg0LXFeZ1h7xKnWjqMLQ4cNsoENo0CuMmRz5KV/2gidspcnwn68ZGWlBptM8mugG11M1ZFFP1BZTSqfe8tneOU4oUKZ0X1Nw7X8fRqOA/tagbjWMIXad6x+eYsrPEnQglpbCbTXK2vp0SdZ1J1kFDYWc8cUH1oqpJFnlS2naG2jsH5PkMjdfyFBPPJiVPU+HD9T6vNbNNfpsHT0LrKP+yV635vI1d0bZnWfNNs2OT76zm543511F/W1kRtL0/LRa7OqLh8wbUumLyd6x41pI9wSmRAoBXQVpx3kIDRcU5Xa9MrIBULEfw5XklwAObXdH4+9Y8sVG74XUd+DZjRVoTwhsHLM0Pv4+wpHCr2hpK3pcYgzhJ0etEWDs9xP/85lIce8q1SBKDfq+DOE1LBqBRAJJsLlLf6NJyzBYVYgd28fPQu526aXhFTQ0oyOiwYYpTv3EEnrfDphjHCQIipGliXRyJwzRNUxS28pLzVShs+wH7nOwytXadsdvksHi3k5N9pyDkn2V6IApCY/e/JicnEAYBhnECAmHl2iFe8fETcM+DT2BOP0TeXPSAP656mduyLT6Qq9TmeNiwSXIDgU4Tp9rBEpMJwwDDcYwwIrztVbviM2/aEwvndjEax4jCMJeIzTE4Qy1k+O2x7YwV+xTQQ8/soLOuRTBxOjVopse0OTgcLVOqKSR9tB7UD0M3HrRMIa62CPIdsk6CTtZrO39Xg7LxfdFGDt17vtY8K35gCcZ9YwIjC0DnnkjRhrZiQS07f/5rM1p7pTUFmHeg2hYOvvVNCmCiPvfZFP+8Q+Y5qP14CVl72HjWFNXsr6aC3QKQmhIc/nMN3bjaGKJQmLW547YzMvI+Na1fb0Kzvsl4W8rgvyDZr509Uz576zmjWZxDKlhRU8yu7+emGqq0keMlLQTUpOq1D3Bc7zMZHuZBWxCqDVW1Jh6tz2doipt1MjVPpSPqnYWvy1WaCmuNWeG79+SZydM69qhnCdT7Euv7RcuNmkB5n28ib4PYQKW+Iup0Jma992XzoQ1wnO9t0wDK1OkGxEk2exeGAf52xT344k/Pwx0PPIG5kz3ApHlhlMeKctxNaduRW3kqhF8nqyclcSCnRtHnGwiEKAixdnqAXXfcGCd/40h0o6zZFAZUiXw6yyVFJ+qg2+tBk+MjIozHMWZmZrx7mIgQuH+Z3xvyozz6hzWW+lYlrAAkBlm7Mgrx5WMvxC33rsC8iS5yxwvHeBO5+Ew5HFk8n4DcPWmoxK6dfN35HJXkOJkUhGzWgCRKnlf4RAZRGGDd9BCbL52PYz79avz3e/bF/MkOxnGKTidCELDf5nYRQlq8QsjJKZgMNbvPeTuEWjcxTa0FYViixgskkgljUUgV76F1zxQk24hNb4pCjCETXopkcU0t0LSWJ7FznVQUc8r7G2ftQi8EIWTD+R/Poea046VKb/5TdXYgsutUfKXi71NjYNLUvmf1UxX+oid/7oaJElDD522VYHg6M43FHX//ugRWXB8pSXLTfQ6CoIxdVPM86zrLRjsEvUktSi86o70Pu5aAzaQYz6yjdq9Nm6S/cPj17AWyXpcc0RjOUuCesRBxi5RrLX8/TwQ4ci9nmQ3rOJqmteVLnhrirBprmpKYGkoY/8z8OlPP+1GLtUqejobxxTQOOsj7K2NhizPIWes1oJuMe9QSXCJPAs5jhmmsocgPrmmfTT4PYxD4kvaa9dN6vlgCjcY0Ap2N65P/jDbD15Tse2KY/P20MElT7nGQf49a7rvG/ZnPUkHkKt4cCUIkjp0jpOwJXtD4hNlMmiJN0yqfUs6ctNgLxesFgfdzW7GwTgQJ7ZTl3fwjzY3RXXDQsUPQPrd2rrB7SFo8kow18Sy47oMWJ0tgWjkb/CukUp0FgCjImhDjOMGBezwdf/mfI/DafXfA9PQQSaoBsJWCP5GrVkd586/M8VmKX7AfSO4zoetis2zcU5XHszhNMG+yj3/cuhzf++PV6HZCdkvzrDr3My+6gmmaPW2wTqALmBgFPEOpUwEUHcISibd95AwyymdGh1TioTGYzmcISVMCBNDt9bMBz34HfzjvVrzzv87AnH4AkxorcQXHLSxJKFIAG+Po2Dk33FIOtbsmNgfYVsAqW7d5ArZy3RD7PX8bfOtDL8N2W2yA0ThBEGRc30YK6L9Iwr1VEJ/dC3k7LdJHrXFWwHMg1Xbd/n+wwtCs6upmSlqLk6znvZ4NIm9qkkLT9HuMWiLcZ6tb3BKZN8Zk4kj/qgWsHX4+mrDsbDFQwwdQtbo/mN0AvdpdrhNQmeWe5boghgEH8lOZ9Vl3cAVcZh2SrHUijDufwvZoO99lod+iE+rtmAoQhavgoY2dwHp0YmQR04am7Z0lLNaYqZn6UuYG23RLZt05rutA1Mjca69b1y1pmqmWP2xS+54+lSWpdfPkmdTYyf1Xnhm+tSQoyXXxpbb7BH/X1qHxNzwzowHTTfP+qNMRMhX4Z43gzCJytew6c8CcGvIXkuClBNK5Z3ULLYH16jpruRl/bW7LYykzziKPaJj1Jd++eIp7zoqRqjKgIqrniAm5ucA4TtDtRIiTFD/+01X4+q8vwcw4Rr/bQZKmFVtQ3hlDFh2dq43aar3ECi1XJYTPFFZAMPPn0O4wAQECpGTQiyL8/muHYs9nZdTRmZlh0QmzFW2NQbfbRa/f0585EeI4xmAw4/osslsapHkLFcQqc8NRRnZ4aPQtCso0yxTdrpIjnHUIu1GAZY+txdd/czmikEAImEGzQBp41pbf+KzhZdPHAtKAtpyeWJgnE5/xsk08qcS6g7yVW33AIO9srlk3xP87+Pn47VcOxXZbbICZUYxOFCIKA9bhmSXUVYcCNnwV3Qvf63DkhuoQV3mICjU75GiYaUGzUZN8rZOkDI47CBFHSdtS/OBSNnjrWyUY++YmefBuoA360C34kHlUHdP67pm/W2xqugPZSs6uu9rHKev4Zh12w7n5yvN3Ej5fQtniQFNnXdPUi2wTBxhY5wEMdeVIo1G6LtSwHcnTUWu1xtnesJBicZ1Sfa2OMlRSVggWU8HqsBffn02yqXQ5vYm3B223CiqrZGWxrw6+bvrcLcAtEs/BnoHOZ89NhphKTz/i8vtp6q49X7fGk+yTiLFq14StDbmGZOeutnvJ2BxqV4jFcJWBUSMm5qMBa10hU9ct0joy+TWlSrynBin9VrTJEie2GQsuGci43TFf99tnNaSdDb7YFwSWoE8jWNQwd6l+n9E/5fM0ossVaLOwrEPvG1mgFvRJ9TySucAsin+tMwbGckKA/HQjUJuTp4bJogEhVMMmoobX5WrA3itTisugRcEk1xJp+5Svf2KdWSUmtHoGVC/8xBkIpiGnqsvhAs2KQu2WGmtNGYtpR9B2JD8rup0I4zjron3oiN3xm6+8FptvtABrc7s4tzuavzK5dagpij92ZgP2fbBbT+yVczYjleCGsZh0MvNLkSIMQ6yZHuLbv78SM6MkU1BOjYi75O/CG8/Dk/QhVJ+JhsOhVWhSwa1Fxks1xs+QNsagE3UQhgTp1pCaTNknCDI51Y99/xz87OTrsXBuF0mSOJRKWBLUfGYQ8FoVO4Ys9iFkGTRWcjvMp6N44FXwCoMAo3ECIuBzb98bHz7sBYiT7D5EYVA7CD1bw/hGjn5by4k62f7ZoN2zQeufUtOsmVOuy7LXqyJKxHK2CmJeMR+G1jcmvLz7+i/seMoD07T7QLXXWV1jXbXrihY1Cea0nRHzPmcS4WCWXTF4ZumaEpza+6atJ8+ckWlKOGuQYnXmHLp4RttOnFoAAlZB3djJq+swYPbX9lTUPkkWQsqsh7N+ffRJxXIGT+HamqwSmnxRnbgh9osRnRhqY/PQNEe5Pt2tJq+f/4u1oNhFEEtOZefGPd/KatJ7Jv2fKrPymOub2a2LH+Zf7F68nvObdeMrs15HDee76imf6wz+iwlY+nNw7hETOWSiRk0K3W3EdJqeidSGaFQ0lueTTwxMgCBUk4c22pe1yE9bCeKhxpaHZvGb+e1MkXULe50IdyxbiQ9+6wxcfuMyLJjbR5ImABeZ4Q2istFKls6IgamEccjxSHCsvwwDvSEtKWCL1ZQ+hhSAwgDjcYz/eu9L8M5X7YxVq9ciCoISlCVTecJ3u130J3p24Vd8jCCfIRzMqGVUCZakaWpIrCrDZuKm1k0jTZO8q+ceaJNzJhHmHbOyys1lXofjBBO9EKddchfe9p+nIwyz2T0w09Gy/Woq3wyyZTmrSlUNotUCyBY3OQlUZXQvDhRTtXsJhCgkDIYJJuf08MOPH4hXv2hbjOOsOAxz/rrE3KUUr9d02+N515Z21qTgSGKGD57AUSctzeXgZxNo2yhLtTGDfkoHmOJ1hv/DA6PxUkV3w2cg7utDFjRuV2BXFlSur2Wz4blhZsP1xZ1GC9LQSY16M5skyz6U3G6PT+yoEaCoEwBqoYzW9hnXUqsa7F/876ubYEvgQTt0+fNoRQ1seU/r7BuMMi/Y2k5EuR8+iq/+eciqnr2KxMJIWS2e6xKvhmSO2Pyt+qw52i2AClKKytmuw/VN+J+azY17v9e3wGqabfOBWwaSHsnyAnARmhz9N81iW1oh6nSGjPGooyvrVVOl1OxlIbzQTDuABi2AKO+YR10Ma1vw1yj1tonVujIydHVa9V7OLg/xKj/XnJ82sJJfVVu7KQXcqd0jsy2wfcJCcGeFybN/m4pUGRcd2rFy3jpqqU3sq6fQdNCtTKqiLY5TdDshnlwzxIe/dQZOveg2zJ/Xz63zqvqnpN+Kq5OKomRYvUTGVe1WEA1SSpuq5ixpjdkZGgRIkhQbzJ/A7798MJ65xQIMRnHZyOLTdZ1OB/1+z3pvKu01soJwMJixGmUomI4mn3dNk7S2t7xu3TTSVBe+MCZXEY0CSxiGF6iPPLkOh376j7j9wScx2csM3a3EwdjmiU5B6AiVc91ZU6dTr0jD2lV4OaMIgzAIMRiOseHCSfzs84dgn502x/TMCN1OlM8L2tvIWE+1Zj5M68KJZBo1yRXVzbr5ApWiZGklGk2BZhaqkv9/+11p98Y9aKpnbzyKYRqKb5oG+tezaDc++sasCiVXcbPJ19EwBN1+zepwtSS9xeu6SZZ7XWaWyN/6Bvn1K6jQyoi7bUdIK3y56mWTGa+1v9qsFSJR9HNYz9iiCGBUmYYEsU4F1Sv5PgsPP+fnZLFakwjVFdmaCfL/mYeXTN54wivuhy9JWt8OmXb/SDwLbearzgtSk83X1ECdzoIPHGxZJKg2Lz6WzWzUgAGbteFLhI2xzaE9z9pnN2K083O2QOYsumP2eueJnW7LJWdC/+887dazwPo/mK3U98/sNHO9hUmbNehhIpAHGGs1S+l7Plr+onlIa4XtLL2G2+Zzsz5ztc+msBvqft77nnLID8ICw5mXMxiOEnQ7IUbjFB/59hn43Vk3Yf7cPpIkYxUayzFB/H5ZufH2GvNBL/diDXBI9h0qTeQt1iKVI3BREGLN9AgH7vE0HPupAyr7CR7P8w7hxETfe/ZnBeGAsS7Z8sm7iEGrForSu63mW+whEoPMDyRJUgQB4fgzb8LN967AnH6UFYOwM4+Sk6wJC7H3JkgO9eyDBlmM2+qBBkGI6eEYm280D7/50qHYZ6fNMRzFmOh1ys6gteD4BTK0t5yDoIbFIFB7rWCglnNORlEctA4wo6gOKVx4jStvBPpGDQpy/6pDZjZIkP575O8QwbeebK669aXMHtEsrpvkffcEdPJsPb7ejYiBUhGT+GfwzLLw+S/+GqaYy+OKbMrMhG9Oxvwr1wL/90IBUz4/ZaamMXTJz4IWnTPpV6UNw9chvPK9mkRJpHJdoRYHzz4XanV13T3TYIGgqZw6AxUNn9ehR7Hvy8LTSYihiX3pMbHRRqPuWTbNeom5LH5t2gySNePYcj35PocYoy9nq2UBqnWtjGduTs79OHN1ntlt8q2holNc193w/EyrGbumc6KNL2l+fwIi5/h2nrXnOcj4bc3gtRj38H5fS+atGURbZTdVYjCEYqsXCKhZ8z612vU6l7XZPZHvwFM0tQ7e6rxz+Y/aGNz0fLIZrdTq4vvUN9W8YZY5DbXJo4S1kPO+Dee1b0+QWBu196Xh2VEt4wmNXX1q8fP+OA0m0GKPQkjRx+I1er0w9/oDfvCpV+Itr3ouVk8NEYZB2SAqgRhr/ps3HNxlT8JvXC/MxMIuHy/lSqaufmuSppg/p4ezr7oPp1x6N+ZOdmEMsqlaCkEUIggCpCbFOB4jjhMkcYI4SbJ/T7L/zqwrQgRBiCAMEIYBwjDM/kRBNt5nRCeNlA4BEUc/UYqwSEytqHPjOKvA71j2JH5++o2Y6EWuYaJGT6yI2w6EYnK10EL9B5AGjNJ+UxjMV1krCsocUSZROzUYYatNFuC4Lx2K52yzFIPhGL1OVHYRjfFHKocipJh0aoieTOia6BXFf6cczaxRBDOe+Rifua0RCLNPtaxdQebpfHoklrXgooooCKEOSb9yroDgVVL1Hhh1Yjg11yMRP+tVgkC9f6pKWd2BriZXHDVpmC80FfpkUPnvGG8kV3rzWlLZdK/WA60OUOEtBN1s2yeprj0nX0ezsXhUOhvyUPZ1Uokled691LZLzNFEqkk8PCqtxtOFsKOn+xxJABgkYphGIbbYD4pCokM/yi1uyBi/BxjaqfOiJtGUFKfGhE08e2qLiEOfXZX+Wt5ZSMCK83XX5i3+S39dag+UaCJQbbpEUOatZsEqqTWk93TRuKATgSz9gYK+xUkV1s/OsvPlVZ+uUeM0TaCncoYX/9RAdvKcOdazkrGqThWzpuEl6dSk5AQBO9M0X1Bn74n1FBRAu6AXW57YxKH8/LvqOEzVBXbivCef0fKstAB+lThk5XDMhsDIddwAHnpzqJZNDd/5piootylS2zQdWoCAKpDbottoBLjrjftCVbku9pEFfOsFbhgSxrFBJwzwvY+/AhPdEMeefB3mze1ljEgjbLvyWsBqDBomWkZQwRm+hssrMpSNmrGuJbF9T7zoqaRUEVCAn55yAw7cYxssmDuJODHIatjsHB6PxhhMD4Cizyf6IlEUYnJywn5fstmWQSD0jkzNKnSLW93bLQwCEAX4wUnX4sHHp9Drho5thH3FhsVaqipQsotDk7p6OhWqTc4clTUmxav7/C2ikLBuZohNNpzEL794SF4MZpK0QZ6RNutPNCuw+TpTcmPXFURyDgaerqIMdJbynS8ACMW6Nsl9E2po4Hrl1am8qahbzeflkssUBJZ/HIhRIlsEsVmjntCNq8nXEZqF4pwvuTPi/pR8fBj/7JFxCwlH6VSHiP2HgkQiZzO/1/Lz8qI6IBvBb/vkZHHjVWNEk1CmXRBpCqI+j0Svr5vWKa5Zazb13fZ+Q03338BVAmz0vNT8rETxyz3BTI0qcLFuSXiI8XsbCNqr1vE1GrAk1l+h3OdTWqaarkBTTCNxP1MJ1HleN+CfWVGdtYqPGrqXbybK1KiVooXKrQ/lbwPaaZ1SzEa5tyYxbrPHg7Lz52Riqv9qobxJQQuVy1meBb59RC3OTovhQRyBZ/eZrXWuXUjKei9TT1kM+oAtZZ+3nUe0wBVPl4p3ueX5nQrfXFjjC/x1ZIwLyuee/X9gqQ/XdbCanoWl5O6oQNrnrPHlUuI+EGse+LxYHd/Eus/A47/iH0uz3Euz7dbz60lraJ9BHYjmYTb4rt+KwWnaSgWfnZhZwUaF80F2Xb0oRJykSJME3/zQ/njfoc/D1LqhFbeLFVD4lhvltUGyVOHwhNBDKY56Q9mf8uHbYpcZQyAtmYhxkmCiF+GGux/Dr8+8CWEYIk6z/Dco8t+ASg/1Mtczxr6b7JLkWgcIgSFO1dGSBXJWLbdTJDbPl6YG48Sg2wlx9a3L8cdzb8XciU52gBJPkJlvILXHJPxj4MbqGBJ/AHyTorKlCIMAg2GMxQsn8Ot/fy2eu93GGI5idKOA/W5jalLToRLXzdENrRuUb2yt0IAmY68YdnsPbya/rnfb/fSb2Zg4a75wrQvIur+XCTkPshpNrc3Bjva03FZFYy47jgbDXOtAgW6w28ZCwVuACYl8WGgZ0MqiXZs98JnCC9l3mkXh5yREFkquH2gB677X0aytQsYjIGE8QIVDV/XYFWgH9fqooloD+Uajk+gXriYrswGhoNA4GcXLa0os9g8Vax9opKN5V53HRsd338qEQDOeLiwAak4Uo6DZte/F1gBP1E2NRY5pKK7b7o9A60Lwc4H8FHku5KDeb34v5bNpQS+eVZhsAEJbqWkLw265zigoi3ED7wABAABJREFU6JxkCbNU3ViFIeKxiWl1NtQIkzgjAT4afs78yUZqGPVNBUcq4CRVnl1RqDR2wj3xE4p9RPtwpt8LjS6vzqs6XdemNyQRHEnY5OjjBm0+Ayn+raZlXuTNW+sEdWRhJFgWEhALKKgspmpASWoAMbQ43yZXaxTE8eULNe9RfCetA6RFrJ/9F6/KkDsHBEhT4L8+8FK87VU7Y/XUDIKAmdWzgqkq7gyI7C62MVRSPx0Jzyopq/ZwqZ1SsbSYtEn2faZgmqQpJroRfnLyVbj34ZWY6EYorP34+pcgmAYsZyVHWnbFi+cROEN93ltoc9vLtiMr8JIkmx1M0xQ/+OPVWLNuiJBM/qa26Iy9R/iCrnR6sqAqLSJkyiyGI4k9vED32QpBGI4TTE508fPPvxa7PWNTTM+M0YlChCGjI5aJJ/t/ab0RBK7KmrIpm/zA4FG9I8HBVzdvG9qTM6Ng3EO9aSO2CXw+9T3tkFWKOfVglskDC56pJziRFvjqiqhZdnStzyNnWrTvWVVNUIs6G1E0omyakz84a9QNQnNHyPOUvV5VWgeZF7hNxZ/n+g1DPh3FVN7lU4pu8gEUDYCJt2OhJSrK3XLejyNuLZNIqgMw5GyE5f/XPPNllITM+OaKte6e71kpwFVx/QEvyhmSazQ7B5nE+BITj6edE0sa5gLJ41tHvngjCuQ2SZZWVFDL+Z6m5Mp5bw0Y8dxDI2ajvPFHzsNrBXILELQuhvrWPClzm958hBe0sNlA2d+litCdUYFDHzPHGQPhgFvBCBHjGNa+8nX8tQ5R+T37rKfcE1n3gNbn81DXPRYzaST2fJuOqPOcPNYt6smi2QB54qlFebOeXXVO2PFeuWaPx2QTYCHnA6X/rvEU0l4QrcX7ecFNNT8xrbyAIfZJQ3ujAjVn0WVtLIThF6ezPpunyJTnR9vCXOYScq0UtnZRSNm8XWLwXx94GV673zOwdjDK7B1Ib5JRWQBWiG22BIxlTyGPr6rArDCNYnZQrn/D4xmyOqoXhXjwsSl8/49XIggIaZIiyc9YUoQHK+UU/14ufspk5zfBX8vbap/2usw+eGpSxGmK1GR/JnodnH/1/fjLRbdjwZwO0iRHaFIjUxOB1nHOf4VZW/OCxIOBvSmqzcOr3RxdZUEizG98nCY4+qOvwL67bIHROEG3E7HYbqygZ6z3FDaWPPCyBR0Q2fSNYjBcBktNtIDNyJWHn0Ub0ZO0uoTAV2zNOjmR6HSbgspHy6pZoLXJp3NgKoWlCNZG6WRpw9kygPuCpu/AlR1c9TBso8zKD5HUwKSePcpRwiAoi02e/Dd2iOQspI82BAg6hZKwtumk1SHLCh1N6wRwMMDb6dEKQq1414CK4vtKkUe+4qMNXanoJmvry+gBvTIL5g72triFtVeEIELxc4EoTpyOak0nwyjgirZHjSzg23a0Vblwfd7aKdyLtSBjV4vOAHFaa5MYWJVJ6N1nJekqUNjU14XzxPFGKis1C2epiTePTS0sJJwEkscbz7r3JXFGdBeN6M45z16hZld/oBddgnZYJoWe2UBJ/VPPHeWeGSKkirAT35PkKzK0+8VBTuggHi8XLZDTMxetJpg1c7Wy20getksqGROicDItgVWVUumpKLxjCkpsNlKAxRf/GwoYEsALB66cs08+Vynk0/R+miJ8Htc0NlgKz0iO7/kLFg5pQDl7Lw5qe8VzNAVoD+Ajc11Jl5fK3fx1Ckqk9mwcgFNSgBFYAIgPqOhEIYgIE50Q3/nIAXjRc7bG2ukYQRh44iR3uDHKKWlvXMOCoCHBAiPZBmPaEIaXRwZxkmD+5AROuuAO3HzP44g6AUZxUr6akyuR8TxsOYec32vDOPcuEmGyGZ6ysRGUzLiiY2bS6kEEZJCmCb73p6sQmzQP2kVCDnUZkrzJXiyFrEHN4rOkDhnO5X8b8VJTM0N88e374PUv3hHTMyOEYeZBaHN4fUGjHfpsFQACWVKV4BQUX3twRpG+trjANaIZTUlPXRHmoIay8FFmeqgBkTOmOUBaAjKezUyKazcxqXYjAlvKkzlx7U2dE1+nq7w2LfGTXdr851DXtZTILdkD2FoRVtBjinmq2o41u7+BNtPU1AH2iOBocYTPsholyeECA1UNLISbJAWFFzlQlCl5YSQPMf5+aerOQSgHnfEUkrKz4szJeCjgUFDYqvDTV1+Q/yF2j9I84dGo5M6haSVy5KUA8K5eMf8T5PfR2wlmeyJlNhjaIV+HUFMduu9jVDBgyFpnmh+hZz7ZAQpqKKSppytcFAKcikOeuaryPnFKJ5s79HZ4fF3l2c6sN4EzntfxqQLKGbVAUF2hdKt9wBEpM7ZG3FdALxAoYOrYxJJCJgVPynrnOU5bymjTSIRhBRdf/6bmvgYUuIwHgjP/bURBm8pzrZjhkvN8SkHqA4qNAtA1zSGTp2Opzppppt3eIqlZCMWhXRaMhTowpQ6gQYMKawFGaSMFDDjyFeh1CrypDxiqUT126IJB4BUQ5PPQpq6bqokDKfdSAosGLQW7uBpxDbDmxE42MuBjYfDmkJOPGjveBHmncGYUY9HcHr778QPw9M0WYjhMsj3J53zZB/WN1RXFHBEjLaIwtPcHQSK+V+EAJAaZOMzKqTF+dsr1CChAFGRZgcnGae3ax+3DWb3DSnwx/yTT09PGlyAQAWEYZsOK1nRP9WPjOAZSgyQ1mDMR4eSL78JR/3EG5k5E+Yao1HW4mWf16Y1tJ6gapZhyJsDO300pfVoYzJu8HNeCeRgEWD01wP87eBd8/2MHIo6zRRWGmeRqXfu+qNi54pdfzKNG3a2lYa/PUN74uP8awiq8iaTaKbU1927oZEnqJ7WgZTSZ+TYexI5iZJEIGJs/9BQ9dZqSp/WeQWyp9CWN4a0g7EusOGVpFtfS1nuSaighrS04UNE/yYVzbFVecVhQjRqi8zzbyNPP8jnWgSqyY10LikhlQE/o8yMHohirQee9ZSZVh6PPF47gOsKW98xXPDWZHbe5v3WFDisAmyT+jfAPXJ/9LtehLyElvpeUUQJfF76VGiFXzK15ppo3rSWUUROvS3aM+L3ZubwpKpcaeNKWXu3zLWxM8slWHNRixyzW56zOKs4yUO6d9Bsl0UkoNNMducBZxDC+3jVhFK0zo+Uq/1KvYZ9XIUm/VTe8G8+dqMs7SMQRI5+J/GwaDZb/LgeS+XommvXMPwl12Gb/Q+MoO892X7bNQ618ndyzrW7usC42O3FBnu++vO0pnCfFZ7DPZcrrGhfATXIdlPOufQBHfeUvSOLMQs+klYm7iOqVNSHBWzAb4/5AWVXxvFXsVmL/KArY1Bj0Oh2c8j+vx87bLkFqDMbjMYYzQ1Zs288jikL0J/r+rjSA8DOf+eyX07RC3wrqZ5pz8LvdDqIos2AIw2yYNQgCBGGAIAgxHo0xGo9h0hTTwxif/eklWPbYWvQ7IdLS+J1gM1XtmSjLlpF7BjkopNtfyB6qqV6fqQkV7xDkIjJTgzH2fe6W+MEnDkSYI26dKERAs1cvlPMCqmoUkT+3czoMgK0ob2R/V0W8vWhmg0CMD8njiO9sueN1P2+ho09pKBhOUCYiL9yi7lH+fBi/vskEW5uFgUhe637eSRZazLdBsw/RAo4KM7mzQd5OjA/11SickpapdA+9SYCHmlknjBTw+ykonE0HG1e3dFRG6+4rO6hI2ZHkoctAFARcBINmMc/SuhjUimABVrmoL1co9N9LUwOotOqecNET3/pS1kzTXDRaiBr4rCBqLQ9qPlNQMwski3+uJqgla0XhGDARHGklxLuFdXNIXusDxabFoF76XlVGlEqSswnTVhwkJ7GpOyupRrFSZaho71km8i33W9sCpgb8gBC9klYj1n0v1wkYscnVLZD3ST2Lmuw+PFYy1GDL4KyRmuLCt6a8XSfR4VHPBzR43EGM6JS+ulDf17lvgZLnaF3QujiWW8pgPYpCx06r6VzzWI5p+8ZpWAgtCq7Mrne7ybucfHZe1HROiLNQWoiZFr9f1yEmNJ+V1b6q9EBLNkG+GWdGMbbfYgPMmejizMvvRq8TZl3bUgxT7E3iCby7Q6tqxGTqouTmFeR07ioiqWWpg0wMZ9XaGaRpggN2exrGSQKTZmdKmAvllOqjISEIA2vEKjWA4XVf/ofWrp1ytOp532Visl+as2tg8PT0AMNRjPmTXfz1yvvxzv/+OzqRGGQ1vOBTVhKDoMkIk3qjtC3Bf8j4iyxUrfM4TrDBork46euH4ZlbboCZUYxOGLJxnkoq1iZlkPh7pYMxy4XrXmOFMmjUR8Nni2h2yKX1d7Ps5qkHX/FctVmEWXYALLuR9UC5NAQQUHj+dc9CoHu1/sXrica1vScuT9+SnHK7eQ2BUe20+Dzk0NAtZYHcKOCI9VxnYTdhIbB1z6vOF8owUElBLuuRYxbxvJT19t0iqknS65DN2aDwswgt6nMlJbL9S8B/2FRgo+4fKs8C4934bEasaX1a+56BgzWof1PHqu5ZrG+3RO1ctz4fPPfSs18t03SB6jd5/snPp8XX8vutGQgc7CRLGKmpU+g7p+Rn8fqiKqCYnBGfTefEAWKBRnaQ9BB0PFTlSERTzKopKhrjeIuiTwKIre71bNd/y0BHHrE9DTerQd+rc9RZx0U+mZ8DLW1FTAOA0LZjOKsY3DJmGM9cNrVkqqxHcJudlVfdezYxpwQVl2oaH6b0B6Ta+873ZwGaJUl2fZ0owAe+9Xf8+vTrsXBeH3GalCQ0OzaSoDk6yLpg2kgP5ap5UXYbYRsl8J8OAkKSApMTIU744quw07ZLkRrCxGSPiahWsZYIiOMEg8FMVT7JjmSmw0kWEmCYKo07FM3qM/bcQgDDcYI/nHs7xkmCQEkaqW4nFZkBe33Lkqco1YobxT+IqUi3BspdzPm8sTH40jv2KYvBXidTFJXrMFtAxuH9l5iC8J3yomfk1PssSSd7fRfoleH3vaKBca8ljYRjlfCiuHGU0hia7aNmEXSTaghFSD50TAb14jIMUSnVwUyB4hqPlgbpHTBRGMmuGNV1SCRK2aAQa70lQ7K0GTmvZ5hv2dfQxrybheC/H0y0xnp9RVXQFiOooTgq3WI+i+KgfHA9spoOL8f+QXYpin2g/Lc93wJXDdBTpPLVY6OGDd1d9rmM1mHK6RzSJ061Y6iJI1bcE3LXHpje/X+FMsiFWFT5fV/nYzYHPRf8cQQn+MyeP5szxr8T7bkZ3l0xJdoLHkNB3sRfA0eoxne0bpaq7n5os4Bo+1pSGZUlLk6Xk+0p45kV8yaimk+nZm2hFIPMZ1lkENWbVQqg1ZlPcGm9fI1Sw+iFFbcUMaW6xN54OlxtOoY+tVLH01dT9WbdJuOJm9DOGd+e55ZV/B7UGJ9r8cmnPqxRdVUbE+jqmw7Y2WTP41GRdoTGjGku0SwLAK5BIanbfnE4SwipRSGmxU2fJ7Gvc6/aJnm6w74uGI/9wVPpjsNlSnmflSeWOd8p1PmlBViNp6Vpa4NSY7VArOnDI7opRs9ACALKRGZgMB7H+I/3vBi7P3tzrBuMEAVhyfAwbE6wzUFpcrd0GxzlsVf6WBMTr7HfJM1H3VasGuBPF9xWfaJUFJiySC2KWePum1xUJoXJpVlMJc6smrsW9u9c+CA1BpMTHVx683Kcf90yTPQimDQF5aqaRqRfxuZF2pUiU8/jXoWmsofMaKhg9ACuR2FZjGR+IJ0wwqqpAd78iufgyJc+A4PhuGwL84HvbJibyhpTqhgasSG1ZM6oPnBCiCGtsGx+SGZCCJXRJa/aJfcZXJ665HkzYQVeZBctUDZ/EgiaklUksQPKpnsJeXhn43poRQVCk9rPpWqLe1QgDayDzfi6lRqiCdeqQqpsWckyV4QTEtNWUseFYBSkiloEMW1Av86TxxEUYvkUiWELI6XuJSgAn3pn4MwRUnF/uegKPxSkhD8X8WGvnyqJvGpUzH9GzBUaNpVNpgreFf2s+M8gV1olx2uSlCH/kv7BD4sGFUb+uQPA8YgznqQaUlVNRavZ66SmmoktTWuzQzTwoKll14aLVAnhklJpkKnVOZQiXlRLywXUzMHBpsIFfP0JEKYYDajWUg3Kzw52osqbySo+gowmg4BXiPnnClDGd4Jtes0/QyD8FzXVT0esShHTkjOdBh6152KdF/Hf40NbPjtlrinLrQIrfpHSHXQSfyg+nExm3UnQGL3PorkVZ1SugGCYeIKTQVBG0SuBTUs0l6xCUya0vi67z8/OeGKoBkJZ4hJC0dApynz3x9PdgnbWKvGQC6/UWpXwoqB47p5k3VGa9tGDPUrdqPn5OtCCi1iRiHuaABE8ascQSutpsbZZF66KW4JuWQDouciQvQ/IOnCMUpiXaqpKTE8NvF7DxnfOSyBHxE0prBaweKT5DM7KcL5B5ZRqCtsi/+Txycj1rwCgMuakcm/k/r6lT6RoWNR2sTWAGn77KV6QWWe0BdaxuidvnxER4tRg0bwejv7Iy7BoXhfjcVI5FxRyoRTYIcDY6qC81VbtyTwPNiwP5gGVUc7t12DNFQP0u12cfuW9uOuhleh1O0jSQpCosKpwL6t6K8NAucxGI2KRrqpDiAcfKluPlFdfKVtoAbKbdvzZt2LNuiEWTkZIOA1Q8oJMWtnZly6MRVBkP0fFDRSCEiBLprVK3olRzrPXDCnA1PQQz3z6Unzp/+2L1Jh8ZlCIMBgqC8vKIsNVEHKCqxSQUHj8XNYlS8ZMWfBWs5P5UCl4BowSgSh+xqI0gRnQ5nxgi9dMggsO5uMKowaqCu3NW+3kDrXyexHkL2rIrxZoecGUM3v54g5YYcvbPAYlRFE8C0mZKRNPGZAFHz8t7hejuaZp6syjVBQDqkRZtCSopUqYiqoqiQugmL7nyTT33dMKY1NHP+EJPXt9eR2FQaqBO2hvgSA88MsEAPD6ZJJMFOARBdKuk4TRaVE4cNDDpCzbzBEykgcDlR5Vgc9SwxiYwL6p/GAM2POX8yTOXK8oBkio2EIAFkYWZRyUSckmO0jKDStKUk6D8c6FwBYN4bLmsOcGpd9YWXAWwEix/wRCQYKiGahG1YZhXtlcBUgpoKvDwTbgFaQbSVUtwJMyJpIrLiNFcgwDmqz54BrRHCnYYSWGWtHvmS2kIHBoepBxSOmeOwkYX6d5gVMWvOzfGzuQxb3icu8lKFPFUkPkqPfZAiEG5CPcEUvQi18U5wV/bRlvuZKr7+yBMucfiBnZOpaGUeT6eaHim0Hne1TOlzsFinbvFZ9NLvCknUWQHUhmnwVPRzkQM9ZaUSvNq5vmcL3+teK+W3FRMFR8AECqiYvIDpoGMFOlpmhEh90pjJWZQsP2t8wbsgKOHLaWVMklaVdRNE2EwBAfYylBPKUDWze76Xs/OatnxP22ijIiIDWO0Jy1pqDPPvJnYYxRQCSyhQ/lLKUClKvxW7FWAfQRMh6TqsrIgLsL8q8wDNALCKNxgp233Qifeeve+PQPzsG8ThdxkpvSG2JNnLzkK/B1yqJfwDvVpCnHomzqgPkJGnZvqAyP+c8EmYV8r9PBssencepld+NZ226KwTBGhABBFJRNM1kHVIxK/shzT0bDTI8LyqKoqW3lRpYYpKlBrxfhutsfwQXXLsNkL0BqEjsxkkljEIC/J99M1QKDPUhIEkHnCQJDaQM7/U6MQdgJ8PX3748N5vcxPTNCvxvlNYcRFCVYCLR/KI/UYKTRyAwj4Npnpq2O6SOS20Or/H354ckO4JJBywuwtHrH/LOVGyNlXVmFNiqLbuvAZ4gGnwksUzxPsDKwE3beRXQ6WYZUOrZqYMwTPEFRkQdErUolC8bGI5iiKWGpCo0SuWowibcSVJX5UhU3PvU+R2BBzkcp6K9FtxQHRfnfRVIAvw1K3bZxXk85WI3i0Vmua+nuavihR2xdFUWJvXY4iOKlDYrCQTtknetXkHdTN0cknw07GI3WlZN7BfYMKDzdwraeoySElxw5cKX45112Q5wJYH/gaguacjjCK8qiDE3wGFQAhDyI8D6XYTPlPgU8rjhZHGmBZ2/WKe4aTRlXJHJlomjRzF16P+8WGsFKMCLx0Z61USh1mtk3Fw8xoriwABqhTu3rMhD7eSNOK7lXJUgWhiGsI4NMdWZYTAWjdtJ9xZv8vHX71ynSPdQ9q5CR+0yCKR5gjDzG2410eqWbZGDPb2qaBr4C2SnsfZ1BudaVe9lKcZLHHgZomDrrK4XV4out5FFJ1fZK0Uww5M7gU11+x/cjEcesxd8VZ05V6Kk+q+K6rGKIU2xlAa69BtCssCzYYSRBDqFC68t5SXk2JMSBLOCCgyECJJQ5CM9T5NqyMnpuyeMRpHPyNX6f+Tlv0dZhsRZI2OIZYzAYjvG2V+6M869dhjMuuQPz52TdOKOVknbVnmHUeUeRWLwr1L1LKidfoyUBikENRuQDBiBKEYUR/nrpvXjHQc/FwvmTOVvS6DkeafVFqfCCIKAgUw5FTrdhkn5up6M6gLOOr0EUBvjrZffg8dXT6IaU1x/ZxaYlQsfsKpR2alnklAeDHeaK558asvne7MYW97n4zGFAWLNuhHcd+gK8dNetMBzF6EShqiBlbQdTUYqIXGSXpGgBp3+RmDNhyWxlbm836g0MUy+yr4fTbmyknizeQNaST+0ESVK18k0WWNdu1KS97MwYA2NS+0And4VV/kfsmkTRb8io53pJj5MJv2XcWGwI/+FFQtlNHnpGodwYEmihCIxBQ8fPeGhYpNFnxOyE8cyZaepmNv0VKp1VM8ItuqgardGiXhRFvKTOKNSeQKMwieSHX7Nx1i5DAMmejbN8g4iJkDviEEWyHTAgwb4HaW7v7HibtZh30CnMxksPq32GXLJcdAi4HyUUqmLBKDBMRVka25dzSLxrAaaY5plTJU83sXxvhRIs6XjloSQoYVmsofJ58thQJjd5DEtNRmuhlHL6jMU/ZVQf26MrNangTvHi0FhVKok5IGjjAFpcUoAMB4nmlPNC7ZDtK6N0KIp7mfq61WLO1+rec2ope1/S9rigjkrPQwiVU1IMsO0uibGep62Ima9VqhKxNE2RJtn1BkGAMAwRhiFmZmbw6KOPYjQaZ6+ZimcW2MqDXuaJx9eNF721lF3+89qssY/SXfy89OjTrknuZ4UOqT07Trl0lCN9c9KA13wcNcWz7945HW0xZ6jRSPn3pSqq/LxGYcpoQigkQJE6wC5lYx2aqjqJRN+hGotZTCjFS8o86PjEU7Y/UjUuALoyfUGtL9lO0iPZF5/rLFigq41qXpAGttq6LFp5R9ViBxb3z+O7rJ9l5IxPkDIy5DYGjOPZqq5jLp4lqa9cUZVskRauaVHSpdjoWRRlNPJeJ8QX3vZCbLJ4LuJxsc4NnJl34qxLd5YaeR2T5cSm/Hfi4qIG7MxLrYKuGHgjpEjTBBNdwi33PYELbngI3U7oHenw5cxlXmmAaGJiwovrGwPEcYw4jq0eY0E97EQBlj22Dqddfh/63U55eKbG4o6wTgxVWjqGcUod34yccWuY5idDiCukmBk5lwUHIQoIM8Mxnr3NEnz4dc9DnKQIwwBhwEzB2d0NLKRUqIA5SZWSUJWHrqi9iaGfMMzM0pQUL0seu/hdyiiT6vA1XzXG7ngR43xnczUQ70ucN2pj/kzmvEDDCgTdHgp3YUk5l0bGRvNt7xZTL0vNivKSXls1xyxkm1OgLHNYjTqidLQc6hCEHYWvS8APc6WzYjSrCHGo+eaUTG6qzSlj1tMKAkc8Ru28iaJMIsNQkk0SszW8q2Y0ChtsLV4j7kHA51cFWutQWrhGpBGHcIEElzQ2NtNaBNNSGItsdkMq7rcoCvm9ScWhEuS0jOJAkmi3Rjniny9QJLVJIJskOoak2dGU5vNFXDReEQfr0PQczHLewosuK/MzVmGlddBFqCIKSkCwQueNwCVNHu84XZL/Paxx+wqvKjrIAm3XoFriIxGMmljckyDw2jqQx/+zvBecZooG3zM+B6LN8ilFA2ldZqVz51PP9Hbi+dmmzYtSpcBorwsgNSnrwpuCiFIq/QZBgJBRO5cvX45bbrkVl15yCc6/4HxMTa3D73/3O2z9tKchjsfodXtsvpApBsv42NI6pK6wKc83bV6O09XE+xtW9PvUbusEzRotBSRgU2gQpFWuRFp3S7OU0ESjVLaRe/+Kc9XXfdM6cd6OnmDhOHO5fBxC0Ob5GVTsT20mmmTHy1Psap9VnuOBnNOzXqOIZwo4bKW7xrWkUgp3rdNFnrjLz91AxAUu9OfkFQ2jA1BEhGBRow0c3qBRRAxr9Byc2XQxbgVPHGSHSKVu790n7rVLamu1DitLg1LkkbF1pN5KSAGCyGA0TvDsp22ID73u+fjisRdistOBKedMjCNmWT39oKKQ2kbMAufOXyeAda4VpU4pwkg5r5IKZRVCmib48wW34nUv3gFhQEhyCwqWLoLb8znPMf9HFISBg3LwZzEapUjiJN881d+lKTDR6eGMK+/FHQ88iflzO0iThG2GqjRyx20rqqEckC94t8UHr5DYwKKWyCVQ7ausIDUAPnrkHth4gzlYN8ioou4CMtZzNOCCFgRd/ZJUZJ+4RhBxShmnORikSVIWSGkxO+O8k5it1LjPjEJWCM1wGmeQI63lKwRiPkM0jh1EpSw4ZJeouo7CqzKVCqaKma5h99spBsmm+AW5MIiW3sjuWxO1r446Y7RZJ4WKqtEifAWZ5rFUopesCPIaP0vev0KVBUeq2bwQafeBGxCbSgiKZDciF5XwtHFVfz1HebGO5uZQkdmTZdRl/rvEFIT5vk3z2UGSvXYjUSVlBkF4cKFmDkOjefmoxo7CXFFgctog2NyvpGNpBr3iUIQ83NhnChQ/MaeYU1QHtbky41sDRazj1J0aipntqpp3+XLAw6EbG14o5gWksQ8r2xerOnQ5ccHwQsaS6Q5Kz7Ei6lk/pSlpcpqxTz1YJhGc/lUqx5FjkwIoioSal20NDVu73iZ1XUAZd1AKFsPVrcGK6TxhQQokaVLewSiKWG5gsHz5ctxxx5249rprcOWVV+LGG27E/fffj+npaQDA4sUbYjwegchmnnAKrWRz+Iq+urlCqqG9W0BmmupFA4/DhYcXew91DtzDJjBoVjTlhZGRM5JEFhVRoxBK8Mk6MxR/0SbabVPR56PfythBCgBmBF2XUxstwIKftRodV8y1QylGtFlGXgBaaLcQTLITRDgoeCFcVQqEoEr8ffRK46F3+/yZLYYGW8fGQyWV546kRluvzbUYcjq9nXzDYVhZHWKf4rtSzFZnfupobjQpp+oNGtQydnjBYs8p6tRk9UrYiMponOAtr9oJf/vHXbjspocx2Q+RJqYEa8tTzNhrmMo5eDbLCmPVLUXdkZFfRB7tKABV3hdJajDZ7+KSGx/AjXc/iudutzGGMzE6nSCrm3idxCYpq/ZchWZEVLfRi84Sue5SAQGr1w1x0gW3IQg0dTTYapk8hyoMF41he6Qysee7sUJRjdXGM6LaLf4ZBgHWDoY4YI+n4zV7b4c4SUuqaJsvp3cgAgl5TaZdLnqaphgOZzAxMYEz/nYGjv72tzExMZn5OlJW1Sc5/8CkIqwLygW/rjTlaH+2KbO5DEKSxBiPYwyHQ2y66ab4/ve/jyVLlmA0GiGMQoRB6KJ7/HPyYXTxGZMkQZqm6HQ6+PPJf8b3vvc99Hv9kgoEAtIkzTcblUVwhXpVhVGZlAX5tQcBTJpi5aqV+OAHPogjjjgC4/GYqb7Z3mReQZKmQMFFY2SgkjNimgCEEFzREgeLDqP4BqrJI7vvTUl5XQHD6SFOJ5YLRdRQo/T9gEZpfONBCrVChJRDkQRmwG1k5MyWmoBxdFJDWD2AgBFrQPMGc67ZQ0GDIj0u15rseJBQ4NS8IRtBDmXtas+wzZqS98wSlWmR0PJXiOMEURTh1FNPw3e/+130e30EISEIQgRBBuRlCna5mm1qrOKGz0hnzJ/ApqMxxWjkwmdEWayK4wRBEGD16lU46qij8J73vBfT09Podrt5AUOOuq7zWbR9IsVdPLOcfB7dtCgCNN88iLUjqa91CLlW6NfZDTnJIzFVcJHISjXOxx9/HHfffTeuvuoqXHrZZbjp5ptw7z33lgUgAHTCAHPnzME4idGf6CHqdEsk3Oe9p81VkuieNsUoEvufPL/ndPDlPlbAIaN55eVnJzV04NXP2JQYs2frE4AiBkqpnfwWuVDTbJq6fmWMV+a8yucs5swkQFq7DmQ85uuCA6CyQwfFH9C6H5IBwro9ZM+y+1QsbYkgw8Apf7FkUWo9oymQz1FZK6QIZcncQ82JPPN4vHDx5kUN54HWUEGTl6sE2nnBPwsvVyn06IpfUck4AexusYGrzB5FAZLUYP6cHj72xj1x7ZdPzc4ubmrsgNT8fGYxFbYXss+XT7NEs6T38topDAM8uWYKJ190O5673cZIUoPIypuKbmK14gxloHvVrCFEEv0g5WOlJi2HIouKdE6/g7OvfgD/+OfDmOxHuUSvO8Bv9QhNQf1ENfRnxJCuEQVW7gtY3HXDJVqtfZZ9gCRNMHeygw+8bjdM9DqI4xSdKLCpSGQriTrzAx5Ko0HFodbnj3I5WWcEyWBmMMBDDz2E1WvWYvnDD+P/6qvf72GTTTbFxEQfixYtUgt8oc7jdCDqh96znxkOZvDoI49iOBzikUcfxcxg8JSvvdfrYaONlmI8GiuJjGFeMXCLrBp6CCn0IBKULt9rpBzJUjob1hoStFX1NYXCGWSBqxSFvhkQUtBhzeCed/R4Iul0QjUqmefggSLdrnW2LIqTMlsIH8IpCqvyNfIOk1GSNmt5C8VSp2smBRLk7wlRlQLVbHO4ydeCoGvKz6iq3eV/byni+jpJYk5Wm+GQFDNV5EeKLynFtE+4REJz1rwZgOnpKTz44DKkqcGTK1di5ZNP4v/6a8GCBViyZAlgDIbDkXU/OJW+OGtSZZ5TvTcNypTlzDO/KwpNT3aKjexM8vXIKVCcElxI47M4zmei+fwVMRYMT5CMjAdUqXYTJxuxUYPHVjyOm268CddcfRVuv/12XH/D9bj//gfwxBNP2F0KRvWLUwMaF3ODadktNtXh6qpZi/1ESiJrFQZK0ZZy0IX5ZDqzvqKr5xTWLWaQy31YjqXAZYxIhVr+OXxCaXBHFDRfNp81hAWw5P9eFPTGc+74WAO+rqx6/ubxy8juo4iPBF1bz6H9KWCe7PaSJy/g5yN59rLFmyIGTUpmEz++U64eWbxvqjMlGAXWaMwbRTVTjnjIz+2oDHtE9DTBqqAAh63zwu2CVuwtRrFUhPbKO5CvLXmfvcqhGmhcBzB4zkEIJwDjAflSsHOxYKeZFEZBHopLDnKGyXAUY7/nbYVXv3BbnHD2zZg/p4M4YXZ4LHCWPbicWlo2v0prCZ5Hkfux5OiB4UUsqrGH1KDfjfDXS27DRw97AebN6VVxW4VTmKAlLwPSNDV6eon8IB8gHif5QshR3xSYO9HB+48+G78581YsXtBHkqTMRoHJrhZzgIVyKCuLidtHFK1qySDl1Xr560G10JnceRhmQjJvfPlO+NEnX4HReIxuGCKKQouKlA11pm7h55EjtoKgh4qmHg6Fh5vJunqj0RBPrnwSd9xxJ8477zz8/vjf4b7778Ocfg9JmjCqCFzvFuUr6/YZjOMY++9/AN5y1FHYeZedsfEmm2ByYgJRFKHb6apqi1QZQDlJnSnVSckngIokSTEcDTGYnsaDDz2IW2+5Faeceir+8uc/I4ljBGFYCiBwX7ACUw6jCHGSIo5j7LvPvnj9Ya/HXi98IZ629daYN29e1jUUh7BR6GsqCqVQYnz0Rc2ri4Scv5VIC/6+rzirSwAb6UK+ZEXMOmpFiLcwZgWZUdgvCmG5VtZa61xAsaRAnbGslPPWqCZg4sEe6pWlCKtIlzvPQXa+lGSMxLU560KZZ9A6exp1py3C6UPH1RkkoaYmi1JnHwt7FSMkQkmMgBvR0bbvdTX7WcRrA1ssKo5jjEYjxHGMFU88gfvvuxc33HAjTj7lFFx26aUIcpZDnCS1HRLtPkZRiPE4hjEGe+21F1598MF4/q67YsuttsKGixej2+2i1+shCiPGwDHVXDU1oMs160oCRrJrEShFcvVcqFL3VYAcKxFQaGc+fzG5Fx07DHgUAqHMg+fUoiRJMY7H6Pf7uPfee3Hgga/A7bff4bz3RDdCkqaIcyskGUO63S6MMVi8eDHOP+98bLf9dhgNR+j1enmBwmbulWSQJ/xGmS/UlCetZ6kUF7V7kgMjHiCmqdNhdXXF75FSrHDFV1kIo6GQkZRllSHjiSVeIJUDbsV6V5REjWfOS2PhSG9geObJAmlNIQpP2RXVVLqpJmYa32eHaFKQe56laYo0TS26dJIkuT92YE3elV535QgYuRZHygyv8YAcWs5Gdcwo2NTjcoSE6UZw2igs8J0c7lydAjM8z98n7ASlUCX4VWMd9qTCkDANwJ7R7GK0rj4bfSvApZlhjH4vwi33PoFXfeIEDIajrD4yXAmUrAaRQ+Rhow9U+KMRq5MglZpt/ZSiprJEEAPCqqlpnPiVQ/GqF+2IOE7zIjb7jOPxGIOZYTZJBlukr8TDTOmAXHTwbB2Y6ekZJEmCgILyAkIirJwaYr8PnYhHVq1DPwqqhrlhHOSAeXzkd8qIirRyjjDlLJlxNqZRbADcDZIag/5ED3/9xuHYeZslGIxidHMxGbtr4z8StK6JN5H3BkU4RVhloF39xf333Y/P/NtnceIJJ6DX7SJJUxiTlNZqdXLAQRCg2+1iZmYGH/zAh/DNb38T/V7PQa2MIgpQ8fAqNVFLvtL4u1NVDHHvSZqmOPHEE/H+D7wf66bWZahwHJevEwYFRbSD0XiM/sQEvvfd7+GoN78ZvX6v4XkIV8066lVdke4rDOvQ/5rn0CowetBNn4y3r/tAYPN/kpIoaGzGB/EQOYcvtaRTq7YkckDcg8JKihrVJDVGdKccH0hJ75RIomcuhjy0mzbrqW0BRz7BCd/BBNcXUpPB1+iv1PCsjNJV4TNxVtdaRX6MPRsNm0YpEWJS414VbwPFoHt6ehq/Pf63+LfP/htWr16NKAqRxLFQbtWLwUIAI0kSLFmyFF//7//G4Uccgblz5/gpRMa2viFPtxN1+9233hU6sL0FlLXB2QoK4GU0VDyfhyHLmxMqq8Aoa4c8YKbm5Vom4qlBmmb03+WPPIxf/OIXmDd/AbbZZht0uz3cc889+NMfTsQF552PsBvl3rhJacJchO5Ot4skSe2CcJQVhCWV3ejlf1OSN5sYJoswH1AkGROamqa2z6WAk/EkrEYBWCSjwxIJ40l9dfB6wTSwgtpoHpY1scu3nuX1q/Y3AqyVQjzUAOSuF1im0Oe1GC5jrypmApsqynv+ReFXFIIrV67EYDCNeXPnYd78+SUAFoWhJcxiNA0FQf1VC3kPW8uh2fLCq835oDHBuFhP6T+uFPwe4T4fq8jLKmlTKCprlJR1psUyH0Dvri+7W0faHGH++0kOdHWiEJ/78YX4zu8vx+KFE0iSBJzQyVkzhuCOZxA/XfVYXeW+hfUSnOLJ5GNjUUh4Ys06vGn/HfHTT70a6wZDhLnNX/Fxu70uqGYXUmpSw03puY8dAZgZjfJFkiEJcWowZ6KHP51/O9781VOxcE63nBur2usFHcUwJafKfJiMuGXkD2XlEKSp5NcdKg4BnSDAyqkB3vWaXfGdD++POEnLxCogZSZTtLrrij14EjbrR5XITxa1tUIPCmSp0+kgSRK8773vxbE//zn6ExMYD0f5sH5dUkIIogBJnGDnnXfBBRdcgIULF2Dd9Dp0O90qEFkcar7kyTG4rQ7boDSzlMUkR9Ntj6oUo9EYRIRer4dvffub+PSnPoMoimBMioDRLoKwAwODfr+PP/7xjzjggAMwMxggCLJObiGBDqYqyutXCFpfncIcD3xU0+mSaBGni2I2BVNTNw3tBvNlsh2oubpu3owaGpJj6SDvjbDOIEUmGnVUJFl8KAIqTsHOi1K1u+KKwUCbt/Lce98spkOv1MSEJDKuoKzaIeYDADSamaS+OZ1U2W1VOj88AdBEcYxnH9Tdu5L2xtU3FdqrM5dUzg0LP1tj+7PCEOI4ixndbhd/P/vvOPLwI7Fuaiq7t3yu0LNler0ekiTB4g0W4y9/ORl77rUHRsMhQAHCkM24iYu2JcddqqHc/1pC4SskqQGxbixUgqB6X/m8SlCEefgGgTgvq3EIbzLpKWLafBUdUfm+RZL8sY9/DD/8wQ/R7/eQxuOKFpoDuFGnizhJsOHiDXH++edj2+22rQpCBSDTANrAI2qk0hiL+Omx3vF1FOs6/9pryJjtMwS34gD0eVCtw6FSzrU1Jqn2/PeCwGIFQAH0vLPKsNV/jVU3+WfpoXUAOcXQ0/3kID989Gypki3WhfqsNAAfioJvMVoEO3/iOgrXXnstjj32WFx00YVYu3YtNli0Afbcc0+8813vwq677opxPM6skUprFunx7QEMPeCrdoZ4lXTFWpdsobIX7yngrUdhSGh4QPUlVYFnj1+z1wta6zDPFrwVc/neZ2ytpZSp/JMHJGCxLs3268MrpvCy9x+HJ9cNEUXErJhyAUaynyJx/RNDQnXU2CKczHqr+BtHZJrtvyAIMByNsXSDCZzznTdi0dwe4iTNriMFwjDAnDnMVYKBo+VrKFwT5TAp2p8Ggcm4/ydfchdMSgioAimJCopULp1asBdK5SJTEYqoGnYsEGROpSnjQNFqz/rweVJjex8RgHEcY4P5Xbz9lTshSVMkaZrZKgZk+a1J7zivQIn00gkCJ2Fi3palwwSX+DYssJiKeo0wDBEEIaYHA8RxjG8f/R287KUvy+bwAtROlROAIAxKcZj99nsJFi5cgCRO0O/1EUVRWVQFme9Edl1pteAsCWAWIInsfgB3USm83YpitnotAiFAr9tFGIZI0xSHHvpaLF68AeI4RhhG1WIPIqQmxXg8xg++9wMccMABGAwGCKMIYX7dpadLJbRais/w+2o8c1CSQiIlqb2+c7lIAk9EgjzxoRoxEulbpCl9ptw7DH7fOq8gQiFS4FHvcnx48sORamZe+PpNufecuA8o1n5u2ZKaVBxCgAlsjyyJ+Pm8k4r3pNzeIc3nikoPPfaHmLQ/yQNHKaAkYiiTTcd3q9gHQVD5skHMYhUJh5i3ddaVnG/U/NGElxfB7xFJwmewvM8FJVskwj4qGWkJtKTjFHuby3CX3n86dUfOXZZWGaU/E5VFRBDkvrdBVghGnQgzM0O8fP+X453vfAfGcYyo0wFAuXiWPxZmwjExPvGJj2PPvfbA2rVrARA6nSgTuSrpFHy2R9m3NUlGWfxwTzABTliAhuLdaXkGwiME5es8MdXNYl7QYvvL/VX4AwZkJaLECjgrPimFl9wf/DMXxdhoPMZ4PEYcZwJma9euRRiG+OQnPo5NNt0YMzNDxCkwTg3iJEPVx0l2LvNMQH5mMpSzhLLPGeQ+qiSoohpwxj9H8XsBvzdsv3AgiDyxXdtL6t6V+QIz5y5iVpB3yeSslOpdKf1KxfrxFgWFR2m+Xi0LBzZ/DQHAGTanXMx8Un69AVv/hS9qVlAEIAQlpaw4pyuRKOPEs2K9+aw5DD/fi7MAtpehBOUs/1MWq6X1RHmOc9Vv9rmNjM0lda9CwNMkRZIk6HQ6+P73f4CXvOQl+MlPfoJbbrkVy5Y9iBtuvBE/+elPsd9+++GYY36MKOpgNBplRSRYHkDGy9oh3glWbCv4OVKAHlzgqZzNZeuX/14508uK81Sx3+CPp/CiLmfBPGcfKboIRgCVqmWJYhkGTwEMT8wuz0IuVFTmqVVRXeSv8hzmu6ukyhfqoFosNAaDUYwtNpqPtx28E6YGo1ylvtg8rJ4yMq9m8i6lNZ1dcxEbvoBQ0c5oqATKPeSLGG/SFL1uhOWPr8Pl/3wI/W6YF64VO7ESd7SJGFXOm5J1qHiFRPIX6HQiPPj4Wlx244OY2w/LAM8UYBjFgiEhxcxEwaktOkDsbE2LuROIoV9it7D8PZPHomwzrJke4cA9t8NzttkIM6PYRrWl14ocHpdFRbFgNNRNHgKoLCeM6LqVdFfmA1hYGwRE6Hd7AAHz5s3Fl778JcyfPx8mNXmXL0BAQFj8CbKWcPb96voXLFxgG8azCykOVVPaDzKjeRmMZXHBcz1m6hpQgED0rOSmWbhgIZZutDT3oss8URJDiDoRxuMx3vGOd+Atbz0K69atQ6fTQSeKyhnVUok0TS1Dajfx0U2ZrUNbfK5UgABGHNyOWTx0c08e3AKBBmtm9U10CKMoglqBFvAXDOwQTfO501S+v0Abi6SlMMUNJG2GB93MdCwDFApICrYnGXGT6oDUZyKLj6DGhFgrotOy02DbH8gEq/zdInlmB6SkXKpKjMphUXbRi4RK65TJOVRG1fJRg2VXlnfrrTUsnkkqKCnF+uXJbXnwyaKwTiGRJ4kSTFEKCb9lRx77U2HMbapOPzc1T9MEaZrg4IMPxpzJScCkCMLAT5cv5g3jGEs2XIJXH3wIjMlYB0EUOmBAZf+gEXP07pKT1NYVjvxZ8/XClBQ5BdCIWXWLKihmy7h/puF7PqCKgioAphTswJc2OEHgVSnUWAoO4JW/fyeKcmAzQBRF6PV6GI1G2HDDJdhhhx0t317ppVo4IpHSZSzN7StHebdTJTpclgE7XDPsqpixgSuSdHRRqPECj4NRGujnJPLMvF6eJT6/SKPR6jXavdahZMqd8nqtzhgU0Ti25zkbw1jAmr1vs8LQWPp+Rb7hPY+1jg3s+UoowBxEvDaa+J94HfLMh2s+ho4QDXtRkwt2jOMxBoMBut0ufv3r3+AjH/kwpqen0et2stwsCNDJ98GaNWvwoQ99EH895VRMTEyUXUUQY2qRpyvK150HnLHmTz0Mh6Kg53RnreOuzfWLarACo8Xads5OUVSDgSOmQYxJBRqVtV4C1DX5g2T5QNjDOACOvM+se2ZM1l4rgHD+GaIwEwZ660G7YOtNF2KYa61wVf1CnMgIGnxpq2eKgrFiO7KLKkcKDRcpY04LJrevK30wiRAnKc65+oFSo6vKQ2vcJIqz1b6A+gPPGIOoE+HKW5bj0RVT6HSDaqDPKHMMZSuSrO6gHaa4OS77nmXsKPypCtP2/AMnqcHcOV2849XPBxEQhSHCILBmFJtQYNQlTpwyKhQhOTJrRGQ3IqpXd6BCW8MgxPT0NPbaay8cfvjhSNMU3U4nM8MkKXXPCuz8GlY9uSoPEmlJ8zTc1sFRYyRd6VEmhEYO2xD06OuSyMIwzFH+YuFmrzkzM4Ott9oa//7Ffy+N5a3C2tqUtvSsYbxujvSRUqRJfxvDEmep6OnQX3liVtPdspYL6yh5qTYeKiN56K8aLVMtJh16stHpGzLxEIWA09VkhQoHSomgXq+V9EOFGVVbDu3+a59TK/yMUFd0QAKWCGrXRD6fQi1eKsh2KjzJtOciE3/ts5A8wBqsU0jsV+cP9NlOjRJmUKNgKgtSTrOXNGUrqQjEeSLUVg1ZHzEIAsRxjG233Q5Lly7FaDi2jqSA/QnzrlHBPNhhhx2w5ZZbVh1IK9kWXXm57xvsPFrJqwvLEO1ZaPeWtDUtE3++B+V6Mu7sFMk1KqlpDCxyPit0JUjHCsbTSSz8LCcn52CrLbdSz1buAElBkNkvNZzLEmg1QlxEFtlynxoBlJSxjcgVKVGKZMOKcaMVL9DjoWMaDqgsDzSADXVnggZuagUmKevHNNGY5TrJ96xJK7GgCnDU17eXNloHrNScu5blhhyP4HGZA3c13W/ffSblwogI/Yk+7rvvPnzlK19BEIbodbtIcxGsgAAyCUw8xuTEBIwx+MY3voE1q9dkbIY4dnUmfLm5z/NU5i5sXcr1qgm7+XwwvSMWBStAAXR95YLGKlBFq3w0YIUd4TCmOOAmGBsaayUVe8PIfSD3kCkompWES+kXXrxvQOhGIdLUYNMN5+HI/Z+N6ZkYFAZOt9HRFJHqnmXsr3gTfE6yZMnxbh4TfiHetEuBXjfCVbc+gkeenEYnCiympbqwmLhkUBgg8gBsn+HVzUzz4fALrn0AaZqAa4uUFbSpeLh24kc26lJ+GK55qg9VWop3GbSY/QEhCAhT00O89PnbYLdnbIIkTtCJMhPishz1eLW18dXyJQ4po++YvO1LcrcYCA+q6oMUCsUF4hMEAd7y1rdgcs4kBsMhYpN11RJTtLoz2k2cZAEvG2AFbrj+Bkyvm84pVnlyGpCTEFkJAduIQUElE/Q1y4S+buMLnxqiAGvXrsWKx1aUHzmKQkRhZk3y1re+FVtsuQXiOGbKckyBz+o0MUjZeOSwWfdHO2xJQbfKAMVlt0U3DrILqNAvtQO23YRgPUqWpqkXxKGaACwprypNUztoJCbEkFlbZbKhRVKoUxpxGGvJsQAjNBS3dg+KuZASEVUSCPK9pkjO6wbZJQINjYpaV3iZtitDEZWpE0mQnV/YczIq1UabYSz+FHHNQ2lUE1g5U8bWr6ldddU7pKnB/AXzsdHGG2WKy6i88DhQlebqNWGYvd+mm26Gfr9fzrbZM0bWA7YpZoooiFeyn9G61ETIRwcVinikFKONAkGioKF8jxUm2IWaIcGmt8H440fgKWydjpIvQzbVtVid23wNdLtdp3tXrSNj0ZSalBEl/dYnzuRQr7W1K49npdtEDV1TH1hnxH71mrMrhXlaU4z4kvWSJshmnQOtU+Y5O4xidaTShGHnd8X/ZDdFs0tQC0sJYjaI4UAwdsBorVaRqIAjTbOx3hjNaHiFnkKAjJVw7rnn4N5770EURhiOR2U3PsnFRtI0y896vR6uu+5a/OMf/0C/37f2r7M/TdXgkF1gCVZYeSTvBCudPfn5C9qyxtwxGovIE+usuXfPc9a6b9Zn0tgBstOp/YwHSFYFnnjMk2wXQbXmliF2SlNQsat8HWVOiHI87XUv3hEbbTAX44KdSFIQkCm2mnyakPkfOugseRItIXQE0VQ0AHrdDpY9vhY33/M4ep0Qpi4rDRjLCECQzWGkSOIk+5Ok2Z+4MPYNEUYRQAG6UYiVa2dwze3L0e0GFS2Ltzu1RKWkTCrqPYYVbsUDEB3GLAcQ/oNUqWh2ohBHHbgziIBRkhGqAuEV40X+WyRr5EN7hUqRO5HrAZRZQChEFZIkwQt2ewGe//znI8mVOcFaz9bMF+OG33LbLbj7nnsRhiGSJBFeUu7GdhIWlpQY01zSGPG/yrOq6pbceustePTRR0GU+UJGUYQ0TbB40WK87rWvQ5qrzxFVA5NlcSnQToL7IRyvpppio60suJqqsoKRlGSklj4G3ZqibUFQe0h6aF1G4fb75hIdWghHzop9LYtwo3e7yJBsiaoFk/yMUpii+FltblNL3gNWlKdKh69twQffXKlIPnxJeptObt37m7oEXYk91CAOI2daVSpSXWyruT8SMPAhy1ZkFBmpPKCKUN3v97Ew905N0xRpro+SOp2h6v033HBxRktPYv+dNfWdW9++gyiiZLGhlbjG0xExIo5w6qKqYqwoWJf7vRiZgLGS9Eye2nirGk3x0gcY62U7A5OZYbe8b0WxTiIQlqRdY5CaFGmSiLOnHoStS+q9TI4GVWop2mLWA7xx6Pse/zPyMFl4HKzrPpJPGKe4h1wkT7Fp0Kx2invkzFVp1x9QLjoXKPue8tRNUVKUNh5N1h/K89Nm8KnuPFf0IZrOWd8hmaZpaQF2+RVXgCinuRe5cl4MJgYZkJ93KKcHA9xyyz+zZxyGduwj9x4Zn3quBKKMi/0Yzwx9HQyHJoaQHFtQQBZTl5fAntuTrJImkLyV4rMnD1I/u8aMsApV4+a5RXeNBXi5amZGCZ6x9WK8dLenYd1MXNJGeQtQOvUS+w6VM/dU0UdFzm+0Y63c53yvZ9op08Mxrrr9URAF+Sw+0wIo/jtNM/VophEQzAyGGAwGmB4MMD2YwQz7MxqOEEUhOp1ObnMQ4c4HV+L+R1ah2wlhiiERiJtF7lIh34OoMCdLpIXfCOKneJrPE5osIZwejLHzjptj3+dugdEorgpBwxMPRg/zeTfNRtFIfh4ApBzC2juV7V6q3rcQY+n1enjd6w8DAESdCFHhxee53n6/j8ceexSXXnpxVnzxgtDUbyCZxNgS8ailBkhRWJMPTBeb/uKLL8msSnJJeACIkwQHvvKVeOazn4XBYNh80NcU7XK2TpvtoIaOlC8o+eaG6tBs70EmvQhrAl0tfc3CTxRRoFkWnka8nmrwSookMaOGWcIzVkdEhLA6io4nMTAN81qyoDWoUbcTHWAV3dfuPU80odt3ON0fX/E2i0POyM5qi2doHfaFsIS2FiW90YPaO0JMsoiE7cvqUwosvy/aFKT0qEhJUrVmn/yvgpqeWompbghtMxnaWdLYaDE1nxM1aqPllctiz+cpJ+d5qzpM/1l5CCmzZEb5O9+icpRUZZFv6lM1U/fZWa9SA4o1xF/OY9cBXtYMdh0QJMV74GcU1e3XuvMSDcVmI7iozY55uiH8c/k6gk4xCXtMAl5asfRUy8+BwJ4f934uZe671X3wnSHq+ocjRtYCVRD3UGciAQYrn1xpnQu+1VF8dxwnbrwlOOu+nA5XLMK0GUsv2MHXomkHQvtity9P1jp33nstFLTrptO0sZA2ID41FJYWqO8Bknxdad/N4sBKQIQwIBy67w6Y6HWQGlS0UUP26Fvp5ED2hBxRadeXAX5MPFNER6sDqViHpMiIlNfevhyj1KDX76Hb6yEMo6y2m5nBYDCDwcyw+v+ZGcwMhwjSQgXOdZxCofhYDBUDwNW3LseaqRE6IcE6TohVwoIqWSGasBFN5TQiZnBcdgwDqmiZAZ8lA8ZJgtftuz3m9KJ8Lo3ApxWq5M1WWzPK4iHtcIA7sJ4qyXgxQGpLMLejLBRJdhzHOOTVr8bGm2yMJM46a7JDYc3WBBk/+LTTTsPMzExm82ChxqilMrrKSShVSTnZq+53i4tL4qwAHAwGuOCCC8qfMcZgOBwiijp485vfhDAM8pw1cPJn4xKMnUNRDuRLXrikWxqlSLQ6gD46cc0BpKrcKXSENrYVjUmLJ7lQaZgMBdKSyTaHQYmKwaYlFd3botB/4okn8Mgjj+TJeMrY0NzMFqWyn5Y0+ZBebRbKEQrihz7cIK36DrXp/Pu6eYKeI+lw3kKtpgslBTvqkh+NImsp8DHhGz4rlwq0XBMKASoBAmfWyLhxQKozq4qCWpeipGGZmnnb4t/9FQfVJusGfJaBREI7G4sFueacjlkNAOF01nyzYLy4gZCBV5LaNP/jvD+R895ytkZ2EgzzG3MshUQB5870NWebJAyQeYFZKoDXPWNFVdgIH0Gf6I9pMf9dKDI6nSi4iswyP9CEsFp1KWs6JFpX2XoZlruYBiEQ333QzlGHTt4k+sHu23333YfBYFCCwtJ2y3o+TKyvNTXXx3apK15nsbd9n9m6Zywb2Wbbp5fsJipSCMYgCArBpBzo33rrrbN9mySeOGGruoP8ALG3Mwo5RpnH5YC8bAYtRyJNbNETy/3FtOd6859LmT6BFxAo6IuewlMCW02CNdbYj/g5rtDKwWOutssXlnwuQUDo5AJoe++8OXbZZikGwyTzPicWA4vbRCJjTU2lLRLkTg2WcKZhRSMH1mCpH1n/aYBeFOLOh1bikSfXodeNQEGIMAwrrZGcpWFMCpNk3W6TpLCamz5BiNIM2xjccOfjlTG8cc2Ii+5g1Wk1uayIneJX5aQbGiiolHTK9FK4CRMRxnGCpRvMxcuenw2xh2HAxGR4UcToNRpNUKisatL8mkqR/EpzNSLvZrVsT5hfSf41mBlgq622wiEHvyYzdA8CdfMUhU8cxwiCAJdccgluu+22nKseVHpEPnEcH0pZgRo1C4LrCFUJYZzEiKII11x7DW688Ub0ej2EYVhSWXfddVfss88+MMag2+3am1Chg/AEyAl0DQGOBypCjdkpS56NQtEyyiwfGtBnPpMXeA5V+dnXp0vddHhaCltNtBk+L4nAQoA5IhXHMeI4xmAwwBFHHomfH/tzEBGGwyHinLKX0Tf1ZEVT+9USg6LbnAJOImMlc9L/T/HxW+97qgzXW/Oiheqppzj1FYXkUTeuXc/Sp1Ak+MYYpDUUHmdOUAEVjNb5ZOq1zrWVHn+2dyU/M4yKlACuxJ774evQdy35sc4XdvCaul+eZRIpz4zUFx+0xE9JbmSiYjgDwNNND4SqKJTurSI4Xb8fjDtHLAXJeHLseqr5Pn+RTHrERhoNGkW3U3SNtRmlolvMwdbWbANZGHIwqcHvTbuWunlTn8q5L15KW6FWnwWwLS08ZxVyRc/qHPDHsNSYrJMQhvj7WWfhVQcdhIcefAhEhNFolFs5KFZPYgbZ+GjSEsDTCm2mNMl9eKkuH6g7w+HOZhczZUSEgHmavvKVB6Hb6yIMA3Q7HURE6ARZhyjM09YwjDAcjbDtNttizz32wGg00uOUAKhUr0GFcaBFNnsJsRxb3B91htgSEvTMjyvAK6Q+gEdAxgeYe9VNuQ9sXdfYA4wb8Xs+lWjNDkyKQZmGRDNTvCbEcYL5c3p4+Z7bIElya52UW+dx4S4hNCVen4/Zlf58RujCKBuei850ohCPrpzGTfesQBgEeV1iBMAtGncAAsO9RRwREUIKIEmyIf7HVw9w/R2PZoOKZEo7A16aluaJlFe7xAtDVNYRpdKcAVdbtRUujTNFavLCMAwCDEYx9nj2Zth2s0UYjRPBjCLLGJ48qKERqL/l+aYZRbcMMupmNQKNZQ81U87LeOZveOOR6HQ6GM7M1Hap4jgGBYTVq1fj72f+Pf9+Vu3zX7CURRu6IqoKmvXZmAosO+jDMAQR4ZRTTsWaNWvK7mYUZWqAbzzyjZiYnMBwOMyLdmpVYJHW/WrTgVFm/oyHWoM6f8I2CGOLg1ntpNR0a73dq4bkRhO3UC0t2DWRRY80VoAqBIziOC5pzf/9X/+Nc885x/Z6s66lXpyFD6anCsJvXWOLuT+nc0az6wSpz8mzByx5cIF+osXckzbn6fhoaYbcQLNCoZzLLFBO6ekIZaZY+mBZXTtS96PvZ3yFR5Xg1s3hVY67XK3avwlkGsi8m2pEMoxPBEN0ZJrogz51yVqgoWF2MfXsG8oLS29iX8NAMDVK2oar23GugKp2aFSxsvqqy+hFco2IAtcktynfgSLY4D+Ha2cRBeWKmuK3XCuaxL1gchjJ7JDAbNHVrwOJZGFa91nkLJovTmqeceV7KIU2Owt6vR4efng5Pv6xj+Ph5Q/r3nI112hE/HQo99a1GNUKyXgE3tASAHIwKkvAxS4Ui5g6GAyw94v2xtve+lYM86KYghCpQSb+F4QIOl1MDwZIkwT/9m+fw6abbYokSfLujGENA1N63Tn4YyuQsEq8ieDQCgu7KOTvR2KUiMtQkVaIA7UG7VK922KpKJ1uo/gKO2cobDVhrYNtCcJAGftow8RQzlN/7k6tGF5J7rW6325bYemiPsZxajP4OX/XCME+cnUBSuYG6YtW2BcKowdCGACjUYwb7n4MANDJxccsEKC0xuEFLrgIibyojD4W5wput9y7Ag88ugadKITdCGOeQ5x9gMD+ULyvbknD23aMxMYujXYjimqWgJftujU6UZBztY3jRSQ7CGpyAEXGOU1LtbygLRcdDTWFVOliw5JBEKDb6SJNU+y1517YZ999kKYpoqjjRTk5ReP0M07H9PQAADniMpyLRR6EiZtTQm5gdkTbCHS1EXu9Hp5Y8QROP+10AFk3CQDG8Ribb74FDjn0YMRxzFQngTpOqxPgCpNcT7HTRoRELSLZc27bLSIPskuoVxyttTjxeC02HgxyDaNeGEGlV2lHJTs4Ctpvr9fDH//4J3zjm9/MAYzABh7EbDA8BunawVB7aCs8ee89gCKbP9s925AQqgmfTE5azgqqIEaDUJK8l97i2bOuzWzsT2oS77bCH9a6I1mIinuaarTfmgdBGhxBDgAzKy+suiTIA+D49pJDMxdAo2lBeStEk1KFDugtSOTzLd/HOP6cxsD/OT2AD7Wab22KX6Zxn7nzhZXYFYlOUVPSpsUVZwTBGHd55XO5JNdEXYdYi/NOl0fbAsYLEtZ9Th/7yauMrVBXK8VOcsTrEADj8bg81z/72c/itttuxYL5C214h89EeRgg1ASSSOuops/eOgGrX+ckAA+DqjFBAZUA6P/8zzfwpje9EdPT0xiOx4hzYDNJEoxHI0xOTuLoo4/GW956FIYzQ3S7XQaeOhk2a8aIbNoDaFVkucrv2wbZTFlolM8SsME4skcByv3ALbTqimnhy+mzMPOxgLRRBEARO1NsJYwC/rrz53ozx3dm+ei5dblUFVeyGmc8TvCspy3FTtsuwcxoXLovVYQV3drGjs0C5jQNa7dYDI5YZFZ/3Xz3CqQG6ESh21EsPUurIjvgNH9JsaxasNm/33zPCkzNjCvNAk3e2mi7NC/wUiES42CPdu+Tc7OJrQQiII5TbLx4Pl74nC1KX5AMPSSXXiEQNjSoEAVCnnw2VgLyZhgjDwXbY48XiEEQYDQaodPp4C1HvSXnoQeIotA2QGdISkCEXq+Ha66+Btdccw2iKKoKL9j+cER8sQmKROBBwkVnUCLEaZpiPB6DiHDJJRfj9ttvK33FkiRBPI7xylceiK222gqj0agKjIUYjUnh7Rl4RBncBMr2NSspfY78fdWN5RYLdUPajmGtbz1wGp6vY6itP8VbazaFC1evc5L6mqLS21HIQ5hlkgqDOXPm4IYbb8KHPvQhJEns9xwsUFUKcvPslh2TFoCL8SQPjQf+LFQD6++Ni/bXFQq+ArGtmEnbwsWwBNWiOWtFl+d+qJQ0pQCtK4Dr5iVJKYR4gViB2sY9D1p2oNVkWOseN3Ts1HvvmfVUO3mKp91sgQmfcrAKJNR9DhKfxSiJNrgqrR9IqcZL2gIBFUAs92JlxUZOrmAxdthKkNflBc9antnlHI3S9XNsuIwikiU7JG0KFMk2KNSS6+Ygwe0smlUz61govjPWlt1X/FLzHHBiYgLfPvpoHHfcb9DpdjGOx7pNUimMBZeaLmx8jOhqWjTHBjVKlUVXYz9g7xVjg+S5joK01DIGCBCg0+kgTVPMmzcPv/jlr/CrX/8arzjwQGy55ZbYeOONseOOO+JNb3oTTj/9dHzsYx/LOoNRWPmjEpUKlMR3mpwfVs4Fb8HPcmVrNRLl9hn2fXEtDmzvO0CnS5JU2+ZjFMU9bQMAkFtMNeV9darO8LCqfOdxm3NXCuU1n8cmm4cmoN+N8MKdt0KaGuUUM/Xhmo/bQUxWaLMAZVGU5rGhYh8aA3SiAPctX4XHV06V849ut4KsIjsyvBNALnZVIESpMbjurhVZN4uAxEmUq2FxQ3bRVwQGaYBbNA1NsRFN9bv2ADdPVbOCbTAeYe/ttsDTN1uEJEkRhdybJgCCQqKbHehBoBeKReCRXilsBqvtAeNd2AbMc0LLtaqfHQ1H2P+A/bHddtvh7rvvRrfTwdjEXmXBTqeDqakp/PWvp2LvvV9kqX2RpbTnFhOqiqeTUOoy1IXISHEgnH7G30paYRzHGMdjhGGINxz5BgAoZwplomg8PHnyGZNCmu3aPxeUaxn2s9a6Nwp1RjON9t2Xan1Tc9LX0G0hcVj6PrtTIDGPtALQqE1MrMOAagoVYDgzg16vi5UrV+L973sfHnv0EfT6vZJCajUVrQH84vWMtcaoxqwbdT/n+/k0ddap85waOpCm5TMs110L24fiMzjJu6IgWlcgWnMzYr0a1MGIBIdyX9cF07pcDYVrkSRo10u5lH1JLQ+4/UQOtOViWpw5YTEbfJccGG+2IJVEiz2SFveZr5cmQEHSqLQ5Gvnzcu7Hk9Roqp/OmjBG3ffksD0825tvE2sGL7CKrPLQhtHR+iKZ1ITUGoVlfPGMKxHDAkjl3LfFWqmdazdehU3f6IWMV84su+dDGvhnpJqKQvVnlGdqJc1UH7+0bj88Z7tp8fCye5FdZRzHGA6HmDNnDs78+9/xxS9+EZ1OB+PRKBNL8RRtFWhYpZxB0/2RYFvxzKU3q9Zv056ZxuIRD9GUmIix1wux86ywOOt0kCQJojDEW9/yFhx5xBF45JHlGI9jzJ07FxtvvDEAlDRRa2zJwueMuy8kE0bmK+r6V4SPFNqm1iXmRUGFSRh1gzfRccu908i6aA92O/m49hLaeIe219sCJBY4YizVVwmEFWKbhUhiQfbf89mbY95kH0mSZiUH2wKmGKXLVwAj/pYlQjW+QZIYUfwU+4YNrhB7rSgMsHzFWjz0+BQ22mCuo2ViCljCVGs8KFRsDFV8Y4guVq8TYOWaAe544Al0IqZK5PaRs9lCU7SrBR2JAZS8fjZMpSZgoKFREuACg0gNYc9nbYFuJwRACIvDzvUrqJJlidJz0Y2WlFBqoGzY4iT2tZANbTDVPbJoMHESY5ONN8GrDz44n99KXO8uhtyNx2MQCKeecipWr16Dif5EJXpAOrLueqPWyJ7XfGW01gjLH3kE519wXjkL2el0YIzBLrvsghe+6IVI0xSdTsfyMPJ1//hcm18Bra4zZCyOvKlJ/MhjuSDZrNYhVFwfW1tUc59UTUVBEdXQLb4XqSaplLMldc+WrK6MbR5re9VkPmGZKFCKD3zwg7jssksxOWdOOTSt3suinU/tgr9pMDn3egga42ZlGrXKkmpXugzFewo7D83SBPBbh7T1tNOoT5kYlamla8K4ysyagBCIHwnw+MZQ7fU0IqaSXl+jkMqV86r3IhvEIPLQxlv1AZ3vkQMY1Xz2hs6pe49a0kwFY4A8BWJ5zzTRGTYvSOJ7dVRr3UqCnKKrGm+po+LlzBC16+RjCdSpbLJllCqdA5agkuxecRVCfkbwDnbTvmxY506s8QFWmupx3f4XQE4qZwp5B8cYe9aL/HNyTarGUlm07OKIWVTHh439d5IkmDNnEjfffDPe9a53Ix6N0Ol2WLwO4Ussqu5tfWeefEURB5BaAK1aQ0Xrstldczemlv7PVhc6y7eK8ylOYnQ6HWy11dbYdtttsfHGG5dzlmEQ2uqzMM1zy+TS3dOabpV33zO6riqIqP5WvYYEGpTVjewYsiLGuEmeUsrW5IKikPedzVA+r7Mm2gD3phK9zButNg2ayFnGQVkUGjz76UuxzRaLMRwnrI6q984E7CYaoW4+3diddGuIq7rHAQHrBjHuenhNmYcacU4aQxabLAjKtjK3a6j+kYzHCAODZY+uxrJHV6PTiRy1QFslh01/Gdgf1riAtMQkXVUf95EnSYoFkx3s/sxNq/M6sMxd7Nc1Csrgof7wBZMyJUNeALWlGBmxgvmQPFnfqxSowjAshVhe//rXYe7cOYiTOEeb3IPAmFxtNAxwxx134Jyzz8mKSkYbVe8J/BLqRvlTR13rdru48sorcM/d96DX7QLI/cEMcNSb34JOp4PBYJB1rwIWJFPTehBd2bHimoxTFNZZZswmkbeomdq1aTYHsIEPZ50Udg6WoAhcM3gY1ehSqgo6n8k3J+gRpLCHuLMZ0NFohG63iy984Uv4/e9+lz/HmbIgLNapBfrwgxRCUdQztK0lCpJq6/hrEvFA5U9KObUo9ayJNHXuj5xxMA3XXSQJzWa65MS3INN2de1blcPAYn2UVHBSi8TZiC3UealJ8254JLx9wjIE5KwWY6kZ0yxEk2aDMqcwljCLQ/2EK+ZhIfCi023fV+NNOLT9aBSDcBLm0ZzW79DExPozuQIvn5Ntw04IBAUytVx6DYS8q7iGSrFT0qE9oqVqimbPA2oFiF1o2iAro9tzQQTPGUwNhTiU5MoqGgwcpW3fvoCILQb1tDP4zpMS9CFrjAd1hZAtUuDsy0B0tUt15DrfW1YUzczMoNvt4rHHVuBtb3s7Hlz2AIIwxHBmqN5V2ekPLE9b446H8HPHpxTK/WhgnJySrA5+IQ5YFyaYIIXlcQb/zICxW6xElBV9IKRJsSfTyqsXsxedK2KTafvzzrlCTuywADILvBMFlamZ+fecEz7Vd37xpCdTVYPHcEVNz1iFgWufA78VUOA504r4aWrGfiQ+aZRYpAGgRSwcjhIsmNvD83bYBOPYsFjPmwyuc0I5jGVYHVRub2PX0qb69+LatFZPEBBGcYxb732c/Y0410w1bwpk3JH8nY09S5h/8CQ/NO98YCVWrxshCEmOfniXZSmDWvbmuZqRndcZYyvMka+pQ4RREmOLjedjm80WIknSUmDGQYHKAwSqf4mawJmGA79uUNaT2Ojml1VQy6iy2U0tlDmTJMGuz9sV++7z4sqqQemuFf4/RRA66aSTsgM/SZAW4jJGFzCoM713P7odCIqkpJMbQ59xekYXNQDSJMXMYICNlm6E1x/2ukwNlRSUmfzJoLV4HREG7fO4FNnajofRk/e0riuqzC1otIQ28zXObWADnnKe00qKaop2p/utgBxeRU9l5m1ychLf/8EP8a1vfgO9Xi/fwkn5WoWoDDF+OtUoYvoONyMSA28hD7cjaAc3Yp1hfTahTmpeJlptLQuaOoZy+N6W7jc2wEZC8MICDbRrMfoh7Zs5UT6zpNQ1eo96vmfq6Hy8A+Tbf9SuJLRpocr3CjkzeSbws8fpZMpn7wKBcm6W2zBIRNwoh4IRBZaVRJf0I1tsTO4bEp1sPtdch34bGEGjJxVnU4WwMLsZHKS6Nyv5GjpGt4xRO9uKp5hcPs65UNsBJy8wKOOo5nvrP0zb+cDKoraAhrQn6dhUO6+vKOnWdcgbnmfB/hkMpvHu97wH11xzNSYmJpCm1ZhIyUTy0VV9K4EztCDm852ZUKsyUHWFq/sp8UCytRvY08vWCXkQP6E4aq0D4/4cFZ105+Lk4ewFw1TglqiBfkxiLMijjyF+J2PxUdU1Urr4TR69nNZun3dkzWHWV7LEqlMdqJejBOSJK00YIlc7dbQh2LmaKnmlabCdKdZTnIPluz9zE0RB6I6G8asn/hmlkTssWz6Og1f3oCoiDNnt2BLEI+De5SuzvNZqCvHaqAKjol6/ZyNlRSWbQepZbKcQ9zy0GqNxjIleB0muXkRGdLyERI7RlgPp3h5kVa9Md7SMfdkBFhBhHKd4zjYbY+miORiOxuh0Iti8Wj4TSVaxCAWNcpPTnOsrHqPRqDDGuEm3p/tWzSgY8NnN4oEUCy1NUwxnZjA5Zw4OO+JwnHnWmdlnD8OyQLetAg0CyoaeL7jgPNx9193YauutMB6Ps04dQZdwFya/TofJQkArBJKIkOSHQqfTweOPP46/nfm3kl5SiMocfPCrsdlmm2FmZgZRFFnIo6SzlAxp32wltZjuKi+bnFkiDeYjuEPWjieRIiVe7RN3XolqVkw1pO6zyhD7RPqN8QBLbgFQrCUfvVSjNhUHe/EcxuMxRqMR5syZg98efzw+8+lPIQypBBcyy5Agf/5GdKvtYkRPDsihCpDn4BMTga6EuyxkSHo92fGA31MLNRQHG/lUOIsZZJaAawemrXBKFvpM4HMZRgxzkAMu6JCJqVEbBDwkZQ3ort9bnllHbi4NZdZL3h/LWJztNW/wRUN3pAlvEeqk5CgqkkNV4fZJ5IW3m+ZbFSCR4AUDq+6d7R2rJXQVbcqoTAE7btuoul3AFoWDe78LIFAmYzX0DbXmMdDimwH3PA4CKjuO5bWT0hng64VgFd8ExebBGEsQpEiCeFFr7S8Ptb1MsDjQJ3zrtL1qKeO2c0iv3eZW3lLuoXzuh/RkU3Y7vSAdoJ7FxqQYDsfodiOkKfCpT30Gp5z8F/T7vWxuMGXz0abyfSRPLMz+vZ5BIddBbfFu7XNTFsKyY+X7HvdQBvxdKSNiURnbuT6DNW6WofuGrU0KGGOMW6QqYxWkgMsyTvH7LllfPAdoaCeW6uHO9nZm5Mib8/rODuOZXa8tqEzDmpDoIgkpBEXbmHiuQFR2rLkgogWiSXo+dPqpfgZQ2dAxBthlu42wcH4f0zNDhCEJGrgA4Azr7pMddohY1mRYFCXWUQLZmi0lLkeIohB3L3sCjz8xhYXz++j3+wiJ1SDGQuUQRGGIKMznvqIIUSdCpxOi04lAYYgwyqrcux9ehULNpqhEDENI5PGU0eJQehAZ1oEkA0EHtQUdKh411ASCiPDsbTZCGFCO8BjYvFp+qPqlxy0015K4tZFs70h8CxU+HYEjpxvrWBgEAcbjMQ488BXY6Tk7YWZmxjsPQQBSk6DT6WD5I4/g9NNPLwswfngGcvbO1wkBypkWLhLGbQiNMRiNRgCAs846Cw8uW4Zer5sVi3HmVXTUUW/JO0lhqS7KPwOn2VV0KdZYJ72z6crJM+SdhHIh5M8pNC4I70qCd7aK+LHE14zTZTGeAse/NsrOJap5MVdyWp9HCAqNY3hU14h1zxTksxAIMiZTFD3pTyfh/e97H8ZxjKgTIgpShIEBWPI6Ho8Z2GSstexXxnTl9+UJRjzQa/QMQV1zASdjJdhOIW7sbg733pPJk0s3lJ0u+6lWBXbgxh+m5ibnjdsM4xuTkSHrOtBBwNUZ7fhmpHBMXQfRar9VVgVQBvwdyrHH88/UFE46I2Q2M3LsdQTCy8daK5RVdNGL7jIVs+5KIqmsC82Xz3fe+L64OFNlp4D8T+DEB6tIkfecMrVtdSbR6jC6Ny81qbdTJun52fVkNLmyW5QaFaQKCAiJKkFnU3Wzss6lfu/KywtgzdkbI6iHVN95kXNZVgfTeIo0o3QmkZt6MyNvsnyMa9AKa5bZf67w2G7de8Z88CX9xe/y50isOyaLBzlPl+Z05HicIAwDjMcxPvzhj+CYY36Efr8PkyYgpLlrGBOiyGOyzIlMjdy/xZIgMZpS9fjrO0yerqTve/B06H33w2ZouPOYRsR21D0fLpxEVU4mrU8shk9xbkvgRHQmqVQwDfQZ85rPmsWaen0F63WKM8Bi4XlG1UH2uJaihG7SanTIKCI1mqI8mHc6905WvU65Tgg7pygvDm0fRLFHvTkgqTE+yDtycZJgq43mYeuN5mI0ThDw+W3DCjGyu8Y2H9RtnpUxRlDpqAC+Sg/1KkcNA8JjqwZ4bOUUyKToRGE5ltbpdNDpdBB1IkTd7N8Dp7vNCqkkySroqekR7nzwSURhUH0OkiIp4rhW5PTJwXiqxWSjc/ZP8/2VpgYT/Q6etfViFqvJmddzfO5QPwcnKVbVomhO5n0BsB7nEtR18f5RLsqydMlSvP71ry+7MRmq6t72NM0SegD485//XHL/0zRlZqg1nPE6lVG4HSy+wU76858BAN1uD91uF3ESY4/d98ALdt8do9GoFJrR/BSbZIGbzEL5/SsOtEL51FK9JCh3HZ6EnBSugXFmekq6r0SnBc2qpNU0rDsLXctfN0nT7E+SZH/yf5dqjBaSL/6VtO4J7OQtSZJyzZx88ql4xzvfgZnBAFEQIB6PkeZ5VHGPASBN4kbUt+75QhAm3MdCjtx+NTtFegKeCLDAmVmBT+avmsdq43soRBos9NIDCPgS1aIoSFN9DfNlmyXYtslsE2XI6h5Z95x08SatS1jMbanJsz5LUj73oFla3BEkaEkH4olYuZIsWmVaSXjnXV4DzT+QzXAYftj696sEt7R1XopDFM80qZ4t30uy62/yi+aiCr56w+RiFxllv6LDEWxRHxIdMEN+I/SyOIhjJHGMJInLuGPgekQaY1BM4qapZzzCDliWnxgHtixgzrv9bKDHKMiAI24Equ1E1HU9dN9RcuZ5q+E1vbNiWKHM7ZxkVJCASpoX3kWxx+dI3S6wUE5F5alnAWVKQTEej8vOyUc+8jH8+MfHIIoiDIdDxHGSA7xRCTiHQYCgAHs9OZZW5PNrghE+vMW+Fp6GDrsFxqKuau8pi5DiDE2TxPu7vljtK1JUUNLILkxBBTclA80+p2xbJWJ5th9jMO79ZeulyBmMZ63IfMMHjlivzYqsfMOy/Jys/xmY2tyuWM9FflrXyZagh9qgaYgXKpDJ1i1vdMkxA4cy7BmpCgJCaoC5k108++kbYlwIyxTRWFhL8KLarZO4fUhgN2VY7cPnEAmGrb2M0bV63QgPPzGFiFDOzRsB4heFeWQnyrB+OM3Vc1avG+KxVeuy1qcVDOstbPnMjGHZmLHkj2xeiEUFs6inufljkmDDRXPxtE0XZsEpCCwVLrUHL0EaY2oNXtXFZNoVhU0IFawFaLwqYVEYIs0D0CGHHILvfe/7ePzxx9DpdHLBGNtjj/sBXnX1VbjqH1dj731ehJmZmVzd00ZKUHMIVveIo1mweLTGGPT7fdx/3/246MIL0cnnHovPfeThR6DX62Jqagr9ft+l38Evk+3mo24gLg7EIAgs6pGKwCdZ0CEKMpTauGe2D4kq0WtjJxdWoWEc7lY5S1l0SGWRq8mq80OLiLL5zAaANB6PsyQqIAcI4b5hknLBE8XCQmLOnDn4/e9PwDvf+U5MT69DL/eZqgxLA4vWnKYo/SYlmu3QMwmWGp2ktxgGnRqJBir7I0mT8t5qQIO8n2larBWyaaQQwj/FujeewojtlRSux5JD4fNQakxqC3XwNSLfN2GFYRAGpZUDv882eML6AV56D1nmxlq97E2OWyTPlnqzL9GQlwfy9ZP9sUr6uXqVLxmdmrhAt7tWeae+AGaKOW2N6eCL/UURyH+vrkuYJqm1lg1xYfIqEBPvUBWJl72R8t+3pdONlWTqIF+hkNjqevN7EgQBkiRDozV6VZqyEZAwLbuRGQ29ivGc0ZJY4m2kpSmKt2cxdmCy6yc//U/OLaYmrXieBg4lXyqqEmmMqMCOKHJMQ1KJ+RuR/YB40VcX44wx2X1ksYTHt+I5FQIzRmFb8bXazUXhPvShD+KnP/1xCSobY5AYICUgQFIKdxSG7EmSIIljxOw6NRA08wAmhZNXn4uV+VJ+X8IgRMi655oHI7fGKgpYeR8LkEPb1z5A2jCKHz/Pi3sdRZHNftICmXEBNzCbNM5KSZFaSsDS2qeY4QyCEEFYnwsVYoNNOVN5/wRFVHJ6bEkQ482ZC8XUTDjR/97F89CeVbGm+N8Zbda0BqD0kgIyWpy3+q4KYlPNeBPvGGZ/yympz9x6Sc6PzwA7yhNqr3tIyXYkyR/OgE6mx8L3uXtuV9oEQRBgajDGQyumEIRArJQ/JbhGBhFRrRwTiIDHVk5j7dQwo2imKVT5lGIwMReEMR71McrhkSoXIdc0naoAXNqhU4YejuMUW208D5ttOCdP8kj32hOqHcY3d1HTlfIaNLssAKfV3Zg/GeMmvca9uJmZGeyw4454+cv3x3HH/bYsCH0LttvtYnp6GqeccjL23udFpR9OsYHqBCCcvzM2fbeopIp7FIYhzvjb3/DEE09gYmICcZxgPB5hs003w4GvOigL3GGoFj1NhSADVas/uZJX1OlYCcv09Do8/vgKrF61GnESAwbo9rpYvHhDbLjh4rwVHpQBJ0nTDNnMv5citQxpZXtN+nCpohBpxUuHATrd6hqXP7wct99+G56z005YvHhxmSTK2dI4ztRki0P58ccew9333INHHnkEK1euRJpmtOANFm2ALbbcEjvssENZbI/HI4RhpA+/G7iJE3tPAOj1evjpT3+Kj370oxiPY0RhhGFOCQaAxGR3iogQ5WIyc+bOQRRFmDdvXiuQJOsoUgmIqIksSYEJN2mJmBIvAKxcuRKPPfoo1k5NlUlIv9/HhhtuiA033LC8nzIBkAVnNVtgyoSPzxmSZHqgjc2fsa7fmBRR1AFYvr1uagqPPvooVq1aiThJMmnzMMSGizfEkqVLMHfuXOfQlECDTEDTVmCLO+jUbuzJnZuW9EWJMGvXYnuViYVadybVWrz4GA/2k5MzazL2lcAMgE63W97rO26/A3GS4JnPfIYFShljrGRRJoYPP/ww7r33Xjz22GOYnp6GgcFEfwJLly7F05/+dGy22WZ5YZUiSbL9V5X19vRgBgaKWEVQlVF9z5zYGZvtGSqp/cYYPPTQQ1j+8MNYtWpVxdwMAixZsiG22GJLLFq0qPxs4/G4vA/88ReFayopXDkiXSZ/IvHLYkyIp/qVpIklxGYU38NiDYbBU38/u0NnlA6pUTVG+HKlfH9LkOixxx7DihWPY3p6ACJCr9/DkiVLsWTDDRGyWGgzOBJLtTyL9QQit3M2Ho/z3GGAD37wQ/jVr36BXq9Xdgz5tkqStGoapCnmzp2LMAydc8AHKqRJYp2nBHK6l1qHXTKN/vnPf2LFihXYe++9y58rzlVjDOJxXIr0xXGM2269Dffdfx8GMwP0e31ss802eOYzn1nGVL6PG4tT2II6Qb53iv1z0403YeGihdhss81L9dEi6ea+b+D5KzmDcVZ30o5PQJKrz/OzcO3atXjssUexatWqcqSj2+1mZ+GSpZicmGDnSJzbcwdV8WUaclw285/Zv5CqYC8L1iiKShBhZmaIRx95BE+sfAJJnCAKIyzaYCE23niTMp/hZx0/P4vPyrUPJPBcd4alvOEETvMm1/JJ8bXMckb7540yhw0AO2y1GGEUotg+pfugEcJIxPkGArCBplQvKkGwMQhBOSUYJKnBwyvWVvPl4GeALWQTpalRKSVVMhNg2aOrMDWYQa/XEVU4iXtX8Fc1MQluxmhbKBrRQbQ4yWSDSHGSYptNFqHfjRDnxo/ZAWwcSW9fomOseUV7H1SD9Wj0JzQtO4wuugT/ULux+flJkmAiDHHkkUfixD/8oZrb8nwVQfNvZ56JT37yk1i0eAOdrkisU8aXmYE68Mt59AVKkyQJ/vznk8oNWlhKHHzwwdhqqy0xHo+r7qSSIJsGs9Ci9V0kXlkwCLFmzRpcftnluObaa/CPf1yJe+6+F0+ufBJr1qwtu6edThcbbLABFm2wCDvuuAP23GMPvOhFL8JOO++CbqeTddfiMcIwsubvtGKqTly5ooNmA7zFIfjI8kdwySUX4/S//Q0XXXgR7rnnbvzlz3/Baw59DWZmZjA5OWmhdkGQiQLNzMzgzDPPxB/+8Adc+Y8rseyBZeoznzdvHrbZZhu86lUH4a1vfRu23XbbvGCKbV+oGprJaDRCv9/HqlWr8LnPfR4//elPEAaEMACSOK39vETABRecj7nz5mCcH7y291FVzCVJgo2WboRDDjm4RLLB/l9FaYgXggZpmqG8YRhi7dop/OMfV+KCCy7ApZdeiocffhhPPvkkptauLZVue70eFi1ahCVLl+A5z3k29n7RPthnn72x7bbbVQl/mpQHuB1c2acw1WySI5xQY5TN13KWQKW5Im+I6elpXHHFFbjwwgtx1VVX4cFly7BixQqsWr3aSjAWLdoACxcuxKabboLddns+XrD7HnjhXnthyZIlrDuQqqq0dZYO1txZOYHRJmjBKQRrTYGtDgl5QR8uZEJtKlOf14Hhhx15u8wCRxXzHRXroCwC77gT5593Ls4662ycd/552P9l++MPf/wDhsMhgoCyAr9Yp0mCTreDKIrw5JNP4owzzsAf/vAH3HDDDVi+/GGMx7ETrzfffDM881nPwpve+EYcdtjhZSJejAcUFMxSyVAUXTYt3lg0TtkN47evGAkpPud1112P0884HeecfTYeeOABPPbYo1i3btq63gULFmDjTTbB05/+NLx0v5fiVa86CDvssGOe6M1kvqWpX2252FmpQqMv1u2yZctw2223Zp/bZN3EomNYqlFKENnKMwh77rUnNli4QVYUlrGJFf9kdzlvuOEGPP7445X3W8ksSBlQTWzODxbF3JgUu+++BzbccEMrWbXIB+Q+Cw7iJEkK5M9jPB7j0ssuxVlnnoWLLr4IDz30UBbjpqZgDDAx0ceSJUuw0UYbYaedd8Kee+yJF77whdh2222ruBpFGI/H+NqXv4pNNt0E737XO8tnRMg6mkVntNfr4a677sK73/0enH/+eej3+1mRxBsXyjkyNTWFH/3oR9hk001h8hyActpvSXEPAkRhhCRNsO8++2L7HbZHHMdWIcPhN14EElEZ9wHg9ttux9nnnI2/nXEGLrn0Umzz9G1w+RVXIAio7HAWtlvdbheDwQC/+Okv8JvjjsNtt92GNatXl++3aNEi7LPP3vj3f/8Snve852E4HJb+ya5nAwszaRZzeYwYjUe4/rrr8fczz8TZ556Lq6+6Cv/5H/+Jj338YxhMjxB1IguEJMaGM6gASImNufTbqjAKwwCDwQBXXnklLr74YlxxxeW4//4HsGLFCqxZszrzr86V4DfYYAMsXrwY2++wHfbdZ1/st99Ly2K4oJc6XTdF7NfOrwkIjDrrWYC3nU4HQRDgoYcewtlnn4Nzzz0HN910E1asWIHVK5/MFOjDCIsWLcLSpUuxww474IV77YW9XvhCPOc5z0a327Ni5Y033IBjf/5zfO2rX8O8+fMRx2NbL6OgsZbm7sYBCaWInzFuIWlEMeim6f7ximL7bbHxPCya28VgZBCFVLKgSmgvtXnBRibiyhowrNvmTPML1iBMNV358ONrkaQGFOpN+fJ7SRF1lUA1PYwxd6KLn59yHT763b9jwdxerihFcPQQjFNs2i1W1iHMPi9ZRaJUCrBRk+xGh0GAVesG+OLb98Fn37xnVhB6vJB0/pONXEoUWS0iGzp+dWiK3X01NT0FUpXZChpoFEWYmZnBy/bfH1dcfjnCMFQ9EguaYZGEH3/88Tj88MPL11AphA6ryr43UqEtSZKykLjxppuw94tehHXr1mXUkiQBUYAzzjgD+710P4zjOKf0SoTL2DWxomQogwoAXH/99TjxxBNxyimn4Lbbbrdos2jRqZ2cM4ndd98db3nzUXjd61+HefPmZ7ROKkRApPIY2TRP1vEwMKX5bPH1+OOP44orr8QpJ/8FZ511NpYtW5Z13/o9jEdj/P73J+Dwww/DuulpTPQm8oI/Lru+v//9CfjhD36Af1z1DxYE9UkqnkxtsMEG+MiHP4xPfPKTmJycxGg0cgpxJ1inKbqdDs6/4Hx86pOfwjXXXINerwdC1jU0aYq0WJemXXe87utZz3gmrrrm6vKAl8mA/j7ZHHPxs/feey+OP/54/OlPJ+GWW/5ZC44EQeAknIsXL8aee+6JN73pjTjkkNdgYmICo9GopKDw2U+NAuMzfbaU8Yy7hstk5vY78Mc//gF//NOfcMvN/8y62bP82mKLzfGyl70Mb37zm7Hvvi9GGIZ5YRJYLABeEBmyY2ojaAXXH8165i1VSY1UklUTnAyYMMag0+3gla88EGf9/Wx0uh3E41i91jAM0ev1MD09jQ998MP4/g++h9FoVCkZA9ZMbx3gVKwR3rFPkwR33n0XLrrwIvz1tL/i0ksuwZNPrix/74gjjsAJJ5yAwWBQFoRFrOr3+1ixYgV+9rNj8b+/+F/cc/fd5b2LorAcxbDqWLZO99xzT3z96/+NffbZFzPDmaxTWCrkBZBtaiIXSfEKe6DyIysUosfjMU4++WT8/Oc/x2WXXYapqSn1fgOERFmvixYtxEEHvQof++hH8bxddwUAvPWtb8FvfnMcoiiyOlZFt9UYg8WLF+O8887D9ttth2F+nhSJ7re//W188pOfnPXeKPZAHMe48IILsc+++2BmZiaLa4JiBQCj0ag8Xw466CCcddZZ3jhCPHHzbJ/zzj0PL9nvJaWqdhG3qtjGVdRNqdxddHt6vR6SNMaJJ/4JP/rhD3HNNVdjOBxa79HtdNHpZB0vzuAAgA2XbIgX7PYC7L33i7DdttviiSefwEl//gvO+vtZ+MAH3o8f/vBHWLt2bWZhFQQlwypJUpxwwu/xxS/+Ox58cBkmJyeRxGPESVLu/ZTNOZEokNp8hWGIJEnwk5/8FO95z7sxPT2NiYkJV2REoTPee889OO/883DqX0/DhRdeiNWrVpV/9/zn74bzzjsP3W4HJs1iSLG2L73sMnziE5/AlVdcAQCZoEZQtCMCpMZgNB5jgw02wHHHHYdXvvKV+bMLEYaRKxpCQUbZL877xx7D9Tdcj3POPRcXXnABbr7pRqybnin//uhvfwcf+/hHMRhMI4o63jljHbhzQZ6C7UVEWL58OX7/+xNw4okn4IYbrsdwOJrVWbho0SLsvfcLcdRRb8Ehh7wGnU6n1HuQbDKrZC+vh8oOFBiLjBjQEkURHn7oIfzwhz/Eb447Dg899JBzbRMTEyAQpgc28DR37lw84xk74oADXo4999oTE/0JXHnllfjud7+LTtjB9TdcjwULF2SFf8+1ZCvinO+sIsBLh21c1xoQXDTCTNaRAxHWrhtivw/+FvcsX4OJblBQIh3x5Mqfz51xc/eaUdaH/fuFkrlBNmKyejrGy563GU7491ejMzGRMZDywtVyO4BBFJRv4d6CKMxa6PctX2XNveXjRGURa4z/LvJ+IFX8TREfZeJFrBSp2rsgIAwIWyyZVyVkAfkRatIRc9+waLWI7GLAFgTSZ/+0ks8otCUDLsPujwjlLGF+qM6ZMwdveMMbyoKwKPosZL2YAQlDxHGMU085Fa9//WEI8gLS6crIEzI1lbyyQO20Nv5pp5+GtWvXYs6cOQiCAGtnZrDfS16K3XffvUQiA4UOxDvLkgZR0fYqdOuWW27B0d8+Gn/44x+xdu2a6gBcuhTP3XlnbLPttpi/YAHi0QgPPfQQrr32Wtx5550IAEz2exkyQoTxcAbnn3c+zj/vfPzomB/hk5/8JF5/2GEgEEajYUVxKbtCNppuTGoppiZpivvuvRdXXXUVzj7r77j44ktw1113lss5CkN0O11QGGCYDi0BnPF4jNSkmJjo48Ybb8Tn/u1zOP2M08tDP+uMZrNvxqTqUikQylWrVuNLX/4yrr7mGhx77M+w4YZLrEK6OnBR0lfCIMDHPvYxfPe73y1/hicfQd49KmguDcr5/sMoDLLZKEYf4nMtlhIuE6rI6CzZ83/ooYdwzDHH4Ne//rV1qGyy6SZ49rOejS222BK9fg9Ta9fg7nvuwT9v/idWr14NAqHTifLZBeCJJ57AaaedhtNOOw177bknPvf5z+Oggw4qabOFl2cVC2zlQM02RqKpVfcxzZOQCPfcczeO+dEx+PVvfoMVK1ZUyV2vh1122QW77Lwztt9+eyzecDHiJMGyB5bhxhuux0UXXYwnn3wScycmkCYJ4jTFsmUP4pe//BWOO+44vPzlL8dHPvJR7L///kjTxCqe+Ux1Ruthxb2nk6dZ8ZQHZ1M3UCkUbb8qVxBAeh9av2Oo3QLzmSmbataDWwgUay8MAwRsVm7dunW49dZbcfHFF+Psc87G1Vddjccfzwx9uwEwpxuCwg7WzQwtOi5H7DudDv7ylz/jy1/6Mm686SaLNmfSNEuwlcsuAIkgCHD55ZfjwAMPxI9+dAze9ra3YTCYRqfTrQAUocTidDNqgDFCxYrodDo488wz8c1vfgPnnXd+SRsnInQ7Xey+x+7Yc6898dxddsGSJUsBEGZmBrjzrrvwjyuvxEUXXYgHH3wIq1evwW9/+1uc/Je/4FOf/jS+8IUvqAwFAhDmaqMJsnniqNOxzu+CsnfwwQdjg8WL8MQTT+L+++7HDTfdiCsuuzzrmoZBNo9DdoEVIkDU7SCIIgSjEeQcn3Z/is4TEeE//uNreM973oPBYBq3334HbrzpRvzjH//A8oeXo9/r5nPoxlHSzIBbgyYbdNmR4LNEcZwVxNdeezW+/OWv4K9/PS2/vuw+PutZz8QBrzgQe+6xBzbbZJOskI9jPPzww/jHP/6Bc885B9dffz1WPL4CZ5xxBs4444zqvfN1lVHxjLXewpCwdu1avPnNb8Zpp51W/s709LSVA+bpngVGGPjtBeq26Xg8EnTx7JUCBq4mcYx77rsPl116Kc7825m4+JKL8NBDD1vFZRRFWUEfJ+WsfmpSDEdDTE5M4tifHYuPf+LjmJqaQq/XLXOlOMl7JibrZs6dMwcrV63Ehz/8EWy//fbYeuut8/wmdWi7w+EM7rjtLlxz1TW44ILzccXll+POO+8qRVHCgNDvdREGAaZnhtw9zha4EV5xmnckhFhWHGfA8apVq/C///u/+PGPf4y77767fCSTkxPYccdnYLvttsO8efMxHM5g2bJluPmfN2PF4yuqvCK/1lUrV+LUU0/Dqaeehv1e8mJ87gtfwEv3e6k1Yyg6I5U7AKMmpkzAJLvOTKE2iiL88le/wte++lXce++95X3sdrvY58Uvxr777ovn7rILFi1aCJis03zrrbfi0ksuwXnnn4cnnngSV111Na666mqEeTd2nIsaPWPHZ+T5GBttCiqwxvC5TOV8M8p5I+foW585xt4XmfhaivE4wfw5PWy2dB7ueHB1Ng6QpsJH0eQdQyiNIx4rjDWvWO5BYtZphnvyMv6jIQQB4cmpEYajGL0JIC5n/FktmdMyo0I5is9Jlp/NpEgSg0dXTlmKWMai0tldwLqAWDYw+UyfLJdTU878EW+fgmCSFBO9CFtsvEDtMBmqVPNMwywFfAaq5LJ2aRaUUF+x5XhK1/ntGDtRKDqFrz30UHzn6KOxbNkydLvdcpZIdn+KOZELLrwAd911F7bbfjsMc3EZP5E2X6KlvDIcEZni/wt0/ozTTi/vbRHo3/CGN2DO3DmYmlqHMIyU3FFZ8AXVmDLkaTzO0P4kSfDto4/Gt775TTzyyCMlfWDp0o3w7ve8G4cddji232479Ps961MsX74cp592Gr7xzW/gzjvvQq/bRZKLo2SHLOHqq6/BG458A/72tzPx9a9/HUuXLsVoPEYURtbBbXLPvIKuOj09jbvvuhMXXXwJzj333Izy9+CD5Xt3wgBhMYtg0szIPU9uC3TRJCkQpZjo9/Gzn/4Mn/v85/HEEyvQ6/XK2aWSqhAQkOpWA+VMWhih2+nhr3/9K976trfhxBNOxPz58zEajZwZziJ5NcZgiy22wIc//OGyqxgnGfXzoosuxvXXXosoKgSM9CTzBS94AV78khfDpAbdbidPMoIsQhTiLQiwbt00ttpyq4qOg2zI2pBRVUiTJM7RWMJvfnMcvva1r+Kuu+7KngERNt5oI7zrXe/C4Uccge222w49NiO4Zs0a3H777fj9CSfg2J/9DFNTU4iiCOO86CtAissuvxyHvuY1+MQnP4kvf/nL6PV6GA6H2bwh94BMUUlCU5WNkyJ2U/xO5v8ZIR7H+PGPjsG3j/42HnjggTKRieMYB73qVfjgBz6APfbcEwsXLFCf7VVXX4WvfOnL+NuZZyLqdLJEJQhKMYXTTz8D5557Ht797nfhq1/9GhYsWIDRcJgl2lwhmFwPVoEslAveNNDiK4u7BsNkIfXd1L2XAF2zQmvN4W0EaossYSi6tRnDIsG9996Lm26+GZddcgkuufQS3JwDCVlyB/Q7EdIcAIvHCToILXsWY0xpsbN27Vr8+5e+jGOO+RHGoxHmTE4gjuPSqJhyODZV1FxL9cMkzbvWY7z73e/CxMQEjjjiiHJGz7o/qiIsx5HtvZWmacnsWLlyJb70pX/Hz352bLnmwzAzIH/uc5+Hz33uczjwwFdgzpw53vt/62234tifHYuf/exnmJ6exnA0wpe+9CUsX/4w1uSgnexOJgYIc3ZFmiZI8tzDAEjjtDx7tttuO2y33Xbl7w4GA/zl5JPxyU98AssfWY5up5vfk6xzFxbU59wKI0mSas5eiAM51Of8fu622wuw224vsPbfLbfcgs9+9rM4/fTTVVYO5c+1IjH5Ouek2AEA43FcdpV/f8IJ+NAHP1jO4xczfZ///Gfwvve/FxstXaq+9Otf/3qsWPEEjv/db/GNr/8PHl6+HP2JPobDEcIgwOTEBNasXVsWTcVnIyKEUQiQwV577YFnPPMZ6ESdfGbQgALgb2f8DbfccgvCMChn423wjtDpdvCGI4/E5ptvnoOQUSZuEnAAKANfhjMD7Pq85+UFB1nslzVr1uCOO+7EZZddirPPPhvXX399ea6GBEx0o7JLhjQBpUHZEAjCIN9rMRbMX4BvH/1tfOqTnypzlYKBAMEChSEkwyH6vT7uvvsunHDCCfjCF75gsVdWPPEEbrj+elx00UW44vLLcf2NN+CxRx+znmUxdpCkKdLR2Ppvba3VBS8bYKByBKbX6+HMv52Jz3/h87j22mvLONbr9fC6170Ob3v72/MCa1H5WlPr1uGee+7Gn/50En74gx9g5cqViMKwBKbCKNOUPO/8C3D5FVfiM5/5DD772c+WjCUnXyQdhCtiYfE7a6fW4mMf+wR+9ctflN2+qakp7LbbC/CVr34FL3vZS9GJOs5nP+CAA/CRj3wE1113Hb717W/hxBNOQCeKgBxA7/d7GA5H+d42jKFIVgfTEY8kPQ+X5x1vCFke1b4k3diFk2GziWmasbu23GhetneKmUWuruuAmDYjsroWWO9RXl1RTCoCV7wwjAJgzfQI64YJ5he0Y5MiUGqwKLUQbiPQYIM0AZ5cM5OjHKkQAGghz+45zkvbjVwxr/R9It5FZJ09yuhjE5NdLF00WSEpCqRtIArDOlVR+PRRZ/+JbPHrmvfzILkFmk2K0tloOMTmm2+OQw89FN/5zne8ORBM1g7u9/t46KGHcO4552D77bcrOfs8oXAHhm0TaYteyjoinU4HV155Ja6//vqyuJiZGWLbbbbFq179qhwJ6lizQXYMcb9XIDtxPEKv18OTTz6J9733/fjDH09EGIZlUNn7RS/CD390DHba6TklIlUULcVtXbp0I7zzXe/C3vvsjbe97e244oor0Ol0EY9HQK5OGXU6gDH49a9/jQeXLcPxv/sdNtpoo9J6IQgCJHE2oxVEAS699FKcfPLJuOKKK3DzzTdjVU5bCQB0oxBgA9RpmubJQjWAHYQBAsoO1iAM0O328O9f+jK+9tWvoBMG6HU7Dj1IUm54QlLEuczqMwZSg3lz5+LvZ/4d//kf/4lvfPMbqthDkRwSET7+8Y9b7zGOx+hEHXz1a1/Ftddcg063a9GGOOpskgQvf/nL8dWvfrV2f2mbTfOnKg7B0WiMiYkeVq1ag8989jM49mc/sw6VPXbfAz865hg873nPzWhfwzFmZsblG/T7E9htt92w22674aCDDsK73vlO3HvvveVclklTpGmCXq8LGMLXv/513Hvvvfjxj3+MBQsWlPOcWcCsVPs0yplW5GQHV0Yb/PCHP4zf//73GV15chKDwQBz58zFf/331/Hud78L3W5FNZRFO4Gw+wt2x4l/+AOOPPJInHHGGej3+xiPx2WyG0UR0iTB97//A9x008047je/waabbWYN4q9Xh81HD2Ymv6aJYtNCtEq3x2gPt3lfA8YxmS5o8w8uexB/+cufccGFF+KKK67Aww8/7HSNMqQ5xSiJwZlWpeFvnGI8GmN6eoCFCxfiwQcfwrvf9S6c+fczMdHrIiVg3fRgVhSuTF/ClNTX8XiMT37ik9h5p52x4zN2xGAwQEeIaZXrjtwYLanlcRyj3+/jjjvuxDvf9U5cfNFF6HQ6uRhYjMFgGm856q341re+iSVLl2A8HpcUMp7MFvYoz9hxRxx99NF4xSsOxPvf/z7cfffd6PV6+MlPflqKOHHA0uqSpfm+T9PKeqswWAYwHBbFXpCxJEyKN77hDZhetw7ve+/78pm0oBo/MJkFQeGhVQiHFWshzWcl1eQccNg2RQx/9rOfjR/84Pu4+eabcf/996Pf72M0GrH4nvk9hkQZCyFoEnCyV2maJuj3e/jVr36Fd7373YDJBFqGwyEmJ+fgf3/+v3j9Ya/DeDzGYDDMVbJzMCof3UlTg4ULFuAjH/4I9t1nX3zoQx/CJZdcktlW5aMBFRhZUY8DCpAkCebOmYd/+7fP22BUnkOsXLkS//znPxEEYWk5Yd1DABP9Pj796U/jWc96lnd2WX5lQGWERx55FFdddTXOPfccXHrppbjjjjuxZk0149eJopKCOIqTco+ErENeiMaMxyPMmZyDX//61/jC579QrutCeV3zny68VU3+MxdecCE+8+nP4LHHH8Of/vQnXH755bjmmmtw9113lXu/G4WY6HYygCOpLKF4/Cr2XPF9x18Pth+lq55ejEvECMIQnbCL//mfb+CLX/gCxvEYc+bMwbp167DVllvhu9/9Hg459JAsRpeWVBng2ut28ZxnPxs7PWcnvPyAl+Od73oHbrv1tqxIHg5h4hig7BnGcYwvf/nLuPOuu/CTH/8Yc+bMwWg8LsFH1FD+i/sbRRGmpqbwtre9HaecfDImJycz27qpKey794tx/PHHY7MtNsXMzAyS2KYgl/65JsVzn/tcHP/b47HXHnvhM5/9DAaDASjIZpMtYIyKTjvJ4ZNq3Es5w4pkyLD5QD4OUQ5b+GoMK1mGYm1W5c2bL5nPGixy7k9hEVoaIzqNlGm3loATKeSd4nthEGHd9BBrZ0ZYMh5jNIqFMF51z6JOJ2Kory2sgyDFupkRVk2NSu51Jo3ruUcFvdIbFPgG0ORXZUOXFXgIEKcJ5k92sGCyizhOq0JMmjzDKF0/P3fYtOEIe8o8gwZlUZE5qcK2XPXMkDV3UNI7ctTqDW94A3784x9jOBxWxRtsH5OsgMheJ+savdVCvYzG/3PETjPJ4QCVilRhTwAAp592Gqanp9Hv90uVuNe+9lBsvPFGmRJkp9PQWSVhRp8VJP1eD/fddx/e9KY34bLLLstQ6pxScNArX4lf/vJXWLJ0STkAXs7lpJXxfBInGA5nsMMOO+K43/wGB7/mENx6y63o9Xr5fFwCE48RhCHmTE7i3PPOw1FvPgp/+OMfMHfu3CqQZ05HCIMIP/7xMTj++N9h0QaL0Ov3MW/uXKydmsoH84E0jkuLjmpA1wBBiiBX1RsOh3lBluADH/wgfvbTn6LT7WA8GmPe5CR2ff5ueOaznoVNN94YUSfCmrVrceNNN+Gaq6/GEyueqGhVaVpKiKeFUiAMTC7ic8wxP8LhRxyB5z9/V8Tx2KJwcapOVjBmzzpJEgxHM5g3bx7i0bjcBlFAuf1JRUcIs5wOSY5wDwYDBGFYzjvZ7gwVaFTQRrVDpRDE6fW6eOSRR3HUUW/FOeechW63Wx40e+31Qpx00knYeOONMD09jU7UQRgFCIyNvI9GI4zHY7x0v/1w8l9OxoGvPBCPPvoooigsuxLj0RgGhF6vhxNPPBFJHOMXv/xlflhmndU0SF0xCvjEkFCi/bfddhve/vb/hyuuuBz9fh9BEGB6ehpLly7Bccf9FgcccACSJMF4PFYVgIuCYWpqCnPmzMX3v/d9XH/ddXjs8cdzJcqkSjjCrAtw/vnn441vfCP+cvLJWLhwYTk7xZXzyG2g2fYQ0GdDjR087e8Tm1sAqZLf0n9OggO2n1YhyNEs1tP2K0kzj8158+bh7HPPwYc/8hEsWLAA/Yk+Fi9ejCeeeKIEXaSCM/F/CPXpxYs3wHXXX4+3vOUtuDmniA6GI+y4w/bYbffd8bStnoYoCjEzHOKhhx/C9dddjxtuuCHv0oelimkJ1uQt6TSJMTExgQcfehD/8Z//iV/96pdWgim76nI23JbBNxiPR5icnMS1116HIw4/HHfdfVfZhSrYJx94/wfx/e9/D4lJs73V6Zby8Px+F0I3o1H2uwccsD/O/Nvf8LrXvx433ngjJvKiKeSUZaoKiIAIKQzCMDvTij0bhCGCchyjUiBOUkIcZ5/lwAMPxNZP3xp33XVXJgyWZIVZkgPVIWAVdVU3iKy5NEs6nnW8ClC36PCsWbMGT3va0/HKg16JHx/z48wKKmBnfo7K5YRFv18cl97PQb04zp7xqX89De973/tgcuZGEbv+8z8+j9cf9joMhzMAAnS7HTmQkilEhlmFPRgMsMsuu+DEE07EYUcchssuvaxMyDl1uTAiD8MQAYLyHACjJsbJuJyv1veCLbI1GmazmNPT0+j1eo7NEqeiZxTZGJOTk/jfX/wvvvD5LyCKQnR7vVKpu7jeMduLmQgOyljPc840STB//nycffbZ+MQnPoHhcMZJ3zQQRj6TB5Y9gNFohIsuuhAf/ehHsWTJhth0082wz4v3xepVq3D7bbdjZmYGQS+ESRME+cVQmhHbDOyZOu7/7IrW6SKOxQ8ncSZck8QxPvGxj+MHP/wBut1uCYxuv932+N3vfo9dn/88zMzMlLP55VkSUpmzxfEQL3zhXjjpTyfhkEMOwV13Zawpk2SdttFwCAoCTExM4Pjf/hZRGOAnP/lpdm/5fD1ptjIZDT2gzKP84x//OE45+WT08yJzPB5j0003xY+O+SE222JTDAbTCMNOThG2xbHyJ1/mmR/44Acwb/48vPe9780Uc6MI49EIQUg52G5rbxiPfZKxGJ1Vwytg8cAYaXNXA/4yexAr7oKfhdnXkrx55TuALbCVsfJIaK9kox8N18fEq6qiMJsVHMYJhqMUZMBmou1mJxEQGeN2tQwrCkbjBNMz4xwh54OkCqeSKgNYSzC7mvK3K2QD8VArvxWjjKekxmDDBZOYO9lDkqNYFuInBjY1xKpUiRIot237YWoTEYNK+ryY3SNpPFuaVhuvWA2fAbHFd6SPEeV+QAl23XVX7PeSl+CMv/0NvbyDY9IEqQgshfLjxRdfjOuvux57vXCvcqNJWlbBBrY8vQoVUka7KubSVq9ejTPPOqukS8TjMRYuXIjDDj/coibxbpQP4y9U9MZxRglYtmwZXvva1+K6664ruzqj0QgveMEL8Mtf/QpLlizBYDAou3gaCy5LsjNkatvttsN3jj4ahx12OEajEbphUAbqNE1zn8Yuzj7nbLzvve/Dcb/9bWlamxXi2eH28Y99HO997/uwxRZbII5jrHjiCZz197/jG9/4BqamprIh9DQRflc2CBKEAUbjEd797vfghBNOAJAJwrzlrW/FG448EjvssINjMTAcjXD//ffht789Ht85+mhMTU2VYhAi60WSZt2FddPT+NEPf4hf/uqXeaFc+TDxYJAVlwWzs5pjclasyZDZDIOnct8VfmXFn04ncpIWAZtVvHfRJUrTJOO6P7kSb3rzW3DeuWdjcnISaZolOxst3QjHHvtzbLzxRhgOh5jI5bO1tZUBBVlytdPOO+Gb3/wmjjrqqEz9LjAs6Td5EdfDn046CRssXowf/ehHSIPUbwXDkyFGxxsMMuXYW265BQcfcgjuvitLugulwoULF+KE35+Al+y3H9atm0K32ysptNKbsvher9fDzMwA22y7DQ4/4gh897vfzZ5jEIByb8jApEjiGHPnzMVFF1+MT33qUzj22GPLQtA6JNnge9EJINQzPkwNzR4sDkLGFN5RKyxLhMqjK/MtAMnG/mAhuqT8RFodwgEFmOhn62W/l7wEZ511FrbYcktMTPSxbmod7rn3Hnz3u9/Fueecm3eHjVXYBkQIKagSCDLo9rq4+JJLcNRRR+H+++5DGATYb7+X4p3veTf2ftGLsMnGGzvXtHLVKlx5xeX47//+H1x00YX5bFOc71GTW7sYBCbNEp8gwMl/+Qsuecc78OKXvNhJ0OUe0iw0kiRLvm+97Ta87nWvw3333ZsDY1ksHwwGeO2hr8V3v/edct8XsVtSoTnoEobdErTYdrvt8Mc//hH7778/Hn74YXRz/1Lk6stkeSjConcVxCZiMzjEGEsEIMoFPhYvXowtN98Cd915VwkAlvOcwrIsYKhU0bmz7BO4ih8rDvkazfYQsPNOO+ddxDgTXcjNpxNj8ll3lIbxdR3Cas4qo9bddtsdeN9734uZmRnMmTOnPI+e85zn4P+94//lrB7ZFS52VsCKrRBEGei06Wab4thjf4aXvXR/rFixolSz1nzPilwtioJcyTnNOp4mdPYVESHI2eUmVyit7DEKO4jsOorigEhnBUSdjBnxspe+FFttsSW23HorLFi48P8j7r/DrajO9nH8Xmtmdjnn0DsIWCgKKgiixogKNrB3o6DR2DUaS94kry3R+EZjotEUa4qJPQoaxd4LGguKIggiRXpvp+0ys9bvj1VmrZk1ex/8/K7ry3ud14jnnL33zJq1nud+7oLW1jbM/2oe/vLnv2haZAzOChOeEEAEQMHblWoFDY0N+GbhN7jwwouwceNG9OvXHz/60TkYM2YM1q9fj/vvvx+ffvqpWJcG/ToJrnTt0gWMMxx44EH44MMPsfNOO2kZB4sifPjRR/jpT3+Kr+bNE3s3i/QEiRhVtScNJKlJ2+dpGgTPALjCsApx2lJcfvlP8MAD90tAn6C9vR3dunXHv/71EMbuPUYb+ilpiO2JQfRZ2NbWhhEjRuC+e+/DiSedKBpbT0xWIzHuBJGA8j//+S/069sft9x6i242k8aAqrpn4AgjhsaGPO6551784x8PoqGhQUc7VSoVnPujczFy95Eol8tSy0osvwAkGB2+76NcLqO9vR1nnXUWFi1ehJtuvAkNKkuS2J+VcS4HLQ5H5URVXTtAzgY3zcbLdB3lRr9RR7yAbk15eMqIiNi0/nSMuyi6SRZbhsTTwDij1mFmmYjyogDK5RDt5arWWiKx56n8Xuq62eobKSUoVyKUyqF0YTSmO6loCa5vrojSlOiL4vYbIKu2Gk+5i5pOHmbTCFDJy+3cWEAx79vOfuZrdABJ1milA0VIts61rLN5gn6QDBUlycPU/BlVCFqNJtfiTvOeKIRGNXlTpk4RD4bnwfNo6l4wiUBSStDS2oJnn3vWosJofYl6XLi9YVEjuNzWdgnDmpkzZ2L+V1/pwqFSqeCA7x+AvfbaC+VSOVWMujN8bAKHL+MEfvjDs/HZZ5+hqalJN3zFYhE3//pm9OrVC+VKGcViwUmdEoc4geeJQy4IApQrFRxxxCScdNJJKJfLCDlQJQQVDlSZCv0WVJ3Hn3gcD9z/APKFfBwoTQRaPGbsWBxwwAEYPHgwdtllF+w9diyuv/563HHHHSI7MB84c5dUUUaIaHZ+dM6PdDP4gx+cjvfeew+//93vMHbsWI3aq7D3MAxBCcGwocNw0403YsZzz6FPnz4p+m+y6PB9H8899xyWLl2qLcxNuqk4t8TBLQ5zCo+6JvlAxDhCxhEyYaLDGBOiZIipZPpgNY2IzD1FmuMwbutRjHXl+wF+fNlleOP1V5GTRgAKrb/xxl9jxIhd0dzcHLtJ1ni+VTHX2tqKU045BUcfdbTUS9nuq2EYolwWrqz3338/Hn3kEU3NVNcs6TannkkTYS4Wi1ixYgVOOvkULPrmG1ngcf18/Pznv8CEiRNRqVRQLDZoqnUSeTUNRlQUCecckyYfoWk1njSEUCzWiEUolYWJ00MPPYRXX31NT8NZgvNorwFzMyapMyotbOQd5nQy476D2I2bzpdEfPaQFGemNsuVwD0dS94v1RhSqYMaPHgwDjvsMOw6fDgGDxqMESNG4OijjsbT06dj3332EfdSTnWtz80imaMJFPJ5TJ8+HUcfdTS+XboUu+26Gx599HE8/8LzOPXkk9Gnd29UyhWUy1VUKvHz3NTYiEmTJuOVV17GOef8COVyBQSeKMYTztxK59Pa1oqnn34m1VTUot2qtaTozxs3bsI5PzoHS5cuQUOxgLBS1m7C/fr1w29uvQWEEuGwmBGC7rKWV81jpVLBsGHDcNttt4n9IYpEw4KYxcCY6A+5NveRGqsMQxyzLlGgSxAE6NS5k80eUjmWPAFqEOo+9/V6M84/kn49cz/r1auncC+NGCrcQ5V5YExRyKkBZvDU5Mm1hygzsN/ddhtWrVqpAT611x3w/QPQo0cPlMvljPtL7AJVxoMVCgWUy2WM2G0kfv6zn8fu4oSI7D9zL46YfDa4LMgFwKTAfkq8lAEdk5lmkeEcW5MUJamLMXtHnk9yWrfvvvth6pln4sDxB2LUHnti//32w4/O+RFmzHge48aN04wL830w2RCqaJNcEGDV6jU4/YwpWLJkMUbtOQrPPfccbr75Zpx44om48MIL8cqrr+Koo47WQLXveaBSm6gop5xzHHTwwejU1Al9+/bBfvvsg969eqFL507o3KkTunbrhsmTJmk6JYsiEOoLYEB+PhVFEWhqLknVka7zxMp1lT9TKBRw8//9Bg88cD8aGhokAC6YPL/4n59j3/32QWtrm2aBJGuA5LrxPA/t7e2YeMhEnHXmmaIWYkyCUEoyIs6LQqGA2++4HS88/4JeU5xz+7OoXGi5X65ctQp33XWX1vCqP01NTZhwyCHG35NUBI7JWjJrGKW3v+rKqzBu77016wVEehAk0EMC4hgAcUvKZT7bqRq+I5RAQjLBSdePdWosIPCIjpNyToeMzGOSDCEkiQw+AkfmrP0JuPF36nmvRgwVyarkiUgVTrgYKBHZEDqEaPrDh4whDGXGHKmjsiNJrRFJdOlW46o3DStY3rpi1Gr6IsZRLATStAOO+V5HJDM8xVzSSGKKM5toKjm3HEo7+lqpjTLtSJFaY3HAbbyIORe0w8MOPxwjRu4mNR4Z4a+Si04IwYwZM7Bp4yapBaha1AwbnbCvRdL9StFOX3jheW2trQTbp512mmiIqOGsx91pkKrYVdoNxhhyuRxuuOEGvPXWm8jLgFxlSX/SiSdh4iET0draCs64pBBxa7oCzUWPBe++72sO/OlnnI4gJ4w5kiHEijZFKcVvb7sVq1ev1hMoc5qoDvcoilAulRCGVUyZOgUjRoxAe1u7ABkolQ6dcbNTLgu0/1e/+iUeffRR9O3bF/ff9wAeffQRDBkyBO2ldlTD0IpkUAYkgTQTaWlpwUEHH4y7/vhH5HI5BEGAwPflIW7/yefz2LhpI954/Q2NsmrrbEpji2aiDjFiFVDpKSeMogvu77PoGrGJQ7yOE/EZhp5R6aZuu+02PPH4YwJhZGI7aWttxYH7j8ePzj0HlWoFuSCXKrZcTTHTmVgCJb3k0kuQy+VQKpWdBYyi2/z61zdj+fLlWlBvrlVXA1oul8EZQ7lcxmWXXYb5X81DPp8Xugci/vuBBx6Eiy++SASS87SRTrIINUEgFW0ybOhwNDQ06sk1Y5CNuijQVPFfrVbxj3/8XbgiRvbhbNFfzX3PkdXHHc+vPnDNPdDh0gaTnpPIfCXG/mZlACYa1pqaRkKSKgp7rzQK/eTniiKmGzT13G/ZuhWdOnXGT664Qt9vnxKoHpYBqHKgIjME33zrLUydOhXbtm3FBRdcgLfffhunnnaKKKqkHinIBcjlfPiBB2qg94rq/qc//Ql7jd5LMiMKlp0957CYFe++9y7Wb9io98vkuZRunrgGjTzPw9U/vRoffvBfFBuKqIYRiOeDQVAFL730MgwfNgzVijAxcRWTFliZoOGp1yiVSjjxxBNx+OGHS0MUqbOSNuzqn3E2smjWuZpcJxq1xIqRIIiXnoLKL5Yqh7iTXusqxvRaobLkoPb3x+6wRGt+meH8TDIqEH0tDW2nysebN28ennn2GQs8VXvD7nvs7q4fpDQi2WQyqYtWa7q1rRU/Ovcc7L33WLS1tYGqrFXD0EvvnfKZo9KcxZzqqXNSeeCJSSgSsWJmTqbp4cGRVkyp6BQKj3rSSCnU1zMMQ2zduhX9+vXFNddeozMFfY/CS2xR6jkolcu46MIL8cknH2HMmLF4+pn/YOxYMTkrl8oolcro0b07HnzwH5gwYaKWNxTyORSCHAq5HMrlMnbeaWecd+55CFmEMIzke4sQhpJ2Xa6iubkF++//PUw4ZAJCaaBjn2diz+YaLKzfOphNYRiGqFSEh8Lzz7+AW397i4jfkc6flUoF4/Yeh0suu1RnoMa52TzzLBRTN08DDlOmTEWnpiY5qfZTGjx1jlx33bVo3taMXC5vnbfWAEmes6+99hoWfD1fMtmUbjlC7969MXSXXWowxezmhXEJNjDxUJdKJXTp0gWXXX45fF/uoxzgUZSqY1M1K2pQuNUwBgBNphCY88QaxxHXs5Sk+7DR2OcDMbRxbhbcGlDFA7WEU6h5P2HMb3haKpa0ZFNDpyjiaClV9SQw2dxSRa3nzPhkjtXLWEzLQAKFNfmq8TslcqzJQRIX2uyBdedO0geN0pURsBhZgqKMFmOJn94U0cFsF2QvmOQDRdLbPE8UOc5gx4zfn6SkJlEKYhRR+r8R26xDFfe9evbCGVOm6ikS5+5DiUikaf78+Xjzrbfg+1IcnlxrEoUgPOZlmxuV2gzy+TzWrFmLl156Rf9wpVLBwB0G4jCpi0pm89lTD2I1byp0Pp/P48mnnsI999yNYrEoBxGCPlMoFHDOj36ktVaU+obWiCeQJvsBUgVEGIbYd999MWrPURppTjb6YRgi8AN8++23+Mff/yEnslV98JgaFEqpzNMCGooN2Gv0aI1K6ymZNHxR95pSirVr12LCwRPx0suv4PwLzkN7qYxKpYrAzxloYhqtUIVXuVzGqaecgiOPnIz29nZjWp98dsTv+vTTT63rUGvztIrmMKoDcsR5bbUKIGtRktjsg1IB9IiiiqOxsRHvvTcTN914E/L5vD48OBXUpJ/+/Gfi4JIUmCQ9xjTziQulONS4Wq3ggAO+j/2/9z0j1NczNkOuXf2+WfQNHn7oYa1dNNdvMl8wphX7uOba6/CMFNKrA1FRZK7532vQpUsXK8g4k1bGxJdq4pnUR3Xr1hW9+/TSk2uuNbi22zKlFJ99+hlWrlgJz/fSIdkpTmji+Em54ZnUARIL79VUhDGjYOTu4pjE4CiHXfy74pTqNoQgtVisurhPTlyFKQeNqW1qCisnBLvvsTu6du2CUnu7dU3MZ8bzPKxduxbFYgMefPCfuO+++9C9R3fd6Km9xfqM5qSSULS1tqKxsQH/e+0v9HvwXBMtKtb78mXf4tsli7WxVHKKnHyWGYtQLosYnXvuuRf/+ue/0FAsglcqIJxJ5D3CbrvuhvPOPVc/Ey6asTIgMfPJLIBMNhdi//Rx/rnnaYdop1zDnIZQkrrnqh4w91HzRiswK6Xb57WB/Zp7nqV1dmS+SjqoamQZV4wJYYzDokg2Rixd6El6NCWCdxNKtsi7776LTRs3olDIwyccngGmNzU1pqY9UaSMt5jWZVqfS60j3wc40KlTZ1xxxRUol0tymkVNwZY1lTGrGSfezc3Ja0IFoFyx0xfbmlQQEgtliQQiPc8D9cRerNZYIOmk++6zDwYNGoRSu9QDmkwCYx3Nnz8fM2Y8h2FDh+ORhx/BTjsNRnNLK4IgD0p9eFRMxrr36I6nnnoSF118kQCcyxW0VipoaWvDrsN3xV//9jcMGz4MoZzUmmcmZ+r1GDzPxx677+6YhcTPeaTiMxI5yTzhsZH8ZxiG8DwPixcvweWXXw4WRsL1XNa+jDFcfMklaGpq1AC92suydPkawGAiRqlSqWLU6D3xvf33l41ioIcKan2rveyz2bMxbfp0qV9V+58vrw+Nz1twvP3WW0JaYoTbcS600n7g6ymxAOQ4wpAJUx4JYqQaWip0kOr8Pu7YYzF69F5ob2+Xg3kaD5wy6O32OUdiqUqyz1NnO0lX9Bx2TWMOZ1TT6pqLqV/VrVMRhcCPHWeTgIoBjhLDUFMdqsQYIindpO6hiEwFQMxIlJQM61oQwsFZJKJQKBEO8LKxjvcoub9yMOuhjeMluJQmMT2eTzaNMWfXGD8aP82Sm33SudIcRmbBd4mNKR94Fru0FrWTO4xjOLYvUNtFV0q9Y2I3lapBNi90claY0vckqKR2vmAsjFeTi1NOOgX9+vWTSLCnjV2SB7AyoXjiscfBpb7K1HCpw1AtSgu1N7RNatN/7733sHjxIuRyMbJ00kkno0+f3iiXS6DUnj5kFb5qI8jnC1izZg1uuP56VCtVRJFYj+pzjhkzFvvuu69wvJLawLg4IZklgLlJlNpL6NK5Cw486EBj6iM1EeqAgrDa9jwPDz/yMNasWaNNJlL3StJ+VAGww8CB9jSRxyJzz/O0duHUU07Df579D0btuYegL8oC0myUTZt081lR14MQghNPOkkj18RoVNQTw6ST6rx5cxFWhVGLeUjUm8KwxFQpi4bNWFamHE87biVROMZRKVdAQNDa2oorrrwC7SUxZWVRBN/3UCmXsfvIkZgw8WBUqhVdRMaNUAwGJYXunMeoXBhFaGxswqGHHWpoTKkxVZYKBNlEPvLII9i6datGSpPugwqIUZb906ZNx5//9EdJyymBc66nLUccfjgmHjIBURRp3atFkWHxlzlVNbZllEoldO7cBbsO31U3JVl1re/72LJ5M7Zs3QLP8/Ua1a9lRP+QutwKgixHNB6PAa3Hz6mL4Un8kqfWSHaz6to/WJ3S3wlAJ845pOi/vXr2QpcuXcXElcGiU5nP4ODBO2L69Kfxwx+ehfb2dkSMiXD6RHFjNj9U6aw8Ct8PUK6UMWHCRAwfPkwXOa73HQQBNktDC8/Ik63HSikWi/j88y9w882/BqXCBbMSMTAuGRyc49RTTkOfvr01uOSaXNsWfOnXYlxoQ33fRxiF2P+A/TFkyC5icu4e70pmAlJh0rUAAZ6svBKxTcSgEpMkXb1DTJ7saQBReaQke3nBaAjNPUk37TRuDAHgo48/1g2uyQzjnGPNmrXGXgyE1eS+TfQUQpvOSbDJp1S7vB511NEYOmyY0+HU0vgR9ydinBnrwl0/xXqyNLWY2CNDizWQVYypNd6rV2/0798fXNNUuc6BVM+s+t5CoYh77r0Hu+42HG2trSjkc/J+iTM9ny+ARQzdu3fHPXffg9ffeAO33vpb/Ox//gf33ncf3nzzTUyYcLB24vV9P34dKUMx643evXob91uW44Tra8HM4t+UMWh9LE8ZiCmg2vd9XH/d9aLGysfSlUq5jEGDBuG4447VTu+UenG9qSLhnJNCgEUEnAkztUKhiImHTDCAbvt7KSFiXRKCvz7wgJxGUl0LmY0MIQRbt27F3Llz5WfiCKMQjAlAaPOWrVi7dp3BXBBpAcykfILEAJ0BPimWFDhB5y5dcMwxx8g1EhtS1d33iTsmymIXKGDEsX9kTv0TDAM7/iIGE4PAlxpCotdJ6oTlCfBR77sG8Mm49HtgIBKEBVf7RizhYcZ8kSDptM1g+gQoeY+mzVMiKaPETROD5GqLTb9j7ZRpIuNCWDt2cJv6O/UBxTukHq2B+hHnKN7UFxLnLJ9nQGOuE4obzVPH0UkXbasjhYzZRKuHpFqtYujQITjyyCMFj14WmtyxeCsVQWF67Y3XhLtUPu/UNrj456qBCMMQTAaBvvjiC3JDyml77LPPOduwS7Z1QVmobBRFqFQqIAS44w93Yv78+cgFAarSOMGXk5QJBx2MxsYGvTEmnalsQ1iSoNEw68Dad999dYNMCRGBp7KSYFJTEeRyWPD1ArzxxhuO3EakaF0A0NSp0VnAKiRLUW0nHzkJnToJlzAxgfLgecSJ8ut7EcXvTb3E2DFj0bVrV5Gr5nvmAAfEOJBWrVqNltYWnQfZYdCjTuGTzKa0xcm2+6H+d0JSHP8oEmY3999/P2Z98gkaGxsFhYhF0kWV46CDJwgr9lJZHiLp2bx9CNr0K4VYcs4xbtw4XSx5VOgmPUpACIcHBiLjKL6aPx8fvP+BNSXWU8iIgUUif87zKFatXoOb/+//BBUsCAAwISuiIuB76pQzhZbV0GGoZ8kEYSz9MI0bCBDp4kYpJkycoD+XTwkCjyCgBAEFcp74LBFjaGhqRKfOnXTjlNRswkH7inMXhS7EubHpPbIGdZ4b+sFUI8nrTqcTAbJ1v8UtNUgXp046q0ZeqdaB5vN55/d7JHaS3XPPPXDQQePR1tqmi3rOmS4skpNys9FSRlWccfTo3gN7j9s7RX1XhajYnwRNdP2mDQ5AJgYoYopbqC/dHXfcjrVr18LzPJTLFTFlkJPrrl274eijj5IAnJt6mjm5g9HsEGoU5xy9e/fGyJG7G8U0jc+CWiqJDKpq1qbE4dDb1F862Q0h/+7/3TW5zqp3giBAW1sbFi9erJuuKuMIjRrlnXfekZpC36aiEeG2TojdENpTZSqZQCG6du2KQyZMdEyPLAFL9uc2TXi4bYSRda9Mx8Us2naSQZJkOUQSEOzTp5fB/rGd4hXQyhjDT6+6GhMnThDuuFJTp7Txys3S9339vIwbNw4///nP8NvbbsOFF1yAvv36IorifF7dHKjn1ROZuOo9NDY2GXQ8YtEMuWS91Kr/kpIcxhjKJaEBf/XV1/DvJ59ATlJZVXaq0pZ2795d1k0kjiBxjk/iiZNgNAGeHzcke+01BoVCHlEYQQ2NPAoxrUYESoSW8JNZn+CDDz7Q0pX0evax7NtlWLJ0ibx+qjYSE8z169djzpwvNNtG5U/6ftxoZ+l3NXgva/5DDz1MsOQS9FNSr7cgsHocng15Zt+7jNxhbgzGOMy/M4mGCWO95PmYiNpz9lkkufd1ZKwVZyoyKXnQzEoJsDDOhOOLoo6HUYRQhuJWQ8mfDkOEYSQctAw2qHrTOp4+mZXBbacfDmJ/NE1Pcixf7hgZJlyaXFnu3BI38ezDLYMPYY1MDeTeqn6NnyOkPpoJyxOHO2kD6VMxZW8TNzyw9YxKt3fKKacIiqWkriWVF8rQxPd9bN68GdOeegqAiHdwNYSuBa82UT/wsXzFCrzx5huaXlQulzF50iSMGrWnFrBT6umplesh5YYTaz6fx2efzcZ9994r9AKGwyUngE897LffvgZXnaaop3WeW40oAcDwYcPRKEPYORTXP360lMEMixhefeVVseHJAFX90KtpjnFfWcRTVQgxaKzq8ra3t1u5gOY7NulFSX0IjzgQCaQ6DEPsMKA/hgzZRTY2XtwoK8RLbpgtrS3YsmWrNe1NTag4T1t011jkdiNgT/xVU5PWA2kozfpcDQ0NWLZ8Ge644w5N7WVSJ1ORhe3+ktpi0nEphTzEDOABtlkRIdwQrAuqyi4774IddhggqDmUIPAEXZQzjmokaGC+H4CxCC+8+IIFimhqi27aKPL5Ah7854P44vPZyEnHX/W5y6USRo7cHQdNiN0hTYAi3mOI1TirAltNFBTtlXOO039wBgYOGiic3xRiLYvDiEvnwzDEnnvuiR122EHrChVFN8VkSEz00vrmdJXN5evZ197+keQBnWV+lNSdcvDtq+TrFP7JZtt8xtSHN/dKyymSxKi+R0S4r4LcOOOIwhCe1LSYrAXbtICnTW70cyi+Z8Ruu1kUSo+KZl/hnuoKrVi+Qk9QnICnZF0oPe5bb72NadOmCQAwigDO5IRCPGf7jNsbe4zaA0w6R9fSyeqzXU2zTZMwSrTmTnwuD3369JbFHElRO4mJv2YFd8OhWSbJG+4aWxLZuKI+up8q0pPgRYfKRGt9q8I1a70rt/AtW7Zg3bq1mmURMeHUKPSnoiH86MOP0NBQBOchqMfl1MYweiP21Ntm9EAzGw48cHwanKDCkE7dO6RkPTGLY3v/WFNl25bAiKow9j8DjDdBEfG8Uuf6UO+qWq2ib99+uOjii3ROotg/PcsUyLw2ymBHgSfKeItS+0zURbJjsmGZuCD1MfR1I6T2erEYR56HtvZ23PCrX2r9r6nZA4D9v7+//tx2jQsr6NM8c1XGH5WO4IoWPnToEPTs2Uv4UBAg8MTeA5mpyRkHkTXejOee07WGmDYysFCA1J7nY+PGjdi6Zat1XdR5Cc4xfdp0sIghnw/gUQ7fh3EukRQoYD6HCtANwxB77LEHdt55Z0kj5nr/YLzG9TbWlhlc76purKxdV83DHdIuk/oL15loSzLMFAO7c+HW3YsTAo39h3CHj4OpOnTs36pp4gxRJNaZ7+cQ5HPI5/PI53PI53LI5QPkcgFoWA0RVkMptA8RhaF+YFjE4zenZ5REPwBJPgnRbjmSIia/dBwDicfamiNhU/iNX0lSo1Ti6JwttCxxq4kxESQ6mINY9ErGbGRX32iz6TCpnymr2GytgnJHTXa9JPE7s9Bzs1g3aTy+J8xcDjjgAOz//f1RKpXENCBZv8lrrwqWRx5+BFu2bNGhtEkU30kZMpDNd995B8u+/VY3oZ7n4fzzz9cTl2Twfdp1TX5JpMnzPPz5z3+SYbTEQLfFZKZvv37YY889xd+7rI+5ci9jEu3g1nRCN5BEFFE9e/VEt27d0kHFxgGo9HOzZ8/Gxg0bQZUpC7MnOHr6ZBwQVgA8HJZHPLtYqDlRVo0Cp6hUyujUuTP69x8QUz7UZCaBtJZKJTRv29aB1+KOPNCOI+JmjeYqKJNL3QwMfuC+B7BixQoQQmXos3gjlXIZjQ2N2HX4cN3Um4go10grYgACVNEeUnbnURSiZ69e6NWrt6C+QOijI/nFeKzTAICZ781Ec7OY5KqGIm6mGfL5HFauXIl//PWvupmNohCcE21EcMjECejVq6dFB/I8T8R1yEaeEruodhUfuVwOUcQwYMAA3HDd9eL6RQxekJPAhgc/yKNULsPzfFx6yaUatNFUY9OAm5B0Nivcua1WxZOArZjRWJr6nuRUhaTI3elpsek6Wm8JdrRnzJy6c6NZNN2eDWoRlTETqW3aeMCz7OutfZSkm2DVOAHALrsMkWuWymgLaOG/WfQsX75cF4pJ5NFsujzPQ7lSwR133InW1lYxuVP3SE47AGDixEPENJS6NcYm/U0XpqjNM44bI8/RVDnohh1At7MosUm9OOeG9X8H10N9ulKd/ZDz7WNAqf0vClFJmFuJqCgR2N7c3Iyf/fzn2Lxps8hFrVQExZYmCG0knsaY+YaK2hdFEfYaM0aAt5Wyc60qCrnJWKjHFNneyStJ7CFxyBizDRSsuo3WJbFzzlHI52QjbutOUxEMxK7nbG2xw6DJ4bKe3H+yHGA7ulGZe0KhUMCLL76I/77/PoIgsOiZ6rkfs9cY8RxSG6wghi7TdYYk9ynOOXp074kePXoIEIxQRPDEWRhxhJFwYFf12OtvvIHmrdvklLCKsMoQhpBsnVjDqs4An4pnMZKmNc/NeA5/+/vf4Ps+SuUyqtUwdT+Vp4Q5hNDsBxk91djYgHH7jMP6devEJDaVYUicjCXzea3LIHcYvVFKNQqdyZGsxXgxTD7SPAemv0cnMmiEAU6zNqOzlLUf0ffC4IIbulsToRG1RuD7yOUC5IKc1r4HQQ4UJL3wuTV2JlpjZb1B87CzkKU4YoITV+Nju83Z5AUeW+gQ7uy7GK9Br0xs4maURNJEpOYksQ6aSGiCk0yIc3KZcuozvy9TH5NtYqrek0KmGxsbceopp2p+tpiiOI40DhTyBcydNxevv/a6po3WOszMsGxFs3vxxRfAGEfgByiVShg9ajQOGH8AwjDUovbkA2XrOw0DgiDA4iWL8NRTT8kGsKKROgAIqyEGDRqIvv36CkQsJZKOqVIsEpbwTP1veTiaMRvC9r0J3Xv0sFyhdBwKFQG/6q0uWboES5Yu0VbPzPRMR6zPTF4r00I/y3goq2E2Rf4xkktBAwqSI0Cg0DCCHj162IcTHDpVxuJw3CSFjyftrjPKH96R8cz2ufyqA27VylV4/InHpbOqZ6OCAPoN6Id+A/qJ5hFEN2yRdtCMhekRj8B4JPdXnnrUq9Uq8vkcOnXqpP++GgmdmDnvVGHhCxcuxKpVqySFMBakK1dUQggefexRfLNoEYrFAihhoEQEbkPqEvc/4ABdpFtTYWKPkV1TpOR64PJQ/NG55+KWW25B4PsolUoItZ5RBK//8a4/4rDDD0O5XNYNKKlT2vJsXowxRqtN3+QubSqJwS9uwYfcMq7KhCJ4B2r11M+RbJOBOms5WUwp9FVkztk4L2PZcyPzdU0TFCtmQ77H/v0HIJ/Li+daTnc0OGGszWq5ktrXkuYiyqDrw//+Fy+/8pJ0Na3oJtTzPHAIo7F99tlHv7+scy+pDXNFQ7j+xNpA7lhV3AkS2WvGYR/PsovcjjWYdSaEugbjjs9jGCTUaAFqOY0y00CDMeeHV+BmoVDA++/PxJQpU7Bt6zY0NDRoEK3WVmsCDsIrABg0aBBef/11XHLJJbLxKNqgAk/nWLqZIjXIUE7QpWPUO2ePnZq4xjr05NHDtsPxnXPubhTqNbXb+SFoBoXYdY0UMM85x0P//Kd+jpPgeNcuXdC3fz9ZC8GSMJjnIGdRQp8Xs4aUdEDEWQGNDdJJXTIEI8YRQXqlcKaB+2+//RaLliwB9cWEkHgEnh/vB6bhFKVA4FHkKEdAGHzZKP70p1fj4YceRmNjozaKiVlqcBrLqL2OQMiiIs7wv9ddh4cffwyNTU3wqJcyCCTWFFCYVjpvW711w00GJK9dmNfYfLjpppYkknEHF9SFoBo/z7NejmSBVfKXmaZSxrDJ/ieHT0zKp6YixHolT5pvqBBUM8GcGA2pS5ZnvtEkrYhbxawZ387Tmy/JfiQVusuJzTaNA+LjRtKN9pAObADmLsTT64nz7N9BSIcOrVRYPWy6g2VQIB8yxjgmT56MnXfaCYuXLNFoIuM29z+S5iOcczz++OM44cQTtKVzrU1Q/Wwul8Oq1avw1ltvw6NUW1yfetqpaGxsRHNzM4rFYkxFzPhdXAb5VqvCan369Kexbds2kb9XKcs1ERfPA3YY6NT0bM8fc0qi3NvUJqg2TmogbCAEPvHR2tqKtWvXJqYd5pPK0mvInKya/GZ9H1lN1K7WFE5nZcm/NwOHuQM+5XrixQ3c1Xgtmj4Y40/m1hM7ElDrYOzxAWzRgaQo/vU3XseSJUt0Zp55z6IoQt/efdCndx89of4ufzxP6ByEYUw8IeEkzcIn8gDypc5n2bJvMXz4MPjSxEXdokKhgPXr12s3WgICX2p4OaGIKlXsMGAHjBo1Sk83O2Z+oloQ5RpGrGviE+He+Itf/AKHHXEYnnrqKcz7aj48SjF6z1E46aSTMHLkSISRK6eSp26kYk3wBKvC2rt4nC8Ll8FQcvO34iiMjEBLk8bd654kRpAJLTqvse54R0B50gGqm2HmpGIR1I9533EPsqaeCf2VsPonen1GRt1hpcARG2gkxsTOpGELU6RHUZXUUVFQSf059VCultG3zwAMGToklgPIBoG7fPJJjX+vUzzzrH1DN+40E9hN6/HS95DXvL2kRuPnRhQEFkkzmlT3miPGc8KSFGgeU2zVGRKFERoaG9CpU1PqGaIEIJyBVcooFvJ48aUXMWHiBPzxj3/E+PHj9bQo6fiqqZiy6Tf/FAoFHHzwwfrfFfBmuQ+rkivBAkCK9h07NFpnvQNgR7I+SyL6hGgAO9WQJmIvCGTUAMmqhBORYVn3WLIQOEk4YbsmD6RGkV8PeiAk9X2u3FAFLhaLRXw1/yu88+67IiZLMgPU2ojCEN26dUe/vv2Qy+U0QP9daiH1rAe+Dz8QvydiPP2pjOibzZs3Y9GibzB69CgpeZHT6kis62JDAwr5PNra2hL1K5HeDx7aWttxzjnnYMHXC/Czn/0MnTp1QrlcjllOJAbzXJFMnrw3u++6G3bfdTeL1cZN6Rox9xFd+KduaT0FbVrBRjLvvF6/PL1RmM25aRyZ3lbTxjdc/xf1DDmSIFRAffLmmTxiIr0yknun6umMgY2vw+HVCJIbRSLh8GTQN3c8Ldy68llX2myguLUJWZELBOCgIMSFSordWjVB8e8jlsOiamadTnckuwjjdWoInix4zEmfKprMG01Iil6VdYBanzGhFXQFuqv/HUUR2tvbMHDgQBxz3LG48w93Oqk/4oFn4JJ3/vobr2Pul3Oxx557oFKp6OmFWZyZYudKpYJcLoeXX3oZK1euRENDA5pbWtCzR08cc8yxYJxpty9XRlaymVUTk2q1iueefU4HbXMqv5fEk+ktWzbjvffeQ6lUAgh0/mQqh4lzUBAdDAuNcMnpkaScNje3YMOG9alrK26p2FAIEZSncrmMb5d+G38viXM1U/lsCW0WAbdAJm7kP1kHpzFiN11GbfYDr4k22uBIIo6FMXAtBE/oTMAdrwXH+0zvktqBLaME4xkAifpnLiea/Ndee00jpAQMgdxn1LVpby/htddfR1gNJSXaNCqSewWPkX3LuZNL1JSLxp+FEThnWLVqtXgmjAbUZndwvT6V8YM+4Ayn39ffeANfffWVdpCVWLY0AKhgwIAB6NOnt3gmOAf1aAql5jzNzkxOR0zHPmFewhGGEcbuNRZj9xqbftaNnE2eQaFT1w2OpphbOxG3qmGekc2a+iAJ4E9Vchp3RDrblZAaW3Sqca/xNBgnPidcXzNrz83IXlTTZ/UMWCYECemsOict+l1GEVqr8nA6bbpAI+M8NM9P9aurYYh8Loc1a9bgpZdfEhmmPkVYjWQNTkA9AlZiGDhoILp27SpzbLOdPi1jGYJMCl3yj3anhK33M0OnOjTT4zUAsroFnVsXn6VtJTbdKX2PiOt32po2Zhj0gElKpHpdyXyqhBX06N4TI0eMwOzZnwuphXRO1vsCgKhaQUM+wOzZs3HYYYfh3HPPxeWXX47hw4dLjWAorid1RxiYekLl+EgoSRS4sLW1qWI4u8FKNY9wTyiIq1lSeWvMfv24sM7o0Fz0Oc4d2dLc3fybCidig60Wzkug47eyfBCywad4L+SM1QZMFFhPCF595VVs3rxZGOhVK2L/kQ1zJPemN998E7lcDpVqRaw1Is9gKiMEKElPpiSbQemjlRSsGlaxefPmmsMyQgDP81GtVtHcbEpPGAAKCoJKpYLBgwZi4MAd8OWXc+Hlc5LZoM5mUYcRCZjefPPNmDFjBv73f3+BY44+BkXl6cAJfJ865Urmc6lArLSWWvUv7l0lqTyOQfuO6g+MtpBn0IaNF1F3vlyNELI4soZYxjZJMEaeSSx5zhKwBAtGfFBpskcMjiZxdB7SBCbZDtnrRVwZP3bdJGbcjIYlfc+DTz35YahE73g21SiRXeUKkLcPOnO0x+2RYqLRJJSgua1iFBsZ3CEHDECM5q8j4ZWZKJNCcBxPEtlOQwQl8NWbGIfDBykuVlwPC+ccJ55wAv7217+iVCqnwC5ujN7zuRw2b96M6dOnY48995DiZOIsCkzUkTGGZ55+RlBRfB9tbW045JBDMHz4MITV0BrbZ01hTT52Pp/H3LlzMfvzz3W0A1NZPyRExEQY7Ruvv47XXnsNaY2bm6ZhDrBZHS1JsriNc9SYtjRes2Z1ZiFMuBGOnWh4GE/mrmVQSGpQpuqhkRGLMtewHbGSsUaNSQjhNjJrTzI7MPngSIE+ruum1qHv+1i/YT0++eQT3cSAcTGBEbkTyAUevvjiMxx26KF192nlmaJentWQEnme2NMYi+B5xGgo08XU1q1bbfoKZ/pZeeH5F/QzXK1WEbIIHvUFwgtg4MBByOfzqFYrQi/meD5Ico+yCjPuRClFhEF8MCbfszU5SE6FE4UVd1S/+nuNoke3sAZ7xPq+LIMn4zU5iSeeFsihi0HDI6PeINXIXsqUcxPY8To19mgTSKgX66CnP6Rj+0tWU863069DZ/OShO6JCDox5ETw3XffxbJl36KxoRHVSgVRJN25jZnj4EGD0dTUhNbWVgRBkEkZ7MiZ6PyZTAdK2zyuFhuH8+8QDtWB49ecjGWZqaWa9EzNpD22Yjyy647Ec00iAh6Kae3BEybg0cceF8UtAEZU8jK07q5cEZP+sFrF3XffjWlPPYUfnXsuzj33XOwiw77LpQp8j4ImoqeSTo2pgyHrTLIa+w5EdiBtBlL33llZxCS9ZPT7Nt42STaFxNIxm/Rpgu00pjIdHqm9byRBBPvNEosJFxsmsczHILnu/CBAxCK8/fY7xuTc1NQx5AMPy5cvwdFHT0at7YmoKXei/sj643vUkmpAGpOlyR4Ea9euM+5v/IIqImT0XmPwxRdzhEkSNyPU5B2Uja/v+5g9ezZOO+0HOPzww3H55ZfjsMMOQy4X6yaViZq71ybadbVD9XYthp5hNqmlZXX2I1PuxjPYhTouFMC21hIqoahnhOGQDSVpLoRZ05MYGHJvQVwzNonS6JosHGKK8OTZSwTb03x2zGuo+mPqRPiN//N9isD30tQx8+EzAkfr7cxWEylpCHoqyN3W4ZqrTICWtooxcnVpbtIfKM7b6bioPEX7NItaIEWNRIamIfU9Vr4gd7pnuQ5c1z+VFfC4ffbBPvvsKyYVRvB3shWnMgfr2eeexYYNG+FLKp2rcVP/XiwWsfDrhXjnnbfR0NCASKIzp552mpXFl1UkmEWq6bD58SefYNvWrSLEmEWStw6EjCNkTLjdGhzzes889QmIR+0A3hr3NvmlTGmiKEIoHdraS6XvULTZNE7OHZAzQTq8ugakRTL0JtkopdlA0OziKZFDRTpYrBLHe+QdKNLMKfK8r77Ct8u+lbom5SxLEEcvd6xo5hCmMKEyiKnVDPoylkOGvXMGiz+vtBvKoU9NEU1xP6UUGzZsxHsz3zPMZES+Gzfu1eAdB+kA8CT9xTTnICT93Fn5ioid5DiJNRHK6p8Ytv/OaY+a+PIsvNRYK1Y+aTIvLIMWn6B5pbY7xFhfXd3D/x/+cBNUqZkdl+2s/P/afJjNYDKaJc2c4R1qgAihSI1RDXKJopG9+eabmpaqTbZgu3H379fPbloT/7QMcWqNbjvaSJjF1Hb8rrpW8h1ssjmHs1FyyUW2F9RNaWFgu4Kb5iUqcgQAJk2ajMGDB6NULoNRD4x4GmRmnCOSX8p52fd9rF23DrfccgsmTJyAX/7yBnz77bcoNhQQ5AOdPZueWPP0GUO3o1HqwL3hHU125jwT8HZfdup8anW1lLKFcDAPkKawmgvRFcFo6fgdwwM7fzd+vvl2rGu1LoqFAtasXoMvvvhcSCXkeSLMztR0j1vNRK2hrDoDWZ1mkFLVTDNQMFCdhWs7nKtaaNvWbal9SuVCE0Jw9NFHibzEalUbtrmiZcIwlMH2Hl555RUcf/xxOOXkk/DiC8+DsUgb6oQOBk/yOU2ZejmaKGIBuhnUZnU/ANslVBuQpQEQXmPDMfmTbaUQ1WpkpzKYTxhxvNkOHDXuNBdD1y57DfG6AjjOB759biDNQvS1ZSu4kyYQeBS+T+3xm80kkpWVGF2ShC20nXnDZfOaoHkmCxR5U3jCnd/zKLa2lFCqRhoJcU3M9AbDiXUY1tQQbM9hxHltmlDGjeSEpJy24JiWmpcseUiZmXu+74NFEQr5Ak459VS8/vrr8KgnhyzSJc6cKkURAj+HOXPm4J133saJJ56oLYyTGi/T4GPG889jy9at6N69O7Zu3Yo9d98T48eP1xzwWjkySLy++vP+++8btAmxMcEIc4+iCIcfehguu/wytLW3wfN8aThDDJqJKJRiq+kY6mCSNsiTWSXcXiMCDZbTPiaQf6Vh2223XbUDWGyZTZwNYP0qFdowx0WFSE0e65HdO7KGDQotIR0/7L9bwcYzp6/m3ysAYe6Xc9HaIiYUURjJYoHLe0lQDSPsv99++MX//q9NCeIcEU+cNtxBUoCtv3PpEkiiiDPXPGccI0eO0K5uanpEKcUnsz7Bt0uXyglg1Xn0xnpVx+SOxJR8XqPz5QY9XdmZJ+m+tjzNVjoo2pM9DTDQUGP9MrgjANJGMRm640Q2VIqtQYzPm2zC6qOHzmmZet00JyKhwSRI6aTqnwOk7vOc2r8T18zUgKKWM2HC4dr1PdSj1udQ91PR54MgQHt7Oz786EMNXnCZH8wTn7exsVMaBFQOljzOuSKWtt/9GZ2fh2XfRL0eEwBFZvGejZM5CiRSA1GvA/pyvUS3owGuHX7ocrrMBTlEUYQddtgBU6dOxc033ywkFxGLm3e4C2nBDqBYvmw5brrp13jooYfwox/9CGeffTZ22GEgAOj4J3t5JvaDBNCO7zCMrQ9gkNqmUe7UEEvSlDoveVrHRZIlJJLDUNsM0ZYR1ZbmpM4Wx5o3FZKkxlQu2aibNdaCBQuwcuVKEf4ehYgMITGlBCxi2HW33XDLrbeCABJkVP0Fsy5qijFhaD+tbD9C9TQUZl3jQG2q1aqkKnNpVkQEtZ4TEPiIwgiHHnoY9vvefnh/5vsoFAo6v9f1JzJc5qOI4dnnZuDll1/B5EmH46KLL8Fhhx8hroVsCvXEkMRTwg6DN0btUOtcIxlnHVX0/PjIjs8RxyakBmTqN7W0lVGNWGw/Ym/IUJI9wu1OjXNirWsdEsXjukXvwWpSaJ4num6QkipCUMgFRt9FndfPNw/UZDg9Z0A+8NCtS1EsUtNFxsgeIyT5zPDYU8PKgiEWT4onXKM0KK00WxxW3INHgK0t7SiVq2goBDA1hEkFu61ZtLVcHTngai0286EmtRBy50boELjqG2s8uMTMVktuWFzHbag8naOPOgo77rgTVixfjiAXoMIi6xBkMpPQ8wJUq1X85z/P4sQTT4Tne5rHriisceFOUK2GePbZZwGIQOMoinDyKaegV6+eOmA9WXC7HlbltOb5HiqVCr6a+6VVuHArflL87JAhQ3D0Mcfg/8s/qkEFT7sjMp2Dw1K0AtdAJkXdqdOgkQ7InnnWZDA5nf2uTV+HiwFSF0VWtDwA+PLLL/U1UaCEPvPlA9uvXz8c8//1/eccHvUQslDvjx9+9F9NfTWRTPO66PxKnigMuV2okIzCxDykeB2QyraysDNhNSklSbFP7r2oZ65FnGNp136pTE+sA04X3fY5oxpzvdVv54SmbqFvXCBnTlOqaKN1q2RCCSgIotRQgqfD0hMxRclCWWG6Tt04bNqvaz9QuiDP87BixXIsXbpUa8x5AldS+1W3bt2s6xHvS7wmbco0TjHBFZe7rGtKnFwDsVbZmKgye7qWZVTDM/O4sovxrPVBCEEtsWf2mrF/xnNY1ttTGXGdK5UKoijC5ZdfjhkzZmD27NkoFotobw/r7kVRGIlJIyFYsmQprr/+Bjz4jwdxzjnn4Jxzf4T+/fojYsIh0o4osbV1da2H0XEHT5JFO7duOkkJplM/p2kT3NkQmvNFnVymrnOGbkKVnCadlvNsMmVNSrSDyVVLEUtTr2lcW8mW8X0fc+bMQUkG0ydZCkQ2F927dsdxxx77/+lZqABRDapLXWypXEbXLl1w3bXX4+STTtLSiqyGMD7bxFr2qYcoDPHMszPw0kuv4IhJk3DJpZfi8MMPEzVopSJkPIY5HcnQrCNpKp308+A822k7Q05AEs0+yXhmSMrRBmhtq4DLmDNu5DHwhGDDZNIQBRYbQJUyvOIknkBSno71sYHf+MygFMgFVDjPRxFCMLCQJnMsQLUegcCiN3iUgoMg8Am6NgqhqEt5R8yADQsNQzpboib8SxIHiDwOjR+nlGBzWxltpRA0aYhAaoxSt6MarpdVlA5URv3vdVGRrIZZfqWGWbxDdIz29nYMGDAAp5xyEsIolIuPWNdDZ9UxgVa89tqr+PrrhaCEStpbhFDaYjPGJNLoYfbnn2HWrE8QBAFaW1vRt29fnHbaqaLoDQLLlKbWNeecI2JiA1i/fj2WyaDlWtezXBINaPO2ZpTaS6hWZF6mfL/ZX+J7BNoW1f1SFAXxu+Xfh5G2PK43MADv0GADIDSzj9INk7GZJO+/c7rBM8w8iF3gmtOKetbg9WvytO4j03LdeP7FtA0olUtY9M3C1KGZ/FMqlRCFEUqlEiqVCqrVUFCJXffNcT+rjv9u/kxYYx2pwGK1J3jU09qirxd87Vy7ycOz3hU03ZB5Vt6Qeb9rUFSI7WVthbGjxtlpvn5NzQkxclzNSY1jv4yjJlw0+u2w7v5/GGLrZ4dn78vfSacGW/eeBBozde0ZE0JSC0QxmvisIpbxmIY9+/MvsGXzFsEQScSAmK/TKB2KQcn2XfAa7I/tnrMmbk09dsn2rwVS8+xOGZ8he7rDs+0mt3fj1JMRob3qhfvufwBdunRFe3u7Blfrrm3GELIIvkeRC3wsWrwY111/PcYfMB533HEH2lpaEAQC+NWZu448zLrPQZ183KxLnQT6kZEH6Mo+TIP72Zc+K3jEen0e0//qZHo52Fpku6+LeKxoXVDBvO4LFy6sDcRBZFe2trShrU18VatVqw6ya5gwjuMy4rnCyHHmhVGHaiSlV7do0B6BH1Dk8wEqlQomT56EX/7yl+LcjqJUJETqTqn8PRbBo0AxJ1yR//Psszj66KNw8sknY+Z77yKQz4UJHNd8tmEHyNuvyZ3QD09NqknmWuOJ/StNLY6ft1Ubm+XHNPWKxh5k4TM84RBom4Wm3pCZhkMMpCRhnsI4kMt76NwQIKxWEUVCFlMul1EulVEuV/QXFY58GQJYLpwduzQVEq23jcg4ZxtGcHQSvRMOgTRRrNTRinEOjxC0tYdobq/C97KuEq8DJ9uLptaG6HKFioPCZQB2jamJk9aigDIag2EmVSerObXjG2wUSlnyn3322ejcqRPa29tl/0GtyavijBcKBaxatQrPycmfGu+r3Dq1iRBC8OKLL6K1tRVdOncBABx15FHYZcguekKSZUhDiPuBJSBYvWoVNm7cmEIwU9QCJpBvz/dAPQ+eT+W/+5qHnvwSgIb8fur+71YwuEfj/049HRId28HHluHZtNiOayjcG5lxcFnOUNkrKqvYSwIOWuNA3O/UdBTVG2q9okRFubCog9NDY6JAPWzduhkbNmxwHKS2wDoMQ3i+eV+J/BJ/5/u+WAu+L+538ovSxLqgMvMw/jL/m3lfPSqnwlJ/R6jU7DKGDes31Pysau3WLiCJVXbEewNx7flpfQNsZgJjNa57IrLAXcsSJ4OMmJwsM9sh00yEm2ijBgudWa+ODrBjHpL2mklNx5X20nxth17SXax0MNcM2fu1fu0kldnZ7BDDcpw7IG7d+bnPRxaDD4u++UaYlPie+/xSDYnv1dw3OOMpg6jtm5zVbip10QWeCcimpoP2NuZopOv3YzUpY7WaUeaehKWWKqldrMb5kYIG19bWhn3G7Y1pTz2Jnr16akfvjra7nHGwKELO81DMBVi6eDGuvvpqTJgwAc8+9yxyuZxg5JSlayUzsnk70BASWhsY/3/5Q2DHHpnnrOtsSl5eau1vxFl/SDWIVRnyjPVrrw1Foefb9XmS1yYrZ9iMiKlWq1i0aFEm6Kc048L9mug6RdQuxlnn22cipVSHxcdDHqMGss5JL3VOqpB7F+2Z0PiLehS+H4jQ+VIJ//Ozn+Laa//XWudExh7QuOyNWXtM6A0jxlEJI6Ej9DxwBkybNh0TJh6C8y84D0uWLEYul9NArfN9qX0jAXbWukex1s6xP2ftCfKco0iTQJKvtWLdVmmOxAyglNg9kYoKRMJhl9gO19rBntjrGjB9CZKDIIKIcTQ1FNCtcwPCMDISHnii+RQ6yrhpSKAznAg0q2eXogzORfYYTpcptriT85ijHMdLcEtnYXfHaTqNRtYoRakUYu2mVtFQWg9aB1pCo93uyONOXLlbGScQTS5Qc0HJh5MngCrhhinDw4ljc+MxtSLZeJl6J2UuM2LESBx3wvEx11u593HbPENNjZ588kls2rhJZxIqa3tKKQqFAlqaWzBjxgwEQQAGhqamJpxxxhngnGvLcrKdBi4gwPqNG1Aql90xGUYBu3HTRm1EwzlzUn9SId4ZSFwqcNlZ/cYFdN1Aa9OhyQimdwEA6ucZzzLg4dbDHe+aiUaNuHrL7JmLCri2focBamQVQBbCWQOsz2pCktfOvP6+56G1pQ2bN2/WOWnmZ2KIdWGbN2/RInRlfiRE7BYWpxd4srihhFrFv6JtOFHpRDNhvn9l2Z3L5dDc3Iw1a9boKaA9LYt/rHlbS82i2ZxgWXuYwZ0mhAijHUK05Z6hnos1T0gX11ZRLTeepMjeQJXS+SLc3H8MhLAWiEYsPoJuKpJFaE2spEPGcaZBRnIymi7e1f02JxK8diJsrSGfocNKNxlqrTg1JjWrSZKauJufk5lZVjrU2jZKWLVqpbydXi0sNBOssK8Lj82I+HY2g3U/t52NWgvtr/9bsvbobNOgjkw5OzIpTJWaGYBf1jUTTWErDjn0ULz00ssYPXo0SqWSBqtssIbowpokIok4Z4jCEDmPopgLMOvTT3Hcscfh5JNPxvyvvkIun0OlUkEYhZnPIc/YPzuMjqRAEbuoRmoqaIDiMI314lXBario1IvDzZRmm/rjBDNJPdWUZhi9cZ75PngHQdGkrKZcLmHDxg26lksvY/H9pVJJxy3YUR2wGuksWZTbuEw+8YSnDLB0rA5qswLUAIEQAs/3EUYRbr75N7jn3nu1lrCQzyPwA3iebCKJzTZknCNi4itkHFU5zVST9L8+8DcceOCBeOCB+3Vdq4zfUrpMTZR0v29igs6cpwwjuSxCuHTFyTKPNBvPuMBW1y42vVm1oVXWL9IUzmxAE1p0RpRkxjgDuM3K4dIXxQJUiPEc2RCzyLFkHA3FHBoLvvTriPd2Js8sdUZTmxNHDOtviRISgn49m5K9GrRDjhEyT6zRGyzCLU9MLvRDSGBxa2udJoQStFeqWLV+2/YwNNz4c70cnToHVTzxsqlfLgS5Nj2P6CY5q2jkSPPKTQ0H9ajMauM4c+qZ8AMfhEp7Xsd7qVaroJRi1qez8MEHHyCfz1tIknIw/eSTT/DlnC9RKBTQ3NyCvfceh/2+t582k9k+YDhGfLds2aKzkZJ1BAWHJ6fHy1esQKlU0tEXHSkYUk55GYVMR0Tx1nuHXbC7DiTn65ngSEeRVp7+LJk1F6lDrElmDSZF7SQbxM9ix6SuYeKaW3o5nm6iK5Uq2ttLqQwtoSGKqW7r1q3Dxg0bpZutafXNO+Q+az4/1rU1IgnSFL5Yb6eRUOOCtLe1Ydu2rda1UXbfBLHl+LfLl2naTKqrMJ1Xs4YOChGUX06U03i9TLMXl2so0lmC5nVP0lH4dk7t4l/CrMl6+mA2ATSOjlr1mZNUp0Mzx/ZTDPW9yehMnW6S6Wtdz920djWdbpninj0GThWDg7HI0i+vX79eg5NUrkm1LimJNVkbNmxM7z3ELjCI5Zi5vdMgM7AxpU5Nzrgz9X31mjaHpZUFxtba15PTm1oU245Oh1wyiVRIu8lC8Dzkcnm0t7dh7JgxePW113HpJZdq9+JcECDn+/BIHK1jNjvCVVIW0YyjHDG0V6rwPBHtNG3aNEycOBFPPPEECoWCzvtMsiGS/55Zp8DNekrqaF2TMXDuZg2B15CNcOdRVnfVJXW4KR0gqTm8rr+661BGMwBi11nfXiqLnOUMQJnKXOQNGzegpbVVN0nu1tht9OQC5WvSHbZj/zIbr0Dq/EqlEi668EK88sqr+P73v4/2UgkR5/D9nAQ04nXGagxxFF01CAKsWrkKF1xwIS44/3w0NzcLQxoZU5Gq7wlS6yrTyd9FjzRpzsn/bp6jzoxmseflAw8t7VWs2dhqR3s46A46Uz27EIgLvYQXlPOos9xTRQ55p4YATcUcwijSI0emgfT4etH0g811M6iwmp5dCgg8knhoLBJo/P1uLg0s3W+CI552K+QxfkhMFFxsgKs2NFtdep0uLv0gm2Y1jkcryUE2p2fuiVbtHC7n+NrafEkNAxGbhmQVsgknylK5jO/tvz/2GbcPyqWyk87JOUco6aBhGGLatGn6oIqiSCMvAPCf555Fe3u7+PtKBSeffBIaGhp0eLd5mOovHn9lNWctzS3gTLldCbMgSmzqnOd72LxpMzZs2GiJrXkHUVj3BKODG1wCXeJII+UdcenkiWlkrZ+x7qkxGa5ZFav9wpW1k7oOxH1AfgeIn2eWrY5fQ83NWFxToe0MZViqjXqbzrpr163D6tWr9OHAHY1nR6lL2iipRn1rNrIExHkpyuUy2traNDKfNOJSjeuSxYvQ2tqqKWDJ+6vyg6gLVUfa1tql8YtjRcj2SFzrI9/JZjHj+4jjy353FFmsat4Ra94suQ8zXPhSXOi4yKyrS0t9FnsOaFf76ZKwruES2b52BjUkTsRg4MTMjPgHwjDEpk2b9e3zqPiK3ZjjQnXDhvXue2AAkwx2Nqe+PrqR74gWlNSe5JHs6VStyXryrN6Ole52cDWYLs4zhqBOA5GO76gXJ2Ln8hZQLpfRrVtX/Pkvf8a/n3wSe++9NyrVKsIwROAHku0gJwQ8TYM094YoYiiXK/CDAKvXrMFZZ52Fu+68C/l8HqHUxieN4LKmP9/1j7V/8bimjNNMiOVwW3cgR2pNArn9jKR0uBmastS9jpkNhNRYg9x8JnmNNZI9pVbGK+VSCSUJjnoUuvk366HA97Fl82asXr2mzqZCOjRprzdBc+0H9aaO6ud830ehUEC5XMF+++2L559/Hjf88gZ06doF7eUyCPFAqCdc4Du4llhYReB7KOTz+Ovf/oYpU87Apk2b4Ae+MDo0G2RL080TJomJOp9SwKDWOj8jJc59OB6c2ewj9cfzKNZuasHazW3wPWJpJjP3evN+aZmGHNSRZFVJ7F4teSCR+LxgjKNHpwYUc55klHAN9Nl5kQAlibaTWPlY4u96dCkgH1BEVpEajye1TskcvKf6JGKBM3GJmGzEHSWG/p8UBBQLvt0AFUQq9A7coVtTvGCapmISuwgjZgPHuQ47NTe1LJoZT9KqXEU7DEqpeg1DT+B8rHmy6LanHckH1/M8cMbR1NiIU085RVtVO9F1aUfueRQvv/IylixZCt/3RcB2Vei21qxZg1defhm5IIdKpYx+/frj2GOPAyAyr1RDmNEFxVoUls6INDPTfKq+iOVxEPgBVq9eja8XzLeCSrN47ckNUGeqGRoiwpHIfnS4o8FGLfXmSQkIhdOlLRUgTrLOhCRyCis6hRh5nrqQ46QmZYsD1gQphVpbE5iOFUikg5QvbViTRPi5PSTgzKYrkqR+TnLXqdbUcuTzAjmf99UCcSg4JsRZFOGsayUomEahlshh1M8XyT7TrT0l2YgxrrW3K1euxpo1a1I24/r/VK5goqCzdj6TlpIFNmhFAhI2UsYuXcOMRh2M6ivNyqBOh2QkC1Ej5zWp5bD2XB287Lbs5x3BJcz9nJLMQiU1gLPy9ey5UmZ/yt0TQhf1NqlFTeqO7YaHp57UFCjAk81a/DlMzU+6wRJ5rhGDnsyY12TdunUWa8MsmkxjBk25JlRmhMppNdmeGRpP1QEAr8vKSOrJsp5HVwJIGkxxG3LVatqSgD6vgVlwpDOCU5TlRNC5nVFIkM/lQCD0/McfdxxefuVl3HHHHdhh0CC0VyoIowie73eo6VXacR6FyOfzYJzhqquvwh13/AGFgvCDUFos13TUBXpmmU7xGhN85WGgxXzW7+Hpyfp2IFok8b5qo7LcBuWtWiJjZ+UdAK0MdUes2Y/PE5aZ3Rqvd+pRHflCZT2kKismv/wgQFt7O2Z/+pnwgmAsszFz7YXOptQxQXMBrFm/MwlwmtUpB5DPC71fp06dcOOvbsSLL7yIk089BYwA1TAE9fzsGtJYR4LlQMCjCDyK0FBswPPPv4DTTz8dGzduQhAEsfcFWOJ5ywADjVqc1ADyUjIONy/E6g3MgeLydduwYVsbAt/XbEuzfiQkuSMa2nNu90dEsyjjQCBiDBHNwRDnRuQaRARb3+5NCHwvdUZTQoTXAqGiu9IumMzWsSgBI+cc/Xt2QWMxD8ZlC2k8SMRxcMVhPsQIeOSWO48ZycHNM564TmKqMwU9SrB07TaUKhEoIeI9OV0Padz9OlIyFY/WKsRUUWNoajhcwc62qx9Hgn6aeEhSaA2px8vmVoPumiyaDzW4KEZykp527LHHYsCAAQjDUIiMZdtPIayxfbkICoUiVq1ahRdfeEHbBEcsAiUUr7/2Gr5Z+A26du2KMIxw5OTJGDhwB60dpCaHxUSdMuIHzDXT1NQI6gkLXEWLUIHkjIspCyFApVrB5198oZtIZxhpHSQZ3HautV0dMzZsbmhhSUJ/5Cgikk0izxA4JAOSM62vTQyH8PqnJHF9el6TzlQPia/ZHGaw6nSDRoyNiXH7M3GOXBAgn8/Lz8aTxlrgIPqw+MDIq3QdgrUOMDNgNnbIJM6piytDj3MHAGNRrGAYTInPpxrCdevW4osv5sTTTcZTz0eS8Q9k6KBdUw3H9/PkgueI3UFr6V9cExqks5nspj4t0tdh6JzJ+84zChEHes15ajLXEQQ5aTyR5aJofUbXBIvUoUcmXeVc04g6GYfuPFmesInLeg6p094/bhCpjjoRhSqxjOdMlHzJkiVobm5OmXqlTHEMkFqd5hz1XVp5B/kFyTiOrGako+QFV0SA1aBkAInu88reTWtxkZwsY4LaQIVjo1WmV1EYonu37rjyyivxxptv4qqrrkb3Hj106HcQ+BkTbiNKhIi7FVUq8Ij4vddeew1mPDcDvh+gXC5rx8nMhpB0bBrlmrLpmo+pRHVuDQYIJ+liOwHc8xpOQrpmVBU46VCvbFAmeaxZyuAK1NITI3FmkURd6QQTzWIcMc0y8IO4Ppa6QFM2on73x598rGuh+Lo7TOHqIboZ7KMO6XZT9F5bt2duob40rwqrIcaNG4fHHn0M/37ySRx08EHCCV7SQZ3GhIl6mEEw28qlEgqFAl577TX87Ge/AONcTNKrYRpcdwLott8AZ8zIso2BXZjAmBkfglpGtXKYpKK1vlmHaoWl5HZxtBEx+zi4ohI44ZZmmOtHhEh/FhVXp4AM+azJzyBbQgzq0xl+4GtpCOdpEJwTAuoHpmsjhe958L3YfS8MI3TtXEDnTkVEjBlCSNKxXTpVlfIER9cxRSEJmoCRx5ALKJav24bla7cJmiNjdtiquYkT4uYDO7jUpkCUJLNKSPbEQTWRSTTcZT9EDMtPUuNh257YC2uz8QgqlQp22nlnnHDCCXqaRz3PFqPLLl4VCI8+/hjK5QoaGorIF/KIogj/+c+zqFQrYIwhCHI444wpOo7CSdEg7qrRdQB3794DHvW0mDiMBKKt+m6RmSje2/sz39efI4sbX+sA48nJdcd4o3GByDu2DtCxozOFEHYIaHcau9DMfoGYB4oLUa2z8XcEGXUV41bRn3DQUp+XMYbGpkZ06tQEHsV5pCzBgFbv4cMP/6st2Tvy3lzOitxGBVIFadJswumIKX9vPhegmC9YGWrEFPmDS80jw8cyJJwxhohFNohj7Rd18s+SgefI2jtT1aHkTKXixa1pVC1n68zpnKLrJ+zcY2qh2ZxmGx2kX68DPqNJg6gkHSqBxGaxOtx9Sr2sxzgHKgsk3C4HRp42RstcCzX2CkopGhobNdPFp1xSRtWeGk9ivv32W2zetFmbidUC2MzYpA6TvHi9heSQayT3JYI6WV+1t0iyHWfn9n2gxKQhIZ3JbAAyvtKPBwH1fIRhhHK5gl122hm33/57vPnWW7jo4ovRrXt3VKuhNJMTYK9nup4T1fxzhAwIOUdVGnOVSiVcc+01WL9uveVmqgHexHZU+1yzjZWsK8Bjy4sk0q+YFUnwhVv7CHGya9IaTSmXIAq16MD01DC+IkZxHeesykGIMntLNqwdOJuTjRlJVctEnwuFQhHFYlEwuhhBlYl8U2b8LsX0mjlzJiqVigBTuR17UwuMcj7X3zGZOIuRYxrfmeU2pRSe74m6kTGccNzxeOmll/DY449jn333FdEojCEIfPieB48S+DRmWHDZ24QMiDhHxBkY4ygU8njwwb/juWefQ0OxaE37amPnGX4MxoPI9bOtjk/esf1ANYXyf3/17QYNeru2w1TfQvRxDXuYbHCtLVaZXWsL/Fc1ieL3CyMiip36dgGkMV4ul0Mun0MuFyCXCxDkAgQ5H0HOBw2CHHI5H7l8gFwuh0B+Uy6XE1Q9EHQuBujdpSDyjjK40mlEJV2VWgRNzhI5HsYVURsJt09wxjl8SrFlaztWrNsmH6raamO7WYkngJRkOIM5aFrJhieNOPMU1QukxgTLoKVaAJjzQE5W4fYEy5p6cOgH7MyzzkL37t0RRUy7hTFThB5FYtrnefj4o4/w/syZ8P0A+VweS5YswXvvvQdKKTZt3oTx3/8+DjjgAJTLZU3fNJ0D9TtU1AfpVKrsi5N/OnXuBOqJ5iBkQDVxKEbSNAEEmDVrFlasWKnBiXraDNckJT6TzKlq3Pg7r7sL5ePpRsK1ydi1KOmIAd52FX/Jsykr0p4nNzl0JIA8OenoAOyT+BWUUHsNGI0zixiamjqjR4+ewu2QEESJhoUzhrAqpttfzPkCC+YvsBpCU7OaFJUrna9NE3cL2czpnzXxNxtEajuzNTQ2oXO3Ltp0hnEiDismijDOuJ6ev/Pue9i2dVtsikTjrFfTjbkW7SlpIAWJ+Cl9l3rmMnUhxGAk6MNPXrsaS9LpTIfYfU0fwKZDKXdMtZQgZjum0h15RjSYa2RFasST12YQUJq1L6NmxhivU1i4XCzr2vvXM3AwtCC1GyOC3r16if0TBCHxwYgnylseB9gTSrBu3TosXrwkIz/WcB4kPBM8qb3/uhs70+zF2pU4Oqz3dGZeGreOgDijCHgHi9zt6xe5Pdnl2ZMhB3ZivbN4P2OSIUPheT4q1SpKpRL22H133HP33Xj3nXdw8cUXoVOnzqhWQ3iej8D3QAlP0fbMCYsKPp8zZw4ef+IJ4RyeeHaS1yApaSEGMyE52ezwuuaJutDltUF43ZbfbFqTc5YO3TYLKbX1VCxBK0UGoMtV5Z0BaMXXhaSuE6FEO1c3NTXJ662mtfbbDUOR3/zV/K/w1bx5ms2VNdmtty8RikzAsxaQUa/ucjq6y3+qiLJKpQrf8/GD007DW2+9iUcefRj77LOPyBiOIuSCnAQ45LHhYIqEYRVRJJ6Xv/z5z2hvb4cvI6GS9GPN5IE781XpCK2MXcPRm/A6OsvUeSQmei3tFXy5aB1ygWcNn2wgljj2yLRTN1dSJ05sp2vONfivTz/CrblaFHE05HPo1bUAHoVobGxAsVhAQ7GAYlGAEcVCAYVCAcVCHjSLSiSQbrFomxoKGD64B6ohS1ge88TWzjNaxVpjebWQTNOahN4GsZEAIQTtlRBzl2zQmx2HW8jnyrZBsgBLTvsce5rTyaj2E1jbitkxZk6D8MTWvCCZTxIfQmKsHFNOwrCKsWPGYOLEiSiXS4g4Q8SNfBaupnARPGnh+/e//12//gsvvIDVa1ZrR6uzfngWcvlAb3KWWYrj1mYFQov4CI7evXqhc6fOCMMw9W1U5VNxjgL1sWLZMrzx2uvGRhA60TBLF2gUwbF7brzmqJpwEJvKmKKl8FhY78xPq6NF4TUqDF4DdU+tWV67I3Sw2gXC6coSI9nFUC0+vXPa6BDU29otnmi6RMBuQ0MR3bp3i/UkiZcTVHCRp1Yul/HUU0/ppirVBJpoO0kXmsZ5nBGdxzNNLcy8KOGOWkFTUyP69O6tG1/1MiriQ/2eQr6AL774HP/973+Fjocxgd4Z145JF86O9gamtawZ38NNnbFDRO8qgM0ejXHesesiqbdJOmscsYNUtAU3QBfX77buIzpoEkIcwE3yCXBch3qFzXah5jVzq/n/c05bqmHgUeq9mlpFAOjbt68BmnBZNMWThChisiir4NNPZ4nmURaW6udMSptjLNrBArH+lBUZzA5uUA1t4zSuC+ms+0EIR4YXFEj2ID6hAyXbBU5YdEF1HVMmMwbIL8/yiAkHxfijxecVIRyEiNw53/f1/lGtVjFy5Ejcffc9ePvttzFl6hRwAKVqCOL5JtPNOVFXAMATTzwh3LtBnD4DGrS24knk/Sa1DVfqbWLWfk/gzOnUId4gNW8Bl2eFWhOZBijJf5fu0TwZ9ZKY3GY2rPrfSYpxaspr9fsi6XXmUQ+MRcjlcxg4aKD1/JlgNhUifOQCQfN9dsYMWQuFxvrh32FHqd9AmgYtzv3adAuV1EsnRd+o/1RjqJq/M06fgrfffhsPPPAAdt1tN7SXy2AQjVrWemYsNkZ8//2Z+OSTWfA8Tw9DkmyNrDg6nhjMmM8zSd5LJKLk4AamIs7hexRrNrRg2boW5ALf8KJwVVEkflWe2KvMCEAQy0eEKDlIKrbBJruEUYRunfPYoXcnVDi11mJ6sgxQnYXlpN7E73tw364iS487oB2epD7YH5YoHmzcYTkOaTdJKeZWG4cjgM8WrkMYMVHY8Po+uSRjk6z34DDXaDlroyNIaNTMBrF2Poy9ISJD85IohpRBBotfz/d8QJoOnHjiCaBUTGVU0HrqPcgcwxdeeAGLFy0GYwzPPvuspGgy7LTjTpg0ebIVRE9Jtl6wVhHqeR7CMESvPn0wcNAgm1pBYhGxRzg8wuDlAoScYfp/nkalUhEWulHtTDNSg9piY4HGnN2cKKiDmYriwMxKTFJ8MkXjGW+IOAtzmp4IdtB6v+ZaVxIJlo2Ik0wUndR5Lx0PWFOFpbg2VKOFw4cPExuoUZCojZBSySCQBewjjz6CDRs2gFBqUZZTCKgDoFf3NPkIpq3Rk+YPiAPq5YEn4lo87LzzzvqAcz1Tqolsa2vD9OnTQAgRzxPsJoWYZl4OGz3bPMemQ5pOdybmqCykk+uWmLFCxO6QSZbGsIb7qMvyOvvgra+pw3Y0Fqire62tE8s2sdiOsIE6rJSOOJuaH5uQNDPAyjBlPMMhk+ixzSBZWIaSnpV8w4zFDIsPPvhAu00qB9+siUGty7M94fTJ85M7stPSIRVJpy53FiDhav3HVuq1Jrzb/8egPSKp+SE112XS7I5zrsPAzUmPuMeJVzAcYgM5BalUKhg1ak88/NDDmDZtGvbccxQq1RBBEKSMOpRG36fCPyCfz2POnC8wb+5c5PI5/foqysSms9s6zAyiReaeVRdATzSDcbPoOte5815yx9TcCcw6hpQkgRLYDQ8s4J2bVFZCjDLd8bE6sM6o3MMJCHbZeZfU4EA77IPDAwOVUoQn//1vbN26Fb7vyYawfqQPHABdRxrCpBGS87yTwKmIOCPOszQ5raOUwveoqAclE+i8887DW2++iSuvuhLE91ENIwQJSrtupgmHT4BCoYBSuYx33n5LN8lqGsczpvVWZrGFsRIjX5lZJkScs5TviaOYEyuCcVBC8MU367Fxawm+R/UqyQ66IzK7MJn24Nh3jaaPczuCxgVVRYyhT9dGdGvIIwpZSgoXrzfx/6kuxi3qg1XOAQB2HtAdvufLiZyBGMknwH44uDUp465qgbhxPOaarsmmUyEGOY/ii0XrsHZzG/I5P3OzN8XhqZ4qI+S81hnI6x2CSaqSsbkyYwESVzGZzALLPFR4qnkxne2oRyX6xDFhwkTsuutuYEwgTPrmG80XZyLEftPmTfj3v/+NT2aJbMLOnTsjDCOccPwJ6NOnD9rb23W2oeWImapis4sH6nlgUYSmhkaM2nNPq6g2TRAYJ4i4WAtBEODNN97Ahx9+iEKhmFl4WQ6s5jI2nF1hFgs1/CPCUAiUN2zaiOdnzEBLS4u14WT099tXHBkLM4W+0bSxw/YjgNymEDheK73WSEfq7e2o/uyijlKip2p77L6HpsMkxfbCnVbQp4rFIpYuXYoHHvgrAt8XqLXh0JeamlhUjOziJK2dihsqFd66YsUKPPLII2hubrYauXH77ONmAiDOIgxDofOZNv1pfPrpZ3JyH2rTmTQd09ZRIqMkUgBRMgydcYYoCkEIsHHDJtz229uwds1aobMOIzDEFFGmNJtqvzEmgLbLZOLpzmST2J+f4Ds8G1k5UbW6KNSf+GRO7ki6kHS7n6bPkkx9m4Mq2qH3lrEXmd/qormKqY+nQYthw4ehUChYU+1kM0bkpOijjz/Ct0uX6XWZNQlw7bX1Gt5kEe3UqPI69464m3/GYIFzWYdPx5SGHVs7vN7tku/RlT9nmi2JWCcBgD1w/wN48sknBQtHZkrquDFis4TMR9SjBEEgHBxLpTKOOeYYvPLKyzj/vPP0tE+f0bIZVDpDAg7P97Ft2zZ8MWeONd2JoggsYlYN47x+HZA76GeA2eyn1P7At+fcJCnXitiw0Jy01NqHDHM74nIcrUNV1nsBda6LTMdr19TMOL/23ntvbfDkaZmF2quBkAMRFw3Ql19+iWlPTUMul9ffZxqc1dJOZ6HUWYMJGI6my5cvx0svvaTPL+0nwTiWL1+Oyy//CebO/VJKe0InYOoyH/J84VVSKpXQs2dP3HH7HXj66WnYeeedUalU5FqmxtSUSGNEsa4BYO7cuYiiSBgVurSUievuNHU0WINpNl/CxC5JwTWeC/WeZi1YjTBilhQlEyxIppqp6RIx+x+u6avW/VZuEiTRcMqfC0OGwX27oKkQgEWRDaxw2/WXkBQlnKT/IX9+5/5d0Lkxh0hayMfmaPZM1TpUE4gSN6h78QPMLPQlFU0huFjgEHRVBo7A97F8zVbMW7IBntTrZOs30p+Q16BImQuEOCA+5qB4ZtNSSIqKUtesoYM1UDLSIbkptbe3o2/fvjj++OPl5NBD4FH4lCAgQrjriY4QlWoFAPDoY4/i9t//Hm1tbWhra0OnTp1x8imnGIYRJIFkpelDYpxNnLQBSgioRDAPOeQQfXh5nrEBSj1WGDHhqsY5tm3bhr/85S+C4moEs5r29irXTbklqX9XhxLjtrZIGxUlhmGMiWKeEIK//fVv+OlPf4pKpaIdJEURRqxcr6QIPyvGinFeZ5ZmX0eOjtmiZ7rlJae4BJnZkB0eTdbu+TNRRvXHlw55Y8aORa9evQDO4Hu+vJaycJIHYGTEOPzlL3/B8uXLUSw2WFRd12eI6YKG6D4RUO86AGNDhhCUEtx733246qqr0N7WDj/w9YEwbu9x6NKlC8qVMijh+lnSQeBcWr7nctiwYT3+cMcdqFaqWvtQ6yFPWoJbU0I49KUkRjUjuW7vf+AB3HLrrahUKnLd2a6fqYxVI3bC0gtmFL6osX+Js4wkCjPSoaIrPZnm32lCuN0gTa2cUI7UWaK1n9sR5ZL9fhI5oUkPC3UtKU09o2pdqKnQkF2GoF+/fnJfpe7XpxSFQgHLly/H88/PsKjYLEH5qnk+dqhPJ0iJSRKaLJKg0ykwLOuX2lMLo8QgceGWqmy4vZ5q0d9qgb3EOWk2QF7HpCaOdWD6bOGc477778Ndd94lDAHltadyH1E1lDbQNPYmzlWRTkGpj5aWErp374F777sP1113PRjjCAKhK/Q9As+L6eFaegNg0TeLrCZWXXsTqHfSZ8l2uFPSGMgwY2ic4eCO/2pqCVPiCpLeJqw15uwIuZvBZcQopLJVCenYkMD4j9RotF3vIGk6s9dee2HgwIHiWfZ9ywgqkq7r1SjU7Jg777oLmzcLUygVH+J6TpNnhUmj19ILnp2Pbf6eP/7xj7j55pv1RDkM1fth2LptK+6++y948803Zb511QlKZbo+A2L6HUVoa2vDkZOPwjPPPI3hw4cjDEPk8zkJaohJN6UGG4AQLPj6a7S0tMD3vJjWZ4dPZr4XJ7rP09k2NlMnLSFicoPI53y0l6v4cN5q+D7VrE6bPEmclt0keR6lfpZn5Lyb2ml7YTIODO7dhHxAwMFS68Ead3Jj20wFWGt/F/Eo9u7RhD7dGxGG3En1IbE1o+0gbplM8VjRxW00TxdsnMgbKgv5lLhdcOtbyhXM/HKlfgtRDWMG1waQiYCam4S+DwYPmlCtQUuDxfGdtfLNJB3ERjpZTZ2PVdBzd4iwme2VPrDFjTj55JPRs2cPlMplPWFVeidlEc/klObLuXMxffp0eJ6HtrY2fG+//TBm7F6C7+0a3xvRGsRqmlnmoavMDQ444AD06dNHR2OYDbP6E0WRtiZ+5pln8PyM5xEEASrliq0NMgvShCueHRzOk74wFvrPokhuQHmsWrUKf7rrjzjppJPQvXt3sIgh8AOreSUZhg/b1UCRhCWyaw0416v7QCYmMEHS7zGL5rhdSDq3cwiTxW5WYamy0wBg1+HDsdeYvUSUjO/Fg9zEM1Iul0EpxcqVK/CHP9ypEchqteo+xGDHiphIWr0CXb2e7/tYsXIF/vznP+Okk05C7z69UW4vIfAFyrbbbrthr732QlVqd0Co3qdVMxtKICKXy+HfT/4bz82YgYaGRk3by6bUkMx7nipGjWeqUqkgXyhgwdcLcOstt+CMH5yBgYMGCkqOynwi7v0wK9cxQ+rjlg6b5lpWditSDS7JzDLhcKnRUxEXjHewRyUd1teYsUPZk4/6T8j2NYNmExN3HfYUhdcBW4QeKgxD9OzZC3uP2xuEEPh+zuniaj6bjzz6CLZs2YJ8Pp8qAJ3FZd2LmDBXMbK5zGczyWNIvabL7KmemRhPxAlxsp0wV53hNeHuiZCRc1d/ahzvM507N2H+gvlYs3YNvMCT4drciRHbBbRJvSMoFAK9p9x004245OKLUSqJAHBQYQoYMY6qzKXkUkOwbevWGKQ1ci3NOKQkxZ4bVDvOed3zgjOelnc4Ng+eAXDyjuireYaDOCeZeko49i5dR5k7EU+freY5TZLnbZ2z02R3qHO4ra0N/fv3x/jxB0hZjqeZKhZQHYkmLAgCzJnzBe679z4QQkQwu6SOJusss+GLhy6kQzVyJE0HPc/DggULcN999+GkE09CLpeTQGN89gtjnEZ8+umn2nOhI+YzFnYgKdG5XA5tbW3YY4898a9//hO9evdGNazC8wN4vg/qUePxFkVDc3Oz9Z54LUf5JCDu2vMzDMdIAokws9MFA0Cso6+Xb8KCbzcjH3jaoMsCLUgceRKr5ewYFs1Yin9ILmtp+MWTlNG4WVRAIgcQ+ATDB3aLzda4a+rNZVIFi+9qphsm46hUIvTsUsSO/boijJhzKK/zPVwVsCXZ4ob5Q7I1TqI9JBF0LhsaxuETig/mrkRrKZTFPIuNLBzCKdLBwyElfDeRhOTiSCIw4Nmoy3c4iMyMkMyIA4e5ltIsVashRo0ahSMmTRJIEudgRNgaR8y0IhfIS0ClfbXcrKaeOVUXC6YmyXGj6hY+JgLb3t6OgQMH4ogjDhdTP0lxZRk3x/d9lCsVXHPN/2LlypUoFAv1CzACJy1C02sddOUwDPV08JprrkNrayvOOuuHujElGe6EHS84SN1F58z54bxOteL47dytS6s1vevwJ0rqebid7VOvIG5vb4fvBzj66KN1hhqRTZXrvVI51fjrXx/Aa6+9ikKhgLBazTRpqkdlMj8nY7awXK3/n//s52hpbsZ5552vQQzf90QD63mYNGmS3fRIoMX8U6kI4KJSqeD6667FmtWrkc/n9d93NEi4XrMjbLsDNDe34MILLgQlwAUXXSAoamG19gQss2DiqWzETMpcFtMhYx9wU5aJVRgSY1KRdn2usRY72Jxxh5lAve+3Gh1Ts5axz3WkEHK9e9ckxYx7soPNCSiEex8ATJ48Wezp1O3+yCR4QCnFRx9+hBdffEk7TmZFryTvWeb+wZF5XzOfR+4GwEhGkaanViR7p+LSVdN8B9wklHf0OUvWIhlZJUwDSu6pqp7ISBCTcaHH37hxI2bN+hS+53ccuDBcMQnhoERNV8TZde3112GP3XdHGAmgNWLCsp9x6Lw4c+JMKAWlXsoNensrlawJFckw7Utl8jlyDWsxagwkIenA4VwXKZDFlJDA1NeRjtWGiLMQQexcUZJRB5m1h/rsjAkw/uSTT0EQBKhWw5qDDUopglwOt99xOz744AM0NTWlQJZ6W3Mtart5pijX06t/+j8oFAo4+ZRTDFoy1c+vmG57+O8H/8Wa1WtTEVFJk8Ss508AWT6KxSLK5TL22XdfXHXVlYhCJppBQsW0VDLIzMacG5F2pjs4gXsfqTkhTIKhBIl4OaIplgosAouj0j6cuxqbm9sQ+BTc6X7rBj7NM1pHZBrMSziMbKxUF2L/liji6NSYxy4DuoGxtASEm5N5namcChRn1oSJy5iCnE+x6+DuiDi3+jhLC2V2S6TGqceN5jCZL0OE1U1sF0viWFiiwheBXOBj7uJ1+Orb9fA8ipBxffGdkwtjelTPvM6iHhiWtNACU2ViEY9A62WY1eObb8d8JhWam7KHlg8WJK3xnLPPERM+2VyZ+6JqCjkTphxBECCMQowcORJHHH4EKtWqVbzGCG7SsMJ9qKdE5gZ3/oILzofneWgvlTObQXW4B76PeV99hSuuuEL/7lKpVFf7IkxwaKqwSW6KqiBqaGjAnXfehX/+8x84/fTTMXToUPE6TIAOLGKpgtZ0eaw5PUA22l+LVtfRA5onHrHvmjXEeS23Nlt8XQu+TT8HMZoVVkMcf+zx2HHHHVEpV2p+RqW9a25uxoUXXYxvvvkGDY2NKEl01KIlG3raWsBEPLUXZhvVqpg6FopF/Pa23+PRRx/FWWeeiTF77YVKpQI/yCFiFFEo1srRRx+Nrl26atQWGSJ+FkUoFAqY99VXuPiSSzUFVjnE1WsE7fdrU/sYi+3kKaW48KKLhPvglKkYNWpPjfAm3VmTuWNwHkrbT8u0CyuDHgM3DSmlL+H10fzUDsk7tmu6XDGdpkodsXH/TlMmUrNKI1mdd2LvcJpoyOKkUqli0qRJGDRoECrlcmZTGkURKBXo9b333IPW1lYAsDNm6zS2ZnOf3C8Yrw+7ch5PelMxKTVARlVsWhm4jmZkxcpVuoDmmt2TiOtxFMbWRIvY69J2/YbW+SAjE9N+T8SKEPE84dr97LP/EQCuHxjX1rScr80m0NQKCKC1X9++mDJ1SsLB1D4PAWCHgTvoSdD/60q3J/bZgII5xbAnjjyjXjSZBsSanhNSZ3JIeGpJadDHzFI1m1RKbLYT6VhdRhJ7X10qOYkZHrmcyH0+9NBDscceu6NcLtfMoq5UKgDj2LBhAy666CKsXLFSTNXa2yw5gg0aUetcNP+7eRao9R+GVYBzNDQ04sabbsbzM57Deeeeh4EDd5DGalQ3ExziLCeEYOE3C/H222/rsHl7Mll/TzHrWAWknnnmmRg6dAgq5TI4IahETLNw1O/t06cvCvlCXcad6z2Y+eMWQBBzW2S2oBkxl2ZJRvLWhhHDG59+65gsus6q5NTcBmPj9tOInjCOVdU7cQ4dSaHeFiXCLGxQn84Y3KcLqhEzZAfQ4DcxamMCAhqxCOpLFbwiSFlmwcXtGEYN7Y287wnnwqRlvJX9FYfsEu7Oo3eL6I3faRjSJN2cOOcIfIrNW9vw9mfLHO5l2VMCnRGY0bebtys52eNJVyqFpNTgRjsPnjpFgtMYydI/ZDvpJXWU7e3t+P73v4/9999f0y+Tr8sghMtV9VkYxwknnIjefXqjYiCtKWYQqXFgwa0xpJQil8shihj23/8AHHb44YiiUG8iLkRLWS83NDTiqaeewv/8z8/0xNJ0RutIo2MeTqpQrlQqaC+VUCgU8OhjT+BnP/sZevToifPPvwCExDpHnjUVrTV+5i6gIV0EK5rtd+jenOuHpFBuXrMgtw48YrvLafdPAhF4LfVJW7Zuca47W/gchwEr44IgyKEaVjFw0EBMOWMKqobZivMQ5hxRGKKQz2PxokWYOnUqVq9ahXw+j1KppCe4tWjYyWeTMfXFEIURwrCKQqGAv//tH7juumvQpTjFjuQAAQAASURBVHMXXHXVT7UZCzXWcHt7G3bddVccf/zxMvjVg5Qyx0YOWqcLRPJ3P/PM07jkkks0NaZUKiWs3Tu2hpWGQ4QUF9DW1oapZ56Jxx59BN27d8d5F1ygp/qmCVRmkwxF+bT3GlJjU+LJqUDyfZKEr29GPl82pFGjEvsOz4nplJdd2LLMIpioG2t83lpxGlmunWmwx/hIDvpSqpFOFJ5KR+55Im6oX99+OP0Hp2ttUVIKoZ5jSoBisYh333sXDz30kA67JhkHdLLARAaAxcxryGs3hYwzd/FMkAJ51P/eaaedrNf1SBxzaf7M55/Plt9D60K/SVBRNYVqTwqCwO2EStzovnnNKKX6/KCemKhQ6bAIAC+//DLWrlsHP/Ad+1e6OXc17NSjoJ6nM4K/f8B4NDQ0oFIpa12ip0w45H48dOgQ2RAyp7txRxp7Kl2fm5u31Z3IJ0GytGdD7cbLNVOo2RG6f3Vs9sfTe1xW7Vbv+E2C2czRKKfOIhZHgVSrVRSLRfzwh2fr6Zvv+5mNUxhFKBaL+OKLL3D66adj7Zq1aCg2oFKp6OferQu2nX3TedpAFApwNJfP409/+gtuuvGX6N+3H8455xxwcPi+bzjZEmNvFf+cNu0pDTLEtRlP0Z5rAp+cwaMeoihE3z59MXr0aCseJ3lvRowYgaamxlQN4TrL9DDHrFHt8an0n1CjX0MFn6C+x6wREZMV+BQLV27GZwvWIp/zdJ2edkp2r3JF19bh8skiksQ+LKZmMKloVx8ljDh2HdwL3bsURZQHRMa3dhVmDGEYIYpErxexCLRcLqNcLqNSrqBcqaBSraJSqaJSriKSQmciu7pdB3VHz65F2z2HuAqH2MqUkwTtgmchOOZhRKxOmSuNDofMqBF8W98jePWjJWgrVVHI+VpLVw8dcIKxjgWb2hx4WjPmooO69cxxjmJdqlsKTTcQUdjGOLwOQh6GYkJxxhlnCI1TBiKomuVSqYQuXbriuOOOE5uT3ABS2qLEqD2V02dqHIkd1iriJwTF6aorr0Qg4ywC39corkeEe5InaVHis4gJzh133I7LL7scnAuqXKlUQrVatRqDrAbdNOfgnKNarSIIAjQ2NODee+/D+eefi2q1gksv/TH2GjMa5UoZ+Xweni+Ka+rROAtL/kO5/DmRRfOzJyxvFbXhO/GJa6dZZ8b01nYHjNElXTwi5rmrw0+txVWr1ghqluS/p4Ny42c1ioQ+IsgJvaiiqV10ycXYaccdEUUR8vk8As+zDVoI4FFBaVbTtg8//BCnnHIqFi36Bo2NjQirIaIodBaxyUaKc0WNEx+oKm2viw0NuOfue3HllVcgrFbxkyuuxO57jERbaxs8z4Of85HPUwQ5KkOjPVxy6SXo2rWLpuBRSrUpBIihjWEMLKyi2FDEX//6V5w5dSrWrF2DQqGAajUU+2+lqieh8XskzvsmDkaCYrGAefO+xPEnHI/HH3sMhBBcdPElGLPXaEnL9fX00NKpOph+XB4unMQAHjf3JpIwiEEdV1AdpBv/X63pkwINkstHMXIyHqkOI8E1J3YGEshqFH5cO1xSg7qXXUx25PmNEdqYleMszo09zSr05HvwPCqjgjjOOfcc9OzVS1OJPY/CU/nLiMGZqjQduvHGG/HlnC/R0NCAcqmEMIp0zMX2ZioKS/nAaOxcH1tk31YqFRBQ2XyxTHMbc3owcIeBqf2UAPBkQRrJ73t/5ky0tYlnN0pll8LIqE3fPyYLpE6dO6G5uRnPP/98PG1MnCXm721ubnY2lrrxZHETr4CgZcuW4d9P/FvrwbJyM80GM82CIJZJ1A47DECnzp3kxMisaQhKpTL69u2LPXbfUzghE8XAYGARTzjbUpvVk3iWfN9HtVrBmjVrsqf8DsDf830ZYWZcowTlLfn6yUaCWJOU7YwcM4AXp7kQ3M6YmVEGmXhVjckptSd0lUoFU6ZOwbDhwxBK4J4mJqL6TARHuVyCHwR49713cdppp2HxokUoFotSXx+mADgz2s1VFzHGUalWEORz8P0Av/nNLbjq6isBAJf/5AoMHTYUpfaSBhk9K8ZMNIT5fB5vvvkWPvroI3ieh0q1giiKEIZMR6qI12M1Jumi/iAyld7zPB1RlTSqKZfLAID9998f1PMs7T03skUsbbil5ctgbxHYERCJtsTOCCcaMPY8ive/WIHVG1sQyEB6FS0ixHk1qIlqWu2M4CO2fhExUxI8OxmMEI5xu/VFoVhALp9DEPhoby+hra0dbW3taG9rt/691F4ChZlPpcdg8U3yPB++F4BxjuEDu2PEjj1RrkZGccudDwBPNjRECSLVSUGN/lzoIAhI3B2bH9YIBye6uItQCAJ8+vVqzPp6LTyPajt1VzGIBJ2JmNRGpCcb5pwrWT1x1M6f4w5Uijg21MyNX2/CSZ69MQEyNpaYhpP4nIQglxPo5jHHHINBgwZqkw6PUqPoFtpBhTBOOPhgjBo1ShcUzsLU0gDUdm5NGmCoq1MqlXDIIYdg6plnolQqiYNO2uhy2IYU4AyIQjBp+vKnP/8Jxxx7HD7+6GMUi0UEga81gKqwThYX6jpFcsLieR4KhQJWrVqFiy++BJdf/mO0tbbikEMOxZVX/ES4i/IajRR3I8PqHtIOsNrqFVuZzRtnbkCmo1S1GkKw3jJ43ZwQqm1caFFEPt+8ufOwbNlyeB6VzXhoNeUKeapUyvB9io8//hhffP6FABjk9HpA//648aYb9URL5Vx6icgYEZMgJ3n5PGa+PxNHHnkkpk2bhlwuh3y+oPUMWbEacdMhClDP91Asivv/40t/jJ9ccTm2NW/DPvsI7QKXsSeeXJcC8aPI5wXNZ9y4cZgyZYqg0XieDtNlDHoCGUnKfTWMUCqV4Ps+Hn3sMRw5aTKenj4dnHPk83lQqSdRU9RkMawKRc/zkMvl0N7ehnvvuw+TJk3C66+9jkKhgL3HjsXVV10l9NRZyLcygootWO01qyYuJIMSalr7J8CtNAUzptJx8MzGKS5KIiMom6RewzW72h6aUAy21qDrd0Cum/A5ySzWXVPz1O9KnlEZry008tw4G6j1euqfpVIJw4cNx2U//rGOG/KJCrlWkzmxB1bDEEEuhzVr1uD0KadjwYIFKBSLoilUe2kUOhs181YrlkUul8O8eV9h5sz35V7OQSGyghW4R2SRt23bNmzatMko9ms3g+o+77jzTlLXzu2QekJAOQflDPlcDnO+nIOnn34ankdRliwCNQV2MQqS96xYLOLTWZ/hxBNPxN//9ncQQrT2N/lsqYnJ0mXf6smime2n9kHNUGEMLIpAKUHnzp3x5z//GWvXroXn+Ygc19tVNGdN6xUIrPYALvdrJqcDYVjFAfsfgEGDB6FSrcLzfU1ZtvRSAHr16h1fW0rhS8CLIs7oDcMIn30225gqGsCFcU8V0BVWK3j11VexccOGFNCBGmaPyeF5ylG0xrPPayBJTokP6kwICe9Q80ky2AhJuqZqCHt074Ebbviljl1SAKNin+h9Rj5PhDPkCwW8/c7bOPSwQ/HYY4/C8zzk8znr2sb1uE1DZsaz4PuiFlq4cCF++MMf4vrrrwOLIhx44IG49NKLUZZMMf0zYWSfsxxoaGjA5s2bcfdf7hHPm2G6AhCnltC8Bi5aqwIeFOilgVfPQxRG2GHAABx44HjxfdLBnMv8JsV8yY7Ska7GlCbc2Im7PCIORohsdAPfQ6Ua4aX/LgHjHF6SacHgcEoz7X+5ZV5puAJaMetmZmD8DwIO+5yMIobOTXmMGtJHfv6E1lYNP22XGcNUxig0TQE9lcgiY+JDj92tr9ARJpo/cO6qlDMeFZ70czI6HR4/cIRYknSrsADgexTNLRU89+5Czd8VD0HtopgnxsdJGoilFUiZkyS5eLymzqIjND/utL21Az5Nnj1JcJ6Ti9W0Iw+CAGEYom/fvjjp5JNia2OjQaXyoVNF7YknnQjf93TTJA7K7CKT15t4pu4F1SG6hBDccMMvsfPOO6O9VIKXy4mJMI9ReUUhFuhtiKhaRT4X4LVXX8XkIyfjZz/7H3z11VfI5/MoFArI5/PSuZRqikjc2InNxPd9rFq1Cg888ACOPPJI3HvvvSCEonv3Hvj9736Hrt266k3GQnxl3If5GVURmywWWOJes6h+8dpRRN5ctzyjcK1tRuOgPMl/HzBgQIzIgcsmIT54GWcIcgGWr1iGDz/4L3KSbmZO4kROUQWlUgn5fB6ffTYbJxx/Ao47/jgsWrRYiMQpRblcxplnnoWpU6dILRMFA0HE41w+HUUiYyhK5TI8z8fChd/gtB+chjPPnIqZM2eCcW7ddw6B9nNpOGUeJkEQYPWa1fjLX/6CI444Avfcczd8z0dTYyfccsst6NKls54e68PVmJpUq1VUqlVceeVVGDZsOMrliph6cqR2Nv0lheeB7+Oz2bNx2g9+gKlTpuDZ/zyDrdu2IJfLI5fLwZfPhvl+Pc9DpVLBggULcM+992Ly5CNxycUXY+269WgoNoBFEW655VZ0794NjDHk83lrKsedIEDSGCwhsU7Siw2NBcBTUxfuomER3iETD0IIWlpasG7dOlkoSKo4Eki3KSkAsG3bVrmnefjOfyzkl9adpNd21TGvTdqEyw1WcOe1M/9ELBLHo1E4Jc8r9XcRi3Dpjy/FmDFj0NLaCiafKW7mLcrXCuUa/3LOlzjuuGPx8YcfobGxUTQ2Mo9VFT6mWZoCVcploVNtaGjA66+/jhNPPAFffPE5gsAHmAjUViwPKmOOiNS3zP1yLiglsuZgckoogBRz7auCMAxD7D5ydwwaNEgAOhI8opo2JfcrT5wfN9xwA2bP/hxNTU2iAa5WEZrNoJyEMrmvAEJD39rWitt/fzuOOvJIvPbaa9hj9z00sOp7BIH8EpRwqveIL2Z/oWUMSW2zep4BkccbBGKam8vl8PXXC3DnH/6AQiGvp5BMxubEk9qMs5cZ2mJZu61auQKtrS1Wg6u0xJ7n4ayzzoLv+/A9TwL+kvni2eHj/fv11XwT/TkIEdb/xnn23HPPYd26dcgX8vqzR1GIqMpQrTC0t5dlLeHj9tv/gMmTJuN/f/ELW1/IYqBBOFVyRJJFpJ+lxN5FCJXsioodRp5o8GMk32HhQUiNdBuSDc64mfQarAcE/bL+WQ9tmhZFEU7/wek47tjj0F4qwQ9yIJ4ntV7xGcJju1pElTLyuRyWLFmKs846C6eeeipeffU1rR+PayAmYQEOQoSRkO/7CIIAvu/jm2++wS233ILJkyfjsccfE6ypxibceutv0dSpk6y3fbCQi1xbFmmTJEpEx1oul9HQUMS/n3wCr7z8ChobGwFwUMqlFQfJpKS7ZBHqfy9d+q1BsuPaI4OD45ijj8GOO+2EarUqgWaiRwlmc+9i8XGeUW9lJRI4vp9JCi8lBHOXbsSHX61GMeeBceY4Q0hKn296peg8QhIzvIgd6W4d26ae0IxoIYSgHEbYsX93jNypN8KQgRrGclmmigDgx4RNY46qbF3lv1NCEUIs7n1364dCzpMiSmXiEo8vCeHWzIQbv59wg8pGDNcrwq3CRR39WgCcMfxnHGgoBnjxv4tw5en7oleXAqphJMMhScLwJqHByECEoMxpzKBkHnficUViB0ACKv+OW5uCszAncQg7an5/mpbLCUmh+ulvshtEdWD84LTTce899+mDQXD5oTP1KpUKhg4ZgokTJmo0NKauOWBxdXHMYi2x/M3JQIz8iMbM932USiXsuONg/OlPf8Zpp50qDDx8X2eoaR2qem2pKWRVhnzgY8umTfjd74QJyGGHHYZDDjkEI0eMxKBBg1BsaBAFBxOFablUwqpVq/D11wvxzrvv4KUXX8L8+fMBAJ2amtDc0oJbb70Vo/cajba2NmnEQ+KGXLvYwmqQ16xZpSkuTFFyzRgFblOKVPaXqY3pCKXTPKRamlut58W89owxgBC0trZiw8YYiaWUOt0t9XRIUl+HDBmCpqYmtLe3gxIKTik8zkA5wCmAKATgg3OGP//lTzhi0hFCb1qpCOti+fsLBeEG+/zzL+CKK6/AylUrccbpp6Nvnz6oVqp60lapVPD73/8OX86Zi9mfz0ZDQwPa29uzQ7wBRFEorzfDo489hmefew4HHXQgDjnkEIwePRq77LwzunbrLopJ+YyF1SqWr1iB+V8vwHvvvIOXX35F3/+Ghga0tbXh97+7HRMnTkBbW5suRON9Kt64PSoAk1122QV33HEHTjvtVLS3t0umArNzTDks8TSLQuQDHxGLMG36dMyYMQO777E7xo4dixEjR2LHQYNRbCgKqi2LsH7tesybNxdzvvwSn3/+OVatWqWL18D3xfu+7fc45NBD0Nrainwun41a636GxIcIR9Jtw63JVgCSI9BXgzbJvcBkVAj+fwqo57KRX7t2LdauWYMgyMnYIUg6TnKqFhcMS5YuRqlUQrFYNHJCaaYRh96HuL0/UkrR3NyCUqm9LjCzYcN6NLc0o1gs1swIJSTd+KmNQf19a2srKuWqpsuqiNTkgm9ubtaMDYt1AZv6lsvlEIURenTvgRtvuhGnnXqaMOUKcjbjAYY+O4pQLBSwYMHXOPa4Y/GrG3+FM888Cw0NDRpxV0U+dKi2Dz/w4Hk5bNywAXfffTduv+MObN26FU1NTSiX2sFAAELFmWqAnIwLw5t77r0XJ5x4AgYNGtShKW+5VMaAAQNw0EEHY+HChQh8P26WZBHFGAcvl5HzfSxevBg/OP0H+MMdt2Py5CPjszBiAo2XhbHAACi2bNmCF55/AX/5y1/w4Yf/RcQYrr7qp5gwcQJOPeVE5AICzqkEBFUxLCgBQRDgP88+g/ffPw/77/89dyMhz1NKKajng3NRROdyOfzpz3/GxIkTcdjhh6O1pQV+kAMlsomn4pmzHkNuRxWJBl5oqD797DO0tbWjWCygWi6LfLRCAa2trTj++BNw2BGHiYbB98Tn5+4c5x133BGUxA62jHMwNWlmDDwUU+H5C+bj7rvvxo033gifeiiVy7L5JwB8NDYWUS5X8Msbfonf3HoLQIADDhgvGBUydopQwddWdWSlXMH69RssRgxPsM+CwMemTZuwefNm7LDDDnWAVJIB3JjFOO+QgdumTZv1ee/yQPI8D1EUYdPGjampqUs3req/SqWKwPfw29t+izlfzsGSJUuQz+VQroY2DmUYjIAAUbUiPA44xzPPPINXXnkZ3/ve/jjiiCMwetQo7LzzzujVs6eMdxLNW3t7CcuXLcO8+V/hzTfexEsvv4wVy5cDAJqamtDW1oY7/3Anvve9/dDa2opcLidcPiEeaaVHIzJbWmiYQ+kPEeHnv/g59hqzF/r164e2tjYUCoWUJMyefpugGdN1yvoN6zHr01mGKyvTQ44+vXrjoosv1oww9R5tAy6jjjfONZ5gdjGtsoNdV3ENiThBAsY5qhFHPgBe/GAxNm5tRZfGPKIopjgSsVHE5bI6xUgMsBKZvkC4pSnS9a91enNzMmgerVxPYitVhr2G90XXTgWUyqH0fWBGHSsBk8SA3Xfx+115OEzqgEbs2Av9ujdgzcY2BL5hcmJmvHG7g017cJk3wu7gY1tkoynUVFZu0QA45yjkAixeuQkvf7gYZ0/eHdUqg8uZIi7s4+aCGFWGRpMcBi2xxXWsi7EyvYwqgNcjlycc+ZwaRMs9TKJCGciKheargEpHoGypVMJeY8bg0EMPxXPPPYdisRjT8eTDHUURTjj+BAzYYQBaW1vFCJ4knxCDKmwRsnncHMcdP4hx65LGCgrpqVQqOPLIyfjDH/6Aiy++WFCdcjlEYQjOmO2eaSIlVdEUBB7FypWr8OCD/8SDD/4TPbv3QN9+fdGpcyeB3sqNpLWlFatXr8LatWv14Sp0N0BzSwt+fdPNOP/883RTqidNjk1c6WsZY5g3b5611pTuLi5mxc8vX7HcagiTlLIs2q35JwhyKJfL+nfxKAIlslHjsaETJQTVMMTq1atTlEETpCIGD873hbHBiBEjMGrUKMycOVNMbKW5lOBkitdgqCIXBPjo449x6mmn4IYbfolx48ahU6dOotBtacFnsz/D3//2dzzyyCNoaWnB6NGj8Yc/3ImGpgaU20tal1kul9GnTz88/MjDOPqYo7F0yVIZm1I1JlLuAksdzC0tLXj++Rfw/PMvoFAsYEC/fujeoyeaOjUB4AirEdraWrFi+QqsW7/eKKDz8H2Ru3n1VVfjqquvRLUqmlWtYbHE8wTEk7ldvo9yuYyjjjoSt9/+e/z4x5eJ4kZSoziPmSI8YYxVDUNQQpALBE1s1qxPMWvWp+IeU4LA93SeYVL3SwhBPi+Mmdra2nDtNdfh6v+5GuVyWb/vlEGTxrAkO0MtUGI7JUKCWhZ1xsxhpTSFtJMEMu7aB026OE/Q+lVD+M4772LTps0oFoUhBjcOXeuZiDg4RJE0Z86XWLDga4wePUozGkzwqZZjX3IdLV+2DBs3bhSBz1HobEo8z8PKlSuxdetWoV8Nw8zXyAp4ZwbD4OtvvkEYhQjkswduNMCIv3fL1i1ob29HoVDQWjRTF5p8rba2Nhx91NG45be34orLf5K4B/GWzSQDIKyUUcgFWLtuHS666GI8+sijOGPK6TjwwIPQf8AO6NK5s1UubGvehmVfL8MLzz+Phx96GF/OnQvOOY4/7njsMmRn3HHHHfA8XxhVGMU8E2MveL6HBQvmY/LkyTj//PMwcvfd0dBQxIb1G9Dc3Ixjjz0OTU2NYIzrSYcoaAmmTp2Khx76F8oaNCTa2UMdUVEorumC+fNx8skn47jjjsWxxx6HMWPGomvXrsjlcmCMYevWrZj/9XzMfOc9vPjSS/j888/13nzJxZfgttt+i/dmvotKNQLnRBerFkWTCQ3xpk2bMGXKGbjiiitw0EEHoVOnTsI1Ehy77bpbDEBEEaphxVr7ra2tOO/88/H009MxZsxYtLa0Icj5+tm1n6+4/lB6b/V7Wlpb8Mwz/5FTICoMSjwPpVI7Bg8ejP/7v5uRz+fR2toqJirGBFgVi9qsY+Tu6NGzB9avX6+L8Lgp5KBRBAoglwtw6623ghDgwgsvQp8+fbXuf8OGDXj1tf/iT3/6M95443WEYYhLLr4EPzz7h1omol0uwbXx3aZNm7Bi5UoJVFIJNhlTainDqZTasXTJUuyxxx41gRySGDZkGdEkAVPThE6d2wsXLqw5QVSf56v580UmJIjOCqQ0LQ9SZ5zv+wijEMOHD8df//oATjrpJGzevAW5vIgQQ5KubAGk8VnY1taO119/Ha+//jpyuQB9+/RFr169kSvkJGWZo6W5GavXrsEGo+nO5/NgnKOlpQXXXnMdLrr4IlSrKhjeE0CQZ+RvVi0dlXjWZe325ZdfYurUqZg2bRq6dOmMcrmKIPATsUJ25qQA2ePipFAo4NnnnsP8+fORz+fAWNxsh2GIW279LfYctad22k6Z0vEEQqeBT57SIBA4Bi2SZVTrDOEAch7Fus1tePbdr5EPfKl5l7+Lws4HTAoZiTmQk00ioRKwIpahpgmKEMmfseehctDEAM8j2HfEDrKXIrJWhWVIqTNNVd1KidrhDR0Ysad2JpWlVInQv1dnjB7SG/9Z/Q3yQQ4RZ+YIDTzZYuuHMYY+48LUGKDKikWzA1jq1zh7VxG+SPHQy5/j9EN3Qz5HNVJISA0KAOepJi0ZgptqEnnchZuLTNxEkth0uJWVY3HZTftYx9SPu8bWEn0nabw5DUAbG7viaSuq2plTz8SM55+XNAsi6QhCH9HU1IRTTz1NTx/EgWE4O8CkjqbH4fFETy7sjOrQbAxFhlKE9vZ2nHfeeSAguPTHlyIMq0K0rg79jF8XMYaI2ZO1DZs2YsOmjTXBQkVHAoBqtYJf3/RrXHf9tWhvb0culzOctJIYiaDzhFVhErJ4ySJ89tls+J6nMzIp1HNkx4LMmzcPlUpVT+JcOUVp5MzW0gRBgK8XLMCcOXNACNEGEHo6T4QDoEc9VFgFs2Z9iqlTp+pcocAPJC3OnkwTQ0NaKBRwyskni4ZQUo2iiGvXrgiACLMUFtRvv/0OJk+ehDFjxmLnnXcGOLBkyWLMmfslWppbAABdu3TFfffeh959eqNUqsALcpIuQ1AoFFAulzFy5Eg88fgTOOmkk7BixQptciEoZdlgC2dMr2MOoNRewqLFS7Bo8ZLU93pyvwDxACKmeW1tZVx26WW49dZb9WRa0cBicEtQbcyHTtk2l8tlXHjhRWhtbcXVV/8Uvu/B8wNUwzDOJuNphzzGOcBCYYohNb1EFunlSqhdxYRRDdXNGaUU1UqIiEX49a9vxnXXXasPRR0rw5PaNHNCTy0wjCdYCkm3ZTj2nTR1OXYWVQUDd5kx8lgfzELxGRoaGrB+/Xr85S93S6qVaLIogTOOhsuokFwuh61bt+J3t92Ghx95BJ4nphP5XM6eBprosPx781lT7nRvvvUW2tvbRbZXKYpp38ZnzeUCrN+wAcuXL8fAgTugUomce1vWdFLp35U+deZ7M8V/9zyQKAIosRDhSLI5Fi78BgvmL8C+++0rgprlc2kaJqjnWjVQ5XIZl//4MmzauAk3/upXCIIcgoCgXK7o519M7MQLVitVSQ0neOfdd/HOu++iW/duGDx4MIYOGYouXbqAg6O9vR3fLPwGCxcuxObNm/VnnHDwwfjH3/+GR594zCDREKcpM4vE55o3bx6uvPIqvfdEUYTu3bth/AHjpelSVU+8PeqhVCrjoIMOxGmnnYZ//etfKBaLggoahglqNEfEBGDY3taOxx57Ao899gR69eqFbt27o6GhAWFYxaaNG7F27TqxBkCE22fEcP111+Oaa64B9QRzhhCS6boZR3lQLF26FFdccQW6dO4MzxcTrN123Q0fffwRisWioNKHIcJqTIcslcWzu2zZMpxyyil48MF/Yvz48SiXy9JUy7cAvKQmX332YrGIO++8C++8/bYEWqvwgzzaSiV0amzCPXffixEjRmhXSwJiRQcRQ7NblWyhgw8+GE8++aScTCstoHgumdQrEiJqwBtvvAn//Oe/sPe4cejWrSu2btmKuV/Oxddffy1c7BnDIRMPwa2/vRVhGIFSH9SL2TKCFize24cffoSlS5eiUCwCURWcmmC+nI3I5nD69Gdw7HHHwjOMalI1X3If4Mj0dLAogZJtw7ig4a9dtw7vvPNOzPIxeHsqjoBC1DWff/45Vq5YgYGDByFUlEYCS7cKYtN0fd9De3s7JkyYiAcf/BfOPPNMNDdvQxAE+myqNfvkCeOVSqWKZcuXY5mc/llnIQHyUndHPU9MuyoVXHftdbjxxhsl48WD7wfxVCsFakHn3SpterlcRhAEeOONN3DGlDPw4D8eRO/evTUIoWPAaJyJKVh9VDd7xWIRzc3NuOOOO1CtVEFyOaFj9fNoa2vD9dddj3N+dLaesFu1E0kUbsm6n1hlv1j7yVGZarUy3KJjAz4C36d45aNF+HLxOnRpyktjK2Id+hbTjRCYcRLErP9Vg2gwReLjgOr+UvVMPKn3IEA1YujVuYBxu/bTNG8qawnV55HkeS8NO73rrr/+VzThfGQah6jilUukLx/42LC1FS/+dzGKOV8uQBjdrO3qI2ii8QUgFi+XOKSGJOHuQ+yfSd08gnwuwKLVm7DX0D7YdXBPVKrigPf0g5Z2d9QUT20168p5Ssc7EMOUQOtjFA0qoUckBOnFqP6DQvC5awhniLxd70tfW+WilNaVJRFyhcT169cPz0rOv5qC+b4Y9084eAKuvPJKQfszncxM9jNHwqFLTcN47MLqNNskNfKmBIIRhiHGjRuHPfbYA6+//hq2bWtGLp8XU5YO6ur05/Wo0K0YTa869CiheoMlhOLWW36L/73mF8J1TTaKlgmFQnY50wWlKr5/c8uteO3V11BsaEC1GoowV3Vgqi95AKxevRoHfP/7GDp0KKrVakpcnUSiTGMBXbD4Pm6//Q689tqrccac5YwrtjI/8EEIxZo1a3DccceiV69eqJTFoaQOVnOKpN6Hol/sMHAHPPOfZ7Bp0yY5rYsyrzmlFGEYYcWKFZgzZw7mfDkHK1as0O+9W9fuePyxx3HQwQeipaVFTA7UJqWdg0URMnjHwTj44IPw/vvvY+XKlXLCS+1DXlFcDWdMi99vXFPrGhtrwPN8VMIQHvVww/U34JZbb0EYRfA8XzaDhn5OMRQs5nRsG64cAg888EB07twJr776GsIoEvpT1sFIFDkNUkVn7EKnHASFFktR/7p06Yq77rwLV151pcxJ9A29Lzel5+l9KKFtJM4DIm2soBpuK8og6eKWoKyTBF3O/NWUCi3nsmXLcd5552LmzJkoFAo6B4s4aegy1kNqUoJcgM9mz8bKFSvwve/th+7dukstSUzd1Zp4OWlgnGntlaILL1u2DD/+8Y/R2tIip5hSdSfpep40H6BUTJPzuRyOOeZYTZGyC9E4GkjpEs1GsVqtoqGhAfPmzcW1116rJ+FMGjEonY8aZPiBj7a2duSCAEcffbQs9CoagAJTDQK3gDrGGMJqFYceeiio7+ON18WExvcDIDGxTjb7al23t7VjzZo1mDdvHj799FN89ulnmDNnDlauXIlyqYRiUTRWR04+Eo8++ii69+yBt999B6++8qreX4QWWRQmgUcR+B48QhEak++ePXtin332xQ9/eDauvfYaDBs+HL7nw/d8+exSUC4KRgaG7+37PbzwwgtYs2aNmOiGYc3i3pfPRktrKzZu3Ig1a9Zg3bp1aG5ukRP3PMIwRGNDI+65+15cdfWV2Na8DYVCAStWLMfDDz9sMYYIYBn8qAZBU6/8ACNGjMDUqWfi8ssvw+DBOwogAMIc47FHH8XixUvE+pGukPl8Hus3bMC0adOQz+cxduxYQbs39pwoDI14MC60pVKLOH3adFxx5RXWOVIul9Gtazf84+//wDHHHi1ck30PHvFskIgSK5alXBYxTJ07dcH0p6fLIpJr3ZirLaGUYvPmzWKtzPoUc+fOtaaL3//e/njyqafQ1KlJnH/wBANIakgBgkKhiPb2dvzkJz8RtGAJGEcRj83FJJimgJyvv/4a4w8Yj12G7KL1oUQ7FnNtVpeqP5xmcMTerzg0+OR5Hu68605MnzZdP/cETNcY1KD2Us/H5s2b0NjUiMMPP1w31OZ0Pw6qt/dnSinCaogRI0dg7NgxeOutt7B582atC2ecuUPJiT3UiOuz9FkY780Enh+gvSQaq9t+exuuufYaRFGYAhiVAy9nQpcfRRE838O6dWvxz38+KMBuQsBkrRLkAsyfPx+vvvYqdtttNwwdOhS+L6QSxPCFMKN0QmkaWKkIp/fnZ8xAQ0OD1uaWy2X85PIr8NvbfqsbZN/37HxF2LR4V/dMHdJRJWkzczBN916LzSUN4yglqIYM19z7Flasb0Y+oLAVX7L/IWn9tukCYR+hAlQwB20uPxbCLWqlnKYTtJUr2GfkQFx4/BjRn0mttdIZ20Y+sb7b8yi8X//6pl/5vgdfUgt8uQiEZTnVluiMCSGpB47A8/DUmws0hxjc/uDE0jXFQWZEU7AQH2AkBUcb1CbbXcppFkMEul6pRtja0oYTD9oNTN5ISkltgxOnFi8e4SPLHc6gZir6qFmI2s5XCW0Ocaedmjkp0ChHvHqptDq3DGiNzEfTXIDDnYFYrVbR1NSElatW4r133xP0Ms8Ti7paxQ3X34C9xuxljeDNMbyIEbG1k4QkqLXJhZsVss6NUHsdLUFQrpSx++67Y9KkI7Dg66/xzcJvNB2mtsbEvryEJeeW4r8JWmSEMIwwZOhQ3H333Tj/gvNQam8XSJXnpejCqrgzHf22bNmCO++8E7///e811YVJcETfBxLrhdSh+NHHH2PYsKHYcccdNbKVnGaYTaIyFPF9H+3lEu6//wH83//9Xyxc15pFIihNRlgppRQbNmzAnDlzMHr0aPTr38+6ryxi1sGn7Nmr1Sp69eqFxsZGPPufZzUSxpyRYeIzepTApx4Cz0Mu8JHL5VCuVDB06FA8/PAjOPSwQ1AulVEsFuF5AqyJz0EJOVAPlUoJgwYNwjHHHI1Vq1fhyy++QMRYnMtkUkjNfAekl1/KXpuI11Aus8OGDsMD99+PCy+6UCD8hMALvJrhucnYBnGgiXVSrVYxfvyBGL3XKHw2+zOsW7tO30Pu2OosZz+HzkUzsSkB9QJEjKNSrWKffffFv/71Txx/wvEya8zThXPM6pAooyPDjydAJxiuwbGelDoz8DSTxNjv7CKD2JEUxlqklGr6yubNm/D11wvw0EMP4yc/+Qk++uhDSZmKwCMm1hqJ9wZiADvqdSJp3+/7AT755BM88/Qz2Lx5E4LAB/UoGpuadCFHPVF8ep4Hj8aGPeVyGR999BEuuOACzJs7Vz+nilZLJVhFpQOb2os+n/05KKEYuftINDQ0WIdsJEOA4/eceKaph08//QwXX3wRvv76a11cMkmPjwENwJMFnR8E+PTTT1GpVLDbbruha7duwkHUF59NFMdpei+hBGE1xCETJ2LHHXfEBx98gObmbcgFOXg+NYom4gTXqOEw6XtUPOO+h1wuLyfgES6//Ce4//779HX47LPP8OILLwrdColBI3VtqnKfGTR4MA4//AhcccVP8Mtf/QpX/OQnmDBhAgYNGqTBSr1mPOFkQj2h4evWrRvGjRuHGTNmYMuWLdJ5NPusV8+ERwV7gnpUNJmeB0DseXuOGoVHHn4Yx51wnJ5m5PN5fPvtt3jo4YdFgUiJbGw9+J6ikIpr1btPHxwwfjwuuOAC/OpXv8TPfvYzTJp0BHbaaSdjn+UIfB9PPPEkvvnmGxSLBTCZHce5aDyqYYgXX3wR77z9NgqFPHr36Y1OnTrF54Evv2Se4cZNm/CnP/4JV155Bdra2hD4gXaJ3X33PfDQQw9h0qQjUCq1I1A6K8KdeYqxcYdovocOHYI1a1bj/fc/ACWe0EJxqwcxyjYeO5hLN2TlTXDE4ZPw+L+fQM+ePRDKqJ9cXqxfMdH2ELEI8+bOw1VXX40Zzz2HfF7IBkxwNc7TE/c58H2Uq2W8+uqr6NmzBwYMGIDOnTvH2Y9qHyMuJiFPmCw63C+le/3y5ctx51134rZbf5uIFbEZgKpZ5UwYXX300UcIwxBDhg5BU2OTBu4sR82k+Y2sicrlMnbddVccedRRWLx4MebPnw/G47NQNJe1VZKZZ6GcCkYsQjUMseeeo/D3v/8dU6dOEUA5TWQhGmkIVA6PGBMA6saNG/Dwww9L9hOV90yYNuXzOaxcuQpPPfUUVq9ahd69e6NP797ImVFe1HYP/fLLOfjxj3+Mxx9/TJvtlMtlNDY04uabf4ObbvoVqqF4LQHeJro7bg9akuB1egBls/usxi/DbyHiHJUwQj7w8fqspbjriY/RWMxZlBbLusX0FCBGCiIxYp80m4JY0h7LWdReIvZrSNpnaznEWZNG4cDRg9BeCuHL4QgHh+cFCHI5aSYkZC+BJ/s93wPhxg7q2kzb29r12DxGXAiO/8V0fDhvDTo1iEIl+bjpJoUTy6ocllsmSQgpSTxb1XEYRv6Es7lQk02KarWCh395PI7Yd2dUqiEC33PnTSWNZCxaKK8ddJXoyuEwADDR4SwaEXH9WkIsMxZzkXKH30NSVaibc5J+ryJQux35fA6fffoZjph0BFpbhXFKW1sbhg0Zipnvv4+GpgZwxvVmbhXTZkFY4xqlQpi5Q7PGkTCcgUbSReB2Hm3tbXjwwQdxzz334ss5c6Rgm8pmIt6QtaGF1WATXdhS+WBXwirAge7de+CHP/whrrjyCgwaOFCYLvhBqpk2ReIff/wJPv/ic2xYtx4Lv1mIDz/6EHO/nBublsiQZc6zc7OVqUtDQwMOnnAw9hi5O/r1749Ro/bEwQdPMOy5xfVftmwZXnzxJWzavAmrVq7ErE8/xYf//UAX2FmZkq7X7NGjO8aPH48hQ4ahb5++GDJ0CCZPnqRF2CQxAYuiCJ7n4Te/+Q1uvPFGcM6Qz+XBWAgWcYtylgRIqhKtP/644/G73/0OQ4YOkcYWgU3FzTiwlDg9jCI89ugj+MMf7sTs2bP1+kmZhvBYo0eMyVSsxRXTXbVP9evXD2eeeRYuv/wyDBgwAKVSCblcINgQmlZoS6ot6qVDg5JEOFesXI47/3AX/vXQQ1i/bp3QaAQiw5CxpD27rXU26UTEaPr79u2HCy64AJddfhl69ughrmkuEPdQNqaWMYIpoCfESf900hsT+pT06M+gQFqG1xa4qunSnufh7bffwZtvvol169di08aNWLRoERYtWoQtW7ZaRgy1LCGIPPC41IMzxlPrXGlhdthhBwwdOhQ9ewod6QHfPwBTpkzB3Lnz8Prrr2Pbtm1YsWI5vl64EB+8/74GwdR7UICiBhUT1yOUmp3ddtsNY8aOQf9+/TFgwAAcccQRGDZsmJ7oq2v13nvvYdGiRVi2bBnmzJmDN954A1u2bJF7Hsv4vETqCUms42cMu+yyM/b73v7Yaccd0bt3b+y7734YO3aMmHCTWJOlpj4q+iCXCzB33lzc/Oub8fTTz6BcLokGh1KdIwrLjiH+7NQolKuS0jts+HDcdNNNOO3UUwVtsxqi2FDE/Q/cj4svuljnIqq8MEA4GB944EE4YtIRGH/AAYJinmBExLl3tuGHSZkslUsoFop4//33cfHFF+OLL77Q60hl/WWtITEtpDp6o7GxCeeccw6uu/469OndW0czqUnum2++gUmTJluu0up/9+vXB+PG7YsjjpiEAw8+EMOGDkNO0s1VU6YaehZFWp98wgkn4vnnZ4AQgsbGRhQbimhrbdPGY+af3ffYHXuP3RsjR47EjjvtCN8T9Notm7fg088+xTvvvIsvvvjcegZ69uyNc350Nq6+6ir06dNH0vh80dSRjDxSNREzYmCU8dGFF16IJ598UjBPlCZObZLceF4IlfE7Arzq1LkTLr3kx7juumvR2Ngoss4ohR8Ip+WZM99HS3Mz1qxdg2+++QYfffhfbNy4SevZ1bNR0zDbaKj23HMPjBo1GjvssAP69++PHj164rjjjkVDQ0PKUd50cCcG82fp0iV488230LytGUuWLMGKVSvx0UcfYdm336b2mo6cvQCw4047YezYMdhpp53Rp08f9OndG8cccww6d+6s6cYJnpgEKkIUCmJi9tDDD+GPd/0JX3zxefZZmJA8aXYIj2n9JpuhZ8+eOPvsc/DT/7kafXr30a7gVi3p0G1xzvWZPn/+VzjssMOwZs1aFAoF9O0r3Gk3btqE5m3brJ/r3r079ttvX4wduzf23HNPbVxVrVaxZPFifDzrE7zy8svYsGGjjLMSvccRhx2Ba6+7BuPHj9fsKstt2dJkEi2c5wkZVkdkEM6ZcYKFFzGGMBLr5uRrpuGt2cvRpSGnc1BjzxMeD8W4i4PIY4sbdV5nNKFWIyClaslPwSGkQTN+PwX7jBiA1lIVhZzIdmYRSzHDbIkIAeGMcxsh4omGsBQjl1K82rVLEbc+9F/86q8z0bNrEVXGDGojN7iyit7JNS2MEJ6Y2wDE1bCZY1s1epW0VM27VY4lhMDzCFraqjh8n53xyC+Plegd17SrVENmygDV2FpSR029n9XcpBw+CXiW0YvpZpd8/aRI1aYbW5uW2bwSY2FxTY9W15bHdOmM6UalUpYifR+nn/4DTJ8uqA+VSgU3/epGXP/LGywtUrKhtSxXYauDTZSZJ65Rctmlmi6SNu5QdBBKBe3xmWeewbRp0/Dxxx9j69at9sarNK+oPRHeeeedMWnyZJz9w7Mxbtze+tBWTYr9vHFJzYmQy+dxyaWX4p6770bgB1rDowoes2G2prLElrOr8FLRnJe0dnP8+PF4++23tbNrtVpF586d8fjjj+P0009HLp8XWX6eLy3hYyeuZOxHkn4CqU9jktsvAmOr+P73vo9XX3tFf4Zk/k9ValyCIMCD/3gQv/3trZi/YIFxzbPd9/fccxQuuuhCnH32OSgWC6hUKghyOSuvMhUFYzm4xsHNQRBgw8aNeOqpp/D4Y49h1qxZaGlpcW/bJDHhN/7kcgGGDxuOY449DlOmTMGIEbsB4CiXK0IjYQIWxgEKR4RHsiFMrrdqNUQuJ4rCz2bPxqOPPornZ8zANwu/RjU0Gw712KbNW8w/Q4YMxTHHHINzzj4He+y5u6YQZzXXromgufFRC6lM27VbzaQ+eGpj0ESL4+M92oy/ufqnP8Udt9+OXJCT1FxRFAa+rxF17rKFp0RTfGL2iMqqZdbaEdMkSSvU+VrChfXII4/C88/PwD333INLLrkExUIR7aV2UEqRyxfgy+LDwrC0s3R8TcR7ZZqWrhohMVEJ8de//hXnnnuuCBmX50oYhjjqqKPw7rvvIJfLa/2x54mJKHGYYaiC3dSIEAKZ/RZq0KS9vYRf/fIG3PDLXwo3v3xBTNMc+3+1WtVmKjNmzMDf//EPvP3WW9iyZYu9nxJB71RU/WRv1b9/f5z2gx/gsh9fhp122hGVSkUXZ57n4YG/PoALzr9Af3+PHj2w97hxmDx5Mg479DAMHz5Mr13RBHKZBQaLqm1KRCwTHUn7DasCfFm+YgXuuvMuPP74Y1i5ciU6+qepqRMOPfQQ/PjHl+GQQyZqKq6a2Aob/Qa88cbrOPSwwzVdsqlTJ4zbexyOPFJ8nhEjR1jxNKKppbruUJ8nDEP9+4844gi88cYbuPiii3HmmVPR1Kkztm7bgvnz52PWrFn45ONPsGTpEmzcsLHDn8fzPAwePAiTJx+J8847H6NHj9LFtnp/Fu7uBIYU6yiegvmeh+bWVtx222249557sHFj/fdULBZx6KGH4aqrrsTBBx8cAy0yK7OhoQG/ueU3uP6665HP51EqifOwUCgIWmEUxZpN7qgXCHUyGsrlsphABiKWoFePnvjoo4/Qr3//uKaQIKjOZZVNoaCG5vH4449i6tSztBSCy5ilXJCT02BmeUPYFgNJ7bAw9qlUq6hWhBsoYxw9evbAm2+8iWHDh6EiI4tcmaWEQO5LohZau3YdnnjicUyfPj3zLDRcQXRraUJtQRBg2LDhmDxpEs6YMgV77TVaAze+52t2AyEZ/huJhnDB/PkYt884DBgwELfccgtGjx4Nxhg2btqI+fO/wocffYhPP/kMi5csSq1nIjWErga7WzfRPJ5xxhSceOIJaGhoQKVchifZixb4Trgl53INDV1u22b9Gdcg3I4jSUW6iYYw8D088/Z8TL1pBjo3FcB5FLv/6vJY9SsOYxse6xRN/aDW4HN7zEnMxAYTiZFgPiVAS1sZo4f1wkt3TJXgqdCKmnsEJSRxbbg21iFc/Ml0OWxra9cLkkgOdzHvY963m3Dk//wb1WqccRFbqaYvvNmZqwtvOlDqVoETyzDGDV0b6AeIdTHDkONv1xyLYw/YGW2lCnKBD9+j1gc3NS48YS5j0dJchjOJxs7cGJI6NpspLBsW7S1OUrRVbhQedoYYtz6vVTyYjQgnMfqXmBqatMZcLoenn3kaZ599DsqlMrp174a33ngLw4YP1dQ5ksjwsyaWGZ+XJCauJmXS0mTWiuRIFAFqwqCQylmzZmHmzJn44P0PsPTbpVi9ZjWatzUjisKYSkJEZk637t0xYMAAjNh1Nxx40EGYOHECdtllF90IEtmgpSfTxueSG9bXCxdixYrlMq6DIYxC4fxlPLSmZsjzEiGr5hTFQFKr1Sq6dO6CPffcE2ZWme/7WLN2LebMmYN8LhfT+nSUBZNB5sxAz6k2hSAJTYKn6LBEuNZ27twZI0eOkPQhQ5drTpUZ03TNlStW4Omnn8FLr7yMhQsXYt26dWiTtKouXbugf/8B2HOPPXDoYYfhkImHoG/fPlLXQ0RGHE9DAa5GxNSlKpTa8wRduKWlFbM++RjvvPuOMB34dilWr16NbVu3pdZRLp9Hz549MXjQYIzdewwOOvBg7LfvvujXv5++/zFdN96PkoJzkgCvTF2zO+zWjnpRVOflK1big/dn4u2338HnX8zGylUrsX7tOlTLlVjPJ+97z1490b9ff4wcORITJkzAQQcehME7DrYADJfezzxXSAKcsuJxkpSZxH6SRsxM1zRqhZPbjsu2ltg8TJcuXYply5eBQkxmmNQNmZMcruOJ4qKPmjrvVKOUMPgCkQYFVNNMVQPVrVt3jBixG1auWoWFX38ttSxMr3HOmfHrYmdr27FZ6jyliRH1KAJfZkZ6ongcOmQI+vXrpxtHpT2ePXs2tm7dGkeZcOP8sUK9ZeMpCwW9p3GuP5vIqxSTmkpYxY6Dd8TAgQPlpMHTxYc6b+KagejCXOVazpo1C2+9/Rbef/99fLNoEVatWoX21jaZDyjeY+cuXdCnTx8MHzYc48ePx2GHHSYBFSCshjoDUu3VTz09DT+9+qfYfcRIHHroIRg//kCMGDFCO1uLvZrL90pjhJMgoazJMOgxZBqiMBPX9KuvvsLzL7yAd95+G0uWLsHKFSuFJlTm6Aa5PHr26IHBgwdjv/32w6RJk3DA97+PnNQPUurpJk7F4RSLRXzyySeYOnUq+vbtiwMPPAgTD5mIvceORVNTk3wmVdwJkRRU9bwQAz6VmYFRBOpRTJs+HRs3bMS5554n3RdtkHjT5k1YtGgxPvvsU8yfPx+LFy3GunXrsGXrFpTLFRBKUCwU0K1LN/Tq3QvDhg3D6NGjsc8++2KnnXa09jiXPt1iSfFkwR/HhIHAAmc/nfUZpj8zHe+88zaWLFmKjRs2IGICnOrZsxcGDhqI/fbZF0ccfgTGHzhemv6Emr6pmkzl1rtkyRIBAMtnUWUwxpRMZsdwEaXpFZnJNAHOmZMjDiDwfOy1117I5XNOwMXcEBln8DyKdevXY8GC+dBxgxKAU3VhxCLLq4GYTs3ShVXowCCHFZ4uxIl8rgI/wB67746GxgY9FSfEdoFM1pwK4AJEDM2sWbMw831ZCy1bhlUrV6J569aUnruxUyN69+6DHQcPxui99sL39tsP++6zD/rLvOEwDLXRC7fNNgCDARIz14iuJz3Pw7ZtW/HMM89g9Ki98P9j78/jbtuuskD4GXPtvd/unNvkprm56QPpCEmAhECIhL4RiIACUkAVZfMrpamqTxQUKVAp8QNF+fw+EIsCf4qioKiAIk0UaQ1EkCaQ0ITQpG/uvbn3nLfZzZrj+2OtNefo5tr7PQnWPxx+lyTnvu/eq5lzzDGe8YznedEIQtg/Dz30EH7rt96AX/zF/4bXvf71+O03vAEPPvQgbt26VTwTb9y4gSc8/vF4ylOeig/+oA/Gi1/yYrzwhS8sIFbOjMWYS1h1/ToGJtK5Rk3jzmvRwMJ0fk2sBDPxlTNj2w/xf7PN+GNf8S/xX3/j7bh5shoZSCzDWAWymJ3oqcfuxzE6tixGEi4CMIVl/aBFR3j3I7fw5Z/3Mnztn/lIvOfWVa19xtxisAJjFWEnHQEGgbLg3UQP8OLiahgSTZUnmZlxvFrg8/7a9+GHXvN7uPvsqHQRSczVDMUhzQDLFDYubdoiDwdVJcuiiybJ3Q0+4kVPxff8n5+J1Wi0ulykmCJV/KjmklMEdChuewmatq716QuH32ASKUN/tNmeZa1WKfe4cxHNQ603a7zuda/D5cUVbt51E89//vPLXJfzJLI+jq5i13YgJJSc4jdukllqUV65JMpSwGOgbPV46KEH8ba3vg0PPfQwLq8uahLeLXDzxk3c+9jH4EkPPAn33nNP+f5J/nlSJLPLjcFhgn+IP9F786fvszIazWNn5Q/yz75gORVnzLUo3+12ePs73oG3v+MduLx9jtR1uPveu91zrskI4QA9oNBUWFLJ2DyP7W6Lhx56CG9961vx4LsfxHrsfg9D5gvcfdddeOzjHosn3v/EYoUxvf+CEpOgaihwSHTtqXoJMUhtsTmL3Slpja79/OICb3/H2/G2t7wVt27fqkXRSB+7//4n4P4n3I+77747uG5SIJpat1SBoQZTXuwzX5yTLXj3UehJqP1FiRZBqR3/P/0n576IpP33+FM6EGBH03nff5dyFNb4qbBdksllIkI3Jpjb3RbvfNe78Na3vBXvefjhYb2lhNVyhfseex+e+MT7cd9j7lNCMRPYxIb1cn5xjgcfehBPfMIDg0E9BlXRyaw5iflh4Yai1LZbZ3DUsbB7bNfv8OCDD+LNb34LHnnPe8pZdnJ6gvvueyye9KQn4UxQ1cCMTs5LASo5X6/XeMc734n7HvOY0Wx7uJ9SGFBXNOIkUENKGUBbOtQZ8FHAiOQeJBf7d7sdLq8u8eijj2I9qp6eHB/jrps3cXR0rGPjdldmP623HiuaJ2nrEsEwIdNakWcwAFxcXuBNb34zHnznuweQarXA4x/7ODzwxAdwduOsXHNmHsT9QMVK7P+JWDApVVvQOUrw/nten+xGld4PoWmdkQXroq6NHg89/BDe8pY348F3PziMxozrbblY4p5778UT7r8fj3/cY3F8dByehcUBAIaWqEYQoP24g+Oh7/N45k8CaTyKuOn1vNlucXV1idu3bw8Mgy7h5tlN3LhxNvjQyrXf90IgUnayrYYx6fWdyFNpo3yuTKRpFhuJnHr6XM6My02Ps+Ml/skP/Qq+9O/9R9x1uhw7xygCi5VhxNVOAlQKr/L3glEpxTn94cXCO5gqXbQ0CRMIGdt+g+/7+s/BS5/7RFxcbUc/0OEmF4tusC1iPVbCwteUcu5ZKnlGBWGf+9GMuAaxu86O8Z0//Mv4or/7H4eCcGyjax7s9DCEuSIFZAVRmEUzKywcHeXBJgtCmiTaiXC+2eAbv/Tj8Wc/7YNGo/pUZovkQT29+mySlxY/3VGxhNHy9BqJdNC1NL5D1DKJq/SsDNJDdZRb8IJJRxn7vskeqiSll8zcX+sZ1G6UcEXhOixLpviW6WndGP55kxHMkTL6fM1iyXr+1U4bG+NPPauifCOLkid7yoG8dvCsGaWduZpMlbsURVg9J6WclKbOlhCiCg//ufc/HtRcSIstCiGVGclEqe3JMyqeEqXBvJZJd1zkWgoeYGudKf+0ABzYlwjsdqPYz3i/UM+JioCIp0aj0NTL0SOSNkLApIYoHsVsilLAPbA4KOs21QF0lTiz9nkd1mxVQEZBc81+FdetJ1ZM1xBVpU52+dUuID+NIGP09P4GwJDtdjcFE4ukjWGpIjxu1sC5tdi8KJhMmRCjzOu5GtesRWJhN8HVNFiaDHupcGjGhkGI89TlK5FZO/RS21xJgWNVWKwmGoqxIeJvAU8FICmLVAn0HbKfpq7NNIbB5WAnBZbKc7bPuTz7cudUC4NyarAfOyjPyixSySKQJ10eu7yH3MvUKU3jnpkSrAIAjWITFs/OfQ8mDLN4VmBK+Hs65XvJhiKM3bBBJMfNAQlmTREAmbknOROmO1btzECKYcmViEjbV/zP6Xvmzt/BE48LW0bT8LT9mGWn1W1lhPwUSleTdpb+yxSPrEyF8cFZErOyGKGAVYEA+GojNRTyFhU9NJiT5UAYhYQ33nTv3YEg1wSYT3ZjLQC2MuTqeiTzzHTZwkXZtXpKKkKNOwNnhdt4YmGMeYS0yZrGBYgDO0FJuWQNnJYzLVrWkh0lLPFM/gcMYjIJhAdvXeKVf+lf4jfe9DBOVt14riQV3cs5zIZWTPE5OQz4xVZyJQwW67s6pgEe4vH55Rovft79+Ld/67OcYCZj6BAeHa3cu5A/uJgSS4642tNjVgbGQ+V9td3io1/8NDzzSXfhre++wtGCRkngQGSAxeyg8vQzRYN8vVzppariVglXTRzyFCIooaOEb/nXP49P/rD3wwP33cB6u8Nq2SHBi2CWqw2ET5QPo52tmRJF5WUiabFc6ToyWWgE9cxcxHVY0jakjhAx8kQDUiIRNpnPI5pArr5moUgz+GGNASElhTArgRULsoAdxbWulcFAljmw2zDJM5lr8h0LH2kjGXd/CKCoR0n1VQjDZ4x2IboTzfFc1Tj/x1JUwxYCshsCI5xDvjhShqyax6w6ztPMoWZyyKQ/KqbGmUVhbVLWs6CXTiUBwdIkjXZSSbxIJV6+IzZ2XlVCz26IH4aiKof6o2fPxGrO1O5N25myM34DfbcWF0xSHdTQLVG9gqzysAIKxgOn7E9TYLhOOCYT6VG6ewKxRtsNotjmYfA+1CABSrIgkEI5A4H6dzC0bbAHNNgyI3Ie9vaULEtfLjFybk2eWa55s5eney8JtqGYl6RjYgWI4nJCeuV9KXXnBv8i8vUkShF5Q3mJMUYLdtLqXHLWop4frAqhKOYSDUDlJK1fig15T9y4XlSLqTR2WSYvNgBISKpoKqeBoPlXWcg6dkBM4MRa6W5EmCQIZTtaVaXPjDAESR3JeMByD08xjhXRxBbqqnDhmPEi7z1hUCLV8YFn1waBkJErLY5JxcoprpXvHkXKauwGaoOlKq5TEcOb5ABrAcaQM5PSkFvQvcf/kqBZOy2QLwkFd5AppGHj+lhUiMRe5kBs9pOcDh4Uk1nNW9nzOXUTpZ7gZ0KrgNmg4uhnswsLwrKypr9JQTKturN1NtACLaEuQtIaBtM5JsEa9V0DKqRHZJLOXZk4pGfI2TS2KBRbZpdgXeWaJ6i8BtTwPmVllTQVzLKQ1+CNLuAmcRYJiBRrNVm8jmlEmemToOA4P1emDUjsTwFI2cKEaBgzqbFP5BDTCs517VTVWy5n+3BYlXaP8t+Tvt7lWWWx14lrDqY6lYy+zzg+WuA7/t2v4Fff+G7cfWNVuoOlCC31iBw50VULjAAcgz2sqsBRBvKUe5qqcfRB3+x6fPofeTZuHC/wyPkGi6QFLm2eLRs50ztblNGJ1uEqO0BljISw2/V4yuPvxie/9Bn4B9/3KzhZHQ2JhGy3kgFUilcfCU+/epHMvmIubgZJoof1ISiXhhEFOVkt8YY3PYxv/te/gK//8x9dZWiTbJMKz0SxgdXs2DhYr3ZMAzmSUjkksg1NIYEjEE+ILQlz+0loQqMMKN5tcuHwRNUl8+KnpNG0zcszyGNQI91hkkm67ZpBoLtVYhIKQWLjq8ONjqPtHE2oVZHMZ4H6M5kBWx0Ai/0Hiy5vSLsgkciboWKqiYqnjQwy+HIWp6BVk5IVi0LR+kGySW4wcNEJWhxp6nKrtRUJIcn3QwF6mEmhsrIrV57TdNAJk3V5IBK7rBbA/gN2oD9KL1EBLCRd1Kkk1thuKMqdOITU3Earu9Kg/5bDiv3cB41IKI8dIE2pJC3/LAqUSfRKlVnCF9KioWWEuFhtQHfyAmXPigrDeO0KoqZRF1ZJguxKykPBZuBlnXifI2a4OUOWWTG0EIgqpNWstabZ20ajbhCSitOyYxRRUxUoQOQrXkUFNF0nMyOtwDOzwnJJMir4Q4mUUEW5LnOuKgBWCp5Ta556uOAkE1SmBqNhFAASNKGybhjOW1KDnMKXrMMepgMpMQ4LwrgieSykyldJ3wIY1UdzP1KQTfr7TkVrMbge7912ICKgSO+NsZhiBCp3hjlU4njds2UE0qCcPFaKqsnNOlmGYAKRpb0BIbuCLEhhrXCS/n358zJEJAGqlrU0+nRaqTxmxAVHFP/ZrhvhkyyhbtNBlz7BKssvtLi2JqQDh1jf+0RVdkAi+RmyUAVd9k8l4Unc87AncwDiBzTyWVYMFQsPGYOy6+S2WFXG7g2eYYWQiCcRUVI5JYR6etGyqPNhAhgniBS/NJIigFA+12m21J/hdVZfg996/lUaDqouoMzxA0adFeCzZ4t8rjxSV49WHX75t96J7/iBX8LJ8aIWg6rDQcojYeIhylhAIkayLB6VpojQPJFgkmKxDPnHZtvjgcfdwMe95GnYbHcD44xYMT/l+rBe8NNDW1xeXc22mY9WS4d65szY7DJSt8Afe8Vz8M9+5PVVbtWpY04UFlI1shZeKQSAYuxZXz4L82phvGsG0OXG63PGjZMV/tl/eC0+7WXvjz/yoidju8vFgHlCVidkwCbVElVXggYmgeLgbrU/RD3ICF6IxsIycoYuVO10wURTMTlLmkbtJqjvM2I0qsCQlBY2BSyRZ0eMn0ktQZ4W54I0vUr7ArHwJfRBX3LIjW7P8JTTGPAzFP1HbQSWHm16bjOeu6SK3IrCVJUMUZdTihhNh7DwRNTH9LjeRgPtyQPMUvVakuHyGUxNJR2AxfQtVYy4GMQG/phUWwe+8HL0C01VZEnON/TA6LotYgmYmdzAp8Ue2NFn2MJTvjtq5bxz9jAUJCLqLB+NiUkriDXc0cZEgjSVxBbEYFfsScprbQR6oSndcfdotT7b2VH+IjW2KAmJO7Xjf01JBhqfCAWqsIpKZeTinZWQoVs114wo+Cz7wdG4VcHJ2rojAh2CDpZGtT0gyBVnqSBW6xmVS5EAJilpAA5Udon12mI1tGfVeRFSxn0SaYykSL8HSvrdWaG5gueqDjrrBJ1bgidaeMNeb6KEIBD7Mx6mGIiMy8rzZr0uLKW5oNGWxmRwf0nnth028jOgoS2EuQe3drMYt9CL3hWSiGiQ0DL0OmfkYD+xM30n1kqPrfjsZvg4/g7FrGESM1k65sgzSMcwCk4qU5BCz6YNA3uy685OdXp6YkmNHxQJITQDvylYw/EDQ7mU6ZnewoEIE9A8Yx2dmOxTYQewKVuq1kfbC2dy7L/w7CdPMy9/T9z+GViKBxSzqgWquOAbsBNtPZFHgHe16LDdMv7mP3k13vbQBe4+WxZ6dN1CUjtFq//LYlkmEin0WWfVIWSYM2UCqEdmyfnFFT72o56NZz7xXqw3u0FUjSnwGLV7XoPEqe/zKK+fkXseTIGnf4QnUFUqTFgsOiwWHba7Hi95zv348Offj/PL7bgx1FATZOOFgyyresHI7srUGhceHmMlDGKFIEsFpPKQp4e03uBvfsdP49bFMDi+2eyquls9RitqaRRH5QOz3SwKaVdBMDd/xZP6JpEonFg9BxApjrz97ul3mUW3Y2p3owrSKNBTvPSaRmsHT2JSxvdsFVFVYSXpcuGK9kWhO9gqhRAGxWFDk5HPgqTZs/hgSWVsDfGr4CE/d/y7ii7DvW9/TlHhPcukyAVhg+5I9F40EkbkuCoDWqotQ6u0So9Ou040+s+iWzBQimGeHWxHy8g3q/Vp8iCYw6hcC1uTVnLdAA5EJOw/9j2r98sU02mZlXCCorETaWsZEW3KdZcueyX0FiQvQHkr3TGgOjNrE+dW30XS1bLcG56KB4XeGkqooZfZmUG7Byiga0diMhTQAvP4fywSeqWAap4RGfoOOdIEKWQaM2eG+u8iISxxrNHhiuKq3Vfy2ZfVIzv/MgkWzISpGJIdSLneJNGB7AHCuls2zGsJCfSpQ0UsOtFckmQKxgQKY9GCAAKll4I0iqorClvbmSdxFskgpgpBuSZKuxQ6HrUKMRWH2eR9gl0BI9VP+j4UpV8U7mxssoqKs3zXcv+zjNh2tlwkfaaLV2+3AjfUmN/iRrHnZ7wQev7o+9deodOcuLSDYXN2uPdMBgBTz1kXdeq8oHFsJHpvcn9Ti4U0McgEqC5tgBoze/Jd2E4gRGeFSNd9EPRiluekfVeAnnoSfEiVp7Rm5Eifr/KcLDRcARSUfFEH52pfTroL2AJJnJ2FCas1H2bFkINonrjzWdGFCeZ1DieCKNCiGBJ2TyWwzdp+QyMHDG4AuoolYDpgNo8mYRIf5YmD7QdjPSrl/tMf/VX8yGveiLvOFqOqKNVAm80wm9ApgSGMssrEa9eQSIRVErkxSTBbbEwaRvWOT47w6R/5XCxSFfOprDQuMdS63dkzNwnae0FCGQ1jYrGTFqNc/+nRAp/1Mc/DoquJbFlz6lTUdNgKjcqkUiQ6cmZRfBYp3xh987Kqzsw4Oz3Gf/m1N+Gbv/c1WC4711lkIEwIpqTPIhIkAwjqDJ1F1GRgkseT2rA5C5EHcuITORuk2AQ9911ipgPCG68VjDB1Ek3L3NGubMA14NIQCNixbMqBzQFdQB5AJViYwDo9H4WScVgwqMA3XssEYkz7ikUAUYm96soLqpGi97P6GYXbpGoAjRRIUAp0XlNo66bOzG4+faAvUoyuycNqokyR7B5abxsys5qCezqtY+u3J+iUlb4nOiccUXiyMNTWByKTTswmdTM6QGxJUskcyEgs8ASzdkkm/zlMCOt6FUnHRLOQnXHSoj96L4tO1+hTJS1LpvWUrQWLTEHIFxtppJxJj0QFHjQohi4BcIe5KYzHzjSNXelhLScNWpWEEaEoAKOK4FgbmklO3mFlk0CQS+qm/2wDFiohI0HDte83Ujl1FLR6LtEoF+87nxXsmARyHPV02urKLkIn8EyVWCYrZKasGR3QM6TsmBKkwQKCMmQnBwTo4inJtUTwQAhYobgMnbhKEJUY4XuqC4NrvDGzwDJmUwAU1cYyObXuaV9H58FUcFCyszwi8c2s8HdSh1qq80RjYEgqW2uArSL2sgAGyJxf7ryUVYoZJ7DrWd5HPcuHWURFbZaxhiPA1nfvpnjmi5XRNmPayyz2nexUZZ3Iy58nORIzqX6SZGwR1DjKWFhCPYfs/Nkk6KkKRjb7aJprE3FyGhMoeQijxEIY4/pp9laDL6NglGCSybzCFfATtRns8qWhEBQzXERibZicWlwXiVGbiC6ti02P2VvKKsm5YNYAixxVqXs8V7qyAECtEFLd1x5sLEBnggI1wjE2ho5h5ItraV0C08CQtGRW9QM85Xx8PkfLBV77xnfh6//pf8FqQaZIqtcNM+Ne6hq2VKJa41ARLiO1lJnr71WxTm2J1aUOl+seH/HCp+IVL3oSNruM1aIr+W8az3HVMZdKz6XqH3KNRUlK2JT4pqK1ASQRQB3har3DJ7z0GfiQ5zwRv/Ab78DJ0WKUUa7cY5KixhQLgPi2raRMClSO9NyFqslNjtr3GTfOjvH3v+c1eOkHPICPe8kzcLXZYdENnc4k+LWO3ahoKAFNVHpIUU3stZKlIZUGh4E6SJS5ue0esHux9aCmaoBpqT9l7VM9lByNJKYHzdlWlCLV0ncQgQjtLpula5LzQZv8G9FWVZWWHEbNVNHDrHWJpWSaBFgVBo3nUTosRKCgm8JsVP5E0kGGGsAGdLBgA8nuIfk5ntY70Ii6pohSoL7l96eAbCYzVTLwMcSEIan8rxbzytuuXQCSsVZRPPtEbm3b+QvHE9PkfbduImTezl+ytKYwQAWL2Tsl8KRhQk3tssdciy4l9li5hqBL2aLyug6Co8BqMRfFDrDFcbA3CvVe/By7ucG4Y8jBetMdTdbdLIooxpqhQZKmxrZI0R3vmATpWYb23yVDgXVxU7EENRxPctYma7W8kJLF7K+C9RnEZOX22IFXzb3NZgTAxRF/X3IOFHJmvKxP1iqJFKH00z7OYuaIXOfGdtmBYdZt9mwqybVY92J9JzE77c46C3iCtOgNTFiZADXZLDBrs/gRGvaLKiyFSmi7qRHPxhNXtWq5T8nM8xcwXgQvdiJR7O0XyoydnuMEaxq9m1NnHffYnNVqvVJD8EXkLBWUFLRMxQKKqf3hWcGCfUaV3aEbHxzSG6uwXu2ssHwWE8hh7AQUPizOyAz2NOaAuaEKJzPzX9YZe5EeEhm4fF5qxMDSmxVl0XesJZtGgYaWwdRia0ow2oriFDVpEeNEDZBknmYEn9R6bsaztlqv/L2cGX1mdImw6zO++tt+Am9/9znuuTF5Dmo6uNWOjqk1XkNBuhVI79IaVqxnORdBTAZjsQS+4BM+ADfPjnB+sS4iepaCOil5wzk1VF5Iqod2pR/aREi1yFkXNrs+43F3H+OzP+a5w+JLuutEe4oERKWg6GR5GoY+HKWbhTrAmYHR32fXM778m38Mb3nXbXQpYTc6jmrqiM0GqMnQcBsgWoBzHQ9Lt5G0s1bB0yiGSBWRVJo37KSn2anBwaKOERVOKR6Sp5VFz6dl08EcdghkF8ZS3+zmbXk51sOvRU/VibftkkQzllHBHM3UcEArDpOsqYsoEVsnndzYK6aA4WwQYsCr+wafQZgprINnxoprKIpB7JkpgAR8SXQldZLUXG9mf1LULWxRIeVvWIXWQnHR3bOIRjHbuRTCTQcZLbo9W2d4WYQc8ks4fMaRqiNHNgj73vMoSlVo7IbuW5JbCX6p5+Zddkn8TIuyzW133hHYkXkOhfekZtAlDR9aSbGKG8lbmJc9pz3PjU3X0IJ7knIW0aQYXi6/tReile2RfVOxRSIa6nOHPcmEpuiD/XkyqrkhzV916XWRVBf3VJkIShlHHVkBrhJVkH1GbbO+g5hibAEgEmeHAuzgbVmi0eRovlavTYoBmmDN29ygdKoa96FYPYTm51VmgAwwKaBK62RWK7UG4c+eLUTmmgjyZLIjl81n0aARMpEDdsmer0Tw/S5qzNyzLnihKYq6OGfFitJdYq1iDsOk8uMv+lhq4ZpRPCeTp0iQuLUn2LKv7DqKAGEX5xvvROzREmMBIa5jrnkSyTFaEz5GyjkzOSIU51bRfXmgkcMdKemisu7pcy5U0W/8rp/Dj7z6jbjrbFXqB5XkVCRf9Ajl2hfWUSaQV/0O9u1ky/iCbMoRLjc7fPCznoBP/LBnoN/1QzGY5BlnaepkrGlqDjM0aEWbtQw7qu/3pNO6ToaC6HLd45Ne+nS83wP3YD2aotrFTeGLgaZwSkNMSVtR/lRBxlkG6i1vfPC/Oj1e4rff/BC+8h/+OIgIyy6h77OSZNVzRTyvyCYQ2GgRWmoWS/rG2K6lVqJhqDuWombpV5JuUulC5KhMDqiYEX1xiTJjVvIah9xLo6hTHQDni9JOiJpJMotjgGg2yY5ob3xAoRTR8aLPZKMuJ+WkLfrIxmdRCEzLWAOrpM4Yk3q1X/TuoIjmJJ59NuvByd8TnBAQSQpnNDqqGoH+hwrNNurWGOqX+noB/tBcp6zkPUlRxbOkmUXvbH5Ra+qw8ZybEq1KG+ImzTmkkXNzPKhZHEfrsbXeXUKwZ/06wES+i/HeMgbthUnxWBVnZtavtY/ddeZRFCrbBMbPyCoFRGP94Oa5JB0/AvBMrKXDg5161/KZzdoFkOlGi8SVaOZZFYYBFbSXgzg7JQ0peG9ylal5pqBTLmlVleZfqXX6/jgM22oujWUsI3uUC6rtOBaS8zhC4D+P9iSFtliAZSmI8zyb2BUCwtTutlpBJUWfD0DcqDCSHfao6OcogTa2XO14qPUa7PpV54VhEahOMSOk6HpQe8qmsmZWmf3pmBhqvcsxnzzLdpBzuJI2ya0DKtgzFjCvY1zk2RckUmZqgOlBLqxKkUQOsJ3+SSrnrNchf2d6n5k9VdzFgmmMJppHnQOQo9giZ3x5D7DMXBtFUwGb4vNEn8U0rhyenY+0/8mGmk3BPqbWOA70tMyNkxV+5OfeiL/9XT+Lu26skEUzKXp4ZcKTZCNGTUzbl4IkVAeUe40YM6igrdby2PU9/sRHPRd3nR5hvWMFRNW9lcZ/yOfKplBIvnIwSIh2JBs7HPV/JxA22x2e+oSb+IxXvB826y0SMgi5WkJMFwXrz8Wq1c1BOsSCuKFEKBwXyKAtAobZ9hk3zo7wfT/x6/h7//I16LqE9bZHzxwcJPLgaKDvpKVsowTK8r6lGXXr0FJBpCSyZo6RUmPjsVKuVOpasoidyZ4p6P4dkhlFBapNUjkoRiyNJETsgYP+DqrjxmWehhkO7ZJJah47JLbbahG0VqJEsx2GOo+kPNeyUYBDqxjP5fomOwQzX6yNVyc/SYPURaqZfhZUiPPIxB6mEJzep0TzxHVpXgxGbj3NdoyrJH3WczBcze5zENRZocZw9MQs34dI9qOCYV8yJeNOkoFVdH2rImvtuEHMU0ZdHzvD0xIDiPaHMxMO4pQtJuaKRQ0OkhFc0Cg9BZ8PMTdk2RPcRP+5jfOR6S6IubWp+EwmbhXzZXnoK5tPanaNZNIaF6uEMJWnOpM9zGyIhLKFyEFU0mLBF0p0NpR/R+zgQUQLuTkrKu8row02tAosh8JDi3CxjAOy7AgKbTZz4zDiXSWJT6IzI9HtmW6uu4cGkwBTYWkSo+kVlFDF0XwXApVvv76LfRW8GFd5DyKme/EtYW+UqMRG952qS5QQaigZUJY59tm13R1XXOZsnrHuHJd3Ic5SVWiykKrjGYAKjk1nckYKLTAK0DOeH/tEo0p+lQKNBIaeQxPvKQfgVqHvs59vnhgYsF1w4ykbgg+m06mo7gwPkgrFXMbh+VqZ2eP2tYSdQjGnZwVtwvvJZr1lAHkEFM1z1rYgHghJJr5Qg81GoweqZN+0ikB7aetNj9Uy4Q1veRj/2ze9CilhsHKQdAc23qHCnmr6jmkuMtDfGlKkzP4a1ZkgQEJoNeXLbcazn3IvPu3lzypdS6XLQZJ9p08vGdOIKliUdIkGJRWsZHitdO9YcVJHA8d2l/G5H/cBeOrj78LVpledQETBmaahydppVFxwoSBWaKQmKKh+P8sVRDXCj/eSM+PsZIlv/K7/gn/9n1+Ps+NlQSDhanyExZ7dENSg9ngRA27SDFWwlr/bKuDcwtZIM0ygpJnDnpn3F1rw0tFRq731GXJ+LrVAqRnKyBziRdAmvnJ+BQ7NhfMoc5YOrWR7H6WlVbQaallIlQ4ydBaD4K4ItQGaNLIcdY3mOpotcCLq0jUpwVJowrU/oOZ/3DpR/K42oeOQbg3NrBsOEromZTwq8BsIpd2/0c9wC2U1MaC5/g75Y+hvQCB4a6g9h3TdLfpKEZhgE7lDr92ovTaLQ10dhHT+CJVn066x8arZWeN2JGTk5mrJyKGQTKELMYUBzFIxSQAq1HZpEVROHDYv2Opuis/z82ksimSa6c5wfAYBzflkHcPN5bT2yyGxgChUJp47zxkNKtoccAHfUqQ9V2ffVaurT4zDYoXVQIgAshn639yz0OcrNbuOVvhAUqZtDkENEML/g8Ky0c/L3yfNAG4t8IlaVjdihdHMmI7HohuxRJ7NaNiHXS/St4u+vcA9qmeeQpr07N90famV81qA2H69Ha9jbtqJ0L7zIrBeYQuC7mH0+HKqnRcyE3JmHK0SHnx0jS/6xh/BW959jtOjhaoVyAhizoZXpqaoD4lOtBMiosF2r8wWyjOFgO1ui8/9hBfgSY+7C7u+R5eEPZqg2JISIaPZ3H9xdLwSQ+rTcOQU3Anb7Rbb7ba59lK3wNFRwqbPeNZTH4sv+KPPx9f945/B0fIYfe4HJNMYXatWrhNboDIf5RdOexcMoipCCVEQOab/SCkh94T/49t+Ak9/4F68+Dn34+Jqi6PVAp1o08rB5X3BICrcDqFWUjC7FHs+wbXCIZ4b29me9ik0ew2hf5t+wgFKGT8mPbro7Tr2b964uIpFD3xwbxW+zjOHxh534N8V+ce1wQFCxNmhgIIiD7bWMiHaF2RmfHVwgPmt+PLZYjhARGv35YCDSyn+UXAI10l8ihBuG3DjKXtVqDbfUUN8ovW7ypQ2KPjc/k1JUdFozzWQSRbswWjR9oOLLAEakLk3MtfL1mYHXlSD54rjALiaBW+U1Y4pWtkAcSoBYEcJClXqxt9NQKCyLGZtGiAWBc/Q76821Vmlk8aDLVJcljFGqjKqzgsCNkUUB7l9Vsn972ihATNA7Q+r7Nko6jigbjWL7Bb9C1r1LgRfiHDo4ALNPDP5vvTzCzi7wTMI/10gNOfun0itVdjfk3sgyi3sHFXgHdqM83b/yd8z14jG2RUD2zMxitr5Pe8p+KeGROh/KJk4DW/oKC6xLCrYz9orTTry7IfZc5VZAPQ0Z4fqu6FSXCX4vcbRF5AV/N4alqOc45hlicbvX6wfK3rnRcgk2NFQxKb29SICc2fOU5rZ+wRd08hwYO3Fcs7YjrTLTIy/+g9/Aq9+7Vtw9+lqqGWsZyMB8ZOqpvDSM1L0DXVdI8QztT6V9FNkhbtcbbZ4xpPuxWe+4lm4uLzAbsdYLhKWR0fNaMicSy3Hzn9xZG+w1TM2r+T27dvo+zZx7+zsDKlL6HvGokt48JELfML/9s/xpnc8gqNVhyyMX0kIU9DUITTCJ1Ixqb0UdNpCBn1igWjyKK1FI1N30SVcrnd4ztPvw3f9tU/HUx9/A7s+FxsNNfwUFX+BB+FsIrynGAwVTtE2ofUHrNY10qpi3CwGo2u2CVkzIWV4n6cZlFleL9kD3R5K5q7cTIHtKIQeiPXq3WezqGJLghejiLhul2ZyXEYMGrToiVYZjg+5BqFuOrfmmkWSNWbdw9G/7hqPCtU2hGapFj7JnwNW+JqiLrPV+L79sfdesLfjHaoIRM89ADosVYqiBPOgR0Ax6BGsSUYw0G8TdNlJaryTVlFtC7LW70dJL5s943zyDgTo5vZrlKDMrf9ZYOIa16CeJdvz0QMihwJ80b9rdcHnOmoumTbJ+hzIZAEINmfBvuuOQI7mOnagpF7lSs9xRvE1iuPceCb72DitzuEcmBe+0+i9UeAlbM+TwKM0fLeNmBYWOg2BOG5YeEmHttrpq5Mf9F5tH24KqzULULnvgrPIdiT3gff23coCXi01pTDqu4hNxWCwBqFU/4rDvSbzWPede85SMuCs/P5Di7qoiJYKxWGcn8C8FksnsjfDpPIqfAjs3jefl3koCpeLDl/9f/80/n/f+/M4O+6QezkD63cNQ7odaNB/ugYW5j8McuBo1fqUusak7mX62kUC3nO+xtf8mVfgL372i/HI7TUSAavVEicnRzHRhgi73Q7r9VrcM1V0YPIhlPQ0/Y/GKaZWZBlSn3x6xo3XJWCz3eGx95ziiz/zQ3B5tRPzbhL5GFWGaj+5/i1JfKSiG36RakPM6h0UISukRjZ3OePkeInX/8678MV/94fw0KNX6FLCejN0MwvtIIWT8YdR1xo0UotuWdSWDWIUUU8djUMYV1KoNLb/iqf3erC4xhwCONf2itBdM18YBZDqt5ea6DbMXIoyg3bPRHrccDhPISkRByV3xbpq/7ph+Hkesvc11/FtdC8jmuvejpnwYpp+Phw+v9M/+z6DqLlElTDHdbqlaM/9zHbwGp9vpb4RvTP53lrvTJpc8yBrLeOvM1/fk1SqDlALTW1QIuUcE4K1CbMeWkWA6uwcWIA54RrAqSnOvYvWM6CA6ndIMcgNwQQ09iz2xAXas/cOoeu6Z2mpc+KZR3OmtAdEmfu7WfqdECBxa2qGsq7uK6Vwv+6LN7IQk5YKEYXZxnypfi4FHrL0KIUQ7Wi8k7mk1M0bNujkrTXRAlFo7iwy8+LOEjLqVDKHs+R2REDFtGDWEcBBRVdLpGpKs5KavYvjNx8QH8Kz44D4o9aPiHXR+bqvGIyK0RKLjCBgGN9g5n4DQbhyTdyKT7FSuvxc+Vw5Avq4JbojDM+Z9Lym+dmM/ZTxaIwmUkGNmyHx/x7Wb6ruCdG5TAKKYsZul7He9lguOnzTv/yv+OZ//Qs4PeqG2cdQLEkKSOk8m4SfZmZrozeJh3Gl4+/h/06z1SBCRwlX2x3e78n34PM+9rm4vNogJWo+Gg9MjWJt2Y6XDf+kueOpDFuTVq7U1DtdRFytd/i8T34BPuIFT8Lti+liCU37gAPyxflAWmk8pfI205s2Hd/lQWTmZ375Tfhz3/Dvsdn2WC077PqMZsMUMyqdhwSdILA1xSJaM11oqw9K4/V9QKc79GdnBGzEOWBs2Rq7tmhB1yiuSRQGBx+wM4uK5g73RlJJs0m2/Ov9M0lNOstMMREVrfu6P4cUUErkp3EAW9VYwgHWDHuSUHdtcwd4Y+3QzPO18znNpHxWRY1mKch779xQyLyao1YKVNdyjc7WPnGcOSXKQxPVZoHFHIJlc6IRzc6c8Xl8n4ASe9biIYXIHV2HTLxtHNkTe6Lu0QF43EGd2WsXyLYAOdBPtHnEXzO5d92XGYBAFUJB52yf5QFTtLGtCF7wuwFItzc+HHjvbGjx+xIkPnBttsCP1vgGB3lFbuwTSz++9hrZU1TOPYdITMYC8FmeZSo553aeJD+/EaPmZtLJAs5zcaXpr+nPRQRzu3P7o2m3tGc92tRGquryHv/bg87/fd+/b2ZQfQ6LVIm8JYoEZsfPPD1a4P/+d7+Mr/2On8bxsor0SKEO1UgoXTYLRgmqrngjdkiBRysdZUSN2MptqnG6RYeLqy3+7Cs/CE+87wauNv1YL7C+3qaCGDs/IAlDpDkPIt3+wOhdY4KqqOwW41Dj2ckSX/4/vmxosvFA1kzwnj/u4+VfNGSwZRVOU0gaJNl8gstQgZxRVaR2u4x7z47xo//1d/Dn/s4PYjcGsM22b36nSuJFByVapCzU7qLiryloEco3wxVFCsEno9ym0szY5TaWwofmiAt1R6F7PC+2A62ymBpo+0EH1gHJZDSTdGjR2DqYWkWrFecgUENEIFYhjBBxanRIne3JhKpHogz2+Y4qjxwgfSlaW9AU3TzZWAQS5y0PzVnEziKSrfc6Y00gw5Y92CjoOLjCzchyk0mKnAdfgObOde1dQRP5WcrftzNLozUb0f5O2+zathSv8fumrm9J6K9Dp5zzOBSFAR/QOWvNTqskSaL0B+7j6yQd+0SUDhJjmdurcl8Hhs1kOmr7ZkWLcXkU54C9wFZLWfWalVj5r+lA1c9DC8zrvK+QTh/YNFDUTRaZwxS5E6AUwJUvmIn8VSAeewFOnikabVextZ8OKRqJObS0CDs94r1l0bUKVaVbIKoFnCPl7UP3IsxMX3R2yHfTOHMsw8DmmYRquRAVZyxYMvZpT6rFjvYqBbb2jFiU6zuERiyYJHTAORCdcfadzeY5UQ4ilcSDPEdazxxS5M/FHd6T5+/L02wo8fFivjDuM+NyMzSEvvtVr8NXfst/xmrZjaqbuRZbroslxY9YZSfD308xXxZ/pl4owHoSIjB1jClNKvVjpOrSArcuN/iQ5z4Bn/9xH4BHzy+RiEaWQx2bk96kjJZXbRy4kgtwoYSlR69pbPUn8Xtdl7BcdtjuMj7uQ5+JT3/Fs/Ho7TW6BDB4diJQFcgMpUAXDhVDz8dN8r/WtAIzgWKbGffdfRPf/5O/hS/5uz+KzY5xtFpgs+tHRSEOitDa8kXDK22uQygT82jjoEHlmkt82HQWfXew2mgcXPhIn7WxsDwE8bdmsRElzRX/LURQWnXk3KSscHD4HUKdanWWuBmAvGWA1rFqy/lH1hyzCW+kdBd0LaeDLKIupkBhjgOE09pTkCgi9ib0B/ydnblydgpoeMIBVdo6WCe2cD0koQ1VX+1130HCq2Z1AiuaZsEm9wzpN3Koyp0+q/xMbfTOD+2OuUI26Ay2jNDnFI7nREps8XnIO+a5olUeeII6aP++FTP2JS0UzM+FptJBMm0BAp4FReJEspWQtgCN2bVk48S+rl5EB7TvgBpF1AGd2iiWwPiLqZEJR68zTIfJixTswMNm4ijifTb00lYsEbzwuFhrgaPm+fGBRXoTFJL/5AzkmTh8DUBln/oqHTCzF64hsz/tGow+NwsgLgK4J4/UfZTN6F6tlQQEgMAB4BmdZbnB7mqNl9j3mhqA51y3Uaq6Y0+3t/VMktDhkE2VLHx859bOIcBA62f2rZ+YLYeDR12YGX0/ACJnx0t8z396Pb74774KadFhQTT0mADkQj3mQo6Tqp8cdE6l/ZkxWK1ei+3MF1JtXZK7mTPyboe/8DkfhrtOl8h9rib0gYLvLMCbWYt3jjeS5h+epCJamlRAAx2Lju1u6LJ92ee9DI97zBnWW1aSvlW5jMQIJbcPD56Pe0VNyCahQuVIXS9RofZtdj3uuXmKf/Vjr8ef/9v/AQ8/eokuJWz7HqFsZFQ4OBXLPe1zIPBvavstoTFzGCXQcr7CNZ8pRqPoIOl1PuCQ4IO6f1rWmg/q/IV8eKE0xpG8tpHLp5nuxz4LDm5uNJ4tJmXn1qF5B1L4lNGqDf7CHLqFUvuOvOhivJeUPPXszP1RoPIYfsbMv2sdGHOF2UE0RWbwHdznQcVBRFebSaDVzrG+sAd2CWfnNPZYa7RQahzQiZx9znMCIXafRwXrNSh1+4CefehyJBoRFW+trgi31soBXTCa6XJHBTId2L2kVrEmC5rWs4vWTMO2hQ95J2bfcfRdewUtdDJ4iLptpI5NdI3kNOrgRtebc2AHReGcuzp796zFNLMu0Cg0wkLbGtjusaGiRjyQ+cWcaJGLlWiotDYA1H3/ng4FcsWs6aEaEPsACiD2iA3jVsPuCXuyqxZDbJ/I29xe4Dl7JNvgkGNXM9fGe3cdrnXfh3QGcUBM3fde+8zY9j2WywW+84d/DV/yd181qHSmseNGRmwQWgPA2dwby1uWfnBKA5MihbLAiFADIYsEPHp+iU95+bPxyS99Jm5fbrBYLJCo6j1UIJ/2Hu2loaFydwYxZ56xXcL5+Xnx3xjqPRL8ccbZ6QkWi0VNzBnYjV+yWnT4+n/+GnzdP/oZ3HW2QO5z6asQSJiIT0USK7He6d+Uo2nqHMrHNQmVOuljIfpK+5J5wrIjPHLrEh//0vfDt375J+Nx95zicr3D0TIhJYpjFM9sGGpI7bJB102gOWieBAil16sMvFd/stfK0L6Ardu5k3b+bHBV8rsT6NDopAQUFat6iEB8w3Uwgse/LxFsIeyHvKNDA1tYwjHFOEQkaT5KkwN7lCJbz2SfFHxgXTC7LhvKlS15cBhk9RAFT77DtSivf07RzyXgBxSV1FJHa73zVoEYJTm83/qGgmvlQ/ZDoIbHc90GzNOD+cC10lynJtm+0/ccraeWdcOccunBCY39+abNQV2/71UMEfu+Bai05tebSa6gMR3sV3fAc9pbBMwoKs8mnkKFtbUO594H7QFT6FBVyrmzoTVruWfPz+73mfuM34f3s53A+LiP+r75w9GeOAAssnGabexv/T5zeIbtAxPfFzPK1qpnb8Ezk7sdkkMdTKN/H73XiM0xx6Z4n6+dfbGr8U5b17LdMVICFl3Ct37fL+Frvv2nkIixIKpeg+RBdUYeLbK4zA4SNeLzHHDt8gFjrlAD+0g9Tch9j5s3TvG9X/eZ+ICn3YPNNmO5SGI3D+NdJOsdaL9rzoPtxKzu48XFZWgsM/1l16WB46rkrY15NiqFUxZwiQgXW+Dzv+b78TOvfTNunCyRc1+5rkWUZlKfZ2EbSOpJyUDQXnRCabN+qGgxUqjcPf1I1yU8cr7Gy1/4VHzLX/xEPOOJd2MzKg8R1SFaEvTLa/UZ5DMMDoZDPimS7W1RNGlP9+XQjUyio8tGYWk28WnV0OO/5Ka5TnBwSE8l65M3l8wGYht8QIApkvq8X0AHBwaqw9cJtAeSWfctgYRZyw9zX3SNJN4mvaTAhzuO+s3kiPet/yjBOlBoKInv5AMMgpnooK7Tnlc5u88Pue9DE4SDwQC4YH5QIdAU57iDn1PXP/P9zBx66u2NtVbd11jrHBID9635MGmdmduZKwhb9iFzPqIHJXN7fAjpvUzmSPqT7UmEaA7sEV6RNv7P+WO2Pov27DO7f5wX6b7vaQC6d3R9c9ctLQve6wik8zzMJN5z5wkfWFDRAWDlQaBzy9uxAWqpHKRlx2L2Ec3kl4c8l5YtSLOAnc4kMcPe/PmpEbLPu7G1NyMgQcbIA+j2c+/G+VnuEcXhuf11DVDqun+2PWPREXZ9xt/6zp/D//d7/xuOFkP7KTOr5lI1gvCJGdndFWH5JIRl1Hk0fkZzP1NJkgmELhFuXVzhq//0K/AXP/eluLjaYrXsRqs8WegOthLRqcvMWHQdjo5WhvUB1TCjRx69VTwfqHRruHQwT09PsVh06jflorw4v0Tf90ridfr3fWbcc/dN/JfXvgWf+9X/Futtj45YyP3bjh5i+mjxyRh+7pDipf4a65lEHnuPKpjX309dh4uLNZ799PvwLV/2SXjxs+8fO4Xd2CnkgxN+OxvJ0Af+dQ6cMAGxXk7MCiE4fJMJgulBHRtW+MNBMurNRNXp7e+nWP0BoZoHJdSNQ/uOCqLAbJvemyLrOh2UOWPuO/3sO/iMVoHEM8nvdX3uWgdzOSiv7Td5DW+uAwp+vsP35vc+DjrU9yXXhxRdhwBY9Ae0R+9k//KhnegI7W1Qbs2EyP4OyR9QknNdMNIi/IcW2HNKp2GX8k7WduABed09cej3y5iLmSLBgmYtw3uVeL8P3/WddsvVu7XAzwEiJ/s8Ie3PHlIIQyTEh8ROapxRvGedN/f5+2Af7mXLROyT1nUfCMhV38a9GpuVfhh9j8kh2Xj83XFudafPdcYPWd6SbMjsp+DH2czVZofj1QIP3brCX/nWn8C//LHX4/RoMdQi2Sh1NktXMYbGtU4Sdn5gOiwXhq11uBaD09tIqcP55Rovf9GT8U/+6qfi3rtOS+FKgtZKBOx2Pa6u1t6ZchTb6boOx8dHMSg7votk0ZFJSZKMuszkm5WLuMf4tQmgRFVCfSxKBm9Cwnbb4yNe8CR80We9GBdXO6TUuSEIJlGPE8xnlRK7eGi4naJUVNnMTlGZy2HADZCQ8err+4yzkxXe8HsP4nP+j3+D7/+p38LJ0QK7PmO77a0d1HygbHH5G0hlhAiRv0XN43ef3xCL2Zsk1lm3tGemRc5iKll/oZAVyX5zhFAyvMJV477lr0YOGNXlhaoSVqAKOftMjFqr+t49cwj7gAonumA9jQ5NzNCQcrfzGhyLKkVJTzgTssdTr3l4t2aNAiEmngENJnU2iroPd2ChUBIGMXu6t4s1/aeVJ4efyUi4DgXJzFIxz3z7fruWluUDxJ4AN36H+fB13Pi9ffMt3Fq31wCTDineIrVAEuqllNK1vGSnYocjr79gDYQiJY05PdqjwNyaWWztwbk1QjM2Koc+29mY1KJGeYPjg64z/F4zCk9mHi/8/sC7sRnvTOfGFv22e4jAiuBgK5q5+4/2RMPyJzzfIv/DwLoo+p7p7N+3RpI9I/fNbJs5RkvxS3PCNq1zSdyTGnMQwjTuLLzDYpAPjHXXKawpABBmxbcQxA0OPnVmXat7GGNhy5Px4DgdqagfaqtzoMezFW6x8YyIVIEk/+z6jKv1UAz+1psfxuf99R/Av3jVr+HsaFHzAVFLhz1tu8VKrSLvj0vTpwrye7sL9ZSFl59csVOzbNf3uO/uY3zVF3w47jrpwGNdlVLLJ9YeBgeKsY3aV3Tr0VtcJvcmyWVx96enJ1h0ydfJ48VcXFyg3/WYJtJUbCJguVwBRNj2GZ/3174fP/nffg83T5fY9b2EF1WSVCiZNLFISVtniDk8polgWouh6X5s9ava43LA3C0ExoISNv2gNvrlX/By/KX/4aVIRCOFVAbMuHMqV8+c6uahCMpBHck9aG+cgA88ZbBGn1wAjNbc9Pyv0QoggeK1KB3ywL0uXWYWUTRoKZt7U52Wue7snXTJ7GEUUY7YU5BdwXjogTbzfdft5EWI6CGdBTZF4t5ElPf4fDXopQd99gGUG0djadDC3D4UCf5eCu416K2RapjsijBzc+5XJs28d3Hu7ywdTIUyMYsPUCEMhXqC5xQmWofsiQN8OcOZFblupnEBkEKA3fMxcZP3rDUEcZB5fwyYo7dF66AAULLgsTOwwWeSBMP20dGja54+uzHrrGyOguelz06hdt7olLt3eg16bRjjA4ohX+t8vYPiAwjppJb2H8WFZlEONEW+SMQrlnlU0Cm90067TIwRJPete4jGQ5pnfWueTHTC9r0z9xl7qLx8KJB78PMxIIDKStnwsoJhhDICpwWtohl6G8PCn5tiQqOoDN9Lyycyek4WnA7foeoYiE7h/t286zOIhnnB//Czb8SX/X9ehbc9dI6bJ0v0OY+1Rx7XR5i56FUiCnE6BKEVbCAllj7OBwJe/X86X7pEeORig6/9Mx+JL/30F+B80+Oum2fxHiZgu+0HyiilgKHMSCmpDqGM94VBfuvWbba+HfLPUBB2wuNC/7m4uES/y6UatYtudXSEzMDxaoFf+e134ZV/8Xtwud6g6+TcwfjpwQshoQg6bEo2Z5FujRJrM8eqMio7hwSnulne+7TACd24Em9dbPEZH/Vc/K0//9F48uNuYLvL6LoB1ZqzX4gmDN9ndEdxSMzRLXjPwT13KLkuyYHX3jJqJXOhNr2/LlmSggO6mSDLBLX1LA4QofmD+nPQzOGcZ9nMjMUfVOLiEuuWr5ZUesO8AqH6WZO8Tv89kVQL5ju7VnMwHvRMRNKqqIINSiG1DmOT3LXoybqYa89c2qJiTiimKdRxzcTZJaYzsYGIBtuYBkWtObfVWL9susxy/TVjbTT3FMwZRtclE5x9j0nRHoPiwlEMr7kn98Xgfd/53yOG7Y1j1zmA6HDg77qiRncErL0X7+d9dV18B2dymKeO65rUtY2AB3P1y6YGyNAoCstoDGIguQVqzD6fFpVX7uFrznvPjQy0hIP4vew0HgpIkAFw9TXNR4u9Re6+9R2Bc/Dst9Z4ixMrM3ma9XRsdrrU15MwnKe9YjLMQ2dwtUzY9Yxv/Bc/i6//zlejo4Tj1QLMWfahGjRRCAEZQS+XbEMWTSXzvyvbsX5Gy2fWZvHLDnjP7St87Ic+Hd/5Vz8VebdDt1jg7Oy0GXu3ux3WV+vqZyhsrDgzukWH46Oj2Tw7qWXE5KxrpO8DR5QF4ZZBgrQ3vcBEhKNlh812hxe+3+Pw1X/qI3F5ta0dkclMNnOwJo2RQfH3sCLGlf+bg1jFziiDKzt2UjcxNNI01qcZhLtvHuMHfvI38cf/yr/Bj/7c7xR1n8Feg2IpYgIQ0Bc5kKIm45HmioADVLGckbjs7u1p6UfCLpaqpxBCDswujUqftEkotFK6zqF3AG3NdGk4kKMOOww2iZU+cpKGcp3CfCYROvRzWDzzyPcQEe1LUmVmKJ/7utSMtqQ39iQAds1FP2/9E5ufbW1DyNOTpX/YLJVyplCL6Nux2e0eSpbw4mup1EbdsOKh2PoOova6aVkIBPszR4VfROVu0XAbcuaWjjdLNZLeSw0rBGmQHIIfc+8kKJQJmqYun7Msyg8JSVl4ycVq0zr25UByHzAm2zMzn9yId7TnbAj39jVUAPdR4SI6G1F8Bs3FYLdWKI7/jDbN1H6GToCTpo/tsaLZZx8zZ68RxtFWsrXHruG6Refe83EuxspYJIBl+XbK/45ig/icWLxH5kGxQqgzdZ8bU5lGlaTNkt1fk4XWnnOJZmJ96z22BN7Uvjpw5MOawoc/FlDffcNhP5gv37OLvXP5JDBv4WT2xBwYxDM5rPUirvlyvRE9GrSPmsrImdFnxmrZ4Tfe9DA+56u/D3/j238Kx6sFjlYJPfeCbSA/0kcVngGmKCzqApVS1iyHYuWn8q2pYGR0CVhvezzhvlN87Z9+BVaJkIGRJjoTB8L2ub2e4D1QLV7HDqGs3PV3nEyUUeXAWDf6xcXlYCdBcXfs5OQEXZew3fXY9RknR0t8yd/5D/jHP/RaPObmMfq+kXwbOwmrJzmwHKMZDG+5EArNFCoLivGkyBxg+oxYdgmX6x7LLuHPvPJF+Av/w4fh3pvH2O56pBRz4Gt3TFyTpa7NqVDNDP6HSp4BghUhdLPiM1HWs0ecYw6Juo4SokTGrmsOHaFTe1kFe5A+KxKgBDz2KY7Bz7rMIqECNZVrsakgewAdb6/9QesZzvinRSq3h6hDunVlZwitUtkB6Od1Op0kkp7ZtR4g0HNU1VZhsQ+lnRNkuq78/765WGog54zYCqMo000dhEMsLWbe+z4Z8UPsBd5XHSyruGcToLD7UR6SzFIOyM4D4a/WGmkj5e+FSEljgxyi/HjwdeyhwkdrU3cMGFHV8D4Rt9gn1HGnkvkBsOi6Vdddl3tYE5Cfv8c+5k46mHSNuNu8dtbCG9H2YCn4EXSc0OooNoAfRswUaibvjWelLKwOZBDNnbuHKI7SXAw6sFMaXgPjGrRKNHO2Q9dO6zm5uC4p6rbDyFxHw2bWWNh9HG80Zx67gh0yM/7Ff3wdvu4fvxpvfsejuHm2RN/nIvs51Q/x+2kVI7XpVnO08mFtCwquLan5MD7UXwmEW5dX+La/8mn4nI96Nh6+fYVFArquw8nJceN5A/2ux3qz9aDWuB7TpDIqxbTE/TEz6NFHb+l5zawv8PRs9BmcijARuQnA+fkFdrsMSiKVFdTPs7NTLBYL5BE57VLCg49e4DO+4nvwa7/9bpweL5Gzml4zyUQjgUEsLSypPUrB1NZ74gWpQlhwGyt5dPj9NJpWXlxu8EHPfgB/5Qs/Ap/80mcAgJotDCW4ryNByHSNnz28g9MKmm4+4NDEpOUVeEiCtIcyd52EoFUkhB5hjeAaFXtAQ0q9Nb/RKB6ig6h9iF9Hs3X+meRrzNJM4hkk54j3WWq4DcrNWeO9if2M6t3+WTGGd9YS9xUBFDNPmA8pKKdrEz6Y7f0jKCj73njLu8wg84XmZffPHrEDitbBIQnAgbLnc89wLr6o5C4CzIDZ+TK8D9Qd20kxVVL7zPac8yNr0aUjQGQWVGmADRxcmJwKD0GimXVAYVJ+2LlE1zoL4oOx3pOYi5qzxTF7lEQXo3VuzSXZkferA0/2fcaBFNrJRaxI1NN8gTzlYiXhbBY5FHcLomIrYpzIsytYLxJg4VlU9c7O9bkzqyjb2q5VA2A6VJCLZ8C8OdZC855a4EFLvXgmjkmRMGWIPjeDicOtx/bFnimnUFRjIiS8b0dQyKipzgE307/b7DIWo9jKa3/7HfjGf/5z+MFXvxGEgaHY971Zw6Of4MxqUbo9bDLMiQEYdEmpke/VzyRVBA9/P8S5ZZfw4K1LfOlnvwT/7z/3Mbi42mDZpeJwIH0ES3E6hrOUErquE2Jmst4bapecc/kuVv6zQ8VDFxdX3IgHZUGkRM1txTkPZo5ka5rhgxZdN/gYjmfJdpdxvOrw6te9DZ/3Nd+Hy6stukTInPceq4wAgWrpEZOuyL3qcX1B7DJEiQLrxTEpYl2st1gtl/gTH/NcfNmf/FA884F7xlZ1xnLRtTfoXu5zw4sK2kaWZxLMfZvtoGm9ajB5WIcw8vTBNeSi36sAojcgieSFZ7KTg+T19w28TxSoOTGagwzAr/cyC8Uxugfp6wU/JxEm9vLfS9GfYPicrjN3996g440Eztq5HNKlkUJId1I0yM7SobL49vLnLGPmuxFtK5nDOxK6KOX39f6bKW6jLqQtkg4VrXmfzocdsBYnfNCFQLrmy9/zM801dYfJXCumRAV3mNBgj1fY3H0GYhN0IDBw3a6WtFDgPZ5yNAf23Mn51Hq315hlC2fVDik07vDccBL/M53J2Rmy2X0PVcRLhtR1ZktpX6FzCGjSKMjqWc3aMgDXnOcVYybldxIpW4JrBqF2p/S9AM3nij3nM9yY6+SZfUyjGgojECJC257nTtfydE27fhi9WC463LpY4x9+/y/i277vv+EdD57jxukRwLK22GNfpRQmfVEYTstyi3I+k52TKevHNbRYdLh1fomXf/DT8c+/5pVYdQNTOo3Pl4MGkHKH4IEua4FLeS3dogviiwDd+j4zQSqiyeF5GlRE+97iEqUyPT09GjqIDV+wi4vLoSoVSU2fGTfPjvDt/+61+Mpv+TGcnK6Gl5Y5KAJ1MajKRUn3LBV7O2HTL5dmom9oPTy+lOE7KCWAGbevNnjq/XfjSz7zxfiCT34BbpwsseuHBdgljZ2E1E9laOvFVVqbSfHxOS7xDkGSqSXoQtOzZF/AGgQxos7NUxL1TdypGMDcgRHRYinyusR7aSJ/Jwl2QEOd/Rll4F3gHGGpgvDwuU6ic1BxPDPbtvcZ7lMTm+sQ7un8tNbwrEBJg1Y9fI7c843ODteFTC2+e0XH3Ixykz7M7CSu66F7mPepkigP2BG2hGSCEZbYT/sOu0wH0vMik3RqdC7KHFcLkgxk5/cm33tozhL9VXEtiLWh5t+B8cQVXrOdW1Zq3J66eVgyJZURKzjoRyTcKaga1zNx+hqAy5xS6tw6RGMkIDwfWYuizBY+jXcwq/R8wLrTnR39/rR9gC5swz3hgFjoWSsS3UOYGT773hr3tZfFgMPYRM5P9g8IODw8DzFKnNS+x7nPbGeI77v7U952gRiVuqYidDJHqzw8vzmksz1pfFCrS1tmwtvKwDgQBIkK0j5n5AwsF4MDwr/76Tfg73/Pa/Bff/2tOF4tsOrSyEo0nLHC9ORQo8EaC1KwkOrvcqkH5HzboBUyHKzTeJqKu6JAmyLZoutwtdniCfce43u+9o/j/Z94E1ebXlBih185PTlBJ637xJ/drsfV5eW4Ljx1JXUJJ8dHYhxouA91DnOeH5eeCrro8BkKwhMsFl27IDy/HLwDjcQkM+P4aIW/+n/9Z/xf3//LuPvGCfq8G9VGNVdiKkyK7keI0ggerKjC9xaEaFdbNKoD1XeiEXnC0D3d7Hpstxkvfu79+F8/6yV45Uc+G4TB0xCA6LDOB1QSXOWm/YBJVhgz/O8Z5b29hZiEdyDUklzRhfmE8E5dz21f/ABYyQsxa4ni97bwOySx4VaSOHOANGXGS3CJzGvl7E0k2Y/4gAiEASjy3tqX6BzQubhWJ+Dg2Z+o7YF4CBn751avhbQ6PnK8tv/A1pkIYC5mN/aZpN+ESDpTYXNcB8i44w4KDd+pFJ0PLCKadHzsp6NiXzJn6HR3ZARuE+BC0a0JQxPUA2a6WbK7633cJJgo/4NbMZShFOiAePZexXh5H9foEGIPMMhkfn9uRt18dkS902u8PX5xWGceB3fgtTYF7/eCex8pl85WbtQCkGMQgK+zlw8t/BtjJTEr4MD1dejPWxDkToqzBuXYWWaJTjXtiUssRLZcUQ7pdRzM2bquyHWqUa3e3zxLrp2qcaDT0XpPpIBPRQ+l2uRpfc/kh74YhR1/7tfeir/3PT+PV/3XNyJn4MZxGkbQlEt8YKdG1cGASBY1UK3iivty+bz67seaxALAZRRtEoox42tmsxKGa868w3d85afij37Y03HrfIOuS6IdNsTnk+NjpEl8yaSCuc+4urqCneGd7r5LCUfGmF6uASICZc6z6+H8/BLMWSXX8sf3FYTnY0FIxOpQYR6q4p4S/sev/QH82Gt+BzfPVtj1pkWt5He1b8f0ImWBNydM4du/5BAANoIycoFIjxDN4x4Kw8urgd/70S95Br7oMz8EH/shT0EiKqpzifY0zhuRXwcoi5pEGFit5src5wHy8OpMVweuvG+4WbESC6fXM/4O5BUGxfx1EKno0CtyxOBQKj5KsmxwZ0t3noujhyTEB9AB1Tu6TpI9Jn5WBjxOhBunZUtptXH4uXsIBEbowDaFOgBt0hhaapR2v0nyEKPcM4lBXSuHJzB7pbs5aAiK+yPmMLU/LAnb3/JpijOxby7hD4ZlOV+EB51QHZ/CVAUY56n2gQmHMgoi37/3HZLf6iCzVrI1XR9XwxtAqeUZq9Y/HVj4qphEoicoXXutAt2k7nfgl723K8Z+T1PVjzTFiShOaGdom3P7zs0vgQ5KmMNi9b3sIPkiqgriCTuzvfMHe5kiM2fzdTEy2gNmcSAKId9rfDt6/SLMfK4BYrkRBAoBmzsCwewRuccuCI31P3WhXMyaALVJD5aFXoaydghyuWCFHOJjOSeYNudRHAvcmKuZisKWEM/4J483OxVJv/SGd+Jb/+0v4Pt+/Ddwse5x8+RoeCbT3HEBzYyHYDmPdP4v1z+xWV9mnAZm7+1XZjaAnglziQiPnF/hb33Rx+JL/vgH45FHbqPrurAOOTkRBaH50/c9rtbrWIF27BBKH8Lp2qdikJlBOWeeC35Dh9DA4sKrbygIE4Lcp3YI3aYY/nefgbvvOsPvv/MWPvur/hV+43cfxNnJYlQepYIYTBddC8Lq6cGT/yFEu7dUvHFKoIdJp4JHCljYs0lsGsn6KPc0fHaXhgTg/HKHxSLh5S98Mv7Up3wgPu7Fz8DZyXK851wCMB2oFFaHeI1J7wFFlV6re4zrQ70JcslFFNpioZ89Jssz1y6aoQ3Umpwnhnx3rO5p/vtaAgIFIDA0Yu2LIz4zmJuJEwNWbX0vNjOTtrI+xdtJrkkKZtTV5g7gfV5pZM/Oa070k7klGUQ5SNUg3wuMgW9rgL/xheRaKvpCeE8h4qi8US57IM3TJ2wTzCWfhZ57JgESWVXug+ilUcywa7jQkqCoJvOdpLYxvepJMTng+JCijZlhZzw8AEBGVRmBvQN7IPGQztYd+l9GAExENZ31+JLAA6z9ju0ectk1s7NqB9y7Y180KaQC6Dqg42/91iJ1Znvh1ZICxdLJgS6BCFJzFtECroRrF4RzQbV6kc0UnoRQI6712SELqmWzE0W0wh8XsXJG9GyfIqvxDt+/iecEY2xcsueI9Zu+hn/wfi9zO8qgKn597rIBMynIURR6TY3G8Xs3qhIWaJG67x7w1522RnUzzA/VntO5MjU1QALVbfW/h8g8AVKpS+Uef+HX34bv+MHX4gd+6rfwyO1L3DxdDU2XPg85maJM6xfIxAZUo3qWkJihZJO7UoXRSEtzF9Vc6x9ZoDYygnIKbGZ0qcMjFxv8L5/5YvztP/eRWG+22G42TSuck5Nj3fQQHd6+77G+WofgHTPQmYIwdGQ4rCDMiCS3uXQIE+LxkmGGUHdhBMLDwOroCMdHS/zyb78Tn/dV34u3PXiOk6MF+qzlYZXip0iIWWSiRPGWqfHCC8nUjktM4VTJPQdFgSwtx7/rxgr+1sUG3YLwkuc8gM/+2Ofhk176dDz58XfVij5n5QdzqLXCXLKt3iEb0RyaC9aWQkL7k+Opn862TdJG78OignWSU/nbtfvXnllB+3tHNE3OU6nBXHLk4bjguFbQnsPjYJ6v1ew1ZZCgukaznx7JBvbZ1v5BiftIc1XaUxTXf1GLnTkUe35+pB6LbH1qyGRakeLdgcl9FBvDvUp1bs9Kf3s/Qo2Qk0Kp292bfQU+5q4VFHZVQmsI8IhGmw7CoTTwWaWMhiJvlBgf2uFstdeuM18XZTyMvR1BDQzN9zDKrTfULaOujxUDO2jGbsbGIRokCNkmBzw7/9w0Ne1OEt45+fz3BSW7fVseSGsXWo2ztiVBwazE7BDEnwggi1pKPNe08k0YlbRH/87OG0rg97o2MzHQdGhFdgenbMvmIHil+5azBoLNmqak14KZB9v/vOxF8IH74Bq+yPYeLJBfgG+deUSso3peYK+KbFOLAtfbt4OPK9ARjc4FwKPna/zMr70N3/OfXo//9PO/i0duXeLG0RJdN4xlsck42M2wsmsKqZm/sdBgQRmddnZlx1Gdu9as15jNEMy9k6JyEpYd4eHzS7zyI5+Hb/uKP4pVB2w2G+x2u5mC8KS57/vcY325droSU25oC8Iox1EFYXRwXV5Kn0F/4Ay2FKk5MnB+fgGeCkryR9zJyTF6BlbLDj/5i7+Lz/9r34erbcZykYoYjS/42aE25f9HXT2L8EzIuwUgqbG1FcRKQbdIsIGp/vduTEbP11vknvHMB+7FJ7z0Gfjklz0TH/rc+3Hj5KhcY5+5iAW1WvCtxK0cTGSQnX0JmhpI56AYPmziyo6iM1X0tiAt16BeyLb6PB1w5vKKCq0uCHXQmqHWSLQI1VB0uicKlqO9dt/xCQLjTEA9GDXGgQFZhUafdVJLqS9St5L3cIClRYRY7Su4PDjR6hvywc/gDrNEMwt2je9oJLMa1Oe9nZQwUZ6hoszFgPLuKF5cXn0NpTBkR1kUaDnBgRQSiWTXvhcVMevun1R1hqTw8MwBzHzw+2wlqNHYnZ03b0r8u2OD96+NCNSbkZwPu5tm3duuYHQlnlG8vxPG8Ssz7/lOqYehht/snm7NPB4CTMr1oQu1qItsInhUkDGCZx6DjWVyBO3OpPxCv1/JeabNCca1V0FshsNgnduw7xjtey9V72HP/YUiVwIQDjsN5tmXswgKwufG6A8jHi+RzDdqxNFDmRe2qGpufElt9MbbNdcgOoztwWh35eBjOGN/WhbykIwVyex6mOkuTzGdmUHCz7vPGa/73Qfxwz/3RrzqNb+LX3nDu3C57nF6vMAicWHaRZ1vmcvXnoUFXdoFYlhbMInPZEd39oifPBOS2PfDz666Bd5zfoWXPv9+fNfXfDruvXmE7S6Dc4/ddivWWf3YlHSH0KI7fc5jQehjEgNYdGaG0KD2TAzqJ2f48CAiXJxfgDlD+vLJw/vs7BRds0MIXFyY32fdjTs5PQF4EGY5PV7iB376N/Fn/9YPgmjw3kDudVLNcVSYFEA9GECmj2doeeQTeRIrisUL1ups+lAIlRDHa0hjZr/eZmy3GTdOl/jAZz4WH/vip+MTPvSZeP4z7sNquVAvlvPoLVIkZyksKvx+YNcl08kW9nYgVUBroNVhsD20YXYnubqRRZ67HxuMOSRUto5r+K7OdQuAayCh3rDcd1rDe5ypFAnzCf97h8xSOwlAfA+tpPZ91ZqUYMgd3dM16JWzYAtd//eiZta+5RMJixzacdmXIIbJGplnbeJEKwEKPz/omB7a/ZY09EMKmL2dZWoUb1FXkNH2xuK4UFRocqNLHXWa9i7jO4ip6n7pzhQH3Z67Bhh1MKBF3j+rJCugg9/9XAfrYBAo+J4WODWbELMFn/m9u+aDwiLX730vzuCo+xfNy9oC605ZF9db675Qmc71Q7zrynklwK5DyQjX1j3YcybMxSO/Fmwhc809tkdMyJ4VTSAhoH0ekpMxT36GGMasxuvKzHjjWx/Bz/zKm/GjP/87eM3r3oZ3PXSOlAjHqwUSEZhzZdfsA7AqG3TUluJR6KXO4low2RbKqBDBmO+PbCSujChXTIpnQ4JvS6O+xqpb4Pxyi2c99R78s6/5Y3jmE+/CZjfY1W02G2zWm6AwHWqBk9Pj9pxlzri8XDcBeFsQutyDg4JQI9bAxeWlk7WVw6tnZ6fFDDEKtucXFyPl1Jr6Dg/o7MYpujT8/mbb42i1wD/6wV/Gl//9V2F5tBhmKTL7Fke8QnWxTzaBku+K1KIpL95Iz9b/Px3q7GePSm1JkHB5mUscl9PUfs8ZuNrs0Pc97rv7BM9/xmPxES94Mj7yg56G5z/jcbjn5rF50UORxwQk0aFSCoKYoT82Bn/tz3BAvbAHwdxBdQiyfd1C79BAvO/wvJPPnEswW11bOkB+3P+d7ogcMnd5ncN27v5aBzwFHnHU6BbuLXL3eTke8pzQHoKfp8+hWWBfMz9037Xv/q6bILX2pUpgDqAv0h4p/7nnvW+Wufkew7kFnt2nh7zLqCtxyDWFAqd75pcPWYd0gC/inMLgfoCAAsCZr1XwzgFHh+y3O4nj72sgJtq/5bmKkYJDziVXnB94L6FQGQsw8cDC2nVwA8XJ64I71+lc2ecl49d1i865tT6bF1irqQN/7+DnSzh45rEZM0Tyr4RRguvcF3MPpTXv+71D49Psz4n3v+/aw1yGGyA0eVsOqTkx6FVynQVM5ARRbl9u8Ztvegived1b8JO//Bb84m++He948DZyZhyvFlguBuu2XS+yXDnDFwCotuOq77sqf1bfxKBbKFtg7BBCLSpqfEz0OpGFI2G5SDi/2uGBJ9yN7/0/PwPPfvI9uNzssFp06BJhvV7j6mpjqNxcRGFOT0/EM9RNmT5PKqMRYWvQODk5PXGQsNJLPD+/YOlWb/GW1Wo1FHzI+tgfA+NmuwX3rGgQ8s+iWzjF6tImRq62Dhj8CTkzzk5X+Pvf/bP46m/7cZycngwPlKMXZgaZQ4nphvAGRRS6cNTRA1LQo3P1W0wnMrJlN+rcu55xtdkhZ8bN0yM87f578AFPfyxe9oIH8CHPeQKe9ZT7cONk1UAEGNo0hB0a2Uqm/IwXX1uKz3bZ9GySnXoJIIvoOVOjTcLte4pEdIzOApgRzKG2EUmGVMnyl0pmDcmOCs9+tKc3KIEAbncqomdT/IAirU8htjNrU3BAgRfSwdyS0egstx5e2ALTPxCpGlP4gjV4E4r9QIt4QIAz4fx5uB72XrLr8lBDKtHaocx+t41fZq2rqWrmZhGt6ITSx83LqTYXhNxvMimOAiSZBL5SrcUhPNH7WqrqczxHW70zBbGdw84WxXr8ONiWmj0IGe7xWalrr9Q8uz/YH+N0QIy0Yx7Rnm/eDrujK3wBXhiI3JXOdotDyydoISXVvaEw4Q2ftVhjTpnbakzYZ9AM5A0uf0NQy58JHHZgHO2Yaq6BVpE/k6e4mXkbP69TC/IBZ9Jc0R/sEeZg+wXxQpdr7fjKkT8lkab5BeuUowUersvgZt0e8XsinFqK4q/673TACAGbe4DXYA3PGBMFKc7XovOU9/RleOxkRVZrAHC53uF33voe/Orvvhuv/tW34hd/611445sfxqO3LoEEHC0SFqOSqO6SYm9iOjyu2gUEwcc+O4uNdowm0/zyKdigW0BNdfa6gQlARwtcbbe4ebbAP/2az8DLP/CJuH0x2kuMa2eYnUzB1p4sN3LrOBkYhanzuSrVeqE25qKzEaBHH7mtmKbWSe309LTaSgSB9fzWaFyvVJTql52dnQk/DXMNmYcZw+mzxw4lM+PseIVv+K5X4+v/2c/i7PhoTDDyWPcZZSyaK/6ocNllgt8yJSWq5vaRmqVsQ6snXw4JL1GrJzum/GX42TSKhlAi9Jmx2WZs+4zMwF0nSzzp8TfxzCfdjQ98+uPwfk++F0+9/x489Ql34ebJEjdPjtB1/1305P/wzx/++cM/f/jnD//84Z8//POHf/7wzx/+mS1Ub11ucet8g7c/dIHffsvDeMNbH8avvOHd+N23PYy3vPMWHjnfIDNjtUhYLbtRb2MYlZrAAi2JEtfgFiiNu7iRu7z1aZ6xXA4xtxFuUfoJtUNIpbM3MPu6lLDeZBwdJXz7X/4UfPyLn4pHz6+wmBRUx4798dEq9grEUAye375QfuTT/8+csVwtcXpy0gQsdrsel5eXqiC03Xt65NFbjKYuxFQQptiOgAfRmKEgtCXZ8AWnp6fouhRTGTIbSmotxDgz7rp5gm/6Vz+Pr/tHP4PVqkMSSA+34NMAxWOSAu62tHbFPZTObnmoBqFkDnBSbiPsgRLq8LFidlH8Ax740uvtDpttP/ozAkdHS9x31ykee/cp7rvnBp70uJu4764Vbpys8Nh7TnF6tMSiI5weL3G0SAWdsMhnbeWLxyAK6xSPKDpJ/YZmT4ip7BUlZHj0gqoy4kT1zQMJXTxvqzArqAoIug3OQFaPopfPhO7mys9ilgg4u3a17IpbFUq5frjF1bfirU1PY/L2KsVTc36LTPs4kaBUM8P0nFVnzbTky39NCt1mt6YUkmkXjaN/HC4crn5rooiIh2SZD9SMG3qOS847szC4njqLk5Q8jWvFIdDs3qgCiojItWRc92qaXebwPFPzzVTuX7/7QgdpjJ3Eh6B3l5yXkI/eW0NiPfgLzXIgtTRq7CLfRVQdBYg97e9NihfIlRN288bN68aw7dh02eDCL9N837Q+tHeHfR7caKBTFDLcLL61SbChxpoycKAKrU1mBNOFI5VKbqwJKnkEh0rLBukXyGyN72h0I6WOMoR1U7x0tQ0cq7hd4/pwr6mqufkpK95LbRDnVHT9rP49HyB3Kfdy8dg1AhrqRBWqtZY65xWQa6xTLCfWq5FmFNuItAaytE+3jejqiMwq6JRcB+SZNlNBwGjP75NoPrDZn6RjTyQKBBMzACCLeKoWUaubAjFUNN1TzSLKiJEqbmSsjja3Ha3iFvFt1tRBq4ia3EV3uGMvYA5b5rLZAVxstnj0cofLqx1uX6zx4K1LPHrrCu94+AJve/ACDz5yjvfcXuPWxRq7nLHoCKvFAqtFh0U35HQ5V8aJWoNcqZIUUeidQrV8blSs5UjmuTMCYxyseklNjRWxdU4zFJZiHRS7B8LVpsddN07wLV/2CfjEFz8Jj9zeYNFJiumwz1erFY6OVo38mHE52gDaLjhzxnK5xMnJkXmtdX1ut0NB2DqNiQgLraZmque9dBqbjDVK6j25nS0Cpo+6utrhL37uh+N0ucDf+PafQE4LpETInKtQjF3ggZNnxKrQB4NaVkLCgBsJjZaaLgribuP4ZINDk6DhLzMPUWm6EiLG8XKBk9WiFF+ZgUdvX+GhR9fY/d5D6HNGzkMISqkeaCl5qwydsLR4MvsklDVxRwbGqBmvGTDetsMdneLXOTiMS/LIkppRW7ZEnlrnb0Qa3Qr7EmM0QkJYaPKXUYVRGGS09QKZREjTvZLfKFZR0WR3ZDYwC+qY23bNItIf8OCaHrd1U1j5b5J4lnJFcITCWXpOCBmgzc1U9WfMp5vsYxJqQc/OykRfl52ZZpemy+uv69ELLbgqRyXRBKMEylSABC60nJiGZsacw+dIDZEB68ccUzytBYb5oEPohRhAAQssDdegs/SM6GZYgSDy4ZGJT8rDVc6VWbDL5FrufGsULQMgRk2kax5YsJ9o9qzYO9k9WDZJICk1uxJrafTipfEecmszQTB2JP8QIjJN8+3mHJSsG0OJbs5FUVLr3+VSliNoJN59kjb5eB0EJ2oQgyPfhUYRLDNmtiqbZABh4+vIse9ofZ8cU95FXHNgGQvLLSecbxBcsp9VSzGygkYGGCeVnmVXzLYBHl3csJmZmkA0GgHvIgRykPDXnN8ytfHBgEWrqbNhAHVOXPsnzO05Sz5MiLND5llkgQ/E+a8eeUhAqBls86tgn0SWM+yIiONIFmn0x5X1PtxlZuRiKl/jWpcGsZhFSlh0hHtuHKm1xpmRex72VMOuzj+f8NaUXnxkbcTYi78oQK6cV1xjpGuC2FEpBWyxWAvDM7jcrHHX6Qrf9hWfjI9/ydPw8MOPFlqs3J/V8KENiLNRuYdU8Iefd9SNPp45zIfnvoBLwmEO4MbBJw9vClBZ6QlF7M5+anWgxu9OCaBE2PYZX/QnXoKTVYe//A9+DD13WHQJfe4rkslskh9qSqyQSEyUu6EMHoUeK2byJi/FchD7JEEnbuxtLWxyOR3o0gPFoKk9jGwuEbquw3JRUWcpmFqLIS9Mrw8i2jPPxe1kh6NBk+B+QwNwDjvJEQLH4j3lqZPnBqJFQRiIBs3/sXM4ZvGq1jyboC0P+Jm9IsRHVEu2dA4oyGlac4bk0fzWYJvaVPPMf4WKMwfFWeBaRggLf1sQKq9KArTpkUFw7FBfoOtuDXDbCYX124sGohgczAcyszsmKDr1m3BjkHjKgl6Zg1YEmYLjHUHC4SY62O9B8r1A8R88DtQ3kuqy3CU3PgaE4m1M/g6cfQSpJBtu7bFCXmXLvXr4BV0lzhWR50YKRfaA4hDQUTNozT2gCwD5anUH1yTaFOyBll0FUTslZnu6eFSUwnapZwrUQ4T8jCjH71aWKTQ3fNeaYaQYPJWdl1bR54GcqJ1LGhANbXPl+cv7eDEK1AnSUlNMUfBeSO0117CxlAAKH1zwmRL4ZVcukOqewLQHuZH4szjjuPz+zAniApXsEvouqgfyB6V+MjN5LU4fheCbg2xYJvtkwFmeH4ybi/lN3Dl+RgpMZfYAquv2RyqW9u/kswmaN6JIYIcuUtD1CvYZx3dIYce4Lp0sLNXAfjVCgkwUWGWT/HdUvR9FvLW5rTuHGOJ56zRWAr0c7VQBCpV5QYEGsaJu6jN40SWcX21x3z0n+Id/6Y/iY1/yNFxcbdAt0rC8eR+cuO+PeO+Zy/pWrDOrZMvi/LNpLQELlu1zjrsN8SWzyvqskmczJWeOD1d1fHF52QTgcrPD//zKD8bpjWP8v77pVVhvehwtu8GnMHn1UlvxW+4du3jHToRERjPZilbJqAyUzLH3crBMh1/JIhFo0FLkWGIx8R5+b2eRgIJiUtNPRe+JrJDT0BAXLe9Aux7Ge5GtbFG8ZJl8lYcuWvTZXy4Ljk8uhZXvsvGUKzIZ1DayCCaHlrfpcKRQjwk1kp+XoyDTTNxEkTGiOiQ9GpVvotzCrAKsTsk44DdIuhsJplqO+uQqKbAiTVyWiaFWusWiKXPT82fSywM8oIMUdaxFscw2O3DeiDVWsBJpqvLVA0aQ95zePIMMs0LW2KA+hTIYoFu18ycROqFuZtHkiSEQyYEbGi6JDcLOWFf6ZlqYqtENY00vlT1dEIMyOxyIGqAPK8YDm45WFqhrfYgcILSa5sfCAHqKVZIRoP2aFCWUeaarOs2AcFh4SGCtFp51nWthHooZMdPv5OHdKkIiHZBsmvXk1qrCeQytUGNkALIR9rHfk0XzkMp6rHWPEQEK4iXLQM5aUIHtcTEtscywblEQcGYZqWBoer4FEPZ0dVRXXq495r19XgU6kGGI2BxGJq8OKGVj5ji+s9zuEJWzfbTeiFB/RfIlEkyPrK4v2/JxpJqR2HOqqyiAGhIPgTO30MGge6zpr1nikzLOWmpyr8+pHHToOAA7qDTMdXFa0s5s11DWY0RsqMyILWkiADQUPgmwHWlarpgorIGSugcCmrjDaVixUPTOyPpzdcUwPJZWg9CFKD9mwVGOK8v/aUbPWL2FWCqsWr8otFi2cWTO4yrpBmhpuRpZa6OAzOIUHAqKGCZB/3QEL5ddh/PLHZ70hLvxbV/xSfjw5z8J2z5jteyQdySWGx9souOYlAVUFQAjz3UXGZ5Oog+TRUqkD1MKKC77gBHbcSbbhE8A9svoFiBYXE/XJRARrtY7fM7HPA93nR7hS7/hB/HgrSucHq/U/OJcJ0gH9HrAc6RcqgC8amTPwn5DBkg/C6U7hy6Kca3Wmdhnf4KmyKgHGYt/ScjlYbEthHQsb85zSAVKRbEyzQTtCM0eVYb00YOal2GHaHGUeoZ1qEdKa3KmxISYjKJrjCZWZFRADy0gmOWM4rhw3OwbK9llDUW6Xp7vvZr9xma2obxbslQGGY4pRvDYJ/dRETh8/6D2q2eqTDEqwZYWY2xKhoJhmulAILKUDlHoMAmvT0Y0X2gqjzqHYt6rUwdTaEELkGID0nCTP0uy6WVk4zTIZou/FrLMxlyeRayQ1BKaMkidsKhLIEUJku+nxD82e53r75I4rKDAHVZggy7idVdSyW0jC9YGCyp7Nf2NqGG+OSTIddxInj1kZDqC0+/lBhhnZjNAHl3m7AuyGZ5uBS/YgfuEwHhaSo8aCrzs8oDqaTPtV+unRXaorsQd/7yZGp03yapkP2rAzF6dUwB+ckY0bvhRuF9r5zxgBTQ45sSaDcHBey3vnigEDtnsB3lttM+6U1n0AAie/+xQrkH0Jzo/R/MAVNc4eTnt8dqzU1fXcKmsFQQA6ppNHHavpQaCygHkG+CasBO5ijAgCHEglG5nq0mzscp+hQerbQgoM5mmO6bes4191dtRqj4q6wWWlGLTNVdWZ1ZWOesujOgScwA6elV18t15bhR1XBs4Sjk8T2AvuzNLvalAEpnseh9Ret8/Z2UJ5wopZl/TUAAIhSwoFI/wOasPFsBqZO0QjZ0xsQdBSTxzGRSYsOwI7zm/xAc84wn4R1/5qXje0+7FxXqHk1UnijpCBMUXMDRQSrfFJ5MeTzoEX3Q0PjNtl3iyLpg2g/jf0/AiiqiH+McRnFhnPRwNjVNNOMRxxQTFY2XWwaVLhNWyw2bb45M/7Jn4F3/zM/HUJ5zh0YsrdItUEtlGyKrXR3pdu+456/quDKGTfBtsGiNcuzyQvoPQ/7Bpr5MxK27Rt+SMmAGS2AxClsV1gJhDiYvi2nnq4Kh8IcJt7bsKWFdsUA3mmF8hPoNgamxZV4xJB9kcT3ZrxUBnKctl0sp+Ziy8btazGFLwiMT/VuuaOVbMmO6d2eeMBF107QN5XMyiMJG1OF3h+DPCwjHq6hOXRVrpg+I90lxWxP7250n8JIqCxoYge1bqRTYNphd/wKkAZY1Cq81vz9/pnyw+S+w1lmIa9pmajikzI6tlX6MUu5chnE7F9ctgz7bzRFBRTzGXWRSTPBZ/optI7Ne7Vehg9vMdxEYkIowx7MEKc/1sjgkyPpFDwh4X4+U9m6Kgvi9uoOkUridS+0SupRYbxo1ttfcAK+KX26PEjU6WQvM46GLpuEuIJrY5vn/GPDzPDEdJsEwAyB9lUPjBwfyUAqpkTOZGZ9Rj+vXGswIA6t9rVXBZIKs8oAhCEPTYB9W5uMiP0XyfPt5Ml4/1+c5q7+hnIz9PkdiY/bYH/FBxu0QtwkaFMjb9ShaxRjEZRMwTAbzYCoFqIVieRxanJMy7QQ3GXNcZMRvKnoKD0BSjmBPus/+04bzxbTNYxlHEzivKW5Tjokkq7LOyvvFeoFZAsHX0TaBjOX+kL6spMlU+Jj9wOg8FtVHebQETiNXUgB+G4QKiUFRoibghXwFFsZwFODtnrSFyXJrJHxRtOExGGriLmO8nlWBysOHI/I7BpwlYdISHbl/hwz/wyfjuv/HH8Lyn3YvNtsfp0UI0Xxg5Z/O+pg790GxKKZV/in8okVoLuinB4frSTTgqgp3SI1Lm83R1tY7kLuAphq0u8tABLB031mIElKiiB5Z6ABpon4jsxWQwG/59ZmC7zbh5tsLrfvdBfPE3/jB+/vVvwV1nJ2VwuW1kZ66e/N1a9SDZGdOD5hbtwcEGr0ys/LwoCD9EdTh04rzPzYdwozAIdRsVwGLQRHldZOkeIU9JtxfchtPyYU4tcGx5U4AQOwqLeRfOO5Iqj49YIF3wfpXU1NPRgYWEah5Jio+j++n5CqVAyPVLJcWPoUfJJlUshYZKqLp0pnVBqKxRFAWS1czURAlXaHCw9tlQn9UcnTRzJdZJAQXvzqlVkf78RE7piS1b1MxlFeoX6SNdUbMjE55Arc0DjOyvxRXQev4HcaPC7G8vWUnWqIrg1pZC7QPhGk0VpRJbWFIsYedd9ZdIio5ct2rmqNCELU2TVWezCDRxNf6171UzQES338o6SQVRonCc1bF7DFtexmaJTEf+XUq2wwknIdivrgmuC0bLEJCiVJaJr+bR9h0gBphUJzGVWKLee4ggk/s5DsgVlg7GlvoqbKhqx1CvW++7p7My3TXU3at4hnBeREElqAEbgK03naTrk645WNDqSgwjNjHKXydz1C2EfxYkWBdmLjFUdievsIs5uzr2VG/5oORZ77+wfoDazwQfPxzzhzxTw6RmNI3BWF9MZv/jdrAsoF+wjat2JtrueJH7CE1K5xUt1+b00jWISqOnNvT7LvmIRo/qXiPH9GBDKaPg+zTdUO89ikn4pstm+TDj2SGuU3fjgkBrlfal0jSzErtzcWM8BMiwx+ReY8PEQoPTQ4KREwHlVr22nGXm/Ah6bW6Fa1KDzD1rDvbI+Rqv/Mjn4Zv/94/DvTePcLneDYqqqCQzdl6CI0U/MygRupSaNhh934dj7ZOi8GKxaJY8uc9jvUWuw1juk5m5MTcPALh9+xy7Xa/alvLou3F2gm7RGTpKZdbcvn0x8tQpNPK+cXaK1BEsD52IcHm1xvpy7ZTxdn3GzdMjXPSEv/IPfgzf86O/ipPj5aBA2mf96hS9SWxYSwkgagRhk0w6/1Jy5w7PSdXCB/kiD80GXQqH49kd5gVoQaV/kgsQEcXKqJQxa8qDy3qszyS1UXg284SEtpFvMAOqzOERochzqn9xol5rA1KUPuklQy2qJ7XAEQ2C2EcWehXLItdIVTvNaUOa4abgDzkkL/oYMuIeXhvB2DYEXU8Sc4TzOAgZ+g+ZZDwXJdmyD1zZHy8VsgcGRXRDcnMdxXNIKZMGSSuzWQsVlaPg+yoKbn2JODyoSaHI9VRV1FZJeTvAL10rArIX1orsepgchcutSZOiqKQ7+O64SpYFnxE4yHWOmyVeJ5LgMFelCsjEQB17ypNrirGfq1HqqLIAJjOkSVVBVYp7RTErUP9Ux3HRVPJCEBZsbHpmWWPu2H7LzLEBaOm9uNhgRIaM1UYDMXaqfJK2VSATK4ns4nG1y6ApmVFzP9AWBZFW/wQGMCkV6/LcC+YnRhDY1+okwEw3sy9oyjSnxBCN59vRk/CoNuCf+xz2VMhgh7KYi7fvyCsTks+HzDUHE7gIRSUOGJZSYDBzKeD9z5G7d5fCR5Mcze/lSreXYPX0fMa1USiElp1ZwGhBpZ3O2SAs+jOqodLuZoTtuoiTK08t9WC9Iw8rdf4KQpfYLUc4xFK0eIHX5CAgaLjIzqwPARyYlvHsQnK1jL+QZoNLid4QOSqJ6giK+NSlDtvtBrvc44s+62X4y5//UmC7wXqXsUhJdY1TSrhxdjqqx8IA/MDVeo311UblqiRyt7Ozk7D5RETY7Xa4uLj01z2K+yyXC5yenoR7bfqMhaRFtfjxSRprCGRHzjcwxymBBg+DqtpclNyUhKHDaP8sFwnnVxvce/dN/MOv+KP4gKc9Bt/4z38OV5sdjo8W2O0ynKLgSOtjBYl6VMoNzbKXeS7Il1VFjJBihO3PkDdvUR5fDMgElSr1QoceEeC1F5+Ua1e3K2wDZH5ISjhBH1J6flBC9pUkRUbS2/kizTw7G2x8DNhfbIc5YKh6FKW9wSGl0HlyCYAVlCA0hEPZ/HY0LM5sEk5ZYs3/IVAotKQYFrJ2ZG8Ewdwuqqt/ZsOrSnViZP7JBjSicJXHCWYLKYyz4wiUAQLyX7DAWIFGwYxalI1Ta1ZoQsG9GiuZgM8mCSSpJsAk9pwFrwLhDunBNIuUTLMwcv5MCBoEYA6Hm5f2bD5SxCwy5pDMcenfGreyxVf8gzSHD2nxAWoLY1TWEgdQGPklwNyu1YO4H0UcvRNEXGcbH+KviB4H+Wq6yaix42O6gK0dMG7tTbb7OipORZfWWD+o9yHedWRYw05IeFLvNEmxADnIdv1VocN1vt9h6FwEzAqgR4S4EjfVv+rsW7UBBIqxEY0FyhdWZwtWSZwdA4NkIbB/jBGWWx11Ugy8aFQi9XnAs5FiKkCsD64u7ChCOchFvjKffK0/LAo40TGuGE1sDTQViy7DNyYasjDhaJbCzWx6yyPpb1yZgwYoIdYjRoEVDTtsyLUPjJ0UK62QiJSuFO9JdAsVbtqYyycvzMPzJJzwMzwgBadg6tY7AZwIkUCN3EZiIhwAsCDC+cUVbtw8xjf82Y/CF37KC3FxeYWrnrFcdKgaKsZ6ytmRVSZLEsJDZMCYJhjYbEBRERyKGys651wUxNtxcPyLcBSXtjq2aVWTkmxlw6mnuZcbmK0Cg6TretejSwn/+5/8MLzoWffjy7/lx/Fbb3o3bp6s0OdeqfvZzU3sTbL3SWc7w0cJsjK3ky5DrQKE4hfzLI6HgNrEqHPIUbVEpF2GuGHAUQuXQNdS0swCframY2mqH5P3GWT2XWAcIi1O1lG7sUaZVf+BmjFW9KBYP0I1z0IRx8W1Fyq/XajAySOxtZpUQRaVpIGrNlNVKZWG6MSCWsmS3hwNPbcmECf03DYALB0nACwKHY5iUInDGqnMI0zrjZW3Pc2fGPLQJINosVxX7LeVoGGTz141gsKx11/dJ+QSdklzh5hNG/a9odTTvjarnkuSNFr/SsmjwI0iRCP+AfoqlAGp9azmEBiRHTArSLy8XxIgoFIoDYQL4oNfq8zWTh+VPQmJNNufhZ/rLYUOs+q+aA96Kf7FZt46Ajf98uVGgU1yXpk0FbQkIhE1mXxnklkrqmZIgQKuCW5T5bP62WnhGF8Ou+8WN61FdKRyaaWpMZkuC2o3T3UfhNjLOO6rGSCUtACKPJdYym+wQu6LIMh0HpLtcokxE6s0ShHQxhoIZgpBSGLdyVeMBbIzrqLgIvnc5LgC1bl5jubyWIxAWEClDZ6otWFIKmTtV6Y1VvY1uUSa2bQcQUp5ncmSujkACMxzZ0/aAAKbq0am5SjnEj5gErFXKHIR64KKudHJj8oRSzOmUOiOWSucJwEwkAEtKBIRd2BzHQUikVM0E3kVn0Ucc8wD8cQmkZfxWtWoiBo9Caj7UsxLaIPIsSadSATP2/KUTcIVOQCQjZskaqNS2E77ZhiTe+T8Ei989hPxt7/k4/Gy5z+A3RiQCk0U1AZcKMjMWc81t9k9bVBFMjl43FOhxEXA3iHOzEztbzs/vxxomI2c5fT0BItFahpMnp9fImcexoXII4cnZ8foUgopMdvtFlfrjS7SRH53dnaKrkuDDcWqw++94xa+8lt/DD/407+J04lCOg5OlwROKlMGCl5aJYra29dQJTjsKnFg9uxbvbZyb9MkI+6DnQeygd8JmIprI1FvUUOxT4t+EkVsRNI+XBzNVLLucXFVcAO1CCcUopDKl9ECbMyKjmcdSxlyPtLS6aq6pZwzcabNosIkgcLYuQJlnzGzidm8X+mf1/LTVFLaDNN34aZXX5hmm46dLDx0gWpnR1F9OqFdt/Tz4gAs52pzExzG0eQC9hgbl30+ifUYu5i4rzNXhwnadOBpR0TNbhDD7+d4wQbZDVgrapr/aNOX5boTCaedo3IUxKDvouwh6QCU1qpwtWKTUVCebWfRXppZq2xUXYwJqfa1KsKmmak8ye5Fa1Q+a8egnzv7dpZ7Z/uXZmgc4d+v2VC83/fYtT3IhlkyMv5MQVOMTM8o2NPSwkEcqtWyhdTcjwIYiOaVOg9InNQEPsEzX1g2Dg2tVd63uF5yZ1drTsLbiGtmW/B7rM8ub3FAaJEXImCDjfqpNZ33lDGaO7X0rlPiVqzUP0vSTRHrhdy50xrTKN0/iggjFBe2FCfWJO1vSFPDaea0VlAhs9OhUPOn1M4Uldo4BzOKJDIRqZOggEFzcwXHsOMxCAWRpUaDmyklNN6PyJXZuHaY98HMYccZcxRvjpXjmVnJ4xziy2uDoH6mrOKzHRsqu3nc54suYbPNyGB87ic8H3/tT78cj73rBFebHY6WC2w2a6zXG2M5NXxaooST05PSDVSPhAhX6zU2661nHYxx4eT0eAAEAoC07zPOzy9l5qUUrheLBU5PjxuAxfDTi4OiZwxoXCsAR8yH1uCiEoxULVM7iTP8r+UiYbPt8bQn3MS3/9VPxTf9i/vwrd/787i82uLkeIldLxEcHZZFw8CXHqTnvNgoMOncmMs8Ghn5cG52UK2wi94Ize6SGuVoUUwqgqgUMOWguzJw9v1abrTjwznLiDXEQWlHwjct5PVTPHfH7AtGijt7DAToaIAkcWTIYVEoOT7DogVPanYgVBhl9l0YGRwlgioOBWbzsANFRAhJcvVewy5N3JlUcwy2OGRDlWIxZ2NTG4YIcKZLRRzOo1lOreyIyIcuRZgIsSIq20agml+V95zV2pP+QtHYPCxdCUYKPrMDI6b3Esmkh10kaPGJ8tyCtUmCekMUF3ShcA6zGv7hUPc7ZkIEUgKNzlYU5DjuGknkmUgL3sAX4K7fbg5te/azbb0HiVEEdqninFmLHUh6JrGjHEdUYkc9bc38BmMVduJUqh0SGvPw7d6yHlhlHTcKiq/YJQY7FpRoNl6GUhOAUA9UMkwKNqAdilolCz9ZvaGV4BFJ5go7QZlrVLsqsdVnfBbJea2ilHS+pJhKUIxjcTmOKCHyjFKgA7uOAFEd0mJhhzR8ZZoFB9T9SrE4J5lPYRdniCmsSbOcG3NMsbcjsfexJWeL5FXGOe7jweG8ND8vaWsPCqpFx5lhk29ZERVE1yg6ZLIQNOKoHAFFUweYplF0ATyxkWFgmwza0loogYrYxzRrI6rBXdbnogMuAqZKzobGzq1M0ooZsmDbtPLNWm2quWKVMZJ1GdcCTMRecFGMqCnqOsh08AiUEhaJ8OjlBo9/zA181Re+HF/4SR8AZsZm1+N41fnbNkeaEvTmACNgDfk5Qb29ILa9+7l4aMSvQFjsjZ/Ct6R2UeJB//1FpZ/3oBn0jlXG6OcUWUiuLjvCZrvDUZfwVV/4R/CS59yPv/5t/xmv+/2HcPP0dKCX5AxKUBLssxhiI4CUPUb1oOXGYQClqBQVDXGya09ZRePcsz5q4upDquoGaXJ0TUhnxsOc8hqFA0YBBckLKMRd04hfqLtD+5B0jxuxmWvdv7Mo6FYx6cLUXXWDoVjoEWFzt1JXowo56s7IJGlW6pIP2JMB0hxz/M1TpTbIIcU6FHrB3LTTcEe/UH82Z14pTp3XnDnxWKc+zsNwds6czDxECJVwY/3GML2mMtNsYWf/ril61fieZpKsah024KuH21klxzFSj5kOdkv1zVHgw1TO9pyNQqDqYvpkkmbM4zhqatlTO8pO0KCnsaXqx94/KslhqcpKRqxAl98kPkDxHZprJlC3Ytv5rJL2JM3U2cv7OyuPojIcUJ4NiEoUnwcyNrcTVWuWtY/iKM5M5j1nZBCGpudCLfEuC/KQe8y24JQzg74mZOypIMOnI3Ux5xgT7S67VnEP11FjJrd1fiqqHWL6MEefPav3QR4NB/RclOqcu81/eMPDdhr3MRi4OdATpzPc0IpnFuJZca5gxT9cYVoYWvE4jWTDEVEdoTL5jBz70CMcMIKCNly3s2mO1JTYUzfnOtsu5iMQkio1kNldwqNQhRLedxhUOlxHCT0Y77l9iY980VPwDV/88XjRMx+Lza4HUcJCKoOKM8SOlDrRQvL5KizYhgOWMreaNzxr12H/3aIssCiRMGpzRDxH2NKbUmykEhhNa6c+HEJLqkB5qrA1ktcBarnowMzoc8Ynfdgz8cJnPBZ/53teg+/8oV8FI+FktQDnfvTglIminAFi81LMHJETH2DXnZieclKJexTkScc5P0hWNzrrYoUlkmw6iuo5RWqckt45wbJJ3GYO5L2pBopQkt3J1UORzWNBDK+gysp03Ju263FCb9DK0ywf2fUmns20SarJz2zH2vjZiiBE6n8T2wTOzFVQgF26/NHOmMUdWw5onmqo3xn3UnWSovaRX7tnMMesNn0v3fBSOLCx+iRDXTGRn9vFRH2WgQhB0H2fU/NzohIkO0yucg+eeeXZlCecufoCceD3I5WWrbR4oHqqUk83d0bR2Vs9jEKgg8Oqv9CMME+cZem6yZIaKZKOEVH2wjs6m3Ii6EpNmRCwk8a4xCFISCaekhFbUW/K7GcCh2cLiVYzm5m/qMAlgyQTa1utWVJtUJRhXFNMjEjLm9l3Q5UNEtvYIqBptnRUb9pOloIZ0P2HMyfXLqF5DkRmtECwH6L9q4iTVOnGloXCVm22ANLSg8ue5wBaiWZT7VpaUUgV72wSKHn+Z4Hkk0/klL+YPiMVRRFWxZzDDgm5eUjDlgnUWOU71aD+pOxrJvXIg+EsS/dQzKjGF4Tic1BCOCFCYu5d+/hBe9zZjDFPsSRQ5Z7zI5X7TT4XadwkeJAs5tisxyBB0p2hhGOqKi215zIBNzOp2VsUgn6SVVObiiyKOcGmEF1Hh7BOljWCKq4aXAQFXE2aCZba6inxMqeLPILkAcpCEIiAQxoApnvLgsmki2oNJCWQZ/6gqm4kcYx3iXDrco3j0wW+7E++BH/hs16Kx9xzhvVmh0VKSmdB5WYE5R6QkIRHoFjBhKb/pAY7jU2OBBFtfsnkAQU7GhL1r3a7HVOsUAAGcHl5NSRAKQKwGMfHR+i61BSOuLwcZghLwBQJT0rA0fHAiaUg6Vmvt1ivt1UWmrX/yOnpMbquC5pyhMurDZB7nBwf4d+/+o34hu/8Kbz2je/CyWqF1A3+hzqlIIdG2gBGUhhBol8C4fG/byYN5zpjLGkVLOZVYOSh9fA6GYiN1WaIkYdDADNlAk7a46pF9VUKlCSwTPFimePeFgLRH2pQGIDIQ0zPkRWXOm7JcJNSU53oUyFC5xLvhoKjEiCw3TUKoC9DbFV0OF3kMWZlplqtOqM+JVN0o/MfFWFerzqkBVY7B7sOZR8vwsJ04SADOKtr4ND3a1bRMZhroqadxgzcJpJfDgSifGdGK8RKjytHw1UCzhSo4FJTtKotAQbfvpKdzzmbgbCLzqHanVMaFsUt2TnKIFFWRV8zrLSsbdg1kth0vlrdOfiSyKDOFPPKAOcDZwcumxTOYPCTBGhAzRlCCrsTZMMNZqijHHcOWqJhRHBnBjkbAm4PrB3qybt35jKwSXJxd+7e4BQDEXX7xegrC9EdSdmL1570liNvndG4SaLmZKWyxJHWPzrZF9HUMAj2yuJJKr4yotce0X7UhdTcZ7sP7mnTMna24jZ7q1bz/PQZJZ9P0Pyua1cEWquU7to3zE1zA/VOOH62FPAmwnjKe5SxxXSeLbDtOmJmtGDAWoByU5TEuou2PUA1Y2ayXCE0cqE9YwnzGegh3iQ2uNtQTQ40kc0vqZ8hFW7lh3c0sA4vdz1e9sKn46u+8MPx8uc+Husd4+j4GF3SYMIUB67Wa2y3WzcKMvmynxwfCw9m3WxarzfYbjaglMZ/redZj0+O0FHyYG8ibLc9Li4vFfVXnuCLtMDJ6VHc1Z+u/tat29wK0gzG8fExFqldSFxdrUfRmRjVPjpaISV56NSZkZwz1put6oDJQNAtOiyXy3AjMTO2262WwRUt227RgboO/S7j5HiJR8/X+Kbv/ll8xw/8Im5dbHF6vBzKBfYeXFoLFgEV0CeWVmhL134R0dMcCGz6MbYby/pwt/QTjgAwMSkZTC4dtP3YBOWoICQKhiU52KgTAjkjCEDNXNaYsHKD0iJpWDNPHdBD0XMdwsMCF3s0xCZvINXB9Z6OaHZsKCxn2/tyjvULi7z6xqQXoyfdGbVrmzDvf2Y/V9P6WKjrRV5owiOTuJXtiGSGGgXhDFrcKAZbyXQr8XaGyOaoIdOtd16V16n3A25F2P2TaqyA6xSETqeCNdK6fzI0XX2XAuGmOEl0mj/cCAS+TRwkjjo+sUTGlHgVK4sdXaXO0X8FxTcSqJEsiQMEW0gqfM4UhM46gWJvUGUPPufdGiQLJFkg0D6BMSVdv9cJxGKmZoEW5hhKofu6AgUxNU+RMeQc3IHCXmSSaETicsSzKr77isIYNDDAnwXbyhpjUxPRgXHJzqgaH0cmp8rasgm2o+vqHApE3tTCbQ3SYX5NWzsIHHhUl5lxRGCz5iJq0R62UnSGqm3a4uqhUXwehnYkbIpBhb/vWV6a2efJRlr0JUo1YsDbnGdSXEmoqZO1TNVUl3ngqAUGkGWQUbhnPPMnopW3TMXljKZ/FikN42Xnlzs88Qn34Es/60PxZz71BTg56nB+uQE4V291C3KOfn/L5SK8z1K3sN9Pg/BLh8WiM7cyGtczY7vZeNWe8fdTSliuloLwqA/Uvs/Ybjeq2aXprAR69NZtVig0s+ojDCqiXaCCOXzYxfkF+p0YxDa9ztPTE3Rd8kp2ROj7flTFiYUIjlYrHJ+swtCdM+Pi4tLVbsO/yzg6WuH4+AjMjF2f0aWElAivfu2b8Y3/7L/gJ37p94HU4Wi1HMQhOIt2PxUhFmuOzgZudrRJg+zVCFTNjskojSk0Sx04QRiZ3k+QbFavJm4mV8S6c1fk96kl66yTC4l6VK8fW4DCKVXFnQePflmvcXaFEeDUPk33iszfq++W/FZY2XgTOKIuWjuVUH0HEgPiZeu5asgnW2T9sMTJIIuTcHST4yTCTcgr5T6W89rxXA2bBJwgutLi81hp5yAwbFCCOuWdkBKkC2fWeCZhbMntE1GzI0hWlMIYyqt/T9cZmBbpA0MPhhODcgRKyNOBqjDHDF3d3i8FSsmqtY62OTM3qCry/bTQBXJUptZ+8Ergsrvi6GGuO2qtaOxN2CRa4t96kxSp9ZAV4W1WXAIyzYZwlfoPXcddZwCBtZNG78seJwq9o0KWQ+hhioNM4yOBWyXjb7tRhSlyGFyhk0uTcGZNj5RMDjZjBZqOTS3YSv+cfdSkfY+lp531aOQm5YCDM7Gyh6IYZDu46r5kwmvXjrKiYGUJ1dqUTpKNAk++AqKzeybxntDP0M4f+1kkPfsrxYU4KAhJAkpsQUZ5DlNgB4Jg3MKM9ZAXJ7SClCQ6xbawU8tJUDF181JArcaM3fls2hNAaVG4zojOSVWDgXS3ltxEhSuq1KdyBFAYJVsFEEg7A/N7zvOBZgEQm0/OgiWRkrylIisWkeGLBhR3e/oSDXOCIODiaovVaoFXfuTz8Jc+76V4zpPvQd9nMAOLRcJms8HV5brmFiK258w4OTnC0dFRGPdyHpwXIpCfOWO1OsLR0UqfYyL/u31+iWxno2kYOVgsOpydnSLeiYTtdoeL80uRj5CLNwsotadoRqstdBBSMdQmDUYjy4HDAT3Fe7DYLhFcEZVD+dZibk+DZ2FmxnbHeNkLnozv/Oufge/+0dfi2/7dL+F1v/cwTo8WWC26odOpEHWj/CVpYBycNeSTct284kZny1f0RNaEVQYXVgEt0kCwHa8SXMka2RpoFX7Y1qHOxTKosq9ZTEZQGPjk2hG+Ona+b0o4XEATnlVwLVgvtS7letl0SqyoUcPzjEhbTNhjMhIXte82E8u6K+K1uA6TQrc5rlNbyX3UNdLBuZprNPMdx74wPmhKqGD0uSE586ktJdRciJp5ikeXXLCiAKZGjBZOh0X1krOiLNM6NsWeUXTKU8I0fYaSLG0R/k0n1ZoTMzmNBzWXERQ4Wvhyv5iSLeJLH1mpxooyQiQaDJ/gMbMBunQnvI4NsVL3tUqYippdEnLtNeW7sUb4AtIOyCSIAq62kgtO6p6Fd6oUQJpEkCD9vTjUZNFFRbv/lAWSrBNHu7+4FJow5u++Co/UWOsnJqpTUNUqg4P9Tmgx2cgYZJe5I9YJ4Wz3wuYKwpnEnoPyjJ/OgGQK98r+EKudtN2JnvnznXJ5xWmyDmHTPYeZxzffAWlIPx7AuazvQPgjeypPmR0MS3pd0JGbJTUFf+MDWCbyYJXsKwylnAuI7XUMwMS2JnFqreTBBsx0bYySr7VcKmuYZoQrzSIrip2RUTnrThxYePqSJpOzVfmWBvRGEZYoapcFE+6qcuOYFeLmYzhAgTN0lk2KrWW7zZzjkY9BLZt8rmCfaTnXWdN7Y/uAdr2AgeLoygN7xln/w3KPsBNWJTckp7gqmgTuKsfZPiKkRLjc7JAz8NLnP4Av/ewPw6e97JkAgO22x2KRXHxznq4YPmfa3LnEIlJ2W0Rj2gTLwJnxLBQpelL1j9Y9ULomRCa1F/P/Nm8Z19rCgd+i1UUU8CXJVvJkFIhofg5k3m94lsJI5FG26VmmUI2ufloiQuqAPjOWC+B//pQPxMd/6NPwT3/kV/FPf/hX8dYHL3B2fIRll5A5gwGksXsWLmh3seSDvjRsL12ZBuXNCF245hcFhs1B7c2cy2ycypMUWqgHWkvQFybF8nP9Vje2DGTmMUWCqwejoYyIaYYtEhqhKmTTHDLUgDbJJ7KuqFFgJ2kUUb5XmdCULi2B3DXq9yw7RnrtkkMKmXnGezDihltAghzOq5Lu1ga03UwVhEh3Ndl2hSUaS1bOwBQLpAfhw93KDhmKegIWLWQpnsO+GcMc/B7HiDOx7kyWFJuozv41wCtyQ15cRA/YHbMByC02QcvjDSqxTXXWKbIhsfYpAmCR641C9VTTTlI65AxkrTzLrgHAUR9UHdKKXl7iVpW8t4ucrPIl6c/gRv+zUkXZSJ2OX5rtWK+mppEBknhfbqoKjDp/2urAV2ofK8DAAU4WIDDcNA7MuB1DI6BDenVSMnT3OSNDM6seXDdlT5kjQStgsG9lc6QWamODoJLLrg7ZXmr0KTXDUgAfK81StNRufVgmZw1SzkNlLWTn1wFH6VVHPRnxoyZhwgu6OLYLi/ttQoemwxY2a2BxAwtQhCvGeAIxLC001nO2z5xZF58y4JMl2LAXPaSYXBAACVCsKFjWjDwTC1al32W1rKJSELlGB5tYSfAdr8hMUYjjadNzCQKGfkTDPVGLsUWaKUZcixg2M9WuGxnX/+XsdWNaPs93893CQs2ObllGEtszhjSwPzH1ukS42mxxtenx3Gc8Fn/q016Ez/qoZ+Nx995EPzaIbDHoxdJjJJ0CF8vMFLD/2Bwyc8rBcYNM/z01nMfIzJ+b4pFQO4St1mxY7FBMYTrIK2Mv3co+QsmT1R00STPhlvaAeSRdImy3jFvnV7jv5jG+8vM/An/8Fc/Bt//gr+Df/Phv4KFHL3F2ssJi0SH3XAVj2D5YDoka1gXFFUW8t63jw7PdMAGNo0ZW0nYYwlxY+0FZX5/GABlaA9vsu5rRMmg5oUZQ5iR5TKwKG4ZJzmlmSC3mVYVLtCQSkcIui0LcHQxB0a6qSjZnL6mlbNU/yb0TcgexK8kt6M+NACOTL8kGYFKCJoqaaJKBuYyXwzp85p1zLRwdEm+WfIuXpo/H4GCRvkNjsGvOHMCuZ7uYzVHHAUWoADoUI72y78CeoqoornuLDA4AZN6jEhnLDvBsb1sg10yh1yYHBAf5VLQQUvyOat5hQSY/40qhSLPoMooOYD1YWwVP0IyBLpLIKLYhoqHuOfRICBHZWRkO/F8Jc5TiBq2qRaeyQavwsoVqLPnkRLiYNV64BS/1oUGtUUz7O4GMPDOb52Nm1FmsK4rWrfYLnYqzPRPrIfwBWPo6KwcdmTTLH1R0fTY+x03atjvlNEsgEDaa75F5llCUflh7+EiYJFyfPHMGBGgJU9D1Ct75bCYcCICwDyS1883VxoGIgnOqdrwMZ8h3tWURSD6EaRYR6QLGxg1mB97oTpx9sIYBszd/1rOosX8smkBAm8FGbQ0C119vz4nO+XGTEh004x7cUOQUz1vpk7qu4QjIJEKihM1mh1uXWzz9gXvxP33yB+JzP+55uP/eE1xebQcF0S5VsbzZEWc+OEcjdVBS9NZnci5uFts0l1rvq7HEWbtgqcpjpONb0UY9YHk4JLNTSB9SLMpYSo02qSuM5k14SaCIFtUp3T3HjycsUsK2Z2wu1njmA/fiG7/4Y/EFn/QC/KN//8v44Z/9bbzj4QucHq+wGucnp3a7olWZKMjwNgvZvTkSZphA2+pZBEFRVEQdS0mToUQFjaaJo0de+EDRCihGtatXmxgIL60XufBNF5nbc1csO3osBr7lcK2dSTAyyqHiljUQZxLG0lkl3NPMTzHYlfK9QQEghU1UfmNUV1SYt55M6mwmhSaq+UdBCbOanxTUWeZ1VhNd1XmAoCsSDGuzHqKmMJ5oHVoYQCSOLIUoJKKY2wkuDf18hUyTE0kfDwhf4ERGwDEQxMrI3e01Of8SjlhbJUnNxy+iTzw2GFKClGZn1eWQlHPS7TojUMVxKq5mg2Wo44DC6ijRoNjHk2TnyuePdcnLbmW9/kSs56YEDKZp5KTwo6gj7OcpfPdlAm/sQcrBuTEZ/0zBgeG7OC42kewQe9U52alxQlGNc3xSsyYDZLERHeMWcSRUfZoRSEkRCaVK4ksftxp7fAtISrD7zSBReJFGzihckVJRrmeUnNki2acunXWHEukkSlmBDL+XTRxkIcogCw8KgAIySSuHQC4JmnRW88ICMVIsIjJUaqu5RsL3cwZy0YlxA4iNu8tkOi/yzKVCj281y7iJf/iSIpx5zeOoQqAz4ufIDE4c3rfJv8jnnM0n5MaayIwykbbyksI53BrX8LN0NPKeZUGRhFLrxIRg8rP1wn/HINTGep78dZBbo37v2FlZtolEA3VoQVdTc4ZHII7YNJSCRq62TYntp/Q7td69pPI9dU6UwrCeQYkSKAFXmx7rzRbPePJj8Cc/4fn4/I9/Lp72uBs4v9zgkdtrdGksZRgh+4yN/2sLx2CzIYcZwiCtMQTKNgYvlYhRRgP0aU+uJcUHdEqmuLzQdBurzR3Jv2kDUFeZGnEDN1RONIP2R5cadwjnquBy0HAcVVIipC5hUo3dbHtstj1e8Iz78M1f9kn4rTc/gn/8H34Z3/tjr8Nb33ULR0cLrJbLYeYgjxu4KDeZmRO10UiVCZIjXddZVlW6bErVZlngeO5SHDILy3qQ6dWrOfmWAydMxdUcqTQOEGGBs+/WTEWqHL+waBfpmcPiAxS0JImln6WeCXIe0gG/hEJ4jDTiTW3s1qjL6+Jh9N3SIwTkAhsrYSHDt5jQ7vFDiICsPLFIB1i1nTw1NDw0YdXlNCWPQxkfLyxSiG1Bd4FdB0p7UklKqKbbBB0PakUEvQZZVcSSyiPXKem3KWDHzIZsQrJQo5BBRPZVcDZdEuOmKxFknqinrBIdmuu6KkEhjjsAopBu2YbY8oIVTUlLiBNi4/vJVI1dcUIO7a3UdHm/0oeQx0Qi7tT4rmAFHTmqMmFFMmoBx4HUnjaKF++UYMQ7SNCwZpBXlmdAPBMJtxbb5hoWBGH2SRKJBEhRxuX8HyqYxw5d1l3EHPbPAjoxW2q5Af1slj8DFLquoRIls4qPU9yw2DrriyiAXzzzGHFbaoJMDS85OC9PD6a0uyNOuDwoxF2ppeb31VSdLvCARre00Stg1V8RMZ1djYOp8KU2PYBNBVkEl2TuI9XUOeLEsxEXiip0Nt1mv2cqq4s1u0EkrFYXIXJJzzIdAotREn1KVu9fLvFdFf3sUg5z5phlw35G0anQGtYGI/CiLjFWPEKZJ06zt2l6BIOvnhLGYW4zQ4i0r6YANqKtrpVu5+mEmpkXsxgriA6To6LmWkSDCOXVJXownveMJ+DzP/ED8ZmveBae/PgbuLrcjoVgwtGqAxGh6xKIUgzsNkVvhuFAioSPxJlEtuvGOqdhNrTaliq0FfIhdvOVPDfYoLQhhue9YEEj8RLN5A9Fmd2PLVpbuUse8yCH6tHfqaOQuS6NbMD/yNxUqmLlPKj6uMNC07W1fyCmDsaY+IgZmNvnG3SLHZ71lHvxdX/uo/G/fPqH4Lv/4+vw/T/16/jN338QOQNHqwW6NLi4Z2Yxj1IP5iZmx65scr1wMn6ILONZQ0afZDThCGaLET1HTbBFoZvPEHLurc4LYnEMVx6xEIggalMilHqoTC6Dkq94MZvukpHhlbMDKikjMpLiHHeVCAiGldyMCTO1HxNRsES0pyRxPI9LqqvA+pmFh6xmBjhkVCSL6npYt9s1HUMcUQRPS3MdTU9hbZp0R4imWD1s0a9gPNlRFWU3aUoUg4TLA+DeIIJCaiY1DzXZ1ZdFEUuJbQ5rT5+Ki7XBLd5WlL+zTzDJIChkKtMIxJntUDHr4R1duSjWgdYQrIkjR+qRkpjQejjGR0slQIEg0bTPi3y8DLJurgteaauZ7ZPfbw6pn18z7VapcTgTdDcvzGE3YFD+2P1p1ig5aw6B7M8ILhNxY3qjtoe4mVhp8CxkGUT7dGb5RyrN9rNDB7/oLOV2gmZZIq0+n3JwU0stTgA5YBnRAfM5ll4XupDIvqY0ZsvR+A6MGBwLcMYUxaQBRnb0NCdc4WbnOZrTIwntcTAnK0BrL+ug2FmR9QcJ0MTPW1ERV1JFh1lXbCpV51Bhmgix54OkaHC7CdI2YXRxAaZNUX8+mBTmmI1DgWSdep/M5rQ1M35idplanSuZwIuchIL8qWQkYusmYfy+22VcbTY4OVrhZS98Gj73E56PV/6RZ+OeGyvcvnULDz50e3AgGJU6AYA6QkrJdy6FSEvOjJTE+B3LZhS7TqZay9DvlU3jSIpius476+da7C94KqAQzi/W62Gj/yDotsyg9XrDkflrubnMvrYwPjgpkfHliRUAYSk7zAPFUc1TCCsASggBVvXZHLZKS+CU9ZWg7+XMJXlVvYdJhTEDx0dLpC7hXQ+f41WveSP+7Y+/Dr/w6+/Au29tsBjRhI6G98AI6DfWjtuZrLYSDO8MxuxOrzggsB95ieW7TXdMdl1spUgyiOmAp3Mgmj/ICmpVExcb+N3dU9CVphiFJklj4thgj0lYZjil08jIPYh54+eTSuwbfAHyB5HzgmqqBsIBNVFCo7qlsFYRxojXJCUcVLXWtNjlaxSLvlvjdRizZ2lP0bL+jO7TdWSsiiebCQjSFQ0przwttx7anrgcmQwpg4yYnKb5hOqzZv6kKF1CzqQSYER3VGE5gShsbBoIjpYXIYy2gFakAhdy2tbLFP2MTOYDMIjDmVJt0yLnnaXyqu8eUqHX2jS81SthpnmrBNFFq2vXFLXUWI/wwgoUZOEcmbhZIKU1IMKtixe+q4JdUIQtoNXnFJeARBI8x7wJYtdcYdyae9ZzR2O3S0nXQ3WUKxbBpkMmY5H37HNEGrAAnOrstD13ZOLPmLH6kHOOVqY1nm5W/q0S0Iw8RCnoik3nlGQCMYl/Z5krpHXolFpmWHh6Ba5QXJjhAUAEaY15egQ7Lx+zC6otjJ1YI+dxy1ZcClocbnrHSkWWqB0pXG5BRg2fDOPDtHaZg4LFP93Iipmj7o9tBEQFrLGpsoUpueKp0rAJUf4lbUrYFY3a4oLdPD8jsqHQLYhoVtN6KnKwg7y4E5SozFRI5cxYbzMy93jiY07xig9+Kv74Rz8XL3v+A7h5ssLVejda0cHlGTI9IfLgBHNVjiYFaldRQBLCehbFZNbr2dohshS8VtiUYcGERx5D18ekMAW2frWuWmRQzpnbw7yM89sX6HMOkzYAuHF2hm7Rhb+dcx48Nzg35goTzm6cokvJNHSGx7XdbnB5udHJw/hzKQFnZ6elkpdBggi4ulpjvdn5mQAQVssFjo+Pwmvebne4vLgcWv7jnNnRaoHT4xXOr3b41Tc+iB/62d/Gf3zNG/Gbb3oQl5stVosFjpYLpFQ7nhUD9Eqb7RY5tDeavS+DO6oEjyKSkbYBsA0nIi9goAo9dZhDSbXDFNGaAsAxlEVQ0t06OWVn2q0cqz0nKcxCqvp8YGbIykfbJVzS/01TQzj4StPLmLMEcAVzoDDAUf9WJi/1UIpM46PCJTzu7dIip44TndGuyEOIPutkxNa42shczpHq5E2KRVlkoMw5OldcW7CYziFRI4kXKoeSegeTELTgWeJWz98U6K3kSxawOpgHU2BwIphWECmw65q9OFFgtZUj54utKvMeJ8OxrrpNONgrzUGq/UZVbKVbcSDI5ebNYWB/cW3FO9RIgSvFzmD/NWtLU8O1GvdhbWWfVyB6Rc1SFO2icnxQCj4JxYIC+5vmFbBXI4cvClr2He4uuDHrKLs0sCrotvM8fU5SgJhLvhpgUyAXFs6LOS/LParjbAAwS+GLCkFfXFDjqvyXRJ7pBQikqnzZpJUG4mmS6+pmIiNWD/xwi6LPB0UpGcuVmSPJMVhgAT/ngxx0fk1yQGxF4qZPSOb7LXskBvJ8gYa21RNzQ+7PAPWE0JdSW/RYcNv4WipCEJv53ca1w6tWevNSSw1lL6TprCMm5WtqxAcO88uUCB0R+sxYb3tsdj1unh3hRc96Aj7xpU/HJ7zk6XjOU+5BAuPW+QbbPiOBcHJyhNPT4zB+7/oeF+eXbn0NotqMo+MVTk6OA4Xz4TYuL6+w2eyCI2/oPJ6eHoMohQ3dq/Ua66tNaEVFRGPNExeEu92uXrcdJWHGYrHA2dnJbA2ykMIr0Q1A+G1IFg1IjfTHQ/qm2rEHIgXzQ1YFXg2QBrYX4fcWaqaYH4kQGB+/hn+SvNaE3S7jPbcu0SXCh33gk/BhH/gkfPGfeAle8/q34Udf89v46V96E37/7Y9gvetxvFpitRw6hzwlJbnIywQLXXeniuGxAtnZ+RdRa+DEi+8iyoNcERj94EiJlV49JBNlxaseO11F1VEGLmsVkA2q6FXtPD1O3x/JeQdrDyEzxODWFOJJ0IWgcHlB4HdjFynbIWxGqMioM34tjlHngOR7DUQODOovuUEkZltm51cC1/d9CW4jDwySWfJMwej2AY+s22HkEMaSHlipUh3G/279Ju2hZkWp2CAJJKX4ZRfYojaE+S4JVe8/1+BRCLOlbobplSuCLG2SWJB9KCg8zMBSfUdxn9eB3uTnxqR/WxUxagUZal26G1Gx6nghz02AC4x2dRHjnBxi1tSIk9RSVyRB72YDHCSoTL8iweTVRPShGrRkfNrZbDPAeAGbGCEfSmxwTv5MaKqQ1zlzNnFZybtraRphvwABIvj4XxJAI+Kh5PxZzqGTknufAEGmOBY1+5vkUTCaJX8Ec91mvtr5+8Kwrpgahadf1wVqFgAvG8aPsrBw4C85kZtIR3Sa8bNFjIw1din4Xk5QLEdeVuVa62xyAbtsR6/lN6zpMsJzr7I6mnisoHlrpVUy6utaBIXlBxqJ7GYK0JoNMGmul4xg3Z5zZwk8s4l0HGXVIZ5ktwKbK1WIT/I1hNi7WQdxtrWItFNzg/iW3UHKFkkxGfKUyzNoFHDLfcbl5RbbXY/T4xWe89TH4GM+5On4xA9/Jl7y3Cfi7Cjhar3BxeVmHF1LOE6psCkYrKQuIDx1NWWTKqXSYXUxCFDAqqYiMHvMjjwTRXdOebCV42SxstosIGqgDuP63eNlvPDuWDr9UiawzudpXhMn5D/z3grFDNxK6pBG4wk0j0K3xuhaZ0AsozBU9uN9b7c7pJTw+HtP8Wkf8X74tI94P7z5Xbfxi7/5drzqNW/AT/7im/CWd9/GepvRLTqsFh0WiZDQDTOH1gQ7kDLXFEZDhWm+UK4tbGtKaZLHor2kNmtQKJIRLAj8+6DqVa3rxq0oZ4s/38ZtDo2zJ6CZqr71PWxG3Gi2GCJbsFI7OWWy4zoUt/Kntcyye0tCczN6z+KwIRa5ZjXgJdcBYTczRqayZXsWW7UD1w1hR+FQ36qCEJvmHTUbIky1m+MIrBSe3kGBQ87oGjAqiQCQWSjNmhFDpmhB14SErWFJO2lz0ujhjIe1RiAj5ChQchKdePZG1VFpT8ZPLlINDHtdCuwbEzS288pTMciahs3BrDACL8Rwn5HqsDUbnM561MyKsjXrnRFegKGFkpjmUF1qX+xIaQ9WsyIaauA5E7ciGhUVtqTbSbbjzn6+ya47cj58dXcyECZqLaqkVQNWdEHWjANmY4dCLUAlYnxYyiip/QAzlx3RH1nNYlNYDOqiL4jrIiGcWEfVm54ceKELhSZa6wsN12tsl6zsbKNiQMDtf3Mmqe4R6/ldS5mXI38aIIq6RMF123n7aD436NKxBOkCTX2SDAAmVaDb58MB5uIBMDJ7jLXPYdLnsjoN2Hfq4fJyEsIz0IJ+sgvvJqAITel/AzQw+3wyyU6HnSfiEb0S89MU2l60LHEEKCPyBbKAEztZ2XCls6W3jPGmG0UgGYztLmOz7rHdZZwcJTzv/e/Hy1/0NHz8hzwFH/ysJ+Dx956ORz3jkVsXYM5Iwg6KLS5BrfMla4Bbpka0lyMiQEBtMZJksTijJVpz1XYs4Wg5GAcI7RGPvbFoUYJRtGNYh1g03Pb2NxSEeALVRUNBAUZZm8wqlDZV8cpIpOKAmOoVDYMU0pFySLeoUzfwlKcH+eTH3cCTH/f+eOXL3x+/+9Z347W//SBe/bq34ede/3a84U3vxkOPXKDf9VguOqyWC6wWHVKqPknZGJJq5U47EyY7KiPNaepsjPOerAw4/fNRRBGG7+WzDlQlPRR85HA4X5hcl3kgc4BwqysZdEG9xZCmc7IYYC5G1tPhQLaQadDeuM5lkDwU2au0KuSQ6neSDH5JzMCy4FdOXYQpqSeTgrHt6VZOOoSRuKMPkT72yKH047B00l2KarQu9TKogi7O166aSHNkDscCQtZDLvp62Y6b12fqwqTLfCVRSaRjJShUWjmJYt7rK+mArSSkecaTjMQsMNFI+zAm4lkf6KylJ40aMCmqJRlVHYJWkWUpJhJ6gIqODWkalU4sWYg+1AsleJVpTbEmQ2mFo/tWVFdaTUixLEmLIk/RIxifR9OZZw0kkSrEhstPk5S7YmWwqq+GWc/s+M+RTEXtZAqhCmLVPdTnZirvnMQ1T0W0ivRkirDAOJ6EGXT1Z8waRCq5dNbj6YJKphTUKankc4pZKtEmmgEM2byHGsNlYTrNy9V70KqgpPGu4ZBXLBRjawM9aqBsp0h0CktRqWmEaqaa9dmlqctCakbOKQFuBnGoF6jhTSipemL9SwBDLDIS+4GVKJ6tnaNiSlhEmc3jaZt1TjyVdV9PwAQj7FOo+mQ01G17X5t4kxCd4QnQlN1yYVkzWZGV62AyYaaCU4quZ/KPypjxdkYkSURjsC5WCbKrExoTkxHk0iAiB5SHSs8FzC27sRh5jc4aKIIBJmaR0MqQaUsyqU6SYLrKN0it1VofapYAy/m0Ejt9jqosX9R/p4CHMMZh0VkjYa/W9ztcXjH6DBwdLfG4x9zE+z/5XnzQ+z0Wr/igJ+OlH/Ak3H26LM+773O5oETcVjI187m+RStBKKg5/bkmm2TGGfFTMyd4WO3ERI1ZWxPzGk23BGU/O9t8A0YfQnJovADzAvXRdm3rFU1YJM8U0mSy4NhAKVqG6vMkD0vTtXBzSxFeFkjCGtTI08wqMkhEI2pZvzuP9IRdv8Pj7znBp3z40/GpH/503Lrc4vfecQu/8sYH8d9+4+341d96O373ne/BQ7c3WK+HwdRlSlh0NHifJPEkiJCLI0VVZpvUWItiEKpEsJKjJt3VIEfLI432GpEYOVMDsQ5K0hi0zSmaXWGtXJhI02Q0fU4MgsNdmlAmFeIelh5BXA4ly9KTAVaraHGQ1nGlHikaQUQDFK5d2fIPJMUMios3dQ8SYLoElUJD1CoQx+SBJNWYGzDNWMjxkDBaUSg1SG2oN/VwZMhTx5OcWBR8KOIquuurySmyg8PWY0x6YtkiIAyoEvxIBgKwHRNjiCxvI8GJ1Ax7L0HOVUmKrrufkp9Z5WGhBDw35Ed+LSpFSetjp14oG+9BW1xHyqjsqXKOvmNtM82cjqKOBmkoeS/GupeTb84oAQTDgAiemlJ0Iwv2sOgga1otaWOs4MCU1EHy3QTpMWk+Q88hsUr4KaIes8d+Jb16ABzYiNtwSI4gJRxBwtt1Ek7TBZAiCRAh1IijfevUUMUU+CBR+VhsQkv/szq1i9H8YMYj1qXuTtiGmAXz2c492dYb2fdqqLxk9ztC4JjVCGHcF1ddMNVJId2NN8qrFOQ2bKmKjqZqBZpIMVvIxmfF2AjGhkynTnaLnM4OEAhYsWuEa25wFQqRq5Monp9itQfNDKzMf6aiMrBd0aqm1s+XVN5D7Du1Ja8w/G7KdoMFSfwEoFG8Uoh1pmJF3ByfrmX+rp4fBfTPSOnG5JHqxUngLk/S7QpI102gyYOcCuuPmdD3jO22x3bXY9dnMDOOlwmPuesEH/Ss+/Di5z2Al37AA3jR+z8WDzzmDEfLBKQFABqKwPFzJ0cDRvU+J3fUyXqDnOItmzyFVTWP2Q4fkWUaygKOihiNzNeC/qA+v41NioK1lf03O/ZGjvk4IkfRZ/uCYk8DxMupolBxF7LBjWbTxZCKT+bhVgN70XG2wg4kq1VLywO8MESjeKWZvy+zcOxaxxEiMHF91+sdrq62YAa6RHjWA3fhhc94LL7gkz4Qm22Ptz14G294yyP4jd9/N379d96FN77lIfzeO2/h4UcvcXm5xq7vwTkPi5s6UEqlzZxSGsw1KZXkk2SHSNoQkBK3Hs8ZUSgV6kJSZurkjAMNkkWCKiUOQq2JkB0/3xVnyczrKUZRJOfHoC45ZUOlGhZ4GlVUb5SZJ4E8MoNH4YGiGmUO+2RBP6PLrOZaXNGRvMm3EU8qa4tIJC/kDIwLxkc2caooAiWM86rCE1Eg/xMySwp4IeiPpHoYymsXpzSF6nyecqa2azKfUf5NCpw92BEh7f4ko+bLIp4wkxJh0jQWMxfjgKEKUBBZEsgkLMCBGiCLZ8yF6uaOWpf01H3ADbXZAT0v1WoYrwfiMdBmk3Fbqjsg1rHi1ZLuQJDwTPaa6sK+dlzFKTrQRFee2RWunKburqaSDskE+70IM1Ax/iwr/lY2XYJqXswgpyI63KsQJgmUA6HihhY1IpYnJ6lu73R+kfMFqQJgLGiRkzeY9QZWbhiFHUGm00hI5AiVwtzaTBEZ3afZdWy6CxbwtSRrJmctLxKe1uyVpN0msVZSWW9JFFQ8dux0oW+GCckwD9g6GnrjbZnYsniPZEEmkgWI6FHKc6JErTSehVpxV75jqRKd3PVR6f4UIQrWBSETB0xYsT6JS4wvRvXj/5YANfls0gBhFMQQUmwkNoxhdkVGjS/TWp6ojTK+JSP0Rgo8ooACaHt6cgY4qTxGWSKU904K3AwmF4RP4RivBfhciELixJKdUCthpi0CpO6AyKmS3POCAgpj/yEBKXNuCltX1RBQMC9R1GtVnNgEBrgb8ysWqpwDSF72eR6icGYgM4ESsFgknB0t8ZTH34UHHncDT3nC3Xj2Ux+DZz3pHjzj/pt44L4buHHSIfeM9abH1dUaFxfAyckRjo5WztYuAgpJADplvlQy76SnNQtFY7JTlPOdPWbhIyjGemJmZYRsHKzm4IF925xhX+urrj55RsGCKOmZA9Z074HSmBvkSkmrEIIi6vNYSB4T7HiclAOnGfbn1KVuz5bQHtqqAT3IWNWVeZ3BcsIZoEIPfbpafVo8oxHm9LPrXcY2r3F6mrBcJDzt/rvxtPvvxse9+KnDv99s8I4Hb+PN77qF33vLQ3jTux7FO99zG+945y286+FLPHy+xXq7w3qbcbXtse0zcibsMhcGVfEnyePQKXikFIlu0ij/z0xINPAHu5JkymCXx0WVi1R53eCaClE81krXVFX/Y1LExrhUULZEB64mkPF8JQkOdn15TXJfLQA5G8l16KJgKkyTav3UZ1YM0ASdSnQbymbnAb0msbilQiElIFGH6aSYgixPz4jY0S9KEGX5bvK4NNl7RqYk6BhU5gwVcAFN04GhRNaELKkkiAV06lA1zio5Hzrm0wfpqW0uCSoJxL2KVzlNoHHtcR7NXSxVblxHqetK0cwC/aoFR13LTgOxgBNkcp1JWix7qyd13ckcsJXSPO3FGqzZDDDK4JfGgXkNYhQwrs+VqkwQLU3U59eYp9QUeOsrO31HFubR2anfwTlA6iKsFFCURCKVRDIlC+9cgKPybg2vI42fJwuGAvDx9PtZzGVnAWYP+2HYb0nQwYRvX4mbO7VeFE06Tfcj9yxGH9qJrswGmSc10KEUUIVAAJl3wfXQDZ4GRCynkU2SBGgp33kuSY8u6sh0ayR9ksXeRbGEKs/BzACRo7yNayJn5GBmtoA10HTuXNYZlf3tLY1ISOUnI74grUKqz2jxCR6IZIqGnRKp2DHt4fpe+7p/mQVdcig0KXXjPu1KjFRF8ngPnPP4GVl4qVVyPKt9I3KOQOW0FiFJdMKhbG6qjRFJjos6j2iKp9BCghLUGM6OVDtlrnOVkbOdPOXawa5/o+Z5E6XSHaqFMNXnp8fHIHcBicJkyNHYgODTuZjLcyzG7KTjEyx4M8Y7RWnmCUCuRUGJr1Q7PbpRMtkSmDMmsCOZvJKlXUKdGRO5ldSqZ5nzTTGaQ3GWlMbnO67tNOX5UrF3XJvlvA5mX2m0fqtNCDMrKdascD0YGhmJsUiERdfhaNnh5GiJmzeOcdfZMR7/mDPc/9i78OTH38T7PXA3nnDvGZ52/9249+YxZH13cfs21rseDz26K9Ts6UggaKE4K/JLVKdJBmEaVmcZOWaWyIPEGrCMOEALFin9ppI7Z3AegV7Rp5P2FaQknfznc8CosKOYjFY9mRUgyMyBxRgp1iABWPR9P8uHTSn5Lk9lziMzo+97JXs/URxyZqQuKeNO2/YcFqRueSvVsiQ7WIIEQwD3GZxSYMkw/Om6LiwWiIDdLpgvoQTOGV2XmhX8ru+R2My7jRS2nBnLxVLRDabOXpfS6H9YD+vtdgcg4/57z/Ck+07xEc9/YKSKMvo+Y9MDF+sem+0O6+0O55cbnF9ucLne4XKzw9VmC85TADKUmJEemPM4oyiLx+FkwyLVAEs0JD9JHIrTtfaZy+cQDZ1PZpHgm45NR5ayVg/nlDrVB8IYyEshkwyCI5oQRITFohvek5ibzJyHrqqWOhv8IaeDAoyOEtCR2IiCrkko1zIc5JMKVT3YUoX9TEsf5Tq0lLfoylDCctEVRczpXodkdfzbqfBgRs882L3QVMADGJOtnHNVauU6O9GVA6ArarnDAx2nJcbOsVcXHP7bsO6F7hizQh/7ae06b0QgURr8SIfLFOpsuc52ZFYIFglKxHCApHKATa8yj8815zwUZpxHYIgVgrlcLICoazglQAbUmg7a1NHYgU9FFbgAINyX7lXmKl6SREFIKSF1Xe0OCoph5ikpHJ5B7sd4Z1RQKdUW7xDvqoAQjYE887AHOeexAE/FpzWlMdkyitBDLE5wiJsETLIozMA1Hk/PXOwVFskSxmdX0luqycfAbpiSklQ6hZWSyEjI4zqGSEiMf32XnHEyDw923CsjrU2i0OLc6Lo0gDBpKgS68jnD88zlmRKAchYKxbZECV03FYbDOZunOMGMfkxAS20IACOTY/qubvTqLWu5XGwuiRpDg1yUCNxnWBlFomGfLhYLsV9F7MAQNzA9W67eWEmADFntCSoFMuc6C5U6KgVMEuANJUI3rXnJ4smM3Pd1rYrCb/Ib7lJSheYQTyroM70Li4LzWAxRGj4D41klRcZ4jC8599jtevR9P+YWtQhKBCxSGvKScQ+lNMz0p6ksyBl5pP9nZgXMoBSUnVNgHzolk77AcC+5XNc43zoVkFnOUqeKe2QOPUoYwGLRYbFYqFn9adP0fY+eM7jPpiAUPerxPdikmSbRPJauH3XeUs4qlUKF2TUqhhg35g3MqjiilLDsunEdjABL6orgx/B4e6XMqwDd8YxxMpY0MBUzGDzGa9Vsn95LmkDDJOKuHDyZitladBVwZIztXarAeZp+P3MBQAbbMS7PQsbXaW9FaX8Sz6YAxpJZMT6P3Gf0fUbPXGLJxE4jxfwanm+azoaxKGNRFE5smb7fjblLQP1HBdYKiAIaz2Ae98iwX7uRvUU0CMCcHR/jeJVwdrLC0bLD8dECx6sOp0cdTlcLHB8t0U1ntig4+txjO+6XPmds+2HdS6BYjqv0JUba2oULcAYjjjZ5+fbZi28N4ZzHa+NmB7Dveyd4WPfUGB+pRgUIJmHf94it/qb4vgjrD8LwTBJFpvPD2lsYC0BmPXLR5141dbKtjW7dPmevAFl/6OTkWHv9mYu8vLgcBzkp2qs4PT0x7czaBcg5Y321ER1I3fZcrZZYLpdh9yfnjM16Aw5ahgxgtVxiuVx4Lyoi7HY7XF2tLRu3JDnHx8fhC2MGLi8vR19GclTS1BGOj47Q8nVUg7fMuLy4GoKnJtKXjX3XjRuzTF7ut8PimrqsCQqhJ+pmKcC79VpTfsYuRdclILV/t99elUOuwh1DMr06Opr93SnJntA8zhWZXiwWoMVyviXf7wRswFWUhxmL1fF8iz33nndfkNkxeW3/MjZX67IZSSArg8fLcv6+x++PBm6YGRT9LmdsN+tKX6WEtFzNPJwdduut6bzV4irtebaykyW7w2BGt1wCmH8+eddXWhyRUhujEuRaa2o9Hj5kKMPjvcw+24zteiPow6QQtOHaaZ4O3/faL3RCtlPasyYZebcLDc2ICNQtZ17XpopZmE7MkKw0nne/Qd9n0U1E+3ty71SaJqAj2QM5uL7tdthvE7O3+KQyY3lyunfMoLQSWBaUQxGVlkf7xxQKYCkYEGP8WB4f77n+7RiX8rjHBtDBa6NDdA7u9I/ujtQuW9dkr/Sb9ZAwGtVmJmB1fHLYdxr6HsZkcXi3c1tmh/XVugAz8ixbLJfjfM7M90qAZTRrnvbMbIyS9CAB9GJkIhGAtJj//X63HbvHmlY9vdfUze/XzeWlKLw1Q6FbLvbEOSBvN17ReATP055YsVuvtX+ogPkXq9X8OhxBGpI6ClwLseVq/r3xblt/X3VIx87cnhidt5sRJILv2BNhsee95+1ad5Rl56OA9+1731yttUjzBCAzYbGajyW8XQ8FgFHKHUDbtP9s3PunR7/rNSVTKMjM7wlG3m4LaFLWwMRa2JdXHPAn7zZqdm6KGZnzAWf7cMYNTyuL7mKtBRZHxwfHSc4D4D0dfev1BrtRvb/OCvOYV3U4Pj4xgjXDAthuNlhvtoZJNoL3KQ1e4xQNn/DwnX0PMlR3JkZHHY5PjjV/XczYrtdbbDbbUBQfAI6OVlguOy3CPI4w9Nsd1pt1tcoyDOyj1RLL1cr4UXIpxC8v1rBeuSjPyvqrSw9Wwm7X42q9VrT3mhoM+cqCc9Z35SwRvIWALPBEc34SvmzSONPoAVKSmLGqZefP41VMpVCKQqpQe7aqoa1a8awCWCkBrRQtWz0UnqWgkpwb4oD+a8yrqv2cQLdSMlTZytTucx66LsyKhjY9i6vLLXbjQG1Bm8QzPz5aYblcamrXuDi22y0uL7a1nS5Otm6RcHp6AjuYDSbknHFxuSuHuEQLOWccZeDk+FhLf3Pt9lxcXqr3zYKas1j0ODvrAOvtN17Cer3Bekz8LZmKGThDh8Wiq3L8QtqaAVxerZH7DKtqmsfNcOPsVNBEoXyt1psNLi83hTKiHgszVquM05OTEIAAgM1mg812i2qYLQRVOOPo6Air1VKo3QGb9QaXV5uhwzFSB85OU+HMUyLFIb+82mG93ozdiUlDrVI+T06AlQhUcp2yeDdaTX64xuUyq2Cj/X0JV1cbbDbDoUNGzYQBnJ4cDygle0vfnBnn52sTXbX4zNnZSb1fw52/Wm+wvtp4q5XxXR6tehwfHXkq8ngtV+v1UPiQVquc6Bon0zO3mBkB6/Ua6/XWz0jxgM6enKa6J+VeYMbFxcaLBZYuRMLJyXFIibm62qHv+6G7NH7fyQmhS51Zf4yLi6thfU+IOyb2RsbR0QrHR8elEyhnkjGup+1mOyLXqCItYyfxpNsOnVkVw2t4u7i4HA7dUBWMcHq6wKJL2rhYPP/Lq/Vo8EtaDW7s9pxwwupoadQzx72z3eLqcl0LYAZSlwZ2A6Si5fATpyfHNmcoYNN2u0VKCavl0nkCTt93eXk1dNCnzsIY07pFh7OTYz1DPK7Li6vt2IUgHfOQ0SNhtVqG6m3DXr8aEtBESq11AtqWqwWOjo4Fk4AUbXy92eFyvVMy6FO8XPbA0RHpg0Fs6eG7aycqG8rqyTGGcydz1QQW/oeXl1foe02pk3v27KwbC3cz5zeCubfPLxuALY+xYmDkgHOh/E1fsNvucH45rKk8HsqVRZyxWi1xdnqq6boi1my2mwFMFl1vjLS7LiXcuJn0WhRx5Gq9wdV0frE2s2ZmHO0Yx8crZW0hF9v5+SV2uzwqSwKc64bJOeNoxzg77ZRlkbTMOL/aIGcr1lWJpacnR+gWnXHjGD+fgfPz9Vi0V7sKEmDyjbOuznOZ99b3PS4ut56SP/735aLDyemJKDR0Hnl1dVWenUrgx1GNs5OhgRBR2RjAxeVu6NySiTUjNfrsrCsddKkhQQA22w0AGpoTzKpYK9e33mC72XqPwPGcPkMyjZWaW2y2W5XXQHhEMg/3NcSCkRNBE9tnYKwxY2x+WKbd8G7XV1e42uiCUAoAro6GXJGZ3TlFBFxcXA1stkSNPJhw2vXlnNOK5yOrrpNMQyrUz6nbmkZwk4lNkUYhNVLOPiY1wmOonwLAZztvl7mebZJpKTC8bJSDU5n7znVciLRN5MQIq3oeKGJvlaafxz0sKdusprdktaKJ1HVPSjqxb+dpvZbpnpWNH+uHsyhzUWT9eyY+NNCZmSGX9KphbYrGVjxKYGwDptBUrBMg7Us0R5+lWp+YV6z02Yy2Y7EIlOX/xvY3qqxsS4xP/u+qUkieZgwIKwSfLNXXl2syyYHBX1HWYiARkhgrr9RWQWQuxfpIN0wkipB6DZQI3cLfGJdFL75XoKkAxtnDsYNRZm8YfR6oCSmR7sOJ4iCpzlrNvJkZizFhU++pHJpcVKQmU9hBm6YGgW6kEznvFpKePMPm5CySbxqae2X0SXSpeEzsu67DoiM1x0DiQBvoacZwHVAdn0RStbYePswJ1NFY/NffW3QDzVR+1kABSbBKhQNtskO/64Qwj/GY6aiAMvIRpUTouTfAhDZlXSzGJMuKP43PeHj2YhgedSYwY1TQTbFkc5I05CRNk+vAfJ370WtqeE4d+kVV52LjTTDQWW1XtoJGiTDQAikVRd+yv2m8r0RmKJvLYdaRFBbh0lFLKQ207CgmMrBIkkqp51ETTbRLz65YLlI9m6VXk3m+zOOa7uu6ngr+NN5XJ9edEJ2a1h+WXUDzB5gHf9VKHxfSXyLRTURuBmK6z0Q8MEpl3BJFaSIa34tIEbgeil1n93tdm8PzmPZfGvfxCErCWL9MyUkBgFI5LImB3A1rPxVNq1GIimTizoXaNUnBMzDGQ0ETp1oAdGNMGP4iKUXaKRYyKxKGWkaVxiVUestc/uSdq9UAK0iawbzw1HEGupTQUSqTLySB4YlmSLXI64ylUZcIHQHcUWGdTO9oahgnMuqdIsZFa7ns1SnOCBVaaT1S5itptLwgqQxM4C5hsUxaO5crHaybzi8BXMuYPIx/VCr+EEsTEuVR9I1UF6t0LVN9p6ksNmFbw8N4jS0aqkXFEGc4jaMtxVcgjedqGuO78TMVhu9dEtRCroKQPKp3p5HqXYisica5eEIaz+dsbb/E/NpEv3dFz6hdUPKGUSuAebRpKrnK5GZgbDvGWLhIeo6XRFXQdYSuM2c/yXEIQkos6HticGWMM4n0+av0g4nNfpJejsMe6FNl4xAn1clJKQnxE3KxqhOjWXVesBYzNY9DBYMJ6HiKJT7vKfthkdDtUh3FYF1QddHZTJbGWEcbSIwKyYIuOT/Wce0zhf573ohdqOkSe7/QCTyiSnGXs5Mc2DF56qTIgREzF1WBZXJ9NYlnmR0IVGKlJkUa6eJshMvKHGpbsmbKt6x/qdXHZ9JWTlrNVEylKk0gkSOG3pFSYEm0vYlMdwMBIi9NLtkjeGELrWxCrnM88B5hIO3pw+Yg06lam1csp6kZuSDf1tBXdkJJKiRmeZCRNuGM6s+gnpQ2EbVDmRtXDlMs1E5tkcV37ugTOlmH/O2MHbPuSk4f7hy5zO0NM3wsEgUqc5RV2KLyn6ah2lqIyIicFcXOafiJpC0J8R6lgkpQM6z1XlkwAOuAu3c/n1PPFWjXNKdVrxhSlNVNNaPO70yiP0i1wJUiOsSxNTEHdheq01325GThwrJ3rYIeO0oj1L9j789RMgZ7fxbk8Ii9eNds29B+k8jfZ2UHAOxVQJZWHKiy0mV4vHLUdRePhCPqVGhQhftYzgqD6jwRBIopjJMJwvNxzrweUKa9SrVw4m8pBxetDhcqsIbPl8GSAJLr2mM2GC/ZIl/Ka2vTZCJyR1HpFrCWtqdARK3MsTCKkTyRj71FOECGtEk5L8ePlJSQVhVrKMVhsUOBju2KfenFunUyY/YOpnnErGbuqxeYtsyAOV+K9YuQNPfJkwCxM49MBxHOctFEd37xXiadFUtG+c2Vh2795MnR4LSiHetYQCS8+jgIbIC0jGide63kqKhhBj4kWpxa06tYOF2RQ2nZFMesc4NJPdTEyGH2rxMdiTghHTrHIqHHOHXIWjjGdjkUjZ+N2Y9S+A7M21XGyqVDMJ0rzNxMmmXHiJk0FqcQeNJq33NM4SnxFdLWHPmL0kuoAABikUlEQVQqGh0Ge76kUjSysRKJT5ipKHXpjlUqn/ZY9Y8SnSKTX40iPRPdOBG0NyLVM5giURIFsHFEvSnCM+q5cNC2b+wTTIJ/ktpM2t4p57k8vRYRWuU5COzWmsQwefx6Ew0VdRwZQw9u3Z+3OiIKyYnB84ZyTRimUEVflcjXDOb35dymUyQOtyR5CyLDSKGAYaZyV5U+s2I7DWclm+XjRcm0SBuMMb1VYFQdsBG+FxW5XtDZ6fFXv0puVrkI+ouT6tKAtA7oW3L+N9SQfZXEVU13iBZTUWmU3jKlIDBJkDoMSfvPjd+aRKIwLKCk6G/KDwW1SzT5BFAQD+UeUx2lwNJb+34JkN60g5VPHbNKtCZBfaV+Z13CZWEFiUyzo+HKiEstNdCsURbvPZdrYGUz6ExxcK0DxPZg16qxKgln+5m++y1NU31cn5BRqeopzW6r+BmxxXbIFMQ+WSRjzhsH7xEUUAIcViiclaemvEdCD6kdWE3DjPjdzKFmUTqyJPpmlsDGg42MHyCVrkfsssgKSa8FPus6SXaatPq/QOzF2gzYDKyrYBdcB2sUdWI1DiXWanQs9w+VJIKoUUtCewQyosS74ZvpJPVJ7JEgmZoeiUicUoSpsFYdZQmIuFfOSnC1SOGLxN0WUHK/MscJsKk4IKXgSKH6Jo4qeqIRCBJnghQ5bglryN8h0cWbBA4s4KhRfQuMxYnQRBOsBZz5HSbjYQVtnG62mwSKrdq3SkrMqlC2S2Z98gES6jKPpAigjH5+6uqKGEdEexPButGk3AqpwpBAbVSeUYQ0qq+AKIaD4lmCzHX9ZVWEhyynRmXjrLqUeC/5ghYa9CPyZDSeWWOQXoiEqg4NbSFBB7xo1afIrLM6AVCzpWRyBaKJ9Pzf5PVqBobcWcyiGNfWJw0PvkKhJy2QTELh03kz1s+TzKXIzoYbypK1q0MGiBI7Lwk6L/Ne4FEYTqBmVaLZQzP7VdjZgHzcbXlyHr4whF+rDEks8/SYBmq9lHV+mJpaHh5C9KqwzDqP07FZezZLtWXHVjHK+aQRQavZ6nM2DrRd5HnIUIYYbH43Pn/Zx76pICTJb2CoeTOaK8/hxrxq4ACFheAk/kEK0amS+0XOOvIZnFaw6UwUlFmmwjkWyHGbXshlzy1gO8fjupIuYTeVloVLGgbEzbS5oJyIUnx/arArGdtejEJt0yMiZMy1OejK7ENzYaTNdb6q7tvK5dNIw5x+L5llwX7CteSkHC13Umg9GbPs/XfEYTCUnWzVTRaUnynosfFQI8ysO4uCjc/EwcgOeteScTwOJDu0sRXAyXlyo/DnWHZWfCo+nV+JSRQged+jVJ8kdIVFh9x49FHcirfNX+X1jLbYU6WfQChucmz+HhVM0tEg0QF+Qhxk4JJ1wXs6JOSu1bTnvH+r7OqRp8NERas+zBiR1TY3ALtEVItImkd6/Utlq9YOSWOm2dRZF3rW3FcVLMb8d3oP0vZkH/3I922xt5ibj8sx8FPPUTjPSdr/gfrJJHK2wWVsb5wDZuWtZzt+ggILmiPGNPMG99TIsgskkmHA2bEYS1I9kLw3YqS7o4Gd+l2xXYA5xFjO1rEuxCxgmGLmh6SpErHV+Wt4uQovPJWzMVrQ6HQWMYnkIUMpR2tF9Bb7xJVY1rgnhunlmtXBVjEOWKhZy04kB+rw0j2GaXBfzaGPNrd3FPvI5XYyVbGjyd+PxHkysaRa657NPWTWc7Q+xtrJOb2UKU4bD4g3rCjT9aVnuz08GwCoNmalKKrgQMm7SZ9d1hNv5rifKREFBdKe1QoIMzWIyiGtkrq0ZZFnZS2Z2eXoCEbIOIYRuFHsKjAKjQzeABjMvtCO5JejzxUgn7QVtJ+TZNNg/J1F5TnHIAmF21/DWQzZbSJVgbLxvXGJCWx7nGT8DxBvU2xJY9II1oahwpE2MY4QSSJzBsjEzSY24XyNU0s/5Kw2nGRxAJlnWtv905wQKYETcV5C2SPYwyNSabNYRlJ9sjCoxQm0P1PtQ3DddGHG6ugCsgshTVLZUBuE8SibzmWahASgZ5kqLWKuimZR7NlAWiXcC51O1n3Wh9TsAyIGIfLHEwFPBN+5taQQKmUoSy20w3VS0BCWIZOIqqQKssNPe0+uiVpOLeDHW40h0VRaihmwYu0gD0DSnc05doEKB6yb8BJwaFYzFciyYkMFhVOxm5VcPZF/qRxid42DhqstSlHuFe+zjuOQEqFvrgfHpIDZS5VyNtCquoqCsknY5UskwxOY5nbJMDrknY8WDTQGh9S8ZIqZApACB/GZ0ySZjc+xWpak2e6LZpjIAxmHlnwGFgzof6WFkl0SIK17pnpPfU9mhU+y3KscdFitQzyza/aHVDaKgEwKQCtohUuzP6uHGOuMbHwvibjRzRJS86yBuETkZn7AcqxAW8KIVrA/z6CRTGK4jiGCuaXqkQklLHOIITUBwrlM/n82dFcBaIjEV79SAfSyk+8zucTkdUjCUxrKj5fsI2sViLLoSkIF0Xhhw1l3eeZDoQ23CkDh+SZBW5rm0IRYhcr1SANvQ37FAcCmC2I2pbGcC6OAUTCc8d7wvRSkcmMb4+xK98z+zSkEjlQsJGMoTyzHFtoIltRy0NRHOOKaK6BMh9gX30ojVMUROgyNmz/jS1oR+QmS73GQKRdMvktFrmPOrJ7CxJ/ZALQl/klhrVoLVX0jVkKOrgGnxGmyWImMqCyyYpETPWMxqVwqy2Hx0DMDKcuggyqXLBew7h/XjWLavmoAkiHMWYcMWPOA9XAxu+HS+hZZiRmkykTL5vjNZBRG2SGVnE03xwQ6cp0iiYyQPmzkCZK5nYBQFafhQinR6JEsJLQRLruzm51wj9kCJlthQ+urHbSGspSjCE12ICb42p5psujm8BOJJ884SRtghwwpVJXhKKdhixwVzbKIoz3sS7ciG6RvoriR6VSJVcJm7oBs5TShdCMdklQni8p8hw4eY7+MeGRoG+o221rDIMnT8ism3GwO9SppzBONOJEf6J5QXq5dSxZzQDQq5qrDw+2FrGYRpfKlUhBVa6wmJxlZvfScNYVJxRzx+8VfDQzNKrWdB0kJZ/37JIx3rerlhGZYMVFmcO5Hjo/GBCfxLIUMk+1aZkhyJgmpyiqqQaO7A48KguOxz7U7NoBsJOYsyFBibP46+vplM6/EZohUejbCzJmNRUUS1hiS6kK50nAk1ZTHuE5c+8Wqs8di5g4czqQU+rlaP8MIac47YTNQD2Bm430GPVvLjkZkaN1FCVh7oHFrVhsG9FPoGo1+kOQoQzReZ1XsZmcw7AoyU8hNcYCQdBNMPMfMbGYjrNct+a4oaapSGSzJ7FgHar/KERMSPm6gqZExXPMkVtag1EplRiI4TzU2uIxjHEF0QeWsq0X2BP9zAuqKimDWowIuZXUURA1UZ0vd5qCbIDqUbMqJnPXnKsWHlJBKi3AqplgNF7RAs8lovmTDQezIzI4MIrUG6trRMd6VWdTgvRR9AtNxUd6x2oLEdVxkfiqLLaEayS7v4JoXTs8oQ6msomShSb0nHmMYt3KncXEVj+PpfUhmhbmH6T57HnwJkxWUyRCtYBTauqopJ0oAVZXaGPypObWyKzCNhGl23nX4KxYlthsrromeZAhm3JgbHXb9/CefbBoVlYvFimJuVS/Wwgrjeh5Iz90KVkv5F9SOuypENbrs5v6iDqxi+ItyVp1FdWxniKMkitQqIKb1IKLZfTbgtYDl5Mz/brfjdgHO2Ky3Zn5GF3fLo9Vg+G0QpenD1put6QhSWRmUCMvlwolmTN/S93nw2bPJyojGLladKzCr+ePwuywoCjKoLJdLM5NUK4vtZjfwrFkP5E+LZLVaGWSgLuBcignGbtf7wkiczEer5ZhEs2o/sn325PBbAIzlajkq0XlkeTLm1eMGdbF3izQaYHo6aM6M3W5nqFRcvJYGg3X7toZ72242Tq1qSvo7SlgdrcxGr89ut9th12dQwOjgPHjSLJaLJpVru90aYRRd7K6Wq4Ie2zQ45zxIKwf3NUmKH61Wld6sYhih3/XY7bb10EftdE/y88tF209ou90Zw1IS5tNczOq3m22zm7Mo3+G7bpwzNpvt0HGR3f0RqKBEo2y3nztL43rajZ5wNvHPoweOlL626dB6s9VdaJGlEtGwLsIoMJjAbjZbaKHrerAslwt0Xdfswey2u8GsG9VzrHaAht9fLhfCIF2rvW23Oy+4M4r4dGmB5WrRbLGt1xvhW2oOhkQ4OlqVw1bDPUPsHApHnZh3iwUWxe5h+Ge92bhnR0Q4Wq1EjNHd8WG/7ZwAzmSdII2wJYY0PbftdrBNcPNboyH1arUcbWD0mMAE3m03u9GHVQpQVQub5ar6OUXWQbvddvBjDMSoFovFYHMiAIW+r6bwVcG2HoiTwqMT38J0r7mi0KKLkYoJcZXw5+KxajvAQ5HXdcmoRFc6+3a7w263A4QhvNvny2VhJdgzmwHsNlvd7VLnFGO1WulEUuzLzWbyq0thjr5YLsYOl57jmsCYzWYTxuHpa45WC+OJphOX7TawJ0B9R8VeIOgO933Gdrv1NOApjncJq8Wi1rpcIeFEQxweLGhSMNPH6LoOy+XCPRUa4+B2sx2TO43CM2NQqha2Dlqgn7Hd9sN+JNNdH+PSYrmoxvTsmaO77a7MlZKbaQdWy0VVMSUY+yfGZrMrayqNcVIWxavVsnSeWSX+VO5dFl2Eak2WCFiuVmGhPJz9/bDmyceiyY9utVzAaRSNlNPdbofcG1Ueca2rpV5zOqYNHVsZ/1XOm4HdaOBeubYi4yIazyCTBwsUZLvZORX/si4WHRZdBzduJNb0blfPoKk5M6mXlneuwIERWCLGInVDHJUdKnEN/W7YM1ZZdFJYX66W6uS1lNcp10Tj/F50iwIGS54bCxB7uezq2hSxNfOQt8hu77SElsslFgsTw8Z1v9ls0O96f7Ojmu9qtWryTLbbHXLfC7V5llpaWC4XSF1S3d8pHvY5Y1fyBf3dkxr9arloMkY2m9EaxsxZTGvn6OjIOBXUPTR9t/fZrUX9svHdxYO2S0mXeIYXlnkzPJwJZTZt1EQJ3SKhOY+63hTOrx0HSZQGfxJ4ny4C0O/6wfQ+JNoQVrSqnmzGbzDnPC4IKpQOpmHTp/Ew9iIVCZnz4CcVqHANBtukDnKHFjOD09C9kJuEHCmRkVKH1FG1X5BiLQz0efDNm7pqciiYAByno1Fq2SMQzHnw8IIwoK2EOyxGzz6JHlS5/4xtn5EN/Ds9k26xaCI3m81k+KmMiIbf7bRUuhXu6fuMfie87GSRyowOHTrhZWclwdfrTU3ahJHpBCSmY9LPS4j+7HY7/P87+7ItyXEdSYCSb1n//6PTnRm+iTYP3LBRUnTOmdtVWRG+UCQIGAxm329W+dtIJIof5FKTWwqkhfOWq0cUa9XNiravi/7sIQkwa8QypWEb0qC2V35VXzlTuAFE60KLSODVn7QQeqLHivYBlGJ9FWbWLLpoLdjkzzaKaXk3AsQr1+8XIe8lwc85K1plvxxSs7SwfWzuXqUt8WfNGqqS5WsvPHwYbAE+V++xrNn3KKehqEMKkYoagDMwLiRIFeV6uSSoPaXnEMqzL19bKJOK/bMsi4szqc2noF4OySCN32JCnWrncTPorixYliV5wRGqViMbU95QqbgwyXMmTmVdm2G4Peuv16uvq6fOo8qlezn0Zij9wpu2vIVUNdCwe4m6gCkxfT40YrzpBq0r1dhqvjelTgNFrl2NLdPtfgtFXlqR1hIySPS7ASI50/1xU8WzbOS83q96UdfONjIxX4bvaL8TE3Fi+vC3o92yU8eiW1BUp1Oc1HAB5kqxzV65Lg1VyGbh05X9mrdgzt0+Q571VpRpiX8t/Y6MAoKE4xhc7r0UwT887m1qjXXVuiy/L4WbVKHL9d7NQ7FTdiZrIZ7WVSYxek99v2O/w3qMoxZ1q1AoFJTsvNGrxjiIBLUViwUEMPeXiKXvz5dy3oh5GZClAE8T29/X3Yzts4n4TsYHGMTpIhg6mmrbzO23nCkx0SZEvNr3S9V+Rc3Li/3yypnkbNa4n0HULJRYW4iN51YKi6TAK2GhtSyU0vz+bKCfVrwdsXaplh4wwDgLNoYsxKWqOxiET3mGDJBUqe8dcKLqA1vzNakqDNALW2VwjKG3dm8vaaHlmhxLS+ZFOTffuhGpGXW2vt6PlDy0hwxCSpSWZVB2Va5cPCKbXywbEP/Cq/IPLh0qmAJqE0WMmLMc7oAlf8hZ+4TT8LdN6apiQv/+ucQEuZZCa26+J4ACsCc2FPCSoydhEWLX+9PyJEMxbd3i6/Ui1gSmgki1EaVFgjqYt9T4FUF1zPT5cHnGHFD3udxpMajCtTjPRNGoAoiWlVTtInPUtqYrSA5bkknkBkWFZCvzkOku0JemFshGRb7DzaxQF/n6GZJaFYKdJlHQHT+FlAkvpUgBWBpK9+TPAj0T5VQ75uDUKElrsIzDZemHlqcB8bmHMlGSuiGTtXc0HiGVzhMpcKUCJpVR2+EWNLFJSSOGrimYPzKb2c6pyG6lhGeFyq1ODmUSmUlPI3jUvFCxArWmPospZ2q0T1nlItDeBJ8VvJHEHjisWQMvMKiOLCz73kYW60hCjou7LJf2ocMUCmJJe8CQhB5JBgs6Dit0j6Q9h5GKjuRyx+C8oZ2ZQygVFhX1V1GEhkx784TzUkuOwyZmAsxwAGl9LjcDQoHtTaWPooL3juGl1AWl+2xyg7NREuCk+k0SA24XvaceKmCPi78qBzL2ncvTOiTmcUjFWe3XJPe6iLHsPrKTz5cFhLY5gRphbUnHvkgca/I+WKEUjnXCRXkOFezLuVpy1KJdzT+zCvqDik6suhJCW3r6CYvwSXIjBi0WDloRm1gZzXvUOcpQTEwmLU3VGPsS6Oo0MoXcSmlaxzQ543bzQIlr6TnCHbGP9sZpfIfW0VQyQtBArO4eS1uQRG1qvDA2eBqjZI3CgsJtk0Ibk7TDF9QUbAPBm6hXdvHZjzAwJUXhkn1ESNVX0roMTgDKfU6twzkElQxVk4VQiLU8AcRIpY7Zqe5zaEVCpQraOqeBR5O4ETDdGTb30GMrkjrHXpUF7Ga0OeYwi06TLixZl//iR73KLkPMb4LUug1vbSi6cExBjOJyjWHEtGXunc1ZnHfjPeEYkc7Nkukgh5tWzjNLtpeYcJWCYVK8iJx73Vx2BrKTvnOGsaORIa98nijK2+A3xpaMb5/yQWczGAg1UseGKeGsHiUzX2oeCOT72EZP58421rZWECKhsm6BUfbjKpEk5xNSz1GZZIGSp2i8V6+B5E3rc+uc8fDuanM0YVAWiTjEMAZoeIzx1H7Ch1K7uTiQJ0rmsGeZJGJ8V8DkwQd+J5KyIU2vmy9OJGTm67shKMDQcsdk53pCSyWjZARyyLmvGaRi5fi3M9p+0ZxImDYhTvIUlUcUoZoGw8JPzfaFxiFqywX4BL+9pqr32h4BCIoyZYpJ24AjdvMestjcWz0WF0LzlfJaAxiBVNCcGj1Zuqgg8p00Gcwgn7T1XcxZ1kjv8IMzxcEp+bB6pkA62Lbvhbk6mSZLy+L4DDgF1Q0FixmY00ptLFBPiI4FREnibu1Q4RYo/clm/rxQDud0R9UhqK0usAh7G/J2OD14VzeNiLKae7eKy2y1tdOJTHYD8KMVIWyKewcKQM9rtjXpohViJjWSb2BriUKDstNMyilQhpV7HW3OyfxO57XJAjaClUILkv09aEWJQFI9j42tHVOS0zVSMa7RwMj65rJZW2gxCGgT9t6MbwW9sUdoIlEK1AuSyCgRYxE+slZnMkosO4uWZbJUixCGKoTjhFfc0c0wPY8uXZ9/Dv02vXQ+Ai/UuaYFhgl8vy+zAwKESoRad1UQQWQvtgiXPmORiIYRR5FyKHIiWeZhOmlGv1aU16ososhbF43vK5JhwSYBKDa7Jg3K7hXqKopZ71u2M1uswA7QRA2ZWc27RrZVpJ6RzSxZFdjam5v1rBaJtVVzYgZUZMwUXgiUuw0ZW99jyI44DvYr+U5y71bDxLvJTWupu/I/5Hr99Hhjpe/P2sRUUKaNFigets3jPOimVEscwoad+x5C4BgmfZqARCZt95AH1BwsrHkijQZQz8+hwWuVczoFUfRnr1KBSNHZAfOV3hv0USYpelCC4UyZIDEuCgRmIlsIWzKzNis6voWnVzNNCrkhfYwQ7VYZunaGnSKfUsnSJn4gMp5Wk4qyfa4uusG6i0TGiDKorXQxTMrt+YxXFP1yxY273u+ekZpDxa4su+1AKIqKQk+jjhvVxNz1qYgOjG7DT+M6Tg2JglH5nHk2svaiY9GZNagXpO8kB5fqXu8eJOjBULWD/84IOj5SPnVcnvjVnqCeoIWBztIMOdhFx0KmuqPWC0+Okbqwy856nxkD5dNHR8QUfVkPWmzUKXSeLLJLaWMZ60KVBCWQAnYCu3lMcup+Z7a/gl+UekmgmjtRm7Qd+1NBSNqKTn394pgKwXbYZ5yQL3QomPIBhWMP6kzamZCs1ZRVspJ0V6KXQnWBlwDY0t34SDUaoW9XHP8FSwDkqGCuD8+x4H5PvVVcSSfvAQqtI/b2ZFe8hG4JgIhO6nxTd6wXrKChontk2zPpuMuuMBl1UzIN+1nHPyqiCDvr0ARvskuK2egF9RELq2LPcuaLtVhcRFujYd0hZ+iJnL5vDELPOnaGZ8Phvp9WkQLRJCM6AyLLWoqsrITwlxd9w8nCZgjNqHhJXkSU4IE0pZiK+HvGwjU4se31iyoYgzF1ueoxySrjC8Ar9FzF72woNIBmOuKIwaHIvkPfdnOrpQyoxmVnOOC41mkCYy1h0qAFqz0ohc8UJVZWW5E8fxgWjJKsx6jHaIcRo5SfcVVD8t4KSm0099GY3PBy3O6tASJrGfTAm7V3EgZDzyQuXS3n7K0yCagIzPrC0AWFCASsL5dM6YHSHBa7bA43TxtmGhXzQdNaW8b7nfkX5Z22mjJJPU8PQkOVMUuvz6BByiJjj1IbJP7N+D2RU7OcyD2pQ+4MRsGaunVgL2dnpcCeOndUVDLvA1mexcFkbVRmPmkkcOLISuZEo8+iJFOvx9mWioGfeB056qKQVgOLSdPmM2TZ7I6oOUReDzfshZDkvmNS+8G2yzHOcpJFPWPS7SaPasI0IigWZ9BUd/aXpADWmDzKP+d6xPuhKc42r81JrmIeeezneZS2S+Qcgv4+LQRtwogQTz0Hd8E7RkH8tzLjbJ6TMRodzSGh+jdFLrlX2BLICPI3VamNDjo5fzs3xx8vMokWm/KJ69034HhT0EDCJXi1ZzzfKX9KZXzMtwQDH84sutOI5QxPXZ9zYRjGkjWVuIxjdgzMFoc5uJB3JTCtKWkw+d1duENSEUxndsDFjL0zACOWvj5BzBv7FhM0TM7nTUP8fIQ+AP2kZgUHmg/BDcPs0rte7BpABCKnhIsxZvSJhe/0qVts5wYUeW1QS51ExbQgX9RimXocC5Xs2OjGoF/AQa5zrnmg5wfPNghI+1aexIPBB5/q6BzFN78TYNsNg2TUyEHBOImhvzsAH2a07ugZRLRa0cU2QImyb2OmtVOGeHI3yBxCUB6kH9XebpaYvJQYnnlLQ9A6RrOEfZAIkwCzALaeU35+toNt6Grz06SqcJW8YnThkknAoAwxPcSMifdUkzKeIoPsQNmdk8n7UGsgpAjTJUoniiGrMXGEDgaoAGkjuV9EkBTFTNFtlElixvR1OTA3xi+wBxVc+STZFmJOsVI1dosEt7a8T2liptQWSElfH6TkiO6UmRm1RW2hclwWc4tWsdVahvR/b3d9OvEcVAJFhqLEwVzi3t60E0LUE3RL7Z1eRA3UEbM0Y18mkop2ZFSaI5uF+aeEaygMARQR84yx9yiytYH7KVc02AuWFRMiQvKNHoMT2ompWhQkJ8ZqgdlPkjp0hN22+AVBQnll7SdAUBXCGJlvIkmZeCexhep+suok9OLUbTzExZW8P1lPJ/Gs6FYUS6E26WwY4lVKzLQ0YY2A0WMVSCPRId0Rn2d/urhi3d6yYOqJe2jYzxhZeT5xCdhuhPINoENWju0sJuYQ8KEYC3Dvn8BxYhyhPpKNRLx/7wK7Zcrv/vgsn/UCBl6W5JJaW4iyARDZOahMQD3npSpyXB77n53gEB+Dmm1Nk4WIBLtip8Lsdk8ydjUbgmDtZs+ClR0aTwrwSaYYCbeFbLQo/WQdw2SsmoJEkf2cjnG2u6YKD//1jHWJjknSEYKjluYJYEjOSFqthNGly47h5sAbiRLx73LoXp9wOEPmAfQmKqNlrQO7+0aDCOSGpRkuW7qZsquSQ5qDXoec/AMXr5OS4bnLe0IWjnKvCrrHUD4CZRXfdmgPhlboB3y1CasOqAJ3ZtKKdLZoahduEtsAOvtua1wmj1gh0lJxkQUXxA2tC8hySINbug8sxDhMemEvXsyL8eYr1nyn2Eh0wCedlkasqE4QOlUQwkczfKgatXrzeLhEjdXpq0ppkJSjgYZouWbeudBzUQo0PUdgXkh52L8VG21AODk0FwHVrXVnbaLLqsCmLkWvUHDQMHrfKfMgul0KwKhS/ur7gYg4O4+eIhTBjhffE7EAiJDzIa5hhuwTJjZZGQtybHbGEjvPpnnCkZIch3gdJYiib6v6fxYibM6rmoVYiaIui3OdUqKNNhE/IzNuEGVQ3kDGda537pQ66zQhs3LqUBcoJuIL3X8KuuAijCI4pXQApMBdtDAX5qChaUAwY/SNRkeFaftmulwkCMfd6B59xi3rOVmjuihzYmDEB+V3aMrx8napqqSKOhS5CzVJARBPt2xKpFsBApUwV1vPJQZkIjNLBepiJD5ESpFRsSyr52ii2Kcy4gTJuFxoV1mIyY05Nntns6n6hu8jKSXQ8QrJ3QE6RorVgmZUwNJmZ1EceTIDDJc7wCg++9AMf6+F8QaKTm67XDNaNJu2ovbK9OJfkdXWsA0Z9H/VOTDhoZuNWJ9PBMB2U6ZtDyPpYnSI/rGxp7Egf3S/2OsTQe5b4yuaciikwsC4BXKLeWnauS1efdpDe8LP6nuUnTCVnEPDbjcP+oIXbQN0wZamQp6z2WcYjYZoPMLPy2bKOcjo7IhX0MWydHoWowMAES1ES0pdvEsBo108ccx6GmlIh+sxBwWeiH/dd1h5IwqEdUnOnaR7KJMRTjIzvEwTGmyzyKp+gc7OhzRFGCTV6M08qtBV6CBd/a9jVnJi6wOMvFnO2gMEpCnVu//z5/1GpPjXfqx4cFVJ2u43ODZo8REkXTxhJBTf79YvbcvDZia6XBaxGKxNVxGYq4sNZaVjhSBQsTDIWxjYmalbLkR/vu+NMhXDTzZYbvnMwwtIoUG6jFa+cs4rCsUra49G+fl+CTl3pFCT3YjWyxKY9Dbvttx94yJsoUhIL3GvIYM+32+4bVLiak8A13QEEW2fb7dF6J0NDMW7y+VCM9C2eUdGER9VKvjSpN2ZtNEoCV80RY0Y77GuSzfKtshkrl4/1mC8JXDle18U8if0AShvmd6fr/Jbk89+WYoHDLKdJa3P6/sdMvH1JdIy5Nnb/hl+RB6IYV5oXZNKBGURXXwxtypFL6Xsy2ftZyLI/bcsvYY0ep4p05IWcaagu1uoe3nKYClrO9Yc6rPnjOoNFhi4Vyn4bv1ghvOZqiw2MiUyQERdoyUZTzgj0PP5bkS52b/o55ESV7+7GPX+fnO37WmelbK5tS6rACMMBCXmRyCKj5RSP4OtWHsLv1dJQWo+r1EiqbxKTWxG9WtaUhoG9Wbxv9tm5iSsrY712tP5XbkbMiXTeUM1/1qWtYOCZGaeShK0VcsNVp+Nu9T8ojxPm3z5mO0e67yuSeOzRn36+/32pEtDo9RjceIk2Bwjmci5ysJLoRZuhZ0vB3Mun3Ukdf68yO8Wrf322WoioRPoFjv63QPNfGnPBTWRdiJfRGKtbCFaPRA/Za1SNAdefde656M7jyi2EyAnQNJYNs0ex9NPUWPFZwArBqPu/o8w71v3xbZt1c8uYJgA6v0116ms39fdm+LOTYkW40MoH9/23boPL7fZFIyVbdYJgVpFvT+3al4t7XPG/l8v1aomkksC07Z96h6PVRjXahvBpvPVCuX35zMop2y68kx0va7DVlHsIE5c85UvpU5F0myXJSUl12+s0YtF2cQeZ3x2Mc5ttI6Kaie0JywPUcGvsT+DUeFdUhI+eqwANWpnAuL1Wec13pN0/NN3y8WOJNAdKEVuHpCCHFrm0WlO7n4TVi1brvlewFLj4uHYrMtgOBLNh3B4IXpWTqp2GFvW4L58q3VdnaZDi0/dP1a8J3Lxdi7rFt1tX1XA91ylx79F5HHj3uTElNs5gge9cs609LyMQwJeiZ+kxGjGSFXJF7oAEGvAqtnsccy56nZ5rkCuIl657VOrOC7OEfGcfs3/7//9T5jLtL/88+ehPL7sn3//npTzZr7C2DJ//jxKUjFptD6fL/p+NyHFOygxl8tCj8cjRIQA0L9/P7UAgENT0pLo8bhNkcCfn2d5X4Oscr2oSwJ/MdX4+A7v90eZhIM0RZSZ6fG4u4Refv6/f//FzfV6OT3+PEJvlpJkZPr370l2LpGqB+G6rnS/36aN7dfrVZNIT/fgxPTnEb/38/Wmz/vjpG3b95vtl2a4/Hy+SFkXSI+WdaX74zqZn2X6+XnS6/OhJOWlBcL933+PaTei7JdnDZ7aCw/IlNJC//33sJiD+Owf+vl5khb0oZ7Mr+tKfx43xWqTHYfn80Xfz0f44rDohIDutxut1ws9/z3VwDQUzE/058+9fEd4OsTr9aH36xPTvwF6PO4dzLC/n3Omn79Pr+RVF2RdF3r8uTuAplEgns8XvV/vOlDt0dI/f/6Ez6Z5vOm1FV3bapD+eNyDs4J+lj+fr6NYoT6bP/cbXW/X0DeTmej5LL+vk41hfXJ/3ELj++Kflenn3w8hOsZ1X7RzyJ5PTD8/z4mpbwHLbreriR/cn/Xn864/Vz3tTOd3y7muq07gmvjD9brS9XqdzDOV8/b+vF18aTfl48+9ADxhpQ/6+XmZ76aB2j9/7rqQN/v2598PvdtzNcIBAOh+v1WT8mGKXv57KaCfz1f1rywx/Xa7ik4gq73/fD67ybaLtQA97rdqghzThF7vd70PNKOEmel+v9eYSB0JL7HwGXZM2/eKzikz0/v9odfzJTwCPdf/ert2A3fbncoZ9PPzQwi0fMq+uND9dg3mdLk+1yd9v9VAXfg1tbv78XjQ5bLWhEyj6TmjnJegM9+6OH/+3IlkYa1ixUY//370GIhIqFJa6u/75D2lcu89n+9AdKNkEdfLlR5/bvGZ4HomXu/OflEeY+tCf/48JtS34pP7fr9DNWWA6Ha/0m1yHglEf//9UM7fYr1Ddk6O6P64jvNs2rnIoH8/T0LOtjfb75h+t0w6+f/+/XO0/mERVO5+RTtsKpNM9Nky/fz7F0KCAOhyvZT7M5DuLfHuTa/XO+gul9+/P250uVycmrHOO/zZb/nd9Xo1/tLjXJX8lHsxH6WULY+dMc4ej7tbN/nd9J5i1bm7XC71HrBAdonl7/enFCnW/odHvHg+nxok4WEKc7lc6X6/hjnb9/ulf39/KDkASnRla17CKYW5W86g1/s1WDXSczcl5RUJkNAcyRVIuKouYN4yvZ+v2pFmpWHf8hx/X49869/fn+7da9kz5QzfRdxgRfd8vT70fL786E79fI8/d+3baO69n78//U6KtDbknWaZZd9vpp+ff15sqj7Udb3UXCOOXd/Pt+cDZE5/24ur5NNCnGRNX8AO3YcUQtYQfobXvZjyboOJ56bJBUSKGtVIVLbmZbrDlYp5QLmd0WVb+1z7OEmUUjTIEhsVVqjOzVzgg8jbZFAgj7T3ZybXNPzBsKPapYaRld/kXEpNoYPSo4URCg6MGQdPXDAWT0YUA54OwFSLwTnv3UmKk5xfa/563D9796sKuObht49+EBpJCWc6uBOeDLNwfD9HY5RQJtOBKs8QgfA+Vvq5E/lisutIWMnwtqNT7GvUK2Ax+O3McXdnG8X4Crvps+rxNKM56sSGgjiZ9h6oACZ6cmn8GyBmD6dWCuGsEinwQPmEgVycIyanJjpk9OHYBSCLWA9Z854siLNi0WUm+A1Amt7SbAOSUbxUGLGk97pxPekjy5P7g52FiVQoTsyqIJTAoWZfeMVBqeImZ+owUXGYgYeJ/NyjbdAAli6lB7W6V9gO/a/xHOfegeP3mrl87RNoAEmof++pV+t9R2avEs0EltjsLd104CCZ8p9disjJpGbEArg43sy+ZRyVgk2RCihbxWiwnluVc9v9IjkQzBAG4LabdHxfi3jfh6K9aIaMMSxmOLvtFrNRYsCcB2ZkqofadLNdYe1LqyK3kuekPjtcu5AMHYGVEIYiPmoQWO69HEcHf4XKzobKL9n5BvoRcbF24n/kPWdtddrnbcA4u5a2P1feB3H2TP0d0bpOitCqRjmMyiOg1Op3c0dYds3w8mXGcV4RzRwSae9HSy8WdP5UZx817XSMX1yuK61LY3+h5N/MgjljcxoerBtAWInEA41oWimiUFYNHBJzoXAOmCJ7wkjFAspo3//BHuEWO7K4n0dAU/TcHQtp8ReeAeKDiCE1Cw9MFp6/naklfWrsCxyqQoq5BLmpuhAoJzqSKOBJkhaaeZth4fZlJrZ3J/SA4Iwf1WwAxy10tjLGPEk0mSeqj7HmovJ+2zHPVGpfLJU59ypvprnOIxR3Zl4QzdZZPRKD6tLJChcuGM+CafR1nJopgsTVXLzDgw9dzF1y7J0IjTF/dUGDJ/U+CifcEaikImFoAqsRYN4/OPF8IQ4CPEkDWTIzS65RqGsI4beuwXa4ULSr8cekg5ZRauwqhyKJRLx4TrENJyQzIRodXk3wGJmR8zreLBYOabRJF1QQYZNc+EuC28xLIJo0szW0XSLIuCcub7JeTnLOlgOhGJ6oxUNKgzNNofWd1eZmtyOLWrONj0CGM7Y6fe65vXAyd6v1CZsU0WpdDErfwKixzqdCdBzrjDUIpG8Y8Sl1WBJiTVrKn06tV5vPVzpp8PM9XpkLQhTHyPtjSNwzx9kQU3GsVx6x4LDzI20SPMsoEHf7hcKQCyvgOAN0zKBMzMmAEnsetRwCZxCaBXvAgdqPMBZBGPOdkoVCDqa2NjLDAgUBwORsANiqrVtgBkKYJT4AGUcChnZ+Wr+RLnw4VJ2O1g60A96Il9K+f9LMnIMcksP4ByU8RPOLi8Orc16nSkAZZr4WMFT4ycaVmhCGNIeJcZNrHHj5M/XaUhiHGYQGBk4bUVByb7s1bXudbPMqKNXyXTioxa4GlMyUMcN4I1Q+WUP/MobOBbPnoFEfRQkV12EvZQFuGNgPRKseVCWnC8tEDs0DSR+LmRGzSHek8XSgXKkUOGWwBmsT7mAh8m+kw81vY4x3Kg8tgA+LYT3IOr6rVB+1ampHlyz/4isoQZ8Wf1Lzjop8wGJaGO8dJ7OsEn0uzzJ1w2DdPTyShx6XKGgftY+LLybKiIP0jgqU5F5b/NJNYjZDZ4ZLRB1wYu02gvgKsz+cFrFFcH0r6eCpBbw7pVqK+XPpQY50sMIw/Q6DcuA5zWE85F0/So5YAEIpxPptwmXHiUDx7KlF9yRdZhSQTD4nMoPZsIIrRoVQxU8yqkW/0d6DuX8iIGcMw2jgCOMkwhSq3ozDS7Gbn+i4lxVWcvE2Nh9ntxZR0c4hQh3pzkE2e8AhAIhAaKond7AdHdvtN70ORwliOmVCiT0ojeuIVKoUq6DTevB6IQBt1kTOuO8WhmZWkk+AiWp+CwFQu/Phh4o8en7GtoA2wKcS77Gz0bxzN0fGw+5OI9XBmiLQhhSRlJLg5E/U+kr2/hmQ2Zk6vguPkRHzwA54GmQDkahWdAYjSRKotWkfIO17MECoZFqwX1oL/C5E7v9dsGPtDcUzAAXztdztwrqh4COEx9vBzE155m+fc9G8iHrGIbYCKW7CZoNkBwCyNF2QbJfg4u9gwcQSiMk0UszaZnmOgWkzRYMxcAypcBcIKx02okug83e281K278uzMxQ1+FgAp7wPcsolF0Gbs9bUGDEFtjKe7MNuTA+dsDGOWnhqZ7GwziVLM5Nt3QMU1EpPU6rk8x3zNy9w7jsaO2rFqkgIVdoODqNfqoGE48h8E6YjF1T4s88f8eyl75Fune9z9eCeD2sKwh7lVZquH3Zi4OTBdcdNSvrtBT8HQYvPDvP7QXJoOrJ8sEY8eA7mwAnRGLsGpi6R48cRSLB7ZbhuN3Yu8WZTYudjcOpCtR1Qs9vnyKH1HpvGj9nDjYrkKFkPoFAEqQ77wqyA1OIZsCR6zwyfjUUDYvBLSjhoefozRrY6cbAiVEoNjcmATWP92Z2Jlqzn/vfaZaWWyHvnZfbkeMR2GbuViuP05TBU3Xivo41pSmdwC/HKWYN5PMAYdrReDhKWIQtukfcje6WuIsjersZ3zQoNbUmpz1iGzAHaTypkV4KjhzQ5b0rpky1NKocUbXkXwaSvamwDOok8skqRxRBTpH4IF4856BzAUrbsf8sYQi1sd5W5vMBeUbpRLAGPJRxckzbbRYoKWJxjZLGNG6RBjJ0440SE2Bqrx4JnkzrGfAAc5IrkAFbM8tTZjgGC+x8n60h2M9wcVHRtn1sRkyTVR42IogSE+VRzwgP1bGOOEn2e3b0BWBGYjautI2dfgUk20bppYy4YkvrbP+vMAk7A7DCArABbGUd59jzmQjYRpDXVCXttVRy6+waHjQlW+heDBdgaW8r7nbzeQgyAzs9B62KyK+FGUTvsffaaQPM2ZDsL6/BP2VkEwQmWcA87yKy1omGWlk1BQMeFD7xErk2mmQ1Lkl2EPAwygIWfTzcYlUqQ7Nj9xqvICpyc+2VMukdzhbBph4cc9VuHEIYv2CIATCRhR/NiipIsFxDHX1n5tLBpOcBL9nXaDAefDTyFGELAuG9z/sXzJUF9JEMnZN85iSg7LLvovHvj7vekEdKKR4JoL0yLEe3PEnPydF+cgHGtJ5K7pnEAUgGB+TJmR60qQUJ04fbWy2y+KJRKSxbJoug4GYeJ6n5XY9+zrH2dlKqhNB8kHog29TH6rNe/frcspL0xj+t+Vo7Jqr6Nrj2mPnN2bWDPS9Z/q3ypspDH58maE2v/MRcbvUkzlDE0/66bQU0pdBSEfU4MvosLZUUEQT2qxWUDNQ2LiRnnWJAqtPN0fiVicXDA3cVu9wmud2H9endjmFI7lK0+7HwvkU0dzEs5IJTte8/zLqa9uf2gg+TyhTP3CpOSRT1gAe3AOtVW5Bz672E3dun/4QaL9kWnstIv/4z5RjAdg99sAMx6poCDx9MvyCgvhuoMjmLAe/Eq8CmganTl9OYr6PK6PUAIXZnZiqCEYFrLFZhJzTUH3XOeahfwjA6kweydhCH8mm1fzvxw4S9tnAFTJJQP37zdzwNssSKp0P7s+TMFmqUxMKAGrLXRLL/TVadqPOCIaQejdyEsX1ZX9fnGE+2apUgTKEcfFXNToNh7KTAJZaKwc8PhzaMm4YwwSkwDQeTezoHQC8/6R6YLIBVSFeITo0XqQptykHkaAFJijXirSB3v7FkqGFnV83Q4dedv1ExBHkgrs/bost872NQ4U2QRq0IFVnzDGF3zIU5tz4DdU+2gBobPweurgxkUOs5rhwQFoRezfYT5zGSQEc4QoI2UVmbsUtrE6P95siPHCTTP6GMISZDiCI7BNFsyOzo3C+EVe5ZacA3mV+b7WBEviR1Cay599tmh8pkSw/8hJGg6s2cM4VEtNDIVlbbEPuAzyRkxkBkFVPOHNomZ3Gwke6GTTa9na1qSRPZcweA/cL+O5k0WY1EaclSiBkF3aHeWsCK2rDMTPfdZ1hzqsg36xLAUNIQzRO2/NdukPusI6cMHU4hb90wIiwsRk1jaIZ0oBO11bjI5rdgoijjjb0lRp2122oSZuJ37VsrTBC9QBaNvAD2DmOGfPe8g4nq2VnZE9jIP3ZWQz+RoZlXr2KHP8gKyqx9R7TgsoCOKLhzMzA5lPxXbITq4CCBHJtcVjnMWwQgig6B3VP/EZ2IOqQGncXwWs1O9o7RDcWZSs2I2b4U4aOjzZX6/MO+g8XaX4cRRau8TiplpoHNJtROc5KiJDhC8I0YjcwrpAjADgyLIyINAKGMiyaAvVlstspmq957qCjhhtzRr/xBZa5IuSqhamYO7YFRt+STYEq8G4uu1FWWucGTHQFYrwQdYkAOiTR2SBA29Lvqqq3WdlbRN3lCv2aD4GIaFGsBXrVGOCqGyCDlDWBxECxNcXM3jLo+Lt3mrWRPtaJFGElSPiR18bRerG1Y3CX9VpED48KvOoRVeEEkimgkuB40JrjSXPaEIg7kDMZrHktgmBpcHxU0WE3yM+MEig1ns7TRUzCRNILzs6kyBlMV39At9wYDICf5YFF0lSXWHSJEJCbR2UQn2pVey4FDfF6zMX3P3hDPPxhSP0di7Gdc3sx+ik8h7wQfqe5D1BJoU3MwBbNBiAp8daKXhLyvkrJ36JKeeCCTSyCrsEGY1o87QglcqKRVfyovJIBiqDuJSP8cIm2jRPnTqhzZtl7RPjOJQvUymXoj0RNYZLUe5QC5eRVysdVKn7TcazlAQZtMVZ0Flz9IoGbLQHQuZq8mupDwq5U7yiQEndr1vlUQ2zyzszckMQZ1+LlH2I3aU2KwAxBATHvEustIJrVSsQEldC1sUoC5UFrFAshVQY2AKkpRSELYuIURRk53SHUt/VNHGwlQsdvyMF4zSlukEFt2GTImMXYTzBWEFsSMQvfFApc7nHWMCkgIl5pVICiCUN8qVtmmxmEygJO4b7WumxcUyoxe/c2pkTNODmskmkkq5KnkO7IcAKSTBrh3NHHTSmcS+ojJOg/FzcFA6xJ3MihavVEsdCIV6d2sERnaOcyZKaYjAcAPpdkVxtBq3BmCtqvbOFdMAQvGaUGdAA6JWE6ALaSlsysopsgZWeKy/Vt3XIw1AoZmynAnszIek4hLE3pKKyJ3SL+wjYH5e5bDyOtmKCbvKNziPoRjk+voRzfQIZE7dPkRWbjxh46njzyV2wd4lSQgrAUHHHHWbs/IDlSP9Uo0aTvXfH2hmosxihtXMP0NooiRbWPY5Q+6K7GSYLe3HlTAliUlV1rlmh0cAAZJC7W8WgYEr3RRgMyko4rnMjxAJtsk4yELLrnwpfr8/GB/ZUIPQjFZNFS/o3Jd1HXmenSnJxSx1JktOxMMollyLqr7/pw+hcw3G7QGmxLSsa//iffNX3x1p4q3MyuvT7Qa3AQLevntk6NzWeRjUBoPXQL3oLcI5EKpiDjwR4wFo+2anUQERuNcluWIyNDAXKD1qop2WxflDtrCeUQziddciEVGmtKRurGm7EplA+ZulsrZJ8orR9YybUYx1MyHoEIOYVmFOKxHi9szad7YKXe3ALJd1yJUbmm3Omba8OcXEtiYpVTNo2XwSszXblovvVkeOoUbPUqrrptQQRqq8bUU2MtmzIGi7AGnjY3WxMaWFKS2LQKK1kuT3+y00vwkSeLmsRFF3EKjmuF8Kecb1z/Dt9JSW4dGEMDFe2toEf9rahjpaIFrW8vvWnqF9i+93U/6T9rJY1iVUM2vvtm3Z+VvJ9+gm31RV+1j/7pazY3dxfa6lw5dcN6Q9t23bhthQ4nLm62XaAnwzmNfWDC2+Lp4JUH9527apLUQrniLPy75nv1vM+qh/moEv0CTfBQ22mz37SrglrImbAXAsOlSeq50rHbu+nNm1alAV014IaXgWs4RoZ7cVw1kXidfrpfpkSQrqsA1oRsjsJXfrj7H2Fe3eUaubnWVm2raNvp9iFg3bwePyXFqHkVXHhuuzzd0f2HVIqjl8F50y7J1tq/E/Sviqx2/zD+MAsCtG1TBjEOPeHsbOQ2hu7M1MeYOjUrVPWMzdx/636V8GaNu+mmkg9nQ3d1eqlGMP9lhj+LdD/bTlK37f5gzvuynGdlJKNWeIRbraeVRURiHQW7zmiIw3S080v98ttmrl8f6ReBSEsX0fb1AgZvkA67IEoikDUMky1wuQmnVdAsso9PfeNkyFiNd1qdZH2oMYIgY6/LGCHWkpeUOoXl5fI+csEnh/NxZlXSG20uch2x22qKaGzCYBFN+7oOuHlhetSZXz8nPkXEFAM7PJfU8vJTdhI+7Uzc63/qmyJVHxMLaX3X8YcLWDj9JaRoyCbd9NxTzVwU3yzAngQljN5LwNwE2CTSSF08r7Jh6vZ59VuQszLYlDsKecfxYaaLpb891G7GJmF+PKPkrhBs81Z4+9y8v3XJdSL0UjaqVmyLr5JrqVI0+yx7Ds85yz8n6NSvR1XUzhrXPhtf1AdKGDiN7vd92M8Rzv7Xotl0vwJ2fQ+/0WSb5F3Zmul0cvrHTChXox5SGV2wahKxpzu91qkm11Joo84vuda5DSFBEmovWy1gSYzFR+Q1wyvV7vnvgbyz5a11R/HwYJrBdLzvR6vQy7VMOot9tdXIx27TI9n38Vui/39rKALrdbkONWM9XtS+/XR6Dl+pDeloXWyxoG7i1/6f3+lGRRlS2g+3oThbDf0H/fPyURMZ8XAF0vF7rcL1M0atu+1dw5vlPWang8+/P5fLvBuEz82oO7P24j+TYL/v1+y/OKOg/1szeDcZ8aE2V86P18CbxB+1reb/ey3pNub85v2jLosi7FrsWqDlaQ4/3+jESvdXZq0n1JF7q59Rlv+P58SlHowkQJFOs6M39n2vK7ri0rVKp1SS7rQpeW7LB5dRC9Xi8d8GkkMtK8PY4jxfSb2dMVAdD1+hCBbr4vFI4tDu1FxoIgUr3f/xw41BIrrjEwLSlcd+BNr9fHxYf253676XMo3j7nLIoeUEIiSuVihvRs5G0kHNI/a0l0uSwho4OZ6bllen/eIT1NGr/b7llLnP5+Ph30YvJg3uWy7saK5+vvSL6JzIwt0eNxoctlEQmL6guP52q78PUvluXS1xYg+nn/o8/3298nCS+/dV3rLF7tQEmJLvHzgJk3LAo53dBbJwvoSUp0UaeUKF1TSNDOuRSFirnSZwYTrctaARgNvrQtlrdcQZghhtSoyWlZ6LZepyyQnD/1vGhWTfuLx/U+fa7jubx7VxQmAb3ebrQuMa0rb5n+vn4CL1nUPXWl+3rRTAAeSXTeNno9t3CausSaez/raCi6urdfdU+xYUQVZP92v03voM/nQ8+fT6gYWczT77tx6vvdxHk0pE8mut4utKSdONeAIRPf2t7578+DUprlaiXfcfu0MTpSotv9Gna6qa77/75eU8rskhJdrnc/LiQYpK/nz/C7NbnDelnocpnnDp/3uPuJB3UbAN3TlS6Xq3tT+Vk/n0yfzxbpMpZnhrI3nQp3vcPu98t0XwCZ3v/7M9aWtWfj5Xqh6853K7nJm4TBnxhpAS3L4veVsNXIW+4gDgzdk5np9X7R5/3tYDKZ3Cml5D6fnFnGlumzfUTDgwZTiYhWYlovtaAHZEjq+/P5HM2AzohoQAuahV1VwrwutF5SKCoJlOeI7GdWy1df6Xa7z8lOL9D79VJ2S/Ic39f5+d+2jV7Pj/Y8NJv5ertUv0XZ6hg/+/N90ufzmQCsoPt9Hrff7zd93m+ibvcngLbcztB9l+y1NmRaovmSckPS3NjN3A+EBjNFucSUKAVUx6Bz1oo+o56WjdQtAgRueNnoYX9O4sJVszWR6b0xN7BVYFPgbIlJhvo5NXSvDGXb3krqMBFlAiZ8Z2gKBAsaYD+M08EjbSBMATVrOjdEwxAa0cwoPG3O0vSYk5HCN1TeKbWkokFJU5r6d94R2mDRXRjcfzPRAwzPLsy9EuW/l3XKyjjZ09uqumdbbyFrrHzi+qwBxSCMQz7tI63mtUi9QwFHi9kXctCJzuioMCdF6dD2A9DKhEJbuAEVip4JvQdbd45JCCGwmc7b3RfoezKKI1AdydiPxykeB7Mjyt+oK0ZCUWeIvES9pBPZ+FnoHWNPq7lqaaWBucqk7YhmKZcuY7SlPEvBlukrsqIjOnHX4Iz3IsH8f0xmUzH162OSfR5/v5T4CMxjWzOul8ISWoxJUjFniooonalKl4PmI4k4yirGDHR2nG1ZvLL4707+w9hNWKygMRJsElm4Gql2NDJZtVTNYmLJbNe0dXvf9fn05OMExIiG6fxHz5trB1OLWng/PJr25EV5z7o08veWyBdaB4S1gbUmYerPLql9bd41JWNYHtCxnPopcziTlqIvF1iMtD2ZOAmwgTUYnaWaoIevGJImPdSfHVg+zTdIdd90y0nnYF5hmDVbyY72zt5b7C1OPGlMaGplvG/g51zJjGMg1shgY0nDRuVwTDxIknsyPoZw+UFvArQYkthQq7nnlDYf0TR/aAEswYSAVHs2+ag8lrbQh1RYb2wQ25SnMTYGMTpmm0LltSG0CogoiWeRzKwuxLlFNt63FuAST1EI9+husMg1DKsBgrXDYfwwuR4J/9toqIF5p94hdTfp7+DPvhovEqlikvkz2051fJ/3+0nl3pJVMgpm3cHWn21N3YV3cvmrWRNSLeuQe+aCHLsLz/q6wQ6CKwoIqeFmhhyahZt9lGhz956yYgeB2C5TMAcI2y4yA/vKM0lfTlFip1FPVpdupA4k0fjWEoAMsicUPxqdUKbOI1ngneJqLyfdUzGSxizoiPpZ8dRIeSpyVQwTCakx0WcY/Xeby0vQpLvGv/htWDZM5+yoDpGhIJbYCO99BfIdXq6phpmToAOxQys9rb3guHerfXEzhCBAHBTxo0BwAcuIc4SVxgm99ciomjHQYNk/gutssDLm5XB+wnrwibke22lwSnB+TVzZai0IpJfYkTqeSJoiJeWR6Ee9pvmeZZcckEnHz8su9wIPEOAJwqKjLqL3/oyiyETVl6WZsSkAYuTYZ74quWFQJGJWuu8eXGOhzEYTm4YGFGTkwB1lRDXlA8aje7isC+Hr58R7DAYUYOszfBSknOO1jQA5Iqevc8aVZPID3IttD7btb3lpa3ConGz3Rb+f+UgKbTdYanbM+bPAM81w3n0C8TNkc4cIYNWK+ui5dTlhNVGoDkPDJEbXmSPbkVZ1o1F8hwLNeF8FMbjgI+fLvR3gxMYmYhp2btDbN7CLg+gKnoiS1vgO6Xdtm4MeILszbfeWcDRp+fXZPPezgTWB9D32c9ICLmX2hqA7s/PqIzmbAC12w7NrbTKq4CyCwMNbV0mkzUVcAJzL+7SKTY3naeqmepypjNgvhe/Zp4g0deiy6KiWAtqNm1E6AZW3mb1taqP18C1AxrRZBgKcux9CWWCOHxZP7xU95cgG/5FzELJDKBROWUF9fHCZRR9s/rM49GFnJ7Jz+P4zLBCOOWA6j5EEv/fHOtzx8rVw7B8LUDD7QeflKtn2BV37dT9vBnrgZo73WfRZILx/kup18UECLIsVndEx98nkKiBiFbVYHdHYUcI4D8N3s2em8PtrPGbYbIcViJNEChOsERFmss0gmfiSohQSyKvDuvMEcrbNrC+LqY5X5GfDRpCGjjpovm7FgQFz2Glj/ZlgpncnUZy8uMN8L8LNgp+IK6zd2HrSxqd3lPsOnkKPo6vFi3/seqrJ+D5Bct0Vivi1pSlxaILMxIE/lD//ZPY1VMwcUucikVsiY7nxr0tKlIlj3LWdR95xZYFW+GbsXyt7hdHxD0dF0TydP3MlyLlTJa3OJxRUg2MP8K/tDeyoht0DHBVObLwZyenzxnWLXZwDBUf7/rJLzw5sjxKGCZ7JkyQ1BM6iYt7rxM/tC2gHqmDX5QvBdfaxTMV6pl8+dDJguf6/MPAKzuxoBAWoaWbMIvbIuaJ57chH1z/XDFCCZK4Y5hQsiAZRgCFKxlWhiQk43XxDj5/1tCbXP40xEjZBWybA7PFdOERd/OHjg9/ruUFDo8DTYtiCivFhMnnwuX5K6CnJpC2x9sDAVZkJM+90+nTV+puPqUdQrVwtEybPjAmK3mJRP0TG8M60WiKHvHtuA3sY9VqSAsgTTysf3DnoH53AVtkjfU47VCpqsdElQlT2GuovML/nA2G5iOoSiMV71Eeq751IJNh5FvGpw+BNEyZJ+QRaYSPFr2tbniBlMMVQkAidMRyeRBpr5hrSSX9TEMoGhZhDAMdiOjP3KZiLsil08ZnEsTEOjrJC3msfQALn05R1UHQH1QQqKuWwCIbzSkqk2REU+cYomnj0JbKMeBCXPQJgRGyflLhLh9sk0Hr1nTMp8aqc9qLfT6RMgSVAN+6KvvsRr8U49hWq+FwBUt3vhUxGQmIKOvaOvKSmE7vnZfr8kzNO7vzb2M/ElElLPitVQJBR7h6lcS94A39J6aHWRh96sFfUyUEfA6gkgzOwdYphmruWf3PrC8sNqdSFnR4ZV1NJ9lEUrA2ADosz7Bc6R2disiWJeSdWgEJT8FkxF+24IWEYfw+pZGyBNKV0Ck/vy2BK0/wTHgQOETqY+Xytmw3eq20ndyjru7/npDx/aFPj9f/DZTiIBn5UpXfAQGZ2T5/Z/fRGF6ls7jJmbyvXOV2Y78UzbQRniSTuwvbaTdVYihYOogfc2bV7EWGhqyFG4h0QJfx+rNdYEs/YApAIcuXITzpKApm07jLm+ydQ5XW1ANjZOfHvoo3WChbWJ3zYKxquECESwceA1jpDXRSSa2Vuu5TnIcwyEkDmCYUDu5W3TAyYMGWpeqGQlm1Ad0MQ192Rc18mPaiPoBi2l8IMBVHoO0BngUooVFTaYki6xpA4Z5FpgiIjdN+RZqY5mrtzgTt3T/m98VtMOQjkcqP/Apf2rpbo6HC8xX2irbQGMN8p2vuPurwwRZ5Cu1+aaWdzTxexOwsdHUexkbSMu64FQlNpDIFzYhmcjDrkTndnzAbD1XahTxhrtDkGmdiZGvNO8QLhCKAni3g3BnL1hFQTUV3gI74HoQeGSCpI+oIKOiGDmFerc9icUp3FZtqN2RLAPWoOOoXKcRqOSdqSCg7dUTSzmAgAR5sQavsBj8rPzgMQtLMQxF/WmpTMOlfpcbR7fB2DeDJIQFgzwH52jhheMDY4vmBrM/AqcHGctff/bMVY7DE/2/m1lm9ME8/Bk8ko7/5reEcR+8ge2svI2SKexP/TQJkGOgK9ubA4GTEVe0jWDvDOfZ8aLbQJQhsURczi3MOAZrbwsGWapJgyzXuaNBXM8M/RTthlUhYdOqL6syBvx1ALAe72iSCkaLZ5dMlAOTdap9A3F0BdWnh42QJCJ8DoQp+cR7EUbJuXcAhki1zWeEHiRJx3nSwYYFJocHR8iTUxKUoNm32R9gAXd11norKK847JAn27a41Qz46Ltx+m695YXGy7v4fMM/EpDB48G2UgO9XBfAKpUG7XE1If73Rv9CluQOdgxEafNTn9hvXI2V738OQtfPRbwpfQdgaOOnNRQY/hiyaHPy2qarKyMR+ShzFqJL4xLeysJ49AO3eRjjBxq5kBx48Y9vOA+9AtzDwjI5KebR81TaiWwzbeesbZJArInhsODFU2eARTrq3znDw5RwglXRyz/nYPlPl4ViRlSjcCKflluHs1u85sfEFxgJIfJVCoxtfZmQTqZIS7NLtFyzFvYYwAAd35YpU1wnPcaVyUXX0R8+gwLQTF/1OG0ApdZiVYoC4ZFmsJ/bvjIp9HE9hCLbdY0qisXkXTdiNh48rBU5VdO6i5kyB2MCuxCN8xS1Vqm6rSZVAVIaIQn0va2+A9dZ/CvCNQ5Mrs3vqEih9tnVI4WsDCP9Gpx+IA5BexepwFgdSzKbLlo2RxGSaOwwjK98kqyGUtnBMBgJmEwqH1e+sVm5hvz4f3iD3XLSZzS8Q4slWyjCtNuSIlfBPf/2hnnT3/AxOPvpiZoUWyelHSvHhh55nG7A079Tgv0COVE4l04c32rBrRn901V7ehmF+anQnZ7pZnkTnO+mc3GKBnlG3ciSZvlJddDu1rZKbBUq0HWgkVahwBTmBNzonbvaPWB7oYlOKkHHJSjYYNgegsw8ZUClmOOU0APlscMgllTEl57/TfGscgu+WiYOHdTDYE15mCib2IeVJHYTgCm3AiD0XpvDsPxq402p4d62Zgy5kn1HSyYlE2cHexMw5GUjFPoWzjR/hlO3iHjyZM9fFTzZg4UXRnwJU/IVAfsGyCfMRC6AN6gQG4YT5b9S80x8IK5EE8z5rqzIthyrXJND7cKqVeY4Ng7spjKglsZyfngrAgamVXldGcTN9mbJCcQRtLCtkowJp/25i7sWkoTwN8NzRm0SmUSDUXawjttSMCa0bx6ZsUf81n0AtpcC+opPeKNHtvBW3OmdCVC11zn2ghSpuQHzLQkZRsl58r05CKHigvq0Spq+4FATNniG4ui1+vPoVb9lsbTBmZEnMJXawJGFQpb1KOWFP10J+3pv5wH6JuXkAIwbjclcoSRwgn05YxDGdtN7ivZaB4Vddfvbe6OMo6plT97KJCrhlbGzRNFnSJU11D4UUoPmyu6KSTc5f0j6omxg5BlIudXBwrPljZ7FEoeemu2Gvm6ttqKx9G8RpFvZSrca4WQGmfbROeafYsktkXdj4pb6Cc8oSiiFEAMHn/H2bKWewrkYkhCzEr9VxZFXbNf45ZK602E1qpPqufDfd188JaUMVHM1bWPysid0o+d5rECJn0Fj85NsnS6KZH7yc7411RjVt3Zcz35ebvN0GXy1lN0/iaAWKzNh7pHyrSUnW5odvtPCCX80lCMVdNeEmRJxk96ucqZzeHSU27A7rfoOh6lP/GQmhA01AzMJQoDYW/nRuYJgQJ0SdkhD6/WnUxkfUFy80uhK1XH7pvJLoBtac3+jisq5WUklYiFtVaFnGY6/fsJVzOfR1ZiGjIvbYJNWQ9CzViZMg6APcYCUQ5YU2AW5yrhVlfSyL3+7ozUPzamNgVbeDi4Ze3HCakLe6kps4YWcEQyncP6uTuh8cpYNkMAbkR00iNSZR8hVWCaDtV5TnF8YCAcveDdDdFdPjyhl5USTZE3ws1xndFdmhQdey5gG7K3IHwqKgceS6JtpcokCvoJoX75I+W/8RqFAfdgHtRd68vRKynHmxZPCyZ2HfA+3lyHoMjdo0z5KtM9PwmCU+7scYjwfMNmyTjH8V5U855GMLL+W4W6upZsCmkcnw3a8+9aeJu+eSB7VxtluzsOYCad2uQXhJvEJx/ee8nozAqPR9b7LLMDxn3dCOAFZV7xGwBsfEowHu54kCyVrNMZhxZ7pMqeKZEAgswsG3ZQ/IyDv3P//yv7tyaztLjcRdGrHKjllf5+XkRtqzoaEMmGPTnz58SaHIWasbjIz1/3sMc2dBv1mWl6+0SkUa6ee/n83EARammS8Jxv9/dopUNTvTz8yO6YEyJdTfv8biTqEdFt6r4/L2e7yq2Go/dPx43YVZqvjuI/v37p1rylor6eNy035XYZtu20fP5GlL4LA8pikfjukyl+F+vd2AEOxDb+/3mvAuJmsfUx9OL6oZ9PO4TY06mz+dT/XRoJDqiM3m7XpXvmdwnTEzP54u+wiMKYNXRvN9vtF4uXUnSmqv+/LxIeuVw/f0WRMpnj7s93++Xfv49+yHrSSAVDv6yLvTn8XCS6O313u9P9dIj0ZGhKoUPul5vdL2u4lIBvT+fYnQqEoLb9VY8eIL52ffnTa/Xu1qjJaO4W9dnWcOOwPv9ps/32xOxFnTa+1wuS/VyGrQtuVbP56sEG3aAKDERPf7cA2AJYl+8xHuz8uK7XC50u109Taje3M/XsxjjciqdE/MByr7QnqHy2b5f77Knu2QzehwCylm6XFZrVFAT2K3uqxo/xJbPtci/P25iP2Oo/jLo/f4azzfZ5S4ejc2MNvdLc4BhANH1eq2m6Xp9cs70fn8i+IFyBl2vF7pcLh1NZCFgwvWZfsWeUKJPILrfb7QsltI73uv5bHeDVgNtXcjH/a4AP+sRVvbUFgoxjPdfiZAdRSyj+Ek10OtyudD9fhfdXxBJL61afDXrFYs6v7r/ZzwvfrtdaFkWMxtW45BAT0YDJXcTdEfOkz6/t2ux1QiwjvenfCaIYqe9UPF9u4RFdM6Znj/P+vmS+r2ci3/k7XY1wjkjbr6e72pEPcDV3EkGoNut+D+GIlOA8LuTc70D/S73bnIFZwNfnj8vB670OXXIO8jsSuYah99qllQWCsu60O1+CwWGmJmez7fxJB15ybIudL/dTJdhxNLXq/qpNj9lASYDoPvtSpd+/w3uN9fn8ny+wrmf9lFvt2u/8+P77+mAewnO/Kl3PiYdlvL7CMEbgOi//+5u7KJiwfTdMv08n3W1kxK9sV60MuFt71di0YeYkjFHLz/zuN9oWVMc398fer/eYraLVRd3WcrdbxK1fm820/R1vYTm78Sg9+tD3+YBSTLOod9BzQOSm/p6/efPZ6PP61OAEGXfUzra63qhaz3LrEBm9NwitxzcJKGp+ta2BoEFfnIuAHS7B9SIUv3nn58n5QxlSSMZN9drjX2CTsli+Pj9+bhCjc2c3ffzdSBISsXrW3Wlmen7+dLr9VFW1+jG7+NZ2nPAPM5gX2fWkiOPx7V4rAJOPWHLGz3/PVXn01Iw7/erqDP0Wdi2reS/8ngzCcVr0P1+p2VhY7NSFOC3betnONn3B2itcVtZGQm2yve79fxQsh9kq251lX/OwRcl3Vo0dE0IOTUv/AOS/hiR6F8W8z1KxXQ1SmNOKYdFte0AKyWz75N8iIq//HsW0JB8qGwEL6VwAhkKn+7cMMVy29KXzoF5KtmN56tEC5mz6+AhFAliR5lAzjUBhLpaWT4raJEHdh0gErYWii8wZJfROgatc8vd64sNFSf8vmIdGqIOMXQOsV5JXGjMlroJPWhvRIek7YI3IW/dqtEBlpcnT56VpCFmGMqkSAYaKtQSoQo71DMlkoNE4SyunRVVaocioYnneOvFnFnRDSRliGvB0/n9Sc+CsDTAiiiJHJPM2hoCQ+BDejXKGSEAfh8LlhYLdz/J4Gm/n7NdJ3GW6u8PILMhm4q14WhPMN5uIzkfhYeOYSzm1tLU+kVRgVmILalZYi2Q4kUYWNGdnYFBff8ihx5PRYwOMdy8RmqovOhIOTCHpfdr+XdYP7O+uGkUpyrGMU0oKL3gYnsO6j3GaKALG0GQJChlY48tC4eAh7fP4JAirGldPBpjdW1acpZzqs8Fwj/MT+kBlV0RuB+wlMLo8uz1n9OBSFy1jVIFrPII5JBap7q3zWM0GzpV9+yM7RVG5xy9o9S2V7K+x5DJI7v7FgGQOu0QBn6Zshgfokhxhy4aK2F5uiB948xdKGOYYT/YTt7szs7dBkykVax7iLpL4ztVMy0bhvABnAkGlISpAOCjFhJFhBG3SiJfypJKmytIMmid7f71MZ5VLIAAclTV2fYccm9syNnDzpRgMZLCHMumV5CK6/hNufK/lBJ5v9XGHiKoz54FmyBVVo9kaylH33quNWNL3ktyVIBClkY27IF2XnPOlNalFDkRi4705ZyM/UwrGsl4lUuxk23LtK5LPGvMzdx+oXVN7n7i1llVe5/reERy9caY38w69yKajoExm+5i98vWTQXtZ0hhjgUVA/RI0OjuJfdZUipXEqxADyLfaVafeRzXZApFkU9CgrpwLKpxDrZ+xscA2cjp1q6Co2iJCBmku9NQ7BmyNC2IxhfSNB0pDuNt6KUPjkomcuCyxIpYus/bJ1sInpUmk54o5H2DAhTP8t1n9XP8Tqw7tKxHZjJj6pikBVMlhYcNvZB9UW8vEbZpsSLL6n8y0L0dPsZZ9bcd03Xr8UZB8h4qP7KB42WgnfhC+mT7xGcnr1JmFXdjGwSeOMTNvZzkqKoeSt6fZWTzbmo+F+KsBabUHZ13Cavuqs/FOeaceyLan2WDpQfwVG2OWXbB/Zo5VjbFNJq9r8Bi0zNIQ4GuzSOUCxr9yIqA1OQ515leZbzcM2ah8jqRJIejqHG433wHNlDDlneF9UJ0WShrlq6aT/WKvWHQcsJYUMPXPPFwY5GQ8Z6KGDQIxPqATkI24qSVeHrJ9IIAoC1n2mpHgV3yL4a7lNS9LDBHEjwXitgTy/NK0Fpw5MSOd8UFDv1x2SD6h/M/PP9L6wE5BeXkHoHxfgx/mE+JTcThan9WXNKKJUi36+c0PrahMsMwrnx08ZZEkuHBCnjAoUjgKLQAyzkw8/4KD7AkQAQF616Mh9/Pgcm8RNQ5vuBMkEeQm/nX5nrOdtcnYzDdyI+RNbr4TO0cYdpp1aBm/pXQhpAwwDDFgl6cmBKlKgwTXAVMhK2N8nCsDM5UmQ5Q+4kDMEWC3f7Ijd9KfCIptA2pU+dvgCbsaYV05DfqCnITnwHM9zJm8kvQgNDe8WOvpgqVgeGcfBbIgZbNdikNYJCdONXUGsufVZ/giBWMYnTpxiQj9bv/J6UoApBeCubdB2vRPUM+MA/9zDTzTKoWv/tdcnoi8QWkMyWdAGXatdTYS8QxkwYxb8WTuDTbiififJDU0xTddT+OYIUwTyGidY/Mr8PUjiNdyjN/WFGqPdzBO8o5qtX9K4EdG+T2wmx2J0p3IU5t5WnitP/7fuCcpzv/BHLgnhD23o9Jix7h+OTsi60YkZ2mbolJEiM/J8vrSu80xa5ghDHQ0+Q6ZDmUmtkXg5jVhpIlihP4WBjd5P8eiyAp7y9GcF6hciSeuytpIRn+rcMJ9FuzBD14J/YhjFm+G5/dE1TFIKlx3NENkJ85kZvHhjA15aPvyhqwwkmTPp4Zmsc+IsdgWXDwjqTpz0om+XuOThWteobHltKeFolTMdEqSVtQhHfXvM/fgZS6smssCSAkfujcu8Mg73QxfVKw+d7Z+wCjiyaeN2oRBWAXhBj61bF/H44vIX0Pgo6/C+/nIDrdHd/BQHBh14d2QCPdGbARdOdsGF8+nhrhmqDYxL1Yg7sIFkfwgYagbvBd0yQ07CvtSo/Es5eLZhKduaCgH9vvcrhT6Qd+E/xmigfzwp9in6oIvNWaGPDPESyK2rJ2q7VUsJ4hsn8n/1cFqghklibUZhOoOQ6eeT/RPr7JHCT7iG0FDAfZJdsWuwwpM7Okj4YKErSdw/72DMxbdy/hgFomVeAEis7BjRcZrbZ+UGsaz9CbWYGH4II8PkdzU9vzmcToPNgLawebdR2YTjGcZAhhU5cpFMXZBwHgykzZuXay04LqwK79NH8b+zSctD/tq2K7/QqMQez/Q/J1HGBx4nfOS8bry3QHXHFnyUwGQtB6+exHlapkIz6k3gGMDaFVJ9bxbSbJMuSFlmhGLUeotMlkm7k9l7D8dSDwdTxAXXB8++EEGhtBL7FUOaZppLxPIBMI1jNr+jyyPjABNKGKbxhPSbkU2FO/1d2ZQX02KHDAXlBx16jmSRGU2Q0EmCLES3qeA7g6hRmnDz4O40HsnjuLzr3LyDRBecZ3FqOsIWMkouRZ0ZqZrztFKvYcw6ZM2v3sPLoS5VNQAAJb0GV2biVtlc+CbiCe7CnewzTrHCWLHBNMh8bdphUTpD4YYNtONWFbDmzmD8Oc0RSafbY8MlokFjNp8HZZVhV6ZqUzQV2cT6Hzn6QhiNbfK4kYYd/A0MR3i3Gvut/9wHuTALv3wBgdwmHhtOfjqcYC9nJHPgP4UMh+m+1h5gCUlONTs2qlUeuFQbx8xhwahmMSsylQOIeLh+69QeR9GTEsbgT9fJV+VxF6xgrz0Op6kdR5ZLrUpeelYmKe4zrHpsbRlkVQIPJhoeBtAVhfNjuNG4iZMLbq4ofh3uNIe3dJlFw0KWJnfj0xoYyxEm3ljh3/IRVcYQyyaXQi7CxRfDGZRPsAodYqgOyKlOOUJBB42JOK5rprVezUOuxnDCX6fWYQgmRpqxMaiZwrnRbt5BHF891Ei4DGVMHZxTlDg/Wh4CBJw6SIY0qAFGM8l2TOUJWgEaWUNxVUyKr7waGNxoy4w6bT09ZNc/x3weF6OWAfR6mqp+gzEMfuN3s+i2xo9vo7jeSZDzs4yNg15bZ0Ki+D7W0EdNQ5Qd81thXtVuMpEh+hqZMWTY17iUcBPQppCDNhixhNyELAHDNrdP6k1wj6xjfzzZGvrAdxdSIE00GInjVVkMPE8WCeK+MXCH/7R9eNywSMPkP27keuMOMJ1ZyZT4CPcFUdZqDs9DycLeraFcJBFrMPN+XgszD9IlCG3x/Ku/JMtsU4+4XVbykbE09y4INM3qhosoi3OOrakAN/VGh0KeDMisV8cPZPMEkfVZywzWCKLRtEbr1H5433DYu4dMA+mtBmj3k9wl92dzzqYAngQUNOmiFj7RUcgC7USo/qQbncsrAEMP3s0yzY1Cigmd6H1FY18cnaVUwY6+H1dKKd6sAD0l61cpQEIEpwQ8rs6HlKDl4miNMNenS5DgEPOt1liebw6mCsQbZb0MYOZTV6TbkF+WxQ5R0s7cgwNNT7QpjExmuk7T66CMxZwNZwNk/1YngnMAHusM4GfWP0+xdvD9NDwAwBt4WDRWQm3zkXJUYE3XCeRk2eJ5NCJZbpFwFTSOK3uZvTWLyd3wTiyAJfqbvYk3YKD57gsbC3LfYv7Kkw1cns0r7VpHPBPKGTRk2ck0bemMww8k5OMOaC5FGc0KdmVMCpQhAsTkBtXjyS847PC3YoLL9LCvcArqlhvfwuQHDpBs8WfODLdRSD48875vZgOq+BBD58PPLdV1Jm6rPbH3kvGZx9nzHnlSPvPfvZbNFMQQfiRNQ5ZWTOCBU89Z7fKbZgYoYCKXfOefdt3HvPgzaBCL4qZT26S3wNFnctDmNcNBMyzxl2YV3o/XL43I6q3KOcA1U8cLouvy1oLWxFdMzfmIwSwLZ5sL8eiGMZn1z9/TzUsCIClnqcQ1XBnV5XD5YbmzMgAeZmscJhzsIxt5JpNwr/Jv6SsDkizIsYUBMHIyUBwUFhfjpGwXTX+SCdyqLegI4bAKm19XGPzEytb2ow9okaljTKyuaEDRCNfXxYhbrUAc80NoyZcyHfLQxzFWNqbceb4cYXLWoPV3aeafvIS3afgs7KA9AVbUIldZRFOAxSTMEUAzSHfI9CodEdTK4F7N8sME3jfLBoByjO7wHG6OBO3l88L+ZfzoWZ4BsOzyYdy1L0Hvgdd5wrz3pWY2lk8+znjhjgcykgD4JkOjS/NewGX0RiXmXPvs2RyEIkuvELWhBmecY+BytuaohMLZrn4NmSwXdRztPh2CJSEXA7X/Y+i1IpfJgU7jQEOWBMxsNkhbwg04gXE3VfU6DrqUgBHplEaNodBExhKv8+/mzzbBkBEi7zUggrmkmlD3vB8awXoTpve89SUnpsfOJZtoHZ7J5cKEQZ6NDVcWJbduIoKpjgAF3e20BhMW9AWMxrKSD62YkoCMhDskbm3gI9ZpzIr5kwtGf5nCZCZVCfFWFlqmI5DqjU5EPD2XJP/xCbgliJ7k/mkY7ubwTqxJPEHAIcAGimCIcICDZFid94fPy9Z6kFYw6KKRAsm8N/orUoziiAeRyHvj8BnMzEWg4q/cCxi9f6O5EDINQwTyDVODVAHmuDYL5RXQmA3SbAMX6ohS31PCz6FuXgg8h8UN2L0z/ZrytOiNKI+R04RDdmwEW5CyLVp0oHb6xwgHZyQT1DP9b1XIcTYc40Hur/B3N1CRMNiXh8AAAAAElFTkSuQmCC"

// ==================== DATA ====================
const USERS = {
  "Directeur Général":{proc:["MPM1"],role:"DIRECTEUR GÉNÉRAL",dept:"Management Général"},
  "Responsable QSE":{proc:["MPM2"],role:"Resp. QSE",dept:"Management QSE"},
  "Chef Service RH":{proc:["MPM3"],role:"Chef Service RH",dept:"Management RH"},
  "Directeur Technique":{proc:["MPR4"],role:"Directeur Technique",dept:"Production"},
  "Chef Service Achats":{proc:["MPS1"],role:"Chef Service Achats",dept:"Achats"},
  "Resp. Logistique":{proc:["MPS2"],role:"Resp. Logistique",dept:"Logistique"},
  "Chef Service SI":{proc:["MPS4"],role:"Chef Service SI",dept:"Systèmes d'information"},
  "Chef Service MG":{proc:["MPS5"],role:"Chef Service MG",dept:"Moyens Généraux"},
};

// Mois démarrant de MARS 2026
const MONTHS = ["Mar 2026","Avr 2026","Mai 2026","Jun 2026","Jul 2026","Aoû 2026","Sep 2026","Oct 2026","Nov 2026","Déc 2026","Jan 2027","Fév 2027"];
const MONTHS_SHORT = ["Mar","Avr","Mai","Jun","Jul","Aoû","Sep","Oct","Nov","Déc","Jan","Fév"];

const AXES = [
  {num:1,title:"Performance Industrielle & Satisfaction Durable des Clients",color:"#2271e8",
   processus:{
     "MPM1":[
       {kpi:"Taux de satisfaction client",formule:"(Clients satisfaits / total clients) × 100",cible:"95%",seuil:"90%",freq:"A",resp:"Directeur Général"},
       {kpi:"Chiffre d'affaires cumulé",formule:"Montant du CA en DHS",cible:"20 MDH",seuil:"≤ 18 MDH",freq:"A",resp:"Directeur Général"},
       {kpi:"Rentabilité",formule:"Résultat net / chiffre d'affaires",cible:">8%",seuil:">5%",freq:"M",resp:"DIR. GÉNÉRALE"},
     ],
     "MPM2":[
       {kpi:"Taux réclamations",formule:"Nb réclamations dans le mois / CA",cible:"≤ 3,5%",seuil:"4%",freq:"M",resp:"Resp. QSE"},
     ],
     "MPR4":[
       {kpi:"Production / Heure",formule:"CA / heures réelles",cible:"160 DH HT",seuil:"150 DH HT",freq:"A",resp:"DIR. Technique"},
       {kpi:"Non-respect du délai",formule:"Nb jours retard / nb jours fabrication",cible:"≤ 8,5%",seuil:"9%",freq:"M",resp:"DIR. Technique"},
       {kpi:"Productivité",formule:"Temps alloué / temps passé",cible:"≥ 1",seuil:"0,9",freq:"M",resp:"DIR. Technique"},
       {kpi:"Taux de non-conformité",formule:"(NC / production totale) × 100",cible:"≤ 2%",seuil:"≤ 3%",freq:"M",resp:"DIR. Technique"},
       {kpi:"Production en montant",formule:"Montant des pièces fabriquées",cible:"20M DH",seuil:"≤ 18MDH",freq:"A",resp:"DIR. Technique"},
     ]
   }
  },
  {num:2,title:"Garantie de la Santé et Sécurité au Travail",color:"#e03c31",
   processus:{
     "MPM1":[
       {kpi:"Taux de conformité exigences régl. SSE",formule:"Nb exigences conformes / nb exigences applicables",cible:"100%",seuil:"98%",freq:"T",resp:"Directeur Général"},
     ],
     "MPM2":[
       {kpi:"Taux fréquence accidents du travail",formule:"Nb accidents × 1 000 000 / nb heures travaillées",cible:"10",seuil:"12",freq:"M",resp:"R. QSE"},
       {kpi:"Taux gravité accidents du travail",formule:"Nb jours arrêt × 1 000 / nb heures travaillées",cible:"0,3",seuil:"0,35",freq:"M",resp:"R. QSE"},
       {kpi:"Taux réalisation programme SSE",formule:"Nb actions SSE réalisées / nb actions planifiées",cible:"100%",seuil:"95%",freq:"S",resp:"R. QSE"},
     ]
   }
  },
  {num:3,title:"Réduction des Impacts Environnementaux & Capital Humain",color:"#00b67a",
   processus:{
     "MPM2":[
       {kpi:"Taux recyclage déchets valorisables",formule:"Qté déchets recyclées / qté déchets générées",cible:"> 65%",seuil:"60%",freq:"T",resp:"R. QSE"},
     ],
     "MPM1":[
       {kpi:"Satisfaction personnel",formule:"Résultats des entretiens",cible:">N-1",seuil:">N-1",freq:"A",resp:"Directeur Général"},
     ],
     "MPM3":[
       {kpi:"Délai moyen recrutement",formule:"Date fin recrutement - date demande de recrutement",cible:"30J",seuil:"≤ 30J",freq:"T",resp:"CHEF DRH"},
       {kpi:"Taux de démission",formule:"Nb démissions (n) / effectifs (n)",cible:"< 5%",seuil:"< 8%",freq:"M",resp:"CHEF DRH"},
       {kpi:"Efficacité du recrutement",formule:"Nb recrutements présents 6 mois / nb hors techniciens",cible:"0,75",seuil:"0,7",freq:"T",resp:"CHEF DRH"},
       {kpi:"Réalisation plan de formation",formule:"Nb formations réalisées / nb planifiées",cible:"≥ 90%",seuil:"85%",freq:"A",resp:"CHEF DRH"},
     ],
     "MPS5":[
       {kpi:"Réduction conso. électricité",formule:"(Conso N - Conso N-1) / N-1",cible:"-5%",seuil:"0%",freq:"M",resp:"CHEF MG"},
       {kpi:"Levée NC contrôle réglementaire",formule:"Nb NC levées / nb total NC identifiées",cible:"100%",seuil:"100%",freq:"T",resp:"CHEF MG"},
       {kpi:"Clôture demandes intervention corrective",formule:"Nb demandes clôturées / nb total demandes",cible:"100%",seuil:"90%",freq:"M",resp:"CHEF MG"},
       {kpi:"Respect planning maint. préventive",formule:"Nb opérations réalisées dans délais / nb planifiées",cible:"100%",seuil:"100%",freq:"T",resp:"CHEF MG"},
     ],
     "MPR4":[
       {kpi:"Taux chute tôle",formule:"Chute de tôle / besoin brut en tôle",cible:"≤ 5%",seuil:"≤ 6,5%",freq:"M",resp:"DIR. Technique"},
     ]
   }
  },
  {num:4,title:"Renforcement de l'Amélioration Continue",color:"#f59e0b",
   processus:{
     "MPM2":[
       {kpi:"Taux de réalisation audits internes",formule:"Nb audits réalisés / nb audits planifiés",cible:"100%",seuil:"95%",freq:"T",resp:"R. QSE"},
     ],
     "MPS1":[
       {kpi:"Résultat frais d'approche",formule:"Coût additionnel PR sans DD / montant entrée PR",cible:"≤ 9,5%",seuil:"≤ 10,5%",freq:"T",resp:"DIR. ACHAT"},
       {kpi:"Commandes traitées en retard",formule:"Nb commandes > 48h / nb total commandes",cible:"< 1%",seuil:"< 1,3%",freq:"M",resp:"DIR. ACHAT"},
       {kpi:"Délai fournisseur",formule:"Délai moyen / dossier exploitable",cible:"1 SEM ≤ x ≤ 2 SEM",seuil:"≤ 1 SEM",freq:"T",resp:"DIR. ACHAT"},
     ],
     "MPS2":[
       {kpi:"Écart inventaire permanent",formule:"Stock système - stock physique",cible:"± 0,1%",seuil:"± 0,15%",freq:"M",resp:"RESP. LOGISTIQUE"},
       {kpi:"Rupture stock consommables",formule:"Nb articles en rupture / total articles en stock",cible:"2%",seuil:"4%",freq:"M",resp:"RESP. LOGISTIQUE"},
     ],
     "MPR4":[
       {kpi:"Suivi fabrication gaines spiralées",formule:"Suivi fabrication gaines spiralées (km)",cible:"33KM",seuil:"30KM",freq:"A",resp:"DIR. Technique"},
     ],
     "MPS4":[
       {kpi:"Taux de Satisfaction utilisateurs SI",formule:"Enquête de satisfaction des utilisateurs",cible:"85%",seuil:"80%",freq:"S",resp:"CHEF SI"},
       {kpi:"Taux de respect de la politique de sécurité informatique",formule:"Nb incidents non-respect / nb total incidents",cible:"100%",seuil:"100%",freq:"S",resp:"CHEF SI"},
       {kpi:"Taux de disponibilité des infrastructures",formule:"[(Temps convenu - Indisponibilité) / Temps convenu] × 100",cible:"100%",seuil:"95%",freq:"S",resp:"CHEF SI"},
       {kpi:"Taux de disponibilité des ressources",formule:"Σ(durée panne × nb postes) / (heures × utilisateurs) × 100",cible:"98%",seuil:"95%",freq:"M",resp:"CHEF SI"},
     ]
   }
  }
];

const KPI_DATA = [
  {proc:"MPM1",kpi:"Taux de satisfaction client",freq:"A",cible:0.95,seuil:0.90,vals:[],unit:"%",scale:100,higherBetter:true,inputs:[{label:"Clients satisfaits",id:"a"},{label:"Total clients",id:"b"}],formula:"a/b"},
  {proc:"MPM1",kpi:"Taux de conformité exigences régl. SSE",freq:"T",cible:1,seuil:0.98,vals:[0.99],unit:"%",scale:100,higherBetter:true,inputs:[{label:"Nb exigences conformes",id:"a"},{label:"Nb exigences applicables",id:"b"}],formula:"a/b"},
  {proc:"MPM1",kpi:"Rentabilité",freq:"M",cible:0.08,seuil:0.05,vals:[0.1243,0.0712,0.0652],unit:"%",scale:100,higherBetter:true,inputs:[{label:"Résultat net (DH)",id:"a"},{label:"Chiffre d'affaires (DH)",id:"b"}],formula:"a/b"},
  {proc:"MPM1",kpi:"Satisfaction personnel",freq:"A",cible:null,seuil:null,vals:[],unit:"",scale:1,higherBetter:true,inputs:[],formula:""},
  {proc:"MPM1",kpi:"Chiffre d'affaires cumulé",freq:"A",cible:20000000,seuil:18000000,vals:[],unit:"MDH",scale:1/1000000,higherBetter:true,inputs:[{label:"Montant CA (DH)",id:"a"}],formula:"a"},
  {proc:"MPM2",kpi:"Taux réclamations",freq:"M",cible:0.035,seuil:0.04,vals:[0.0299,0.03,0.0309],unit:"%",scale:100,higherBetter:false,inputs:[{label:"Nb réclamations",id:"a"},{label:"CA mensuel (DH)",id:"b"}],formula:"a/b"},
  {proc:"MPM2",kpi:"Taux fréquence accidents du travail",freq:"M",cible:10,seuil:12,vals:[5.5,8.8,12.7],unit:"",scale:1,higherBetter:false,inputs:[{label:"Nb accidents avec arrêt",id:"a"},{label:"Nb heures travaillées",id:"b"}],formula:"a*1000000/b"},
  {proc:"MPM2",kpi:"Taux gravité accidents du travail",freq:"M",cible:0.3,seuil:0.35,vals:[0.07,0.21,0.53],unit:"",scale:1,higherBetter:false,inputs:[{label:"Nb jours d'arrêt",id:"a"},{label:"Nb heures travaillées",id:"b"}],formula:"a*1000/b"},
  {proc:"MPM2",kpi:"Taux réalisation programme SSE",freq:"S",cible:1,seuil:0.95,vals:[],unit:"%",scale:100,higherBetter:true,inputs:[{label:"Nb actions SSE réalisées",id:"a"},{label:"Nb actions SSE planifiées",id:"b"}],formula:"a/b"},
  {proc:"MPM2",kpi:"Taux recyclage déchets valorisables",freq:"T",cible:0.65,seuil:0.60,vals:[0.58],unit:"%",scale:100,higherBetter:true,inputs:[{label:"Qté déchets recyclées",id:"a"},{label:"Qté déchets générées",id:"b"}],formula:"a/b"},
  {proc:"MPM2",kpi:"Taux réalisation audits internes",freq:"T",cible:1,seuil:0.95,vals:[0.95],unit:"%",scale:100,higherBetter:true,inputs:[{label:"Nb audits réalisés",id:"a"},{label:"Nb audits planifiés",id:"b"}],formula:"a/b"},
  {proc:"MPM3",kpi:"Délai moyen recrutement",freq:"T",cible:30,seuil:30,vals:[16],unit:"jours",scale:1,higherBetter:false,inputs:[{label:"Date fin recrutement (j)",id:"a"},{label:"Date demande (j)",id:"b"}],formula:"a-b"},
  {proc:"MPM3",kpi:"Taux de démission",freq:"M",cible:0.05,seuil:0.08,vals:[0.0075,0.016,0.0197],unit:"%",scale:100,higherBetter:false,inputs:[{label:"Nb démissions",id:"a"},{label:"Effectifs totaux",id:"b"}],formula:"a/b"},
  {proc:"MPM3",kpi:"Efficacité du recrutement",freq:"T",cible:0.75,seuil:0.70,vals:[0.86],unit:"",scale:1,higherBetter:true,inputs:[{label:"Nb recrutements présents 6 mois",id:"a"},{label:"Nb recrutements hors techniciens",id:"b"}],formula:"a/b"},
  {proc:"MPM3",kpi:"Réalisation plan de formation",freq:"A",cible:0.90,seuil:0.85,vals:[],unit:"%",scale:100,higherBetter:true,inputs:[{label:"Nb formations réalisées",id:"a"},{label:"Nb formations planifiées",id:"b"}],formula:"a/b"},
  {proc:"MPR4",kpi:"Non-respect du délai",freq:"M",cible:0.085,seuil:0.09,vals:[0.084,0.085,0.083],unit:"%",scale:100,higherBetter:false,inputs:[{label:"Nb jours en retard",id:"a"},{label:"Nb jours de fabrication",id:"b"}],formula:"a/b"},
  {proc:"MPR4",kpi:"Productivité opérateurs",freq:"M",cible:1,seuil:0.9,vals:[1.10,1.05,1.08],unit:"",scale:1,higherBetter:true,inputs:[{label:"Temps alloué",id:"a"},{label:"Temps passé",id:"b"}],formula:"a/b"},
  {proc:"MPR4",kpi:"Taux de chute tôle",freq:"M",cible:0.05,seuil:0.065,vals:[0.059,0.061,0.062],unit:"%",scale:100,higherBetter:false,inputs:[{label:"Chute de tôle (kg)",id:"a"},{label:"Besoin brut tôle (kg)",id:"b"}],formula:"a/b"},
  {proc:"MPR4",kpi:"Taux de non-conformité",freq:"M",cible:0.02,seuil:0.03,vals:[0,0.0001,0],unit:"%",scale:100,higherBetter:false,inputs:[{label:"Nb non-conformités",id:"a"},{label:"Production totale",id:"b"}],formula:"a/b"},
  {proc:"MPR4",kpi:"Production / Heure",freq:"A",cible:160,seuil:150,vals:[],unit:"DH HT",scale:1,higherBetter:true,inputs:[{label:"CA (DH)",id:"a"},{label:"Heures réelles",id:"b"}],formula:"a/b"},
  {proc:"MPR4",kpi:"Production en montant",freq:"A",cible:20000000,seuil:18000000,vals:[],unit:"MDH",scale:1/1000000,higherBetter:true,inputs:[{label:"Montant pièces fabriquées (DH)",id:"a"}],formula:"a"},
  {proc:"MPR4",kpi:"Suivi fabrication gaines spiralées",freq:"A",cible:33,seuil:30,vals:[],unit:"km",scale:1,higherBetter:true,inputs:[{label:"Km produits",id:"a"}],formula:"a"},
  {proc:"MPS1",kpi:"Commandes traitées en retard",freq:"M",cible:0.01,seuil:0.013,vals:[0.0141,0.017,0.008],unit:"%",scale:100,higherBetter:false,inputs:[{label:"Nb commandes > 48h",id:"a"},{label:"Nb total commandes",id:"b"}],formula:"a/b"},
  {proc:"MPS1",kpi:"Résultat frais d'approche",freq:"T",cible:0.095,seuil:0.105,vals:[0.0652],unit:"%",scale:100,higherBetter:false,inputs:[{label:"Coût additionnel PR sans DD",id:"a"},{label:"Montant entrée PR",id:"b"}],formula:"a/b"},
  {proc:"MPS1",kpi:"Délai fournisseur",freq:"T",cible:null,seuil:null,vals:[],unit:"sem",scale:1,higherBetter:false,inputs:[{label:"Délai moyen (jours)",id:"a"}],formula:"a/7"},
  {proc:"MPS2",kpi:"Écart inventaire permanent",freq:"M",cible:0.001,seuil:0.0015,vals:[0,0,0],unit:"%",scale:100,higherBetter:false,inputs:[{label:"Stock système",id:"a"},{label:"Stock physique",id:"b"}],formula:"Math.abs(a-b)/b"},
  {proc:"MPS2",kpi:"Rupture stock consommables",freq:"M",cible:0.02,seuil:0.04,vals:[0.00368,0.01,0.012],unit:"%",scale:100,higherBetter:false,inputs:[{label:"Nb articles en rupture",id:"a"},{label:"Total articles en stock",id:"b"}],formula:"a/b"},
  {proc:"MPS4",kpi:"Taux de disponibilité des ressources",freq:"M",cible:0.98,seuil:0.95,vals:[0.98,0.984,0.981],unit:"%",scale:100,higherBetter:true,inputs:[{label:"Σ(durée panne × nb postes)",id:"a"},{label:"Heures travail × nb utilisateurs",id:"b"}],formula:"(1-(a/b))"},
  {proc:"MPS4",kpi:"Taux disponibilité infrastructures",freq:"S",cible:1,seuil:0.95,vals:[],unit:"%",scale:100,higherBetter:true,inputs:[{label:"Temps convenu (h)",id:"a"},{label:"Durée indisponibilité (h)",id:"b"}],formula:"(a-b)/a"},
  {proc:"MPS4",kpi:"Taux de satisfaction utilisateurs SI",freq:"S",cible:0.85,seuil:0.80,vals:[],unit:"%",scale:100,higherBetter:true,inputs:[{label:"Score satisfaction (/1)",id:"a"}],formula:"a"},
  {proc:"MPS4",kpi:"Respect politique sécurité informatique",freq:"S",cible:1,seuil:1,vals:[],unit:"%",scale:100,higherBetter:true,inputs:[{label:"Incidents non-respect",id:"a"},{label:"Total incidents",id:"b"}],formula:"b===0?1:(b-a)/b"},
  {proc:"MPS5",kpi:"Réduction conso. électricité",freq:"M",cible:-0.05,seuil:0,vals:[0.13,0.02,0.04],unit:"%",scale:100,higherBetter:false,inputs:[{label:"Conso année N (kWh)",id:"a"},{label:"Conso année N-1 (kWh)",id:"b"}],formula:"(a-b)/b"},
  {proc:"MPS5",kpi:"Levée NC contrôle réglementaire",freq:"T",cible:1,seuil:1,vals:[1],unit:"%",scale:100,higherBetter:true,inputs:[{label:"Nb NC levées",id:"a"},{label:"Nb total NC identifiées",id:"b"}],formula:"a/b"},
  {proc:"MPS5",kpi:"Clôture demandes intervention corrective",freq:"M",cible:1,seuil:0.9,vals:[0.95,0.98,0.97],unit:"%",scale:100,higherBetter:true,inputs:[{label:"Demandes clôturées",id:"a"},{label:"Total demandes correctives",id:"b"}],formula:"a/b"},
  {proc:"MPS5",kpi:"Respect planning maintenance préventive",freq:"T",cible:1,seuil:1,vals:[1],unit:"%",scale:100,higherBetter:true,inputs:[{label:"Opérations réalisées dans délai",id:"a"},{label:"Total opérations planifiées",id:"b"}],formula:"a/b"},
];

// ==================== KPI DISPLAY LABELS (cible & seuil avec symboles) ====================
// Cibles et seuils EXACTEMENT comme dans le tableau Excel — symboles uniquement là où ils existent dans l'Excel
const KPI_LABELS = {
  // MPM1 — Excel: 0.95 / 0.9 → pas de symbole dans Excel pour ces deux valeurs numériques pures
  "Taux de satisfaction client":           {cible:"95%",          seuil:"90%"},
  // Excel: 1 / 0.98 → valeurs numériques pures
  "Taux de conformité exigences régl. SSE":{cible:"100%",         seuil:"98%"},
  // Excel: '>8%' / '>5%' → symboles présents dans Excel
  "Rentabilité":                           {cible:">8%",          seuil:">5%"},
  // Excel: '>N-1' / '>N-1'
  "Satisfaction personnel":                {cible:">N-1",         seuil:">N-1"},
  // Excel: '20MDH' / '≤18MDH'
  "Chiffre d'affaires cumulé":             {cible:"20 MDH",       seuil:"≤ 18 MDH"},
  // MPM2 — Excel: '≤ 3,5%' / 0.04 → seuil numérique pur
  "Taux réclamations":                     {cible:"≤ 3,5%",       seuil:"4%"},
  // Excel: 10 / 12 → valeurs numériques pures
  "Taux fréquence accidents du travail":   {cible:"10",           seuil:"12"},
  // Excel: 0.3 / 0.35 → valeurs numériques pures
  "Taux gravité accidents du travail":     {cible:"0,3",          seuil:"0,35"},
  // Excel: 1 / 0.95 → valeurs numériques pures
  "Taux réalisation programme SSE":        {cible:"100%",         seuil:"95%"},
  // Excel: '> 65%' / 0.6 → seuil numérique pur
  "Taux recyclage déchets valorisables":   {cible:"> 65%",        seuil:"60%"},
  // Excel: 1 / 0.95 → valeurs numériques pures
  "Taux réalisation audits internes":      {cible:"100%",         seuil:"95%"},
  // MPM3 — Excel: '30J' / '≤ 30J'
  "Délai moyen recrutement":               {cible:"30 J",         seuil:"≤ 30 J"},
  // Excel: '< 5%' / '< 8%'
  "Taux de démission":                     {cible:"< 5%",         seuil:"< 8%"},
  // Excel: 0.75 / 0.7 → valeurs numériques pures
  "Efficacité du recrutement":             {cible:"0,75",         seuil:"0,70"},
  // Excel: '≥ 90%' / 0.85 → seuil numérique pur
  "Réalisation plan de formation":         {cible:"≥ 90%",        seuil:"85%"},
  // MPR4 — Excel: '≤ 8,5%' / 0.09 → seuil numérique pur
  "Non-respect du délai":                  {cible:"≤ 8,5%",       seuil:"9%"},
  // Excel: '≥ 1' / 0.9 → seuil numérique pur
  "Productivité opérateurs":               {cible:"≥ 1",          seuil:"0,9"},
  // Excel: '≤ 5%' / '≤ 6,5%'
  "Taux de chute tôle":                    {cible:"≤ 5%",         seuil:"≤ 6,5%"},
  // Excel: '≤ 2%' / '≤ 3%'
  "Taux de non-conformité":                {cible:"≤ 2%",         seuil:"≤ 3%"},
  // Excel: '160 DH HT' / '150 DH HT' → valeurs textes sans symbole
  "Production / Heure":                    {cible:"160 DH HT",    seuil:"150 DH HT"},
  // Excel: '20M DH' / '≤ 18MDH'
  "Production en montant":                 {cible:"20 M DH",      seuil:"≤ 18 MDH"},
  // Excel: '33KM' / '30KM' → valeurs textes sans symbole
  "Suivi fabrication gaines spiralées":    {cible:"33 KM",        seuil:"30 KM"},
  // MPS1 — Excel: '< 1%' / '< 1,3%'
  "Commandes traitées en retard":          {cible:"< 1%",         seuil:"< 1,3%"},
  // Excel: '≤ 9,5%' / '≤ 10,5%'
  "Résultat frais d'approche":             {cible:"≤ 9,5%",       seuil:"≤ 10,5%"},
  // Excel: '1 SEM ≤ x ≤ 2 SEM' (cible) / '≤ 1 SEM' (seuil)
  "Délai fournisseur":                     {cible:"1 SEM ≤ x ≤ 2 SEM", seuil:"≤ 1 SEM"},
  // MPS2 — Excel: '± 0,1%' / '± 0,15%'
  "Écart inventaire permanent":            {cible:"± 0,1%",       seuil:"± 0,15%"},
  // Excel: 0.02 / 0.04 → valeurs numériques pures
  "Rupture stock consommables":            {cible:"2%",           seuil:"4%"},
  // MPS4 — Excel: 0.98 / 0.95 → valeurs numériques pures
  "Taux de disponibilité des ressources":  {cible:"98%",          seuil:"95%"},
  // Excel: 1 / 0.95 → valeurs numériques pures
  "Taux disponibilité infrastructures":    {cible:"100%",         seuil:"95%"},
  // Excel: 0.85 / 0.8 → valeurs numériques pures
  "Taux de satisfaction utilisateurs SI":  {cible:"85%",          seuil:"80%"},
  // Excel: 1 / 1 → valeurs numériques pures
  "Respect politique sécurité informatique":{cible:"100%",        seuil:"100%"},
  // MPS5 — Excel: -0.05 / 0 → valeurs numériques pures
  "Réduction conso. électricité":          {cible:"-5%",          seuil:"0%"},
  // Excel: 1 / 1 → valeurs numériques pures
  "Levée NC contrôle réglementaire":       {cible:"100%",         seuil:"100%"},
  // Excel: 1 / 0.9 → valeurs numériques pures
  "Clôture demandes intervention corrective":{cible:"100%",       seuil:"90%"},
  // Excel: 1 / 1 → valeurs numériques pures
  "Respect planning maintenance préventive":{cible:"100%",        seuil:"100%"},
};

function getKpiLabel(k, type) {
  const lbl = KPI_LABELS[k.kpi];
  if (lbl && lbl[type]) return lbl[type];
  // fallback
  if (k[type] === null) return '—';
  return (k[type]*k.scale).toFixed(1)+(k.unit?' '+k.unit:'');
}

let excelData = {};
let currentUser = null;
let currentFreq = 'all';
let currentVizFreq = 'M';
let currentExcelProc = null;
let vizCharts = {};

// ==================== INIT ====================
document.querySelectorAll('[id$="-logo-img"], .login-logo-img').forEach(img => img.src = LOGO_SVG);
const cartoLogo = document.getElementById('carto-logo-img');
if(cartoLogo) cartoLogo.src = LOGO_SVG;
const cartoFooterLogo = document.getElementById('carto-footer-logo');
if(cartoFooterLogo) cartoFooterLogo.src = LOGO_SVG;

// ==================== AUTH ====================
function doLogin() {
  const sel = document.getElementById('login-user').value;
  const pass = document.getElementById('login-pass').value;
  const err = document.getElementById('login-err');
  if (!sel) { err.textContent='Veuillez sélectionner votre profil.'; err.style.display='block'; return; }
  if (pass !== 'ventec2026') { err.style.display='block'; return; }
  const parts = sel.split('|');
  const name = parts[0];
  currentUser = { name, dept:parts[1], role:parts[2], mainProc:parts[3], ...(USERS[name]||{}) };
  document.getElementById('user-name').textContent = currentUser.name;
  document.getElementById('user-role').textContent = currentUser.role || parts[2];
  document.getElementById('login-screen').style.display = 'none';
  // Afficher le bouton Gérer mes KPIs
  const manageBtn = document.getElementById('manage-kpi-btn');
  if (manageBtn) manageBtn.style.display = '';
  buildApp();
  applyNavAccess();
  showPage('accueil');
  // Vérifier les alertes KPI après connexion
  setTimeout(() => checkKpiAlerts(), 800);
}
function doLogout() {
  currentUser = null;
  NOTIFICATIONS = [];
  shownToasts = new Set();
  CUSTOM_KPI_DATA = {};
  updateNotifPanel();
  const manageBtn = document.getElementById('manage-kpi-btn');
  if (manageBtn) manageBtn.style.display = 'none';
  document.getElementById('login-screen').style.display='flex';
  document.getElementById('login-pass').value='';
  document.getElementById('login-err').style.display='none';
}
document.getElementById('login-pass').addEventListener('keypress', e => { if(e.key==='Enter') doLogin(); });

function toggleLoginPass(btn) {
  const inp = document.getElementById('login-pass');
  if (inp.type === 'password') {
    inp.type = 'text';
    btn.textContent = 'Masquer';
    btn.title = 'Masquer';
  } else {
    inp.type = 'password';
    btn.textContent = 'Afficher';
    btn.title = 'Afficher';
  }
}

// ==================== ACCÈS PAR PROFIL ====================
// Définition des pages autorisées selon le processus de l'utilisateur
const PAGE_ACCESS = {
  // Pages universelles : accessibles à TOUS les utilisateurs connectés
  UNIVERSAL: ['accueil','politique','dashboard','calculateur','visualisation','excel','objectifs','rapport','suivi'],
  // Pages réservées : Directeur Général (MPM1) et Responsable QSE (MPM2) seulement
  RESTRICTED: {
    'cartographie':['MPM1','MPM2']
  }
};

function canAccessPage(id) {
  if (!currentUser) return false;
  if (PAGE_ACCESS.UNIVERSAL.includes(id)) return true;
  if (PAGE_ACCESS.RESTRICTED[id]) {
    const allowed = PAGE_ACCESS.RESTRICTED[id];
    const userProcs = currentUser.proc || [];
    return userProcs.some(p => allowed.includes(p));
  }
  return false; // page inconnue → refus
}

// Met à jour la nav : masquer les liens non autorisés, afficher les autorisés
function applyNavAccess() {
  if (!currentUser) return;
  // Liens de navigation
  document.querySelectorAll('nav a[id^="nav-"]').forEach(link => {
    const pageId = link.id.replace('nav-','');
    if (canAccessPage(pageId)) {
      link.style.display = '';
      link.style.pointerEvents = '';
      link.style.opacity = '';
    } else {
      link.style.display = 'none'; // Masquer complètement les pages interdites
    }
  });
  // Raccourcis accueil : masquer aussi les cartes rapides non autorisées
  document.querySelectorAll('.accueil-quick-card').forEach(card => {
    const onclick = card.getAttribute('onclick') || '';
    const match = onclick.match(/showPage\\('([^']+)'\\)/);
    if (match) {
      const pageId = match[1];
      if (!canAccessPage(pageId)) {
        card.style.display = 'none';
      } else {
        card.style.display = '';
      }
    }
  });
}

// ==================== NAV ====================
function showPage(id) {
  // ── Vérification d'accès ──────────────────────────────────────────────────
  if (!canAccessPage(id)) {
    // Afficher un message d'accès refusé dans la topbar momentanément
    const titleEl = document.getElementById('page-title');
    const prev = titleEl.textContent;
    titleEl.textContent = '⛔ Accès non autorisé pour votre profil';
    titleEl.style.color = '#dc2626';
    setTimeout(() => { titleEl.textContent = prev; titleEl.style.color = ''; }, 2500);
    return; // Bloquer la navigation
  }
  // ── Navigation normale ────────────────────────────────────────────────────
  document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
  document.querySelectorAll('nav a').forEach(a => a.classList.remove('active'));
  const pg  = document.getElementById('page-'+id);
  const nav = document.getElementById('nav-'+id);
  if (pg)  pg.classList.add('active');
  if (nav) nav.classList.add('active');
  const titles = {
    accueil      : 'Accueil — Ventec Industries',
    politique    : 'Politique QSE',
    cartographie : 'Cartographie des Processus',
    objectifs    : 'Objectifs Stratégiques — Mon Processus',
    dashboard    : 'Tableau de Bord KPI',
    calculateur  : 'Calculateur de KPI',
    visualisation: 'Visualisation — Analyse KPI',
    excel        : 'Tableau Excel — Saisie & Résultats',
    rapport      : 'Rapport de Processus',
    suivi        : 'Suivi des Actions Correctives'
  };
  document.getElementById('page-title').textContent = titles[id] || id;
  if (id==='visualisation') { setTimeout(()=>buildViz(currentVizFreq),50); }
  if (id==='excel')         { buildExcelTable(currentExcelProc); }
}

// ==================== BUILD APP ====================
function buildApp() {
  buildAxes();
  buildKPIGrid();
  buildCalcSelect();
  updateStats();
  buildExcelTabs();
  buildRapportSelect();
}

function buildRapportSelect() {
  const sel = document.getElementById('rapport-proc-select');
  if (!sel) return;
  const userProcs = currentUser && currentUser.proc ? currentUser.proc : Object.keys({MPM1:1,MPM2:1,MPM3:1,MPR4:1,MPS1:1,MPS2:1,MPS4:1,MPS5:1});
  const PROC_NAMES = {MPM1:'Management Général',MPM2:'Gestion QSE',MPM3:'Management RH',MPR4:'Production',MPS1:'Achats',MPS2:'Logistique',MPS4:"Systèmes d'information",MPS5:'Moyens Généraux'};
  sel.innerHTML = userProcs.map(p => `<option value="${p}">${p} — ${PROC_NAMES[p]||p}</option>`).join('');
}

function getUserKPIs() {
  if (!currentUser) return [];
  if (!currentUser.proc || currentUser.proc.length > 4) return KPI_DATA;
  return KPI_DATA.filter(k => currentUser.proc.includes(k.proc));
}

function freqLabel(f) {
  return {M:'Mensuelle',T:'Trimestrielle',S:'Semestrielle',A:'Annuelle'}[f]||f;
}

// ==================== AXES (PER PROCESS) ====================
function buildAxes() {
  const cont = document.getElementById('axes-container');
  const objHead = document.getElementById('obj-page-title');
  // Update the objectifs page subtitle based on logged-in user
  if (objHead && currentUser) {
    const proc = currentUser.proc && currentUser.proc[0];
    objHead.textContent = proc ? 'Processus ' + proc + ' — ' + procName(proc) + ' (' + currentUser.name + ')' : 'Tous les processus';
  }
  cont.innerHTML = AXES.map(axe => {
    const procs = Object.keys(axe.processus);
    // CORRECTION: Toujours filtrer par processus de l'utilisateur connecté
    const visibleProcs = currentUser && currentUser.proc && currentUser.proc.length > 0
      ? procs.filter(p => currentUser.proc.includes(p))
      : procs;
    if (!visibleProcs.length) return '';
    return `
    <div class="axe-card">
      <div class="axe-head" onclick="toggleAxe(this)">
        <div class="axe-num" style="background:${axe.color}">${axe.num}</div>
        <h3>AXE ${axe.num} : ${axe.title}</h3>
        <span class="axe-toggle">▼</span>
      </div>
      <div class="axe-body">
        ${visibleProcs.map(proc => `
          <div class="axe-proc-section">
            <div class="axe-proc-title"><span class="axe-proc-badge">${proc}</span>${procName(proc)}</div>
            <table class="obj-table">
              <thead><tr>
                <th style="width:220px">KPI</th>
                <th>Formule de Calcul</th>
                <th style="width:100px">Cible</th>
                <th style="width:100px">Seuil</th>
                <th style="width:80px">Fréquence</th>
                <th style="width:140px">Responsable</th>
              </tr></thead>
              <tbody>
                ${axe.processus[proc].map(o => `
                  <tr>
                    <td class="obj-kpi">${o.kpi}</td>
                    <td class="obj-formule">${o.formule}</td>
                    <td><span class="cible-tag">${o.cible}</span></td>
                    <td><span class="seuil-tag">${o.seuil}</span></td>
                    <td><span class="freq-tag freq-${o.freq}">${freqLabel(o.freq)}</span></td>
                    <td class="resp-tag">${o.resp||''}</td>
                  </tr>`).join('')}
              </tbody>
            </table>
          </div>`).join('')}
      </div>
    </div>`;
  }).join('');
}

function toggleAxe(head) {
  const body = head.nextElementSibling;
  const tog = head.querySelector('.axe-toggle');
  if (body.classList.contains('collapsed')) {
    body.classList.remove('collapsed');
    tog.style.transform='rotate(0deg)';
  } else {
    body.classList.add('collapsed');
    tog.style.transform='rotate(-90deg)';
  }
}

function procName(p) {
  const names = {MPM1:'Management Général',MPM2:'Management QSE',MPM3:'Management RH',MPR4:'Production',MPR5:'Finance & Comptabilité',MPS1:'Achats',MPS2:'Logistique',MPS4:'Systèmes d\\'information',MPS5:'Moyens Généraux'};
  return names[p]||p;
}

// ==================== KPI GRID ====================
function buildKPIGrid() {
  const grid = document.getElementById('kpi-grid');
  const kpis = getUserKPIs();
  const filtered = currentFreq==='all'?kpis:kpis.filter(k=>k.freq===currentFreq);
  if (!filtered.length) { grid.innerHTML='<div class="no-kpi">Aucun KPI disponible pour ce filtre.</div>'; return; }
  grid.innerHTML = filtered.map((k,i)=>buildKPICard(k,i)).join('');
  updateStats();
}

function buildKPICard(k, i) {
  const hasVals = k.vals && k.vals.length>0;
  let valsHTML='', statusClass='';
  if (hasVals) {
    valsHTML='<div class="kpi-values">'+k.vals.map((v,idx)=>{
      const disp=(v*k.scale).toFixed(k.scale>=100?1:3);
      const cls=getValClass(k,v);
      if(idx===k.vals.length-1) statusClass=cls;
      const lbl=k.freq==='M'?MONTHS[idx]:(k.freq==='T'?'T1 2026':k.freq==='S'?'S1 2026':'2026');
      return `<div class="kpi-val-item"><label>${lbl}</label><div class="v ${cls}">${disp}${k.unit?' '+k.unit:''}</div></div>`;
    }).join('')+'</div>';
  }
  const cid='calc-'+i, fid='form-'+i;
  const cibleDisp = getKpiLabel(k,'cible');
  const seuilDisp = getKpiLabel(k,'seuil');
  const pct=hasVals?getBarPct(k,k.vals[k.vals.length-1]):0;
  const barColor=hasVals?getBarColor(k,k.vals[k.vals.length-1]):'var(--border)';
  return `
  <div class="kpi-card">
    <div class="kpi-card-top">
      <span class="kpi-proc-tag">${k.proc}</span>
      <span class="freq-tag freq-${k.freq}">${freqLabel(k.freq)}</span>
    </div>
    <div class="kpi-card-body">
      <div class="kpi-name">${k.kpi}</div>
      <div class="kpi-formula-lbl">${k.inputs.map(x=>x.label).join(' / ')||'Voir formule'}</div>
      <div class="kpi-targets">
        <div class="kpi-target cible"><label>Cible</label><div class="val">${cibleDisp}</div></div>
        <div class="kpi-target seuil"><label>Seuil</label><div class="val">${seuilDisp}</div></div>
      </div>
      ${valsHTML}
      <div class="status-bar"><div class="status-fill" style="width:${pct}%;background:${barColor}"></div></div>
      ${k.inputs.length?`
        <button class="kpi-calc-toggle" onclick="toggleCalc('${cid}')">Calculer</button>
        <div class="kpi-calc" id="${cid}">
          ${k.inputs.map(inp=>`<div class="calc-row"><label>${inp.label}</label><input type="number" id="${fid}-${inp.id}" placeholder="0" step="any"></div>`).join('')}
          <button class="calc-btn" onclick="calcKPI(${i},'${fid}','${cid}-res')">Calculer</button>
          <div class="calc-result" id="${cid}-res"></div>
        </div>`:''
      }
    </div>
  </div>`;
}

function toggleCalc(id) { document.getElementById(id).classList.toggle('open'); }

function calcKPI(kpiIdx, formId, resId) {
  const k=getUserKPIs()[kpiIdx]||KPI_DATA[kpiIdx];
  const resEl=document.getElementById(resId);
  try {
    const vals={};
    for (const inp of k.inputs) {
      const el=document.getElementById(formId+'-'+inp.id);
      if(!el||el.value===''){resEl.textContent='Veuillez remplir tous les champs.';resEl.className='calc-result bad';resEl.style.display='block';return;}
      vals[inp.id]=parseFloat(el.value);
    }
    const {a,b}=vals;
    let result;
    try{result=eval(k.formula);}catch(e){result=NaN;}
    if(isNaN(result)||!isFinite(result)){resEl.textContent='Valeur invalide.';resEl.className='calc-result bad';resEl.style.display='block';return;}
    const display=(result*k.scale).toFixed(2)+(k.unit?' '+k.unit:'');
    const cls=getValClass(k,result);
    resEl.textContent=cls==='v-green'?`Atteint : ${display}`:cls==='v-yellow'?`Tolérance : ${display}`:`Hors cible : ${display}`;
    resEl.className='calc-result '+(cls==='v-green'?'ok':cls==='v-yellow'?'warn':'bad');
    resEl.style.display='block';
  } catch(e){resEl.textContent='Erreur.';resEl.className='calc-result bad';resEl.style.display='block';}
}

function filterKPI(freq,btn) {
  currentFreq=freq;
  document.querySelectorAll('.dash-filter-bar .filter-btn').forEach(b=>b.classList.remove('active'));
  btn.classList.add('active');
  buildKPIGrid();
}

function updateStats() {
  const kpis=getUserKPIs();
  let ok=0,warn=0,bad=0;
  kpis.forEach(k=>{
    if(!k.vals||!k.vals.length) return;
    const last=k.vals[k.vals.length-1];
    const cls=getValClass(k,last);
    if(cls==='v-green')ok++;
    else if(cls==='v-yellow')warn++;
    else bad++;
  });
  ['stat-total','stat-ok','stat-warn','stat-bad'].forEach((id,i)=>{
    const el=document.getElementById(id);
    if(el) el.textContent=[kpis.length,ok,warn,bad][i];
  });
  ['acc-total','acc-ok','acc-warn','acc-bad'].forEach((id,i)=>{
    const el=document.getElementById(id);
    if(el) el.textContent=[kpis.length,ok,warn,bad][i];
  });
}

// ==================== CALCULATEUR (like Image 4) ====================
// Stored calculated values per KPI index → {periodLabel: value}
const CALC_SAVED = {};
let calcCorrectionMode = {};

function buildCalcSelect() {
  const sel=document.getElementById('calc-select');
  sel.innerHTML='<option value="">— Choisir un KPI —</option>';
  getUserKPIs().filter(k=>k.inputs.length>0).forEach((k,i)=>{
    const opt=document.createElement('option');
    opt.value=i; opt.textContent=k.proc+' — '+k.kpi;
    sel.appendChild(opt);
  });
}

function showCalcForm() {
  const sel=document.getElementById('calc-select');
  const idx=parseInt(sel.value);
  const area=document.getElementById('calc-form-area');
  if(isNaN(idx)){area.innerHTML='';return;}
  renderCalcForm(idx);
}

function renderCalcForm(idx) {
  const area=document.getElementById('calc-form-area');
  const kpis=getUserKPIs().filter(k=>k.inputs.length>0);
  const k=kpis[idx];
  if(!k){area.innerHTML='';return;}

  const cDisp = getKpiLabel(k,'cible');
  const sDisp = getKpiLabel(k,'seuil');

  // Saved values for this KPI
  const saved = CALC_SAVED[idx] || {};
  const savedKeys = Object.keys(saved);
  const isCorrMode = calcCorrectionMode[idx] || false;

  // Determine next period label based on freq and already saved
  const savedMonths = savedKeys.filter(k2=>MONTHS.includes(k2));
  const savedMonthIdx = savedMonths.map(m=>MONTHS.indexOf(m));
  const nextMonthIdx = savedMonths.length < MONTHS.length
    ? (savedMonthIdx.length > 0 ? Math.max(...savedMonthIdx)+1 : 0) : null;
  const nextPeriodLabel = k.freq==='M'
    ? (nextMonthIdx !== null && nextMonthIdx < MONTHS.length ? MONTHS[nextMonthIdx] : null)
    : k.freq==='T' ? 'T'+(savedKeys.length+1)
    : k.freq==='S' ? 'S'+(savedKeys.length+1)
    : '2026';

  // Saved values chips
  let savedHtml = '';
  if (savedKeys.length > 0) {
    savedHtml = `<div style="margin-bottom:18px">
      <div style="font-size:11px;font-weight:700;color:var(--gray);text-transform:uppercase;letter-spacing:1px;margin-bottom:8px">Valeurs enregistrées (${savedKeys.length})</div>
      <div style="display:flex;gap:8px;flex-wrap:wrap">
        ${savedKeys.map(periodKey=>{
          const v = saved[periodKey];
          const disp = (v*k.scale).toFixed(2)+(k.unit?' '+k.unit:'');
          const cls = getValClass(k,v);
          const col = cls==='v-green'?'var(--green)':cls==='v-yellow'?'var(--yellow)':'var(--red)';
          const bg = cls==='v-green'?'var(--green-bg)':cls==='v-yellow'?'var(--yellow-bg)':'var(--red-bg)';
          return `<div style="background:${bg};border:1.5px solid ${col};border-radius:10px;padding:10px 14px;text-align:center;min-width:80px;position:relative">
            <div style="font-size:10px;font-weight:700;color:${col};text-transform:uppercase">${periodKey}</div>
            <div style="font-size:16px;font-weight:900;color:${col};font-family:'Plus Jakarta Sans',sans-serif">${disp}</div>
            ${isCorrMode?`<button onclick="deleteSavedVal(${idx},'${periodKey}')" style="position:absolute;top:-6px;right:-6px;width:18px;height:18px;border-radius:50%;background:var(--red);color:white;border:none;cursor:pointer;font-size:11px;display:flex;align-items:center;justify-content:center;font-weight:700;line-height:1">×</button>`:''}
          </div>`;
        }).join('')}
      </div>
    </div>`;
  }

  // New entry form
  let newEntryHtml = '';
  if (nextPeriodLabel !== null) {
    newEntryHtml = `
    <div style="background:white;border:1.5px solid var(--border);border-radius:14px;padding:22px;margin-bottom:18px">
      <div style="font-family:'Plus Jakarta Sans',sans-serif;font-size:14px;font-weight:800;color:var(--navy);margin-bottom:14px">
        Nouvelle saisie — <span style="color:var(--accent)">${nextPeriodLabel}</span>
      </div>
      <div style="background:#ffffff;border-radius:8px;padding:10px 14px;margin-bottom:16px;font-size:12.5px;color:var(--text-mid)">
        <strong>Formule :</strong> ${k.inputs.map(x=>x.label).join(' / ')}
      </div>
      ${k.inputs.map(inp=>`
        <div style="display:flex;align-items:center;gap:14px;margin-bottom:12px;flex-wrap:wrap">
          <label style="font-size:13px;font-weight:600;color:var(--text-mid);flex:1;min-width:160px">${inp.label}</label>
          <input type="number" id="calc-input-${inp.id}" placeholder="Saisir valeur" step="any"
            style="flex:1;max-width:340px;padding:11px 14px;border:1.5px solid var(--border);border-radius:9px;font-size:14px;outline:none;font-family:'Inter',sans-serif;min-width:140px"
            onfocus="this.style.borderColor='var(--accent)'" onblur="this.style.borderColor='var(--border)'">
        </div>`).join('')}
      <div style="display:flex;gap:12px;align-items:center;margin-top:8px;flex-wrap:wrap">
        <button onclick="calcAndSave(${idx},'${nextPeriodLabel}')"
          style="padding:11px 24px;background:var(--accent);border:none;border-radius:9px;color:white;font-weight:700;font-size:13.5px;cursor:pointer;font-family:'Plus Jakarta Sans',sans-serif">Calculer &amp; Enregistrer</button>
        <button onclick="clearCalcInputs()"
          style="padding:11px 20px;background:white;border:1.5px solid var(--border);border-radius:9px;color:var(--gray);font-weight:600;font-size:13px;cursor:pointer;font-family:'Inter',sans-serif">× Effacer</button>
      </div>
      <div id="calc-result-new" style="display:none;margin-top:14px;padding:12px 18px;border-radius:10px;font-size:14px;font-weight:700"></div>
    </div>`;
  } else {
    newEntryHtml = `<div style="background:var(--green-bg);border-radius:10px;padding:14px 18px;color:var(--green);font-size:13.5px;font-weight:600;margin-bottom:18px"> Toutes les périodes ont été saisies pour cet indicateur.</div>`;
  }

  // How it works
  const howto = `<div style="border:1.5px solid var(--border);border-radius:12px;padding:18px;font-size:12.5px;color:var(--text-mid);line-height:1.8">
    <div style="font-weight:700;color:var(--navy);margin-bottom:8px">Comment ça marche :</div>
    <div>• Saisissez les données brutes et cliquez <strong>Calculer</strong> pour obtenir la valeur de l'indicateur.</div>
    <div>• Cliquez <strong>Enregistrer dans le tableau de bord</strong> pour ajouter la valeur aux séries historiques.</div>
    <div>• La valeur sera visible dans le Dashboard, la Visualisation et le Rapport de processus.</div>
    <div>• En cas d'erreur de saisie, activez le <strong>Mode correction</strong> pour modifier ou supprimer une valeur existante.</div>
  </div>`;

  area.innerHTML = `
  <div style="background:white;border-radius:16px;padding:28px;box-shadow:var(--shadow)">
    <!-- Header -->
    <div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:22px;gap:16px;flex-wrap:wrap">
      <div>
        <div style="font-family:'Plus Jakarta Sans',sans-serif;font-size:19px;font-weight:800;color:var(--navy)">${k.kpi}</div>
        <div style="font-size:12px;color:var(--gray);margin-top:4px">Processus ${k.proc} · ${freqLabel(k.freq)} · ${
          {MPM1:'Directeur Général',MPM2:'Resp. QSE',MPM3:'Chef Service RH',MPR4:'Directeur Technique',MPS1:'Chef Service Achats',MPS2:'Resp. Logistique',MPS4:'Chef Service SI',MPS5:'Chef Service MG'}[k.proc]||'Responsable'
        }</div>
      </div>
      <div style="display:flex;gap:10px;align-items:center;flex-wrap:wrap">
        <div style="background:var(--green-bg);border:1.5px solid var(--green);border-radius:10px;padding:8px 16px;text-align:center">
          <div style="font-size:10px;font-weight:700;color:var(--green);text-transform:uppercase;letter-spacing:0.5px">Cible</div>
          <div style="font-size:15px;font-weight:900;color:var(--green);font-family:'Plus Jakarta Sans',sans-serif">${cDisp}</div>
        </div>
        <div style="background:var(--yellow-bg);border:1.5px solid var(--yellow);border-radius:10px;padding:8px 16px;text-align:center">
          <div style="font-size:10px;font-weight:700;color:var(--yellow);text-transform:uppercase;letter-spacing:0.5px">Seuil de Tolérance</div>
          <div style="font-size:15px;font-weight:900;color:var(--yellow);font-family:'Plus Jakarta Sans',sans-serif">${sDisp}</div>
        </div>
        <button onclick="toggleCorrMode(${idx})" id="corr-mode-btn-${idx}"
          style="padding:8px 16px;border:1.5px solid var(--border);border-radius:9px;font-size:12.5px;font-weight:600;cursor:pointer;background:${isCorrMode?'var(--red-bg)':'white'};color:${isCorrMode?'var(--red)':'var(--text-mid)'};font-family:'Inter',sans-serif">
           Mode correction${isCorrMode?' (actif)':''}
        </button>
      </div>
    </div>
    <!-- Saved values -->
    ${savedHtml}
    <!-- New entry -->
    ${newEntryHtml}
    <!-- How to -->
    ${howto}
  </div>`;
}

function calcAndSave(idx, periodLabel) {
  const kpis=getUserKPIs().filter(k=>k.inputs.length>0);
  const k=kpis[idx];
  const resEl=document.getElementById('calc-result-new');
  const vals={};
  for(const inp of k.inputs){
    const el=document.getElementById('calc-input-'+inp.id);
    if(!el||el.value===''){
      resEl.textContent='Veuillez remplir tous les champs.';
      resEl.style.cssText='display:block;background:var(--red-bg);color:var(--red);padding:12px 18px;border-radius:10px;font-size:14px;font-weight:700';
      return;
    }
    vals[inp.id]=parseFloat(el.value);
  }
  const{a,b}=vals;
  let result;
  try{result=eval(k.formula);}catch(e){result=NaN;}
  if(isNaN(result)||!isFinite(result)){
    resEl.textContent='Valeur invalide — vérifiez les données saisies.';
    resEl.style.cssText='display:block;background:var(--red-bg);color:var(--red);padding:12px 18px;border-radius:10px;font-size:14px;font-weight:700';
    return;
  }
  const display=(result*k.scale).toFixed(2)+(k.unit?' '+k.unit:'');
  const cls=getValClass(k,result);
  const statusLabels={ok:' Objectif atteint',warn:'En tolérance',bad:' Hors cible'};
  const statusColors={ok:'background:var(--green-bg);color:var(--green)',warn:'background:var(--yellow-bg);color:var(--yellow)',bad:'background:var(--red-bg);color:var(--red)'};
  const cn=cls==='v-green'?'ok':cls==='v-yellow'?'warn':'bad';
  resEl.innerHTML=`<div style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:10px">
    <span>${statusLabels[cn]} — Résultat : <strong>${display}</strong></span>
    <button onclick="saveCalcValue(${idx},'${periodLabel}',${result})"
      style="padding:9px 20px;background:var(--accent);border:none;border-radius:8px;color:white;font-weight:700;font-size:13px;cursor:pointer;font-family:'Plus Jakarta Sans',sans-serif">
       Enregistrer
    </button>
  </div>`;
  resEl.style.cssText=`display:block;${statusColors[cn]};padding:12px 18px;border-radius:10px;font-size:13.5px;font-weight:600;border:1.5px solid currentColor`;
}

function saveCalcValue(idx, periodLabel, result) {
  if (!CALC_SAVED[idx]) CALC_SAVED[idx] = {};
  CALC_SAVED[idx][periodLabel] = result;
  // Also push into KPI_DATA.vals AND excelData for cross-table sync
  const kpis=getUserKPIs().filter(k=>k.inputs.length>0);
  const k=kpis[idx];
  if (!k.vals) k.vals=[];
  const PERIOD_ORDER = k.freq==='M'?MONTHS:k.freq==='T'?['T1','T2','T3','T4']:k.freq==='S'?['S1','S2']:['2026'];
  const pIdx=PERIOD_ORDER.indexOf(periodLabel);
  if(pIdx>=0) {
    k.vals[pIdx]=result;
    // Sync to excelData: store the scaled value (what user would type)
    const globalIdx = KPI_DATA.indexOf(k);
    if (globalIdx >= 0 && pIdx < 12) {
      excelData[globalIdx+'_'+pIdx] = result * k.scale;
    }
  } else k.vals.push(result);
  updateStats();
  // Re-render the form
  renderCalcForm(idx);
  // Refresh rapport and suivi if visible
  if (document.getElementById('page-rapport') && document.getElementById('page-rapport').classList.contains('active')) buildRapport();
  if (document.getElementById('page-suivi') && document.getElementById('page-suivi').classList.contains('active')) buildSuiviActions();
  // Show confirmation toast
  showToast('Valeur enregistrée dans toutes les sections !');
  // Vérifier les alertes KPI
  checkKpiAlerts();
}

function deleteSavedVal(idx, periodLabel) {
  if (!CALC_SAVED[idx]) return;
  delete CALC_SAVED[idx][periodLabel];
  // Also remove from KPI_DATA
  const kpis=getUserKPIs().filter(k=>k.inputs.length>0);
  const k=kpis[idx];
  const PERIOD_ORDER = k.freq==='M'?MONTHS:k.freq==='T'?['T1','T2','T3','T4']:k.freq==='S'?['S1','S2']:['2026'];
  const pIdx=PERIOD_ORDER.indexOf(periodLabel);
  if(pIdx>=0&&k.vals) k.vals.splice(pIdx,1);
  updateStats();
  renderCalcForm(idx);
}

function toggleCorrMode(idx) {
  calcCorrectionMode[idx] = !calcCorrectionMode[idx];
  renderCalcForm(idx);
}

function clearCalcInputs() {
  document.querySelectorAll('[id^="calc-input-"]').forEach(el=>el.value='');
  const res=document.getElementById('calc-result-new');
  if(res) res.style.display='none';
}

function showToast(msg) {
  let t=document.getElementById('calc-toast');
  if(!t){t=document.createElement('div');t.id='calc-toast';t.style.cssText='position:fixed;bottom:28px;right:28px;background:var(--green);color:white;padding:13px 22px;border-radius:12px;font-size:13.5px;font-weight:700;z-index:9999;box-shadow:0 8px 28px rgba(0,0,0,0.18);transition:opacity 0.4s';document.body.appendChild(t);}
  t.textContent=msg;t.style.opacity='1';
  setTimeout(()=>{t.style.opacity='0';},2800);
}

// ==================== VISUALISATION (Power BI style) ====================
let vizDonutChart = null;

function buildViz(freq) {
  const cont = document.getElementById('viz-charts');
  // destroy old charts
  Object.values(vizCharts).forEach(c=>{try{c.destroy();}catch(e){}});
  vizCharts = {};
  if (vizDonutChart) { try { vizDonutChart.destroy(); } catch(e){} vizDonutChart = null; }

  const allKpis = getUserKPIs();
  const kpis = allKpis.filter(k => k.freq === freq && k.vals && k.vals.length > 0);

  // --- Compute stats for ALL user KPIs (not just this freq) ---
  let ok=0, warn=0, bad=0, noData=0;
  allKpis.forEach(k => {
    if (!k.vals || !k.vals.length) { noData++; return; }
    const cls = getValClass(k, k.vals[k.vals.length-1]);
    if (cls==='v-green') ok++;
    else if (cls==='v-yellow') warn++;
    else bad++;
  });
  const total = allKpis.length;

  // --- Summary ribbon ---
  const ribbon = document.getElementById('viz-summary-ribbon');
  if (ribbon) {
    const cards = [
      {icon:'KPI', val:total, lbl:'KPI Totaux', color:'var(--accent)', bg:'#e8f0fb'},
      {icon:'OK', val:ok, lbl:'Objectifs Atteints', color:'var(--green)', bg:'var(--green-bg)'},
      {icon:'!', val:warn, lbl:'En Tolérance', color:'var(--yellow)', bg:'var(--yellow-bg)'},
      {icon:'X', val:bad, lbl:'Hors Cible', color:'var(--red)', bg:'var(--red-bg)'},
    ];
    ribbon.innerHTML = cards.map(c=>`
      <div style="background:white;border-radius:14px;padding:18px 20px;box-shadow:var(--shadow);border-top:3px solid ${c.color};display:flex;align-items:center;gap:14px">
        <div style="width:44px;height:44px;border-radius:10px;background:${c.bg};display:flex;align-items:center;justify-content:center;font-size:12px;font-weight:800;font-family:'Plus Jakarta Sans',sans-serif;color:${c.color};flex-shrink:0">${c.icon}</div>
        <div>
          <div style="font-family:'Plus Jakarta Sans',sans-serif;font-size:30px;font-weight:900;color:${c.color};line-height:1">${c.val}</div>
          <div style="font-size:11.5px;color:var(--gray);margin-top:2px">${c.lbl}</div>
        </div>
      </div>`).join('');
  }

  // --- Donut chart ---
  const donutCtx = document.getElementById('viz-donut-chart');
  if (donutCtx && (ok+warn+bad) > 0) {
    vizDonutChart = new Chart(donutCtx, {
      type: 'doughnut',
      data: {
        labels: ['Atteint', 'Tolérance', 'Hors cible'],
        datasets: [{
          data: [ok, warn, bad],
          backgroundColor: ['rgba(0,182,122,0.85)', 'rgba(245,158,11,0.85)', 'rgba(224,60,49,0.85)'],
          borderColor: ['#00b67a','#f59e0b','#e03c31'],
          borderWidth: 2, hoverOffset: 8
        }]
      },
      options: {
        responsive: true, maintainAspectRatio: false, cutout: '72%',
        plugins: {
          legend: { display: false },
          tooltip: { callbacks: { label: ctx => `${ctx.label}: ${ctx.parsed} KPI (${Math.round(ctx.parsed/(ok+warn+bad)*100)}%)` } }
        }
      }
    });
    const legend = document.getElementById('viz-donut-legend');
    if (legend) {
      const items = [
        {color:'var(--green)', label:'Atteint', val:ok},
        {color:'var(--yellow)', label:'Tolérance', val:warn},
        {color:'var(--red)', label:'Hors cible', val:bad},
      ];
      legend.innerHTML = items.map(it=>`
        <div style="display:flex;align-items:center;justify-content:space-between">
          <span style="display:flex;align-items:center;gap:6px;font-size:12px;color:var(--text-mid)">
            <span style="width:10px;height:10px;border-radius:50%;background:${it.color};display:inline-block"></span>${it.label}
          </span>
          <strong style="font-size:13px;color:var(--navy)">${it.val}</strong>
        </div>`).join('');
    }
  } else if (donutCtx) {
    const legend = document.getElementById('viz-donut-legend');
    if (legend) legend.innerHTML = '<div style="color:var(--gray);font-size:12px;text-align:center">Aucune donnée</div>';
  }

  // --- Progress bars (last value vs target) for current freq ---
  const progEl = document.getElementById('viz-progress-bars');
  if (progEl) {
    if (!kpis.length) {
      progEl.innerHTML = '<div style="color:var(--gray);font-size:13px;text-align:center;padding:20px">Aucun KPI avec données pour cette fréquence.</div>';
    } else {
      progEl.innerHTML = kpis.map(k => {
        const last = k.vals[k.vals.length-1];
        const cls = getValClass(k, last);
        const color = cls==='v-green'?'var(--green)':cls==='v-yellow'?'var(--yellow)':'var(--red)';
        const dispVal = (last * k.scale).toFixed(2) + (k.unit?' '+k.unit:'');
        const cibleDisp = k.cible !== null ? (k.cible * k.scale).toFixed(1) + (k.unit?' '+k.unit:'') : '—';
        // bar width: percent of target achieved (capped at 100)
        const pct = k.cible !== null && k.cible !== 0
          ? Math.min(100, Math.round(Math.abs(last / k.cible) * 100))
          : 50;
        return `<div style="display:flex;align-items:center;gap:10px;padding:8px 0;border-bottom:1px solid var(--border)">
          <div style="width:10px;height:10px;border-radius:50%;background:${color};flex-shrink:0"></div>
          <div style="min-width:160px;max-width:200px;font-size:12px;color:var(--text-mid);overflow:hidden;text-overflow:ellipsis;white-space:nowrap" title="${k.kpi}">${k.kpi}</div>
          <div style="flex:1;height:12px;background:#ffffff;border-radius:6px;overflow:hidden;position:relative">
            <div style="height:100%;width:${pct}%;background:${color};border-radius:6px;transition:width 1s ease"></div>
          </div>
          <div style="min-width:70px;text-align:right;font-size:12px;font-weight:700;color:${color}">${dispVal}</div>
          <div style="min-width:55px;text-align:right;font-size:11px;color:var(--gray)">/ ${cibleDisp}</div>
        </div>`;
      }).join('');
    }
  }

  const countLabel = document.getElementById('viz-count-label');
  if (countLabel) countLabel.textContent = kpis.length + ' KPI avec données';

  if (!kpis.length) { cont.innerHTML = '<div class="no-kpi">Aucun KPI avec données pour cette fréquence.<br>Saisissez des valeurs via le Calculateur ou le Tableau Excel.</div>'; return; }
  cont.innerHTML = '';

  kpis.forEach((k,i) => {
    const card = document.createElement('div');
    card.className = 'chart-card';
    const labels = freq==='M' ? MONTHS_SHORT.slice(0, k.vals.length)
      : freq==='T' ? k.vals.map((_,j)=>'T'+(j+1))
      : freq==='S' ? k.vals.map((_,j)=>'S'+(j+1))
      : k.vals.map((_,j)=>2026+j+'');
    const lastVal = k.vals[k.vals.length-1];
    const lastCls = getValClass(k, lastVal);
    const lastColor = lastCls==='v-green'?'#00b67a':lastCls==='v-yellow'?'#f59e0b':'#e03c31';
    const lastIcon = lastCls==='v-green'?'':lastCls==='v-yellow'?'!':'';
    const lastDisp = (lastVal * k.scale).toFixed(2) + (k.unit?' '+k.unit:'');
    const cibleDisp = k.cible !== null ? (k.cible * k.scale).toFixed(1) + (k.unit?' '+k.unit:'') : '—';
    const seuilDisp = k.seuil !== null ? (k.seuil * k.scale).toFixed(1) + (k.unit?' '+k.unit:'') : '';
    const statusLabel = lastCls==='v-green'?'Atteint':lastCls==='v-yellow'?'Tolérance':'Hors cible';
    const statusBadgeStyle = lastCls==='v-green'?'background:#e8f7f2;color:#0a9e6e;':lastCls==='v-yellow'?'background:#fdf6e3;color:#d68a00;':'background:#fbeaea;color:#c0392b;';

    // Value summary bar
    const valSummary = k.vals.map((v,j)=>{
      const lbl = freq==='M'?MONTHS_SHORT[j]:freq==='T'?'T'+(j+1):freq==='S'?'S'+(j+1):2026+j+'';
      const vc = getValClass(k,v);
      const col = vc==='v-green'?'var(--green)':vc==='v-yellow'?'var(--yellow)':'var(--red)';
      return `<span style="background:#f4f7fb;border-radius:6px;padding:3px 8px;font-size:11px;font-weight:700;color:${col}">${lbl} <strong>${(v*k.scale).toFixed(2)}${k.unit?' '+k.unit:''}</strong></span>`;
    }).join('');

    // Trend
    let trendHtml = '';
    if (k.vals.length >= 2) {
      const diff = k.vals[k.vals.length-1] - k.vals[0];
      const pct = k.vals[0] !== 0 ? Math.abs(diff/k.vals[0]*100).toFixed(1) : '0.0';
      const up = diff > 0; const neutral = diff === 0;
      const good = neutral ? false : (k.higherBetter ? up : !up);
      const arrow = neutral ? '→' : up ? '↑' : '↓';
      const tCls = neutral ? 'trend-neutral' : good ? 'trend-up-good' : 'trend-up-bad';
      trendHtml = `<span class="trend-badge ${tCls}">${arrow} ${pct}%</span>`;
    }

    card.innerHTML = `
      <div class="chart-card-header">
        <div>
          <div style="display:flex;align-items:center;gap:6px;margin-bottom:3px">
            <span style="background:#2e5596;color:#ffffff;border:1px solid #0f203a;padding:2px 8px;border-radius:4px;font-size:10px;font-weight:700;font-family:'Plus Jakarta Sans',sans-serif">${k.proc}</span>
            <span style="background:#ffffff;color:#1d4ed8;padding:2px 8px;border-radius:4px;font-size:10px;font-weight:600">${freqLabel(k.freq)}</span>
          </div>
          <div class="chart-card-title">${k.kpi}</div>
          <div style="font-size:11px;color:var(--gray);margin-top:3px">Cible : ${cibleDisp}${seuilDisp?' · Seuil : '+seuilDisp:''}</div>
        </div>
        <div style="text-align:right;flex-shrink:0;margin-left:10px">
          <div style="font-family:'Plus Jakarta Sans',sans-serif;font-size:24px;font-weight:900;color:${lastColor};line-height:1">${lastDisp}</div>
          <div style="display:flex;gap:6px;margin-top:4px;justify-content:flex-end;align-items:center">
            ${trendHtml}
            <span style="font-size:10px;font-weight:700;padding:2px 8px;border-radius:10px;${statusBadgeStyle}">${statusLabel}</span>
          </div>
        </div>
      </div>
      <div class="chart-canvas-wrap" style="position:relative;height:170px;margin-top:10px"><canvas id="chart-${i}"></canvas></div>
      <div style="display:flex;flex-wrap:wrap;gap:6px;margin-top:10px;padding-top:10px;border-top:1px solid var(--border)">${valSummary}</div>`;
    cont.appendChild(card);

    setTimeout(() => {
      const ctx = document.getElementById('chart-'+i);
      if (!ctx) return;
      const rawVals = k.vals.map(v => parseFloat((v*k.scale).toFixed(4)));
      const colors = k.vals.map(v => {
        const c = getValClass(k, v);
        return c==='v-green'?'rgba(0,182,122,0.82)':c==='v-yellow'?'rgba(245,158,11,0.82)':'rgba(224,60,49,0.82)';
      });
      const borders = colors.map(c => c.replace('0.82','1'));
      const cibleVal = k.cible !== null ? k.cible * k.scale : null;
      const seuilVal = k.seuil !== null ? k.seuil * k.scale : null;

      let datasets = [];
      const vType = currentVizType;

      if (vType === 'bar') {
        datasets.push({
          label: k.kpi, type: 'bar',
          data: rawVals,
          backgroundColor: colors, borderColor: borders,
          borderWidth: 2, borderRadius: 6, borderSkipped: false
        });
      } else if (vType === 'line') {
        datasets.push({
          label: k.kpi, type: 'line',
          data: rawVals,
          borderColor: lastColor, backgroundColor: 'transparent',
          borderWidth: 2.5, pointRadius: 5, pointBackgroundColor: colors,
          pointBorderColor: borders, pointBorderWidth: 2,
          tension: 0.3, fill: false
        });
      } else { // area
        datasets.push({
          label: k.kpi, type: 'line',
          data: rawVals,
          borderColor: lastColor,
          backgroundColor: lastColor.replace(')',',0.12)').replace('rgb','rgba'),
          borderWidth: 2.5, pointRadius: 5, pointBackgroundColor: colors,
          pointBorderColor: borders, pointBorderWidth: 2,
          tension: 0.3, fill: true
        });
      }

      if (cibleVal !== null) datasets.push({
        label: 'Cible', type: 'line',
        data: k.vals.map(() => cibleVal),
        borderColor: 'rgba(34,113,232,0.9)', borderWidth: 2.5, borderDash: [7,4],
        pointRadius: 0, fill: false, tension: 0, order: 0
      });
      if (seuilVal !== null && seuilVal !== cibleVal) datasets.push({
        label: 'Seuil', type: 'line',
        data: k.vals.map(() => seuilVal),
        borderColor: 'rgba(245,158,11,0.7)', borderWidth: 1.5, borderDash: [3,3],
        pointRadius: 0, fill: false, tension: 0, order: 0
      });
      vizCharts['chart-'+i] = new Chart(ctx, {
        type: vType === 'bar' ? 'bar' : 'line',
        data: { labels, datasets },
        options: {
          responsive: true, maintainAspectRatio: false,
          plugins: {
            legend: { display: cibleVal !== null, labels: { font: { size:10, family:'Inter' }, color:'#8da3c5', boxWidth:20, padding:10 } },
            tooltip: {
              callbacks: {
                label: ctx => ctx.dataset.label + ': ' + (isNaN(ctx.parsed.y)?ctx.parsed.y:ctx.parsed.y.toFixed(2)) + (k.unit?' '+k.unit:'')
              }
            }
          },
          scales: {
            x: { grid: { color:'rgba(0,0,0,0.03)' }, ticks: { font:{size:10,family:'Inter'}, color:'#8da3c5' } },
            y: {
              grid: { color:'rgba(0,0,0,0.05)', drawBorder:false },
              ticks: { font:{size:10,family:'Inter'}, color:'#8da3c5' },
              beginAtZero: false
            }
          },
          animation: { duration: 900, easing: 'easeInOutQuart' }
        }
      });
    }, 80 + i * 30);
  });
}

let currentVizType = 'bar'; // bar | line | area

function filterViz(freq,btn) {
  currentVizFreq=freq;
  document.querySelectorAll('#viz-freq-M,#viz-freq-T,#viz-freq-S,#viz-freq-A').forEach(b=>b.classList.remove('active'));
  btn.classList.add('active');
  buildViz(freq);
}

function setVizType(type, btn) {
  currentVizType = type;
  document.querySelectorAll('#viz-type-bar,#viz-type-line,#viz-type-area').forEach(b=>b.classList.remove('active'));
  btn.classList.add('active');
  buildViz(currentVizFreq);
}

// ==================== EXCEL TABLE ====================
const EXCEL_PROCS = ['MPM1','MPM2','MPM3','MPR4','MPS1','MPS2','MPS4','MPS5'];
const PROC_RESP = {MPM1:'Directeur Général',MPM2:'Resp. QSE',MPM3:'Chef Service RH',MPR4:'Directeur Technique',MPS1:'Chef Service Achats',MPS2:'Resp. Logistique',MPS4:'Chef Service SI',MPS5:'Chef Service MG'};

function buildExcelTabs() {
  const tabsEl=document.getElementById('excel-tabs');
  const kpis=getUserKPIs();
  const procs=[...new Set(kpis.map(k=>k.proc))];
  if(!currentExcelProc||!procs.includes(currentExcelProc)) currentExcelProc=procs[0]||null;
  tabsEl.innerHTML=procs.map(p=>`<div class="excel-proc-tab ${p===currentExcelProc?'active':''}" onclick="switchExcelProc('${p}')">${p} — ${procName(p)}</div>`).join('');
  buildExcelTable(currentExcelProc);
  // Sync all existing historical data to excelData on init
  getUserKPIs().forEach(k => {
    const gIdx = KPI_DATA.indexOf(k);
    if (!k.vals) return;
    k._origVals = [...k.vals];
    k.vals.forEach((v,mi) => {
      if (mi < 12 && excelData[gIdx+'_'+mi] === undefined) {
        excelData[gIdx+'_'+mi] = v * k.scale;
      }
    });
  });
}

function switchExcelProc(proc) {
  currentExcelProc=proc;
  document.querySelectorAll('.excel-proc-tab').forEach(t=>{
    t.classList.toggle('active',t.textContent.startsWith(proc));
  });
  buildExcelTable(proc);
}

function buildExcelTable(proc) {
  if(!proc) return;
  const kpis=getUserKPIs().filter(k=>k.proc===proc);
  const thead=document.getElementById('excel-thead');
  const tbody=document.getElementById('excel-tbody');
  // Build header: KPI | Cible | Seuil | Fréq | Mar | Avr | ... | Total/Résultat | Statut
  const numMonths=12;
  thead.innerHTML=`<tr>
    <th style="min-width:180px;text-align:left">KPI</th>
    <th>Cible</th><th>Seuil</th><th>Fréquence</th>
    ${MONTHS_SHORT.map((m,i)=>`<th style="min-width:70px">${m}<br>${i>=10?'2027':'2026'}</th>`).join('')}
    <th style="background:#3a68b5;color:#1f2f53">Résultat<br>Final</th>
    <th style="background:#3a68b5;color:#1f2f53">Statut</th>
  </tr>`;
  tbody.innerHTML=kpis.map((k,ki)=>{
    const globalIdx=KPI_DATA.indexOf(k);
    const cDisp=getKpiLabel(k,'cible');
    const sDisp=getKpiLabel(k,'seuil');
    const cells=Array.from({length:numMonths},(_,mi)=>{
      // Check if this freq makes sense for this month index
      const showInput=k.freq==='M'||(k.freq==='T'&&(mi===2||mi===5||mi===8||mi===11))||(k.freq==='S'&&(mi===5||mi===11))||(k.freq==='A'&&mi===11);
      if(!showInput) return `<td style="background:#f9fafb;color:#ddd">—</td>`;
      const key=`${globalIdx}_${mi}`;
      const storedVal=excelData[key];
      const dispVal=storedVal!==undefined?storedVal:'';
      return `<td><input class="cell-input" type="number" step="any" value="${dispVal}" id="ec_${globalIdx}_${mi}" onchange="updateExcelCell(${globalIdx},${mi},this.value)" placeholder="—"></td>`;
    });
    // Final result
    const allVals=Array.from({length:numMonths},(_,mi)=>{
      const key=`${globalIdx}_${mi}`;
      const v=excelData[key];
      return v!==undefined&&v!==''?parseFloat(v):null;
    }).filter(v=>v!==null);
    let finalVal=null,finalDisp='—',statusHtml='<span class="cell-calc cell-neutral">—</span>';
    if(allVals.length>0){
      finalVal=allVals[allVals.length-1];
      finalDisp=(finalVal*k.scale).toFixed(2)+(k.unit?' '+k.unit:'');
      const cls=getValClass(k,finalVal);
      const cn=cls==='v-green'?'cell-green':cls==='v-yellow'?'cell-yellow':'cell-red';
      const emoji='';
      statusHtml=`<span class="cell-calc ${cn}">${emoji}</span>`;
      finalDisp=`<span class="cell-calc ${cn}">${finalDisp}</span>`;
    }
    return `<tr ${ki>0&&kpis[ki-1]&&kpis[ki-1].proc!==k.proc?'class="group-sep"':''}>
      <td style="text-align:left"><strong style="font-size:12px">${k.kpi}</strong><br><span style="font-size:10.5px;color:var(--gray);font-style:italic">${k.inputs.map(x=>x.label).join(' / ')||'—'}</span></td>
      <td><span class="cible-tag">${cDisp}</span></td>
      <td><span class="seuil-tag">${sDisp}</span></td>
      <td><span class="freq-tag freq-${k.freq}">${freqLabel(k.freq)}</span></td>
      ${cells.join('')}
      <td style="text-align:center">${finalDisp}</td>
      <td style="text-align:center">${statusHtml}</td>
    </tr>`;
  }).join('');
}

function updateExcelCell(kpiIdx, monthIdx, value) {
  const key=`${kpiIdx}_${monthIdx}`;
  if(value===''||value===null){delete excelData[key];}else{excelData[key]=parseFloat(value);}
  // Sync to KPI_DATA.vals so dashboard, visualisation and rapport pick up the value
  syncExcelToKpiData(kpiIdx);
  refreshFinalCells(kpiIdx);
  updateStats();
  // Auto-refresh rapport and visualization if they're currently displayed
  if (document.getElementById('page-rapport') && document.getElementById('page-rapport').classList.contains('active')) {
    buildRapport();
  }
  if (document.getElementById('page-suivi') && document.getElementById('page-suivi').classList.contains('active')) {
    buildSuiviActions();
  }
}

function syncExcelToKpiData(kpiIdx) {
  const k = KPI_DATA[kpiIdx];
  if (!k) return;
  const allVals = Array.from({length:12},(_,mi)=>{
    const v = excelData[kpiIdx+'_'+mi];
    return (v!==undefined&&v!=='') ? parseFloat(v)/k.scale : null;
  });
  // Build a dense vals array preserving existing historical data
  const merged = Array.from({length:12},(_,mi) => {
    const fromExcel = allVals[mi];
    if (fromExcel !== null) return fromExcel;
    return (k._origVals && k._origVals[mi] !== undefined) ? k._origVals[mi] : null;
  }).filter(v=>v!==null);
  if (!k._origVals) k._origVals = [...(k.vals||[])];
  k.vals = merged;
}

function refreshFinalCells(kpiIdx) {
  // Recalculate final result for this KPI
  const k=KPI_DATA[kpiIdx];
  if(!k)return;
  const numMonths=12;
  const allVals=Array.from({length:numMonths},(_,mi)=>{
    const key=`${kpiIdx}_${mi}`;
    const v=excelData[key];
    return v!==undefined&&v!==''?parseFloat(v):null;
  }).filter(v=>v!==null);
  // Update KPI_DATA vals for stats
  if(allVals.length>0){
    k.vals=allVals.map(v=>v/k.scale); // convert back to raw
  }
  // Rebuild table (lightweight)
  buildExcelTable(currentExcelProc);
}

function resetExcel() {
  if(!confirm('Réinitialiser toutes les saisies du tableau ?')) return;
  excelData={};
  // Also reset KPI_DATA vals for excel-entered ones back
  buildExcelTable(currentExcelProc);
}

function exportExcel() {
  /* ── Helpers styles ─────────────────────────────────────────────────── */
  const B_THIN   = {top:{style:'thin',color:{rgb:'2E5596'}},bottom:{style:'thin',color:{rgb:'2E5596'}},left:{style:'thin',color:{rgb:'2E5596'}},right:{style:'thin',color:{rgb:'2E5596'}}};
  const B_HEADER = {top:{style:'medium',color:{rgb:'0F203A'}},bottom:{style:'medium',color:{rgb:'0F203A'}},left:{style:'thin',color:{rgb:'2E5596'}},right:{style:'thin',color:{rgb:'2E5596'}}};

  function sHeader(){
    return {font:{bold:true,color:{rgb:'FFFFFF'},name:'Calibri',sz:11},fill:{fgColor:{rgb:'0F203A'},patternType:'solid'},alignment:{horizontal:'center',vertical:'center',wrapText:true},border:B_HEADER};
  }
  function sTitle(){
    return {font:{bold:true,color:{rgb:'FFFFFF'},name:'Calibri',sz:14},fill:{fgColor:{rgb:'0F203A'},patternType:'solid'},alignment:{horizontal:'center',vertical:'center'},border:{top:{style:'medium',color:{rgb:'0F203A'}},bottom:{style:'medium',color:{rgb:'2E5596'}},left:{style:'medium',color:{rgb:'0F203A'}},right:{style:'medium',color:{rgb:'0F203A'}}}};
  }
  function sCell(o){
    o=o||{};
    return {font:{bold:o.bold||false,color:{rgb:o.color||'1F2F53'},name:'Calibri',sz:10},fill:{fgColor:{rgb:o.bg||'FFFFFF'},patternType:'solid'},alignment:{horizontal:o.align||'left',vertical:'center',wrapText:true},border:B_THIN};
  }
  function statusRGB(cls){
    if(cls==='v-green')  return {bg:'D1FAE5',color:'065F46'};
    if(cls==='v-yellow') return {bg:'FEF3C7',color:'92400E'};
    if(cls==='v-red')    return {bg:'FEE2E2',color:'991B1B'};
    return {bg:'F1F5F9',color:'64748B'};
  }
  function applySheet(ws,wsData,cols,numCols,dataRowsWithCls,procKpis){
    const totalR=wsData.length;
    /* titre */
    const tc=XLSX.utils.encode_cell({r:0,c:0}); if(!ws[tc])ws[tc]={t:'s',v:''}; ws[tc].s=sTitle();
    /* en-têtes */
    for(let c=0;c<numCols;c++){const a=XLSX.utils.encode_cell({r:1,c});if(!ws[a])ws[a]={t:'s',v:''};ws[a].s=sHeader();}
    /* données */
    dataRowsWithCls.forEach((row,ri)=>{
      const cls=row[numCols]; const sr=ri+2; const alt=ri%2===1; const baseBg=alt?'F0F4FB':'FFFFFF';
      for(let c=0;c<numCols;c++){
        const a=XLSX.utils.encode_cell({r:sr,c}); if(!ws[a])ws[a]={t:'s',v:''};
        if(c===0)                    ws[a].s=sCell({bold:true,color:'0F203A',bg:baseBg,align:'left'});
        else if(c===2)               ws[a].s=sCell({bg:'D1FAE5',color:'065F46',align:'center',bold:true});
        else if(c===3)               ws[a].s=sCell({bg:'FEF3C7',color:'92400E',align:'center',bold:true});
        else if(procKpis&&c>=5&&c<=16){
          const mv=row[c];
          if(mv===''||mv===undefined){ws[a].s=sCell({color:'C0C8D8',bg:'F8FAFC',align:'center'});}
          else{const k=procKpis[ri];const mc=getValClass(k,mv/k.scale);const{bg,color}=statusRGB(mc);ws[a].s=sCell({bg,color,align:'center',bold:true});}
        }
        else if(c===numCols-1)       {const{bg,color}=statusRGB(cls);ws[a].s=sCell({bg,color,align:'center',bold:true});}
        else if(c===numCols-2&&procKpis){const{bg,color}=statusRGB(cls);ws[a].s=sCell({bg,color,align:'center',bold:true});}
        else                         ws[a].s=sCell({bg:baseBg,align:c>=4?'center':'left'});
      }
    });
    ws['!cols']=cols;
    ws['!rows']=[{hpt:28},{hpt:24},...dataRowsWithCls.map(()=>({hpt:20}))];
    ws['!merges']=[{s:{r:0,c:0},e:{r:0,c:numCols-1}}];
  }

  /* ── Classeur ─────────────────────────────────────────────────────────── */
  const wb=XLSX.utils.book_new();
  const kpis=getUserKPIs();
  const procs=[...new Set(kpis.map(k=>k.proc))];

  procs.forEach(proc=>{
    const procKpis=kpis.filter(k=>k.proc===proc);
    const header=['KPI','Formule / Calcul','Cible','Seuil','Fréquence',...MONTHS,'Résultat Final','Statut'];
    const numCols=header.length;
    const dataRowsWithCls=procKpis.map(k=>{
      const gi=KPI_DATA.indexOf(k);
      const mv=Array.from({length:12},(_,mi)=>{const v=excelData[`${gi}_${mi}`];return v!==undefined&&v!==''?parseFloat(v):'';});
      const filled=mv.filter(v=>v!=='');
      const fr=filled.length>0?filled[filled.length-1]:null;
      const fs=fr!==null?(fr*k.scale).toFixed(2)+' '+(k.unit||''):'—';
      const cls=fr!==null?getValClass(k,fr):'';
      const st=cls==='v-green'?'✓ Objectif atteint':cls==='v-yellow'?'⚠ En tolérance':cls==='v-red'?'✕ Hors cible':'— Non calculé';
      return [k.kpi,k.inputs.map(x=>x.label).join(' / ')||'—',
        k.cible!==null?(k.cible*k.scale).toFixed(1)+(k.unit?' '+k.unit:''):'—',
        k.seuil!==null?(k.seuil*k.scale).toFixed(1)+(k.unit?' '+k.unit:''):'—',
        freqLabel(k.freq),...mv,fs,st,cls];
    });
    const wsData=[[procName(proc)+' — Tableau de Bord KPI'],header,...dataRowsWithCls.map(r=>r.slice(0,numCols))];
    const ws=XLSX.utils.aoa_to_sheet(wsData);
    const cols=[{wch:36},{wch:38},{wch:12},{wch:12},{wch:13},...Array(12).fill({wch:10}),{wch:16},{wch:20}];
    applySheet(ws,wsData,cols,numCols,dataRowsWithCls,procKpis);
    XLSX.utils.book_append_sheet(wb,ws,proc+' - '+procName(proc).substring(0,14));
  });

  /* ── Feuille SYNTHÈSE ──────────────────────────────────────────────────── */
  const sumHeader=['Processus','KPI','Fréquence','Cible','Seuil','Dernière Valeur','Statut'];
  const sNumCols=sumHeader.length;
  const sumRowsWithCls=kpis.map(k=>{
    const gi=KPI_DATA.indexOf(k);
    const allVals=Array.from({length:12},(_,mi)=>{const v=excelData[`${gi}_${mi}`];return v!==undefined&&v!==''?parseFloat(v):null;}).filter(v=>v!==null);
    const combined=[...k.vals.map(v=>v),...allVals.map(v=>v/k.scale)];
    const lr=combined.length>0?combined[combined.length-1]:null;
    const ls=lr!==null?(lr*k.scale).toFixed(2)+' '+(k.unit||''):'—';
    const cls=lr!==null?getValClass(k,lr):'';
    const st=cls==='v-green'?'✓ Objectif atteint':cls==='v-yellow'?'⚠ En tolérance':cls==='v-red'?'✕ Hors cible':'— Non calculé';
    return [k.proc,k.kpi,freqLabel(k.freq),
      k.cible!==null?(k.cible*k.scale).toFixed(1)+(k.unit?' '+k.unit:''):'—',
      k.seuil!==null?(k.seuil*k.scale).toFixed(1)+(k.unit?' '+k.unit:''):'—',
      ls,st,cls];
  });
  const sumWsData=[['SYNTHÈSE — Ventec Industries KPI'],sumHeader,...sumRowsWithCls.map(r=>r.slice(0,sNumCols))];
  const sumWs=XLSX.utils.aoa_to_sheet(sumWsData);
  const sCols=[{wch:10},{wch:38},{wch:14},{wch:12},{wch:12},{wch:18},{wch:22}];
  /* style spécial synthèse : colonne Processus en bleu */
  const synthRowsStyled=sumRowsWithCls.map(r=>{
    const cls=r[sNumCols]; const [proc,kpi,freq,cible,seuil,val,st]=r;
    return [proc,kpi,freq,cible,seuil,val,st,cls];
  });
  applySheet(sumWs,sumWsData,sCols,sNumCols,synthRowsStyled,null);
  /* surcharger colonne Processus */
  synthRowsStyled.forEach((_,ri)=>{
    const a=XLSX.utils.encode_cell({r:ri+2,c:0});
    if(!sumWs[a])sumWs[a]={t:'s',v:''};
    sumWs[a].s=sCell({bold:true,color:'2E5596',bg:ri%2===1?'F0F4FB':'FFFFFF',align:'center'});
  });
  XLSX.utils.book_append_sheet(wb,sumWs,'SYNTHÈSE');

  XLSX.writeFile(wb,`Ventec_Industriel_KPI_${new Date().toISOString().slice(0,10)}.xlsx`);
}

// ==================== UTILS ====================
function getValClass(k,v) {
  if(k.cible===null||k.seuil===null) return '';
  if(k.higherBetter){
    if(v>=k.cible) return 'v-green';
    if(v>=k.seuil) return 'v-yellow';
    return 'v-red';
  } else {
    if(v<=k.cible) return 'v-green';
    if(v<=k.seuil) return 'v-yellow';
    return 'v-red';
  }
}
function getBarColor(k,v){const cls=getValClass(k,v);return cls==='v-green'?'var(--green)':cls==='v-yellow'?'var(--yellow)':'var(--red)';}
function getBarPct(k,v){
  if(k.cible===null) return 0;
  const ref=k.higherBetter?k.cible:(k.seuil||k.cible);
  if(ref===0) return v===0?100:50;
  const pct=Math.min(100,Math.max(0,(v/ref)*100));
  return k.higherBetter?pct:(100-pct+50);
}

// ==================== RAPPORT DE PROCESSUS ====================
function buildRapport() {
  const proc = document.getElementById('rapport-proc-select').value;
  const periodIdx = parseInt(document.getElementById('rapport-period-select').value);
  const periodLabel = ['Mar 2026','Avr 2026','Mai 2026','Jun 2026','Jul 2026','Aoû 2026','Sep 2026','Oct 2026','Nov 2026','Déc 2026','Jan 2027','Fév 2027'][periodIdx] || MONTHS[periodIdx] || 'Mar 2026';
  const cont = document.getElementById('rapport-content');
  const kpis = getUserKPIs().filter(k => k.proc === proc);
  const today = new Date();
  const dateStr = today.toLocaleDateString('fr-FR', {day:'2-digit',month:'long',year:'numeric'});

  let ok=0, warn=0, bad=0, nd=0;
  kpis.forEach(k => {
    if (!k.vals||!k.vals.length){nd++;return;}
    const last = k.vals[Math.min(periodIdx, k.vals.length-1)];
    if (last === undefined){nd++;return;}
    const cls = getValClass(k, last);
    if(cls==='v-green')ok++; else if(cls==='v-yellow')warn++; else bad++;
  });
  const total = kpis.length;
  const perfPct = total > 0 ? Math.round((ok/total)*100) : 0;

  const badKpis = kpis.filter(k => {
    if(!k.vals||!k.vals.length) return false;
    const v = k.vals[Math.min(periodIdx, k.vals.length-1)];
    return v !== undefined && getValClass(k,v) === 'v-red';
  });
  const warnKpis = kpis.filter(k => {
    if(!k.vals||!k.vals.length) return false;
    const v = k.vals[Math.min(periodIdx, k.vals.length-1)];
    return v !== undefined && getValClass(k,v) === 'v-yellow';
  });

  const responsable = {MPM1:'Directeur Général',MPM2:'Responsable QSE',MPM3:'Chef Service RH',MPR4:'Directeur Technique',MPS1:'Chef Service Achats',MPS2:'Resp. Logistique',MPS4:'Chef Service SI',MPS5:'Chef Service MG'}[proc]||'—';

  // Build KPI rows - all 12 months with excel data merged
  const RMONTHS = ['Mar','Avr','Mai','Jun','Jul','Aoû','Sep','Oct','Nov','Déc','Jan','Fév'];
  const kpiRows = kpis.map(k => {
    const globalIdx = KPI_DATA.indexOf(k);
    // Merge stored excel values with historical vals
    const allMonthVals = Array.from({length:12}, (_,mi) => {
      const exKey = globalIdx+'_'+mi;
      if (excelData[exKey] !== undefined && excelData[exKey] !== '') return parseFloat(excelData[exKey]) / k.scale;
      return k.vals && k.vals[mi] !== undefined ? k.vals[mi] : null;
    });
    const hasAny = allMonthVals.some(v=>v!==null);
    if(!hasAny) {
      const empTds = Array.from({length:12},()=>'<td style="color:#ccc;text-align:center">—</td>').join('');
      return `<tr><td>${k.kpi}</td><td><span class="freq-tag freq-${k.freq}">${freqLabel(k.freq)}</span></td><td>${responsable}</td><td>${getKpiLabel(k,'cible')}</td><td>${getKpiLabel(k,'seuil')}</td>${empTds}<td>—</td><td><span class="stat-badge nd">N/D</span></td><td>—</td></tr>`;
    }
    const valsUpTo = allMonthVals.slice(0, periodIdx+1);
    const validVals = valsUpTo.filter(v=>v!==null);
    const lastRaw = validVals.length>0 ? validVals[validVals.length-1] : null;
    const lastDisp = lastRaw!==null ? (lastRaw*k.scale).toFixed(2)+(k.unit?' '+k.unit:'') : '—';
    const cls = lastRaw!==null ? getValClass(k, lastRaw) : '';
    const badgeCls = cls==='v-green'?'ok':cls==='v-yellow'?'warn':cls==='v-red'?'bad':'nd';
    const badgeTxt = cls==='v-green'?'✓ Atteint':cls==='v-yellow'?'! Tolérance':cls==='v-red'?'✕ Hors cible':'N/D';
    const trend = validVals.length>=2?(validVals[validVals.length-1]>validVals[validVals.length-2]?'↑':'↓'):'—';
    const trendCol = validVals.length>=2?((!k.higherBetter&&validVals[validVals.length-1]>validVals[validVals.length-2])||(k.higherBetter&&validVals[validVals.length-1]<validVals[validVals.length-2])?'color:#dc2626':'color:#059669'):'';
    const mTds = Array.from({length:12},(_,mi)=>{
      const v=allMonthVals[mi];
      if(v===null) return `<td style="background:#f9fafb;color:#d1d5db;text-align:center;font-size:11px">—</td>`;
      const vd=(v*k.scale).toFixed(2)+(k.unit?' '+k.unit:'');
      const vc=getValClass(k,v);
      const bg=vc==='v-green'?'#f0fdf4':vc==='v-yellow'?'#fffbeb':vc==='v-red'?'#fef2f2':'#f8fafc';
      const col=vc==='v-green'?'#059669':vc==='v-yellow'?'#d97706':vc==='v-red'?'#dc2626':'#64748b';
      return `<td style="background:${bg};color:${col};font-weight:700;text-align:center;font-size:11.5px;white-space:nowrap">${vd}</td>`;
    }).join('');
    return `<tr><td>${k.kpi}</td><td><span class="freq-tag freq-${k.freq}">${freqLabel(k.freq)}</span></td><td style="font-size:11px">${responsable}</td><td>${getKpiLabel(k,'cible')}</td><td>${getKpiLabel(k,'seuil')}</td>${mTds}<td><strong style="font-size:13px">${lastDisp}</strong></td><td><span class="stat-badge ${badgeCls}">${badgeTxt}</span></td><td style="${trendCol};font-weight:700">${trend}</td></tr>`;
  }).join('');

  // Action comments for hors-cible — full inline plan d'action forms
  const actionRows = [...badKpis, ...warnKpis].map(k => {
    const v = k.vals[Math.min(periodIdx, k.vals.length-1)];
    const disp = (v*k.scale).toFixed(2)+(k.unit?' '+k.unit:'');
    const cls = getValClass(k,v);
    const key = k.proc+'_'+k.kpi;
    const action = ACTIONS_DATA[key] || {status:'Ouvert',causes:'',plan:'',resp:'QSE de réponse',date:''};
    const statusOpts = ['Ouvert','En cours','Clôturé'];
    return `<div class="action-plan-card ${cls==='v-red'?'bad':'warn'}" id="apc-${encodeURIComponent(key)}">
      <div class="action-plan-header">
        <span class="aph-icon">${cls==='v-red'?'✕':'!'}</span>
        <span class="aph-proc">${k.proc}</span>
        <span class="aph-title">${k.kpi}</span>
        <span class="stat-badge ${cls==='v-red'?'bad':'warn'}" style="flex-shrink:0">${cls==='v-red'?'Hors cible ':'Tolérance !'}</span>
        <span class="aph-val">${disp}</span>
        <button class="apc-toggle-btn" onclick="toggleApc('${encodeURIComponent(key)}',this)" title="Ouvrir / Fermer">
          Éditeur <span class="apc-chevron">▼</span>
        </button>
      </div>
      <div class="apc-collapsible" id="apc-body-${encodeURIComponent(key)}">
        <div class="action-plan-body">
          <div style="margin-bottom:12px">
            <label class="apl-field-label">Cause racine</label>
            <textarea class="apl-textarea" rows="2" placeholder="Décrire la cause..." onchange="saveAction('${key}','causes',this.value)">${action.causes}</textarea>
          </div>
          <div style="margin-bottom:0">
            <label class="apl-field-label">Plan d'action correctif</label>
            <textarea class="apl-textarea" rows="2" placeholder="Décrire les actions..." onchange="saveAction('${key}','plan',this.value)">${action.plan}</textarea>
          </div>
          <div class="apl-two-col">
            <div>
              <label class="apl-field-label" style="margin-top:0">Responsable</label>
              <input class="apl-input" type="text" placeholder="QSE de réponse" value="${action.resp}" onchange="saveAction('${key}','resp',this.value)">
            </div>
            <div>
              <label class="apl-field-label" style="margin-top:0">Limite de date</label>
              <input class="apl-input" type="date" value="${action.date}" onchange="saveAction('${key}','date',this.value)">
            </div>
          </div>
          <div class="apl-status-row">
            ${statusOpts.map(s=>`<button class="apl-ssb ${action.status===s?'active-'+s.toLowerCase().replace(/ /g,'-').replace(/é/g,'e'):''}"
              onclick="setActionStatus('${key}','${s}',this,'apc')">${s==='Ouvert'?'⚠ Ouvert':s==='En cours'?'⏱ En cours':'✓ Clôturé'}</button>`).join('')}
          </div>
        </div>
      </div>
    </div>`;
  }).join('') || '<div style="color:var(--green);font-size:13px;font-weight:600;padding:12px">✓ Aucune action requise pour cette période.</div>';

  cont.innerHTML = `
  <!-- Hero rapport -->
  <div class="rapport-hero">
    <div style="display:flex;align-items:center;gap:14px;margin-bottom:12px">
      <img src="${LOGO_SVG}" alt="Logo" style="width:46px;height:46px;border-radius:8px;background:white;padding:4px;object-fit:contain;flex-shrink:0">
      <div style="font-size:11px;font-weight:600;opacity:0.6;letter-spacing:1.5px;text-transform:uppercase">Filiale Ventec Groupe</div>
    </div>
    <h2 style="font-family:'Plus Jakarta Sans',sans-serif;font-size:22px;font-weight:900;margin-bottom:4px">RAPPORT DE PROCESSUS</h2>
    <div style="font-size:15px;font-weight:700;margin-bottom:8px">${proc} — ${procName(proc)}</div>
    <div style="font-size:12px;opacity:0.6">Période : ${periodLabel} · Généré le ${dateStr} · ${responsable}</div>
    <div class="rapport-progress-bar"></div>
    <div style="position:absolute;top:24px;right:36px;text-align:right">
      <div style="font-family:'Plus Jakarta Sans',sans-serif;font-size:46px;font-weight:900;color:${perfPct>=70?'#4ade80':'#ff6b6b'};line-height:1">${perfPct}%</div>
      <div style="font-size:11px;opacity:0.65">Performance globale</div>
      <div style="display:flex;gap:14px;margin-top:8px;justify-content:flex-end">
        <div style="text-align:center"><div style="font-family:'Plus Jakarta Sans',sans-serif;font-size:18px;font-weight:900;color:#4ade80">${ok}</div><div style="font-size:9px;opacity:0.7">Atteints</div></div>
        <div style="text-align:center"><div style="font-family:'Plus Jakarta Sans',sans-serif;font-size:18px;font-weight:900;color:#f59e0b">${warn}</div><div style="font-size:9px;opacity:0.7">Tolérance</div></div>
        <div style="text-align:center"><div style="font-family:'Plus Jakarta Sans',sans-serif;font-size:18px;font-weight:900;color:#ff6b6b">${bad}</div><div style="font-size:9px;opacity:0.7">Hors cible</div></div>
        <div style="text-align:center"><div style="font-family:'Plus Jakarta Sans',sans-serif;font-size:18px;font-weight:900;color:#94a3b8">${nd}</div><div style="font-size:9px;opacity:0.7">Sans données</div></div>
      </div>
    </div>
  </div>

  <!-- Stats row -->
  <div class="rapport-stats-row">
    <div class="rapport-stat"><div class="rsv" style="color:var(--mid-blue)">${total}</div><div class="rsl">KPI suivis</div></div>
    <div class="rapport-stat"><div class="rsv" style="color:var(--green)">${ok}</div><div class="rsl">Objectifs atteints</div></div>
    <div class="rapport-stat"><div class="rsv" style="color:var(--yellow)">${warn}</div><div class="rsl">En tolérance</div></div>
    <div class="rapport-stat"><div class="rsv" style="color:var(--red)">${bad}</div><div class="rsl">Hors cible</div></div>
  </div>

  <!-- Donut + Hors-cible side by side (like Image 2) -->
  <div style="display:grid;grid-template-columns:1fr 1fr;gap:18px;margin-bottom:22px">
    <!-- Donut chart -->
    <div style="background:white;border-radius:16px;padding:22px;box-shadow:var(--shadow);border:1.5px solid var(--border)">
      <div style="font-family:'Plus Jakarta Sans',sans-serif;font-size:12px;font-weight:700;color:var(--navy);text-transform:uppercase;letter-spacing:1px;margin-bottom:16px">Répartition des statuts</div>
      <div style="display:flex;align-items:center;gap:24px">
        <div style="position:relative;width:160px;height:160px;flex-shrink:0"><canvas id="rapport-donut-${proc}"></canvas></div>
        <div style="flex:1">
          ${[[ok,'Atteint','var(--green)'],[warn,'En tolérance','var(--yellow)'],[bad,'Hors cible','var(--red)'],[nd,'N/D','var(--gray)']].map(([v,lbl,col])=>`
          <div style="display:flex;align-items:center;justify-content:space-between;padding:6px 0;border-bottom:1px solid var(--border)">
            <span style="display:flex;align-items:center;gap:7px;font-size:12.5px;color:var(--text-mid)">
              <span style="width:11px;height:11px;border-radius:50%;background:${col};flex-shrink:0;display:inline-block"></span>${lbl}
            </span>
            <strong style="font-size:14px;color:var(--navy)">${v}</strong>
          </div>`).join('')}
          <div style="margin-top:8px;font-size:11.5px;color:var(--gray)">Total : ${total} indicateurs</div>
        </div>
      </div>
    </div>

    <!-- KPI hors cible list (like Image 2) -->
    <div style="background:white;border-radius:16px;padding:22px;box-shadow:var(--shadow);border:1.5px solid var(--border)">
      <div style="font-family:'Plus Jakarta Sans',sans-serif;font-size:12px;font-weight:700;color:var(--navy);text-transform:uppercase;letter-spacing:1px;margin-bottom:16px">KPI hors cible — actions requises</div>
      ${badKpis.length===0&&warnKpis.length===0
        ? '<div style="color:var(--green);font-size:13px;font-weight:600;padding:20px 0"> Tous les indicateurs sont dans les cibles.</div>'
        : [...badKpis,...warnKpis].map(k=>{
            const v = k.vals[Math.min(periodIdx, k.vals.length-1)];
            const disp = (v*k.scale).toFixed(2)+(k.unit?' '+k.unit:'');
            const cls = getValClass(k,v);
            const col = cls==='v-red'?'var(--red)':'var(--yellow)';
            return `<div style="display:flex;align-items:center;gap:10px;padding:9px 0;border-bottom:1px solid var(--border)">
              <span style="color:${col};font-size:14px;flex-shrink:0">${cls==='v-red'?'':'!'}</span>
              <div style="flex:1;min-width:0">
                <div style="font-size:13px;font-weight:600;color:var(--navy);overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${k.kpi}</div>
                <div style="font-size:10.5px;color:var(--gray)">${proc} · ${responsable}</div>
              </div>
              <div style="font-family:'Plus Jakarta Sans',sans-serif;font-size:16px;font-weight:900;color:${col};flex-shrink:0">${disp}</div>
            </div>`;
          }).join('')}
    </div>
  </div>

  <!-- KPI table -->
  <div style="background:white;border-radius:16px;padding:22px;box-shadow:var(--shadow);border:1.5px solid var(--border);margin-bottom:20px">
    <div style="font-family:'Plus Jakarta Sans',sans-serif;font-size:13px;font-weight:700;color:var(--navy);margin-bottom:14px;text-transform:uppercase;letter-spacing:1px;display:flex;align-items:center;gap:8px">
      📊 Tableau des KPI — ${proc} — ${procName(proc)} — Suivi mensuel (Mar → Fév)
      <span style="background:var(--mid-blue);color:white;padding:2px 10px;border-radius:12px;font-size:11px">${total} KPI</span>
    </div>
    <div style="overflow-x:auto">
      <table class="rapport-kpi-table">
        <thead id="rapport-kpi-thead"><tr>
          <th style="text-align:left;min-width:180px">Indicateur (KPI)</th>
          <th>Fréquence</th><th>Responsable</th>
          <th>Cible</th><th>Seuil</th>
          <th>Mar</th><th>Avr</th><th>Mai</th><th>Jun</th><th>Jul</th><th>Aoû</th><th>Sep</th><th>Oct</th><th>Nov</th><th>Déc</th><th>Jan</th><th>Fév</th>
          <th>Dernière valeur</th><th>Statut</th><th>Évol.</th>
        </tr></thead>
        <tbody>${kpiRows}</tbody>
      </table>
    </div>
  </div>

  <!-- Actions -->
  <div class="rapport-action-section">
    <h4>Plans d'action & Commentaires <span style="font-size:11px;font-weight:500;color:var(--gray);text-transform:none;letter-spacing:0;cursor:pointer" onclick="showPage('suivi')">Cliquez pour saisir</span></h4>
    ${actionRows}
  </div>
  `;

  // Build rapport donut chart
  setTimeout(() => {
    const donutCtx = document.getElementById('rapport-donut-'+proc);
    if (donutCtx && (ok+warn+bad+nd) > 0) {
      new Chart(donutCtx, {
        type:'doughnut',
        data:{
          labels:['Atteint','Tolérance','Hors cible','N/D'],
          datasets:[{
            data:[ok,warn,bad,nd],
            backgroundColor:['rgba(0,182,122,0.85)','rgba(245,158,11,0.85)','rgba(224,60,49,0.85)','rgba(160,174,192,0.5)'],
            borderColor:['#00b67a','#f59e0b','#e03c31','#a0aec0'],
            borderWidth:2, hoverOffset:6
          }]
        },
        options:{
          responsive:true, maintainAspectRatio:false, cutout:'68%',
          plugins:{legend:{display:false},tooltip:{callbacks:{label:ctx=>`${ctx.label}: ${ctx.parsed}`}}}
        }
      });
    }
  }, 80);
}

// ==================== SUIVI DES ACTIONS ====================
// Actions data stored per KPI
const ACTIONS_DATA = {};

function buildSuiviActions() {
  // Build action cards from KPIs that are hors-cible or en tolérance — FILTERED by user process
  const cont = document.getElementById('suivi-actions-list');
  const userKpisAll = getUserKPIs();
  const badKpis = userKpisAll.filter(k => {
    if(!k.vals||!k.vals.length) return false;
    const last = k.vals[k.vals.length-1];
    const cls = getValClass(k, last);
    return cls === 'v-red' || cls === 'v-yellow';
  });

  let total = badKpis.length;
  let ouvert = 0, encours = 0, cloture = 0;
  badKpis.forEach(k => {
    const key = k.proc+'_'+k.kpi;
    const st = (ACTIONS_DATA[key]||{}).status || 'Ouvert';
    if(st==='Ouvert') ouvert++;
    else if(st==='En cours') encours++;
    else cloture++;
  });
  document.getElementById('suivi-total').textContent = total;
  document.getElementById('suivi-ouvert').textContent = ouvert;
  document.getElementById('suivi-encours').textContent = encours;
  document.getElementById('suivi-cloture').textContent = cloture;
  const countLbl = document.getElementById('suivi-count-label');
  if (countLbl) countLbl.textContent = total + ' action'+(total!==1?'s':'');

  const currentFilter = (document.querySelector('#page-suivi .filter-btn.active')||{}).textContent || 'Tous';
  const filtered = currentFilter === 'Tous' ? badKpis : badKpis.filter(k => {
    const key = k.proc+'_'+k.kpi;
    return ((ACTIONS_DATA[key]||{}).status || 'Ouvert') === currentFilter;
  });

  if (!filtered.length) {
    cont.innerHTML = '<div style="text-align:center;color:var(--gray);padding:40px;font-size:14px">Aucune action pour ce filtre.</div>';
    return;
  }

  cont.innerHTML = filtered.map(k => {
    const last = k.vals[k.vals.length-1];
    const cls = getValClass(k, last);
    const disp = (last*k.scale).toFixed(2)+(k.unit?' '+k.unit:'');
    const key = k.proc+'_'+k.kpi;
    const action = ACTIONS_DATA[key] || {status:'Ouvert',causes:'',plan:'',resp:'QSE de réponse',date:''};
    const badgeCls = cls==='v-red'?'bad':'warn';
    const statusOpts = ['Ouvert','En cours','Clôturé'];
    const statusIcons = {Ouvert:'⚠', 'En cours':'⏱', Clôturé:'✓'};
    return `
    <div class="suivi-action-card ${cls==='v-red'?'bad':'warn'}" id="sac-${encodeURIComponent(key)}">
      <div class="suivi-action-header">
        <span class="sah-icon">${cls==='v-red'?'▲':'!'}</span>
        <div class="sah-tags">
          <span style="background:#2e5596;color:#ffffff;border:1px solid #0f203a;padding:2px 9px;border-radius:5px;font-size:10.5px;font-weight:700;font-family:'Plus Jakarta Sans',sans-serif">${k.proc}</span>
          <span style="background:#ffffff;color:#1d4ed8;padding:2px 8px;border-radius:4px;font-size:10px;font-weight:600">${freqLabel(k.freq)}</span>
          <span class="stat-badge ${badgeCls}">${cls==='v-red'?'Hors cible ':'Tolérance !'}</span>
        </div>
        <span class="sah-title">${k.kpi}</span>
        <span class="sah-val">${disp}</span>
        <div class="suivi-status-btns">
          ${statusOpts.map(s=>`<button class="ssb ${action.status===s?'active-'+s.toLowerCase().replace(/ /g,'-').replace(/é/g,'e'):''}"
            onclick="setActionStatus('${key}','${s}',this,'sac')">${s}</button>`).join('')}
        </div>
        <button class="sac-toggle-btn" onclick="toggleSac('${encodeURIComponent(key)}',this)" title="Ouvrir / Fermer">
          Éditeur <span class="sac-chevron">▼</span>
        </button>
      </div>
      <div class="sac-collapsible" id="sac-body-${encodeURIComponent(key)}">
        <div class="suivi-action-body">
          <div class="suivi-field">
            <label>Analyse des causes racines</label>
            <textarea rows="2" placeholder="Décrire la ou les causes racines identifiées…" onchange="saveAction('${key}','causes',this.value)">${action.causes}</textarea>
          </div>
          <div class="suivi-field">
            <label>Plan d'action correctif</label>
            <textarea rows="2" placeholder="Actions correctives à mettre en place…" onchange="saveAction('${key}','plan',this.value)">${action.plan}</textarea>
          </div>
          <div class="suivi-two-col">
            <div class="suivi-field">
              <label>Responsable</label>
              <input type="text" placeholder="QSE de réponse" value="${action.resp}" onchange="saveAction('${key}','resp',this.value)">
            </div>
            <div class="suivi-field">
              <label>Limite de date</label>
              <input type="date" value="${action.date}" onchange="saveAction('${key}','date',this.value)">
            </div>
          </div>
        </div>
      </div>
    </div>`;
  }).join('');
}

function setActionStatus(key, status, btn, prefix) {
  if (!ACTIONS_DATA[key]) ACTIONS_DATA[key] = {status:'Ouvert',causes:'',plan:'',resp:'',date:''};
  ACTIONS_DATA[key].status = status;
  const activeClass = 'active-'+status.toLowerCase().replace(/ /g,'-').replace(/é/g,'e');
  // Update suivi card buttons
  const sacCard = document.getElementById('sac-'+encodeURIComponent(key));
  if (sacCard) {
    sacCard.querySelectorAll('.ssb').forEach(b => {
      b.className = 'ssb';
      const s = b.textContent.trim();
      if (s === status) b.classList.add('active-'+s.toLowerCase().replace(/ /g,'-').replace(/é/g,'e'));
    });
  }
  // Update rapport card buttons
  const apcCard = document.getElementById('apc-'+encodeURIComponent(key));
  if (apcCard) {
    apcCard.querySelectorAll('.apl-ssb').forEach(b => {
      b.className = 'apl-ssb';
      const txt = b.getAttribute('data-status') || b.textContent.replace(/[⚠⏱✓]\\s*/,'').trim();
      const match = status==='Ouvert'&&txt.includes('Ouvert') || status==='En cours'&&txt.includes('cours') || status==='Clôturé'&&txt.includes('lt');
      if (match) b.classList.add(activeClass);
    });
  }
  // sync data in btn siblings
  if (btn) {
    const parentRow = btn.closest('.apl-status-row,.suivi-status-btns');
    if (parentRow) {
      parentRow.querySelectorAll('.apl-ssb,.ssb').forEach(b => {
        const isCls = b.classList.contains('apl-ssb') ? 'apl-ssb' : 'ssb';
        b.className = isCls;
        const rawTxt = b.textContent.replace(/[⚠⏱✓]\\s*/,'').trim();
        if (rawTxt === status || b === btn) b.classList.add(activeClass);
      });
    }
  }
  buildSuiviActions();
}

function saveAction(key, field, value) {
  if (!ACTIONS_DATA[key]) ACTIONS_DATA[key] = {status:'Ouvert',causes:'',plan:'',resp:'',date:''};
  ACTIONS_DATA[key][field] = value;
}

function toggleApc(encodedKey, btn) {
  const body = document.getElementById('apc-body-'+encodedKey);
  if (!body) return;
  const isOpen = body.classList.contains('open');
  body.classList.toggle('open', !isOpen);
  btn.classList.toggle('open', !isOpen);
  btn.querySelector('.apc-chevron').style.transform = isOpen ? '' : 'rotate(180deg)';
  btn.childNodes[0].textContent = isOpen ? ' Éditeur ' : ' Fermer ';
}

function toggleSac(encodedKey, btn) {
  const body = document.getElementById('sac-body-'+encodedKey);
  if (!body) return;
  const isOpen = body.classList.contains('open');
  body.classList.toggle('open', !isOpen);
  btn.classList.toggle('open', !isOpen);
  btn.querySelector('.sac-chevron').style.transform = isOpen ? '' : 'rotate(180deg)';
  btn.childNodes[0].textContent = isOpen ? ' Editeur ' : ' Fermer ';
}

function filterSuivi(filter, btn) {
  document.querySelectorAll('#page-suivi .filter-btn').forEach(b=>b.classList.remove('active'));
  btn.classList.add('active');
  buildSuiviActions();
}

// Override showPage to also trigger rapport/suivi builds
const _origShowPage = showPage;
showPage = function(id) {
  if (!canAccessPage(id)) { _origShowPage(id); return; }
  _origShowPage(id);
  const titles2 = {rapport:'Rapport de Processus', suivi:'Suivi des Actions Correctives'};
  if (titles2[id]) document.getElementById('page-title').textContent = titles2[id];
  if (id === 'rapport') buildRapport();
  if (id === 'suivi') buildSuiviActions();
};

// ==================== NOTIFICATIONS & ALERTES ====================
let NOTIFICATIONS = [];
let shownToasts = new Set();

function checkKpiAlerts() {
  const kpis = getUserKPIs();
  let newAlerts = [];
  kpis.forEach(k => {
    if (!k.vals || !k.vals.length) return;
    if (k.cible === null || k.seuil === null) return;
    const lastVal = k.vals[k.vals.length - 1];
    const status = getValStatus(k, lastVal);
    if (status === 'bad') {
      const key = k.proc + '_' + k.kpi;
      if (!shownToasts.has(key)) {
        const displayed = (lastVal * k.scale).toFixed(k.scale >= 100 ? 1 : 3);
        newAlerts.push({
          key,
          type: 'bad',
          kpi: k.kpi,
          proc: k.proc,
          val: displayed + (k.unit ? ' ' + k.unit : ''),
          seuil: getKpiLabel(k, 'seuil'),
          cible: getKpiLabel(k, 'cible'),
          time: new Date().toLocaleTimeString('fr-FR', {hour:'2-digit',minute:'2-digit'})
        });
      }
    }
  });
  newAlerts.forEach(a => {
    NOTIFICATIONS.unshift(a);
    shownToasts.add(a.key);
    showAlertToast(a);
  });
  updateNotifPanel();
}

function getValStatus(k, v) {
  if (k.cible === null || k.seuil === null) return 'nd';
  if (k.higherBetter) {
    if (v >= k.cible) return 'ok';
    if (v >= k.seuil) return 'warn';
    return 'bad';
  } else {
    if (v <= k.cible) return 'ok';
    if (v <= k.seuil) return 'warn';
    return 'bad';
  }
}

function showAlertToast(alert) {
  const container = document.getElementById('toast-container');
  const id = 'toast-' + Date.now() + Math.random();
  const div = document.createElement('div');
  div.className = 'toast ' + (alert.type === 'warn' ? 'warn' : '');
  div.id = id;
  div.innerHTML = `
    <div class="toast-icon">${alert.type === 'bad' ? '🚨' : '⚠️'}</div>
    <div class="toast-body">
      <strong>Depassement detecte — ${alert.proc}</strong>
      <span>${alert.kpi} : ${alert.val} (Seuil : ${alert.seuil})</span>
    </div>
    <button class="toast-close" onclick="dismissToast('${id}')">×</button>
  `;
  container.appendChild(div);
  setTimeout(() => dismissToast(id), 7000);
}

function dismissToast(id) {
  const el = document.getElementById(id);
  if (!el) return;
  el.style.animation = 'toast-out 0.3s ease forwards';
  setTimeout(() => el.remove(), 300);
}

function updateNotifPanel() {
  const list = document.getElementById('notif-list');
  const badge = document.getElementById('notif-badge');
  const countLabel = document.getElementById('notif-count-label');
  if (!NOTIFICATIONS.length) {
    list.innerHTML = '<div class="notif-empty"><div class="ne-icon">✅</div>Aucune alerte en cours</div>';
    badge.classList.add('hidden');
    if (countLabel) countLabel.textContent = '0 alerte(s)';
    return;
  }
  badge.textContent = NOTIFICATIONS.length;
  badge.classList.remove('hidden');
  if (countLabel) countLabel.textContent = NOTIFICATIONS.length + ' alerte(s)';
  list.innerHTML = NOTIFICATIONS.map(a => `
    <div class="notif-item">
      <div class="notif-icon ${a.type}">${a.type === 'bad' ? '🚨' : '⚠️'}</div>
      <div class="notif-text">
        <strong>${a.kpi}</strong>
        <span>Processus ${a.proc} — Valeur : ${a.val} | Seuil : ${a.seuil} | Cible : ${a.cible}</span>
        <div class="notif-time">${a.time}</div>
      </div>
    </div>
  `).join('');
}

function toggleNotifPanel() {
  const panel = document.getElementById('notif-panel');
  panel.classList.toggle('open');
}

function clearNotifs() {
  NOTIFICATIONS = [];
  shownToasts.clear();
  updateNotifPanel();
  document.getElementById('notif-panel').classList.remove('open');
}

// Fermer le panneau si clic en dehors
document.addEventListener('click', function(e) {
  const panel = document.getElementById('notif-panel');
  const bell = document.querySelector('.notif-bell-wrap');
  if (panel && bell && !panel.contains(e.target) && !bell.contains(e.target)) {
    panel.classList.remove('open');
  }
  const modal = document.getElementById('kpi-modal');
  if (modal && e.target === modal) closeKpiModal();
});

// ==================== GESTION KPI PAR PILOTE ====================
let CUSTOM_KPI_DATA = {}; // stocke les KPIs personnalises par processus

function openKpiModal() {
  if (!currentUser) return;
  const proc = currentUser.proc && currentUser.proc[0];
  if (!proc) return;
  document.getElementById('modal-proc-label').textContent = proc + ' — ' + procName(proc);
  buildKpiManageList();
  // Vider le formulaire
  ['nkpi-name','nkpi-formule','nkpi-cible','nkpi-seuil','nkpi-unit'].forEach(id => {
    const el = document.getElementById(id);
    if (el) el.value = '';
  });
  document.getElementById('kpi-modal').classList.add('open');
}

function closeKpiModal() {
  document.getElementById('kpi-modal').classList.remove('open');
}

function buildKpiManageList() {
  const proc = currentUser && currentUser.proc && currentUser.proc[0];
  if (!proc) return;
  const container = document.getElementById('kpi-manage-list');
  const allKpis = KPI_DATA.filter(k => k.proc === proc);
  const customKpis = (CUSTOM_KPI_DATA[proc] || []);
  const combined = [...allKpis.map(k => ({...k, isCustom: false})), ...customKpis.map(k => ({...k, isCustom: true}))];
  if (!combined.length) {
    container.innerHTML = '<p style="color:#94a3b8;font-size:13px;text-align:center;padding:16px">Aucun KPI pour ce processus.</p>';
    return;
  }
  container.innerHTML = combined.map((k, idx) => `
    <div class="kpi-manage-item ${k.isCustom ? 'custom' : ''}">
      <span class="kpi-m-badge">${k.isCustom ? 'PERSO' : 'DEFAUT'}</span>
      <div style="flex:1">
        <div class="kpi-m-name">${k.kpi}</div>
        <div class="kpi-m-targets">Cible : ${getKpiLabel(k,'cible')} | Seuil : ${getKpiLabel(k,'seuil')} | ${freqLabel(k.freq)}</div>
      </div>
      ${k.isCustom
        ? `<button class="kpi-del-btn" onclick="deleteCustomKpi('${proc}',${idx - allKpis.length})">Supprimer</button>`
        : `<button class="kpi-del-btn" disabled title="KPI systeme — non supprimable">Systeme</button>`}
    </div>
  `).join('');
}

function addCustomKpi() {
  const proc = currentUser && currentUser.proc && currentUser.proc[0];
  if (!proc) return;
  const name = document.getElementById('nkpi-name').value.trim();
  if (!name) { alert('Veuillez saisir le nom du KPI.'); return; }
  const cible = parseFloat(document.getElementById('nkpi-cible').value);
  const seuil = parseFloat(document.getElementById('nkpi-seuil').value);
  const unit = document.getElementById('nkpi-unit').value.trim();
  const freq = document.getElementById('nkpi-freq').value;
  const higherBetter = document.getElementById('nkpi-dir').value === '1';
  const scale = parseFloat(document.getElementById('nkpi-scale').value);
  const formule = document.getElementById('nkpi-formule').value.trim();
  const newKpi = {
    proc, kpi: name, freq,
    cible: isNaN(cible) ? null : cible,
    seuil: isNaN(seuil) ? null : seuil,
    vals: [], unit, scale, higherBetter,
    inputs: [{label: 'Valeur', id: 'a'}],
    formula: 'a',
    formule: formule || name,
    isCustom: true
  };
  if (!CUSTOM_KPI_DATA[proc]) CUSTOM_KPI_DATA[proc] = [];
  CUSTOM_KPI_DATA[proc].push(newKpi);
  // Ajouter aussi dans KPI_DATA pour que tout le reste fonctionne
  KPI_DATA.push(newKpi);
  buildKpiManageList();
  buildApp();
  checkKpiAlerts();
  // Afficher confirmation
  const btn = document.querySelector('.kpi-add-btn');
  const orig = btn.textContent;
  btn.textContent = 'KPI ajoute !';
  btn.style.background = '#059669';
  setTimeout(() => { btn.textContent = orig; btn.style.background = ''; }, 2000);
  // Vider le formulaire
  ['nkpi-name','nkpi-formule','nkpi-cible','nkpi-seuil','nkpi-unit'].forEach(id => {
    const el = document.getElementById(id);
    if (el) el.value = '';
  });
}

function deleteCustomKpi(proc, customIdx) {
  if (!CUSTOM_KPI_DATA[proc] || customIdx < 0) return;
  const kpiToDelete = CUSTOM_KPI_DATA[proc][customIdx];
  if (!confirm('Supprimer le KPI "' + kpiToDelete.kpi + '" ?')) return;
  // Retirer de KPI_DATA
  const globalIdx = KPI_DATA.findIndex(k => k.isCustom && k.proc === proc && k.kpi === kpiToDelete.kpi);
  if (globalIdx !== -1) KPI_DATA.splice(globalIdx, 1);
  CUSTOM_KPI_DATA[proc].splice(customIdx, 1);
  buildKpiManageList();
  buildApp();
  checkKpiAlerts();
}

</script>
</body>
</html>
"""

# Render the original HTML/CSS/JS inside Streamlit.
# Height is intentionally large so the full dashboard remains usable.
components.html(HTML_CODE, height=5200, scrolling=True)
