# Ventec Industries Streamlit Dashboard

This Streamlit app embeds the original HTML dashboard to preserve the same layout, colors, JavaScript functionalities, and visual style.

## Run locally

```bash
pip install -r requirements.txt
streamlit run app.py
```

## GitHub / Streamlit Cloud

1. Create a GitHub repository.
2. Upload `app.py` and `requirements.txt`.
3. Go to Streamlit Community Cloud.
4. Select the repository.
5. Set the main file path to `app.py`.
6. Deploy.
